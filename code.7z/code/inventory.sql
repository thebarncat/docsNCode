select ServerName, OS, OSLevel, SerialNumber FROM Host where OS is not null;
select concat(ServerName,".",Domain) as hostname from Host where Active = 1;

select Servername,Domain,OS,OSLevel from Host where Active = 1 order by OS asc;

select OS, count(*) as total from Host where Active = 1 group by OS;

select IFNULL(OS,"Total"), count(*) as count_os from Host where Active = 1 group by OS WITH ROLLUP;

select Name,Frame.SerialNumber, Location, Rack, status FROM Frame LEFT OUTER JOIN Host on 
Frame.SerialNumber=Host.SerialNumber where ServerName not like "%sn%" order by Name;

SELECT ServerName,Frame.Name,Host.SerialNumber FROM Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber order by ServerName;

SELECT ServerName,Active,Host.Cores,Host.Mode,ClockSpeed,Host.Memory,
Frame.Name,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,SANSpace,Description,Rack,Virtual,
Status,Note FROM Host LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber where Active =1
order by ServerName;
/* INNER Join */
select Frame.Name, Host.ServerName from Frame,Host where Frame.SerialNumber = Host.SerialNumber;
select Frame.Name, Host.ServerName from Frame INNER JOIN Host ON Frame.SerialNumber = Host.SerialNumber;

SELECT ServerName,Active,Host.Cores,Host.Mode,ClockSpeed,Host.Memory,
Frame.Name,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,SANSpace,Description,Rack,Virtual,
Status,Note FROM Host LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber
where ServerName = "axdedora1";

/* UPDATE Join! */
update Host,Frame set Host.Virtual = 1 where (Frame.SerialNumber = Host.SerialNumber)
  and Make = "VMware";

update Frame,Host set Name = "YY" where (Frame.SerialNumber = Host.SerialNumber)
   and Host.Servername = "lxdepbb1" and Make = "VMware";

select Name,Domain,ServerName,Frame.SerialNumber, Location from Frame,Host where
   (Frame.SerialNumber = Host.SerialNumber) and Make = "VMware";

update Frame,Host set Location = "WA" where (Frame.SerialNumber = Host.SerialNumber)
   and Host.Domain IN ("sbprod.com", "sharebuilder.com");

update Frame,Host set Location = "DE" where (Frame.SerialNumber = Host.SerialNumber)
   and Host.Domain = "ingdedev.com";

select distinct Make from Frame;
update Frame set Make = "IBM" where Name IN ("cpaixrep001", "cpaixdblp001", "cpaixdblp003");
update Frame set Make = replace(make,"9117","IBM") where Make like "IBM%";

select Name,Make,ServerName from Frame, Host where
   (Frame.SerialNumber = Host.SerialNumber) and Make = "Dell";

update Frame, Host set Name = "B80-103C9CF" where (Frame.SerialNumber = Host.SerialNumber)
  and ServerName = "sbaix3";

/* get all hosts on frame x */
SELECT ServerName,Name,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame, Host where Frame.SerialNumber=Host.SerialNumber and Name = "DE550E";

SELECT Name,Make,Model,Cores,ClockSpeed,Memory,Rack,SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame  WHERE Name = "DE550F";

select * from Frame where Status in(0,2) order by Name;

SELECT ServerName,Name,Status,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Note
FROM Frame, Host where Frame.SerialNumber=Host.SerialNumber and Status in(0,2);

SELECT ServerName,Name,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame, Host where (Frame.SerialNumber=Host.SerialNumber) and Name = "WA550A";

SELECT ServerName,Name,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame LEFT OUTER JOIN Host on Frame.SerialNumber=Host.SerialNumber where Name = "WA550A";

SELECT ServerName,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,Description FROM Host
LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber where Active = 1 and
Domain IN("sharebuilder.com","sbprod.com","brqa1.ds") order by Domain,OS asc;

select ServerName,Cores,Memory,SANSpace from Host where (Cores = 0 or Memory = 0 or SANSpace = 0)
and OS = "Linux" and (Active = 1);

select ServerName from Host where (Cores = 0 or Memory = 0) and OS = "Linux" and (Active = 1);

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber
where (Host.Cores = 0 or Host.Memory = 0) and OS = "Linux" and (Active = 1);

insert into Frame (Name,Make,Model,SerialNumber) values ("GX520-GQM35BX","Dell","OptiPlex GX520","GQM35BX");

update Frame set Memory = 81920, Cores = "8.00" where Name = "DE570C";
update Host set Memory = 3920, Cores = "2.00"  where ServerName = "bprdeaxnim01";

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber
where (Host.Cores = 0 or Host.Memory = 0) and (Active = 1);

select Name,Make,Model from Frame where make like "IBM%";

update Frame set Memory = 64000, AvailMem = 47616, Cores = "8.00" where Name = "WA550E";
update Host set Memory = 27648, Cores = 4 where ServerName = "rq1mnaxperf01";

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where (Host.Cores = 0 or Host.Memory = 0)
and (Host.Active = 1) and ServerName not like "%vio%";

update Frame set Cores = "2.00", Memory = 32144 where Name = "DE505A";

/* dates: */
insert into Host (ServerName,Domain,BuildDate)
  values ("foo","bar", curdate() );

update Host set BuildDate = curdate() where ServerName = "bqamnlxsfg01";
select ServerName,Domain,BuildDate from Host where ServerName = "bprdelxstail06";

/* Frame Status Update: 0=intactive 1=active */
select ServerName,Frame.Name, Rack from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where ServerName = "lupus";

update Frame set Status = 0 where Name = "DE550D";

/* DELETE VMs: */
delete from Host where ServerName = "axmnrdw1";

update Frame set Status = 0 where Name = "B80-104208F";
update Frame set Note = "former axmnpnim, not in use" where Name = "B80-104208F";
/* END */

update Frame set Status = 0 where Name = "1950-3P3Q0G1";
update Frame set Name = "MN550-10F76C1" where Name = "SIQ01";

/* all active servers for push outs */
select ServerName,OS from Host where Active=1 and ServerName not like "%vio%"
 and Domain IN ("ingdirect.com","ingdedev.com","ingqa.com");

select ServerName,BuildDate from Host where BuildDate > DATE_SUB(NOW(),INTERVAL 3 MONTH)
 order by BuildDate Desc;

select ServerName,BuildDate,OS,Domain,Description from Host where BuildDate < curdate()
   order by BuildDate Desc LIMIT 10;

/* all active Linux servers for push outs */
select ServerName from Host where Active=1 and OS = "Linux"
 and Domain IN ("ingdirect.com","ingdedev.com","ingqa.com");
 
 /* get physical servers in prd */
select ServerName from Host where Active=1 and OS = "Linux" and Domain = "ingdirect.com"
    and SerialNumber not like "VM%" and (ServerName not like "%sn%");
    
select ServerName,Cores,Memory,SANSpace from Host where (Cores = 0 or Memory = 0 or SANSpace = 0)
and OS = "Linux" and (Active = 1);

select Servername from Host where VM = 1;
select count(*) as col1 from Host where ServerName like "%sn%";
select count(*) as col2 from Host where Active =1 and VM = 1;

select Name,Model,Status from Frame where Status in (0,2);

select * from Frame where SerialNumber like "%CB%";
update Frame set Note = "Japan junk in lab room" where Name = "D20-061C46B";
update Frame set Location = "MN"  where Name = "WA550A";
/* 06-CBEEG */

insert into Frame (Name,Make,Model,SerialNumber,Location,Rack) values
 ("MN-D20xx","IBM","7311-D20","100F17C","MN","SB-QA-RROW");

select distinct Domain from Host;

/* get new domains servers */
select count(*) from Host where Domain in ("main.corp.int", "main.corp.qaint", "main.corp.devqa");
 
/* get ENV by OS*/ 
select  OS, count(Domain) as PROD, Virtual from  Host where Domain
   in ( "ingdirect.com", "main.corp.int") and Active = 1 group by OS having Virtual =1;

/* ALTER TABLE */
alter table Host MODIFY VM int(1) DEFAULT 0;
alter table hosts change column OS OS_Level VARCHAR(25) not null;

/* this counts the virtual as subtotal and gives the overall count as total */
select count( if(Virtual=1,1,NULL) ) AS vcount, count(*) as total from Host where Active=1
  and  domain in ( "ingdirect.com", "main.corp.int")  and OS = "Linux";

select ServerName, VM, Virtual from Host where Active = 1 
 and ( VM =1 and Virtual = 0);

select ServerName, Domain from Host where Active =1 and VM=1 and OS = "Linux";
select count(*) from Host where Active =1 and Virtual=1 and OS = "Linux";

select count(*) from Host where Active =1  and OS = "Linux" and Virtual = 1 and 
    Domain IN("ingdirect.com","ingqa.com","ingdedev.com","main.corp.int","main.corp.devqa","main.corp.qaint");
  
/* check for mismatch between virtual and VM linux */
select Servername from Host  where Virtual =1 and VM is null and OS = "Linux" and Active =1;

select count(*) from Host where Active =1 and VM = 1
    and 
Domain IN("ingdirect.com","ingqa.com","ingdedev.com","main.corp.int","main.corp.devqa","main.corp.qaint");

update Host set VM=1, Virtual = 1, OS = "Linux" where ServerName = "rprmnlxmsgq01"; 

select Servername, OS from Host  where OS != "AIX" and Active =1;
select ServerName,Domain from Host where Active = 1 and
 (OS != "AIX" and ServerName not like "%sn%");

select distinct Domain from Host;
select * from Host where Domain = "";

alter table Host ADD CONSTRAINT chk_domain CHECK ( Domain IN ("ingqa.com", "ingdirect.com", "ingdedev.com", 
"sharebuilder.com", "sbprod.com", "main.corp.qaint", "main.corp.int", "brqa1.ds", "main.corp.devqa" ) );

select * from information_schema.table_constraints where table_schema = schema()
    and table_name = 'Host';

SHOW TABLE STATUS FROM ServerInventory;

select ServerName,Frame.Name,Frame.Sockets from Host LEFT OUTER JOIN Frame
    on Host.SerialNumber=Frame.SerialNumber where Host.OS = "Linux" and Host.Active = 1
	and (Host.VM is null or Host.VM = 0);

select ServerName, VM from Host where OS = "Linux" and Active = 1 and VM is null or VM = 0;

select * from Host where ServerName = "bprmnaxvio01";

/* ADD Frame IBM */
insert into Frame (Name, Make, Model, Rack, Location, SerialNumber, Status) 
 values ("DE740B-10BFD9P", "IBM", "8205-E6B", "B7", "DE", "10BFD9P", 1);

insert into Host (ServerName, Domain, Virtual, OS, OSLevel, IPAddress, SerialNumber, Active)
  values ( "bdvdeaxvio01", "main.corp.devqa", 1, "AIX", "6100-07", "172.30.3.39", "065D97R", 1);

update Frame set Sockets = 2 where Name = "DE740B-10BFD9P";

/* THIS IS HOW TO GRAB UNIQ FRAME NAMES WHILE GRABBING A HOST ON THE FRAME */
select Frame.Name,ServerName from Frame, Host WHERE Host.SerialNumber=Frame.SerialNumber
 and Frame.Status = 1 and make = "IBM" and ( ServerName not like "%vio%")
GROUP BY Frame.Name;

update Frame set Location = "MN" where Name = "MN740F-10A8E1R";

/* ALL LINUX */
select ServerName, OS, OSLevel, Domain from Host where OS = "Linux" and Active = 1 and 
(ServerName not like "%sn%");

/* RHEL4: */
select ServerName, OS, OSLevel, Domain from Host where OSLevel = "RHEL 4" and Active = 1;

/* DEV and QA */
select ServerName,Domain, IPAddress,Virtual from Host where OS = "Linux" and Active = 1 and 
Domain IN("ingqa.com","ingdedev.com","main.corp.devqa","main.corp.qaint");

SELECT ServerName from Host LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber 
where Frame.Name = "DE550M" and Host.Active = "1";

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where (Frame.ClockSpeed = "") and
 Host.Active = 1 and ServerName not like "%vio%" and OS = "AIX";

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where Frame.Name = "DE550B"
and ServerName not like "%vio%" LIMIT 1;

/* PRD LINUX */
select ServerName,Virtual from Host where OS = "Linux" and Active = 1 and 
Domain IN("ingdirect.com","main.corp.int") and ServerName not like "%sn%";

/* DEV Linux */
select ServerName from Host where OS = "Linux" and Active = 1 and 
Domain IN("ingdedev.com","main.corp.devqa");

/* ALL DEV */
select ServerName,OS from Host where Active = 1 and Domain IN("ingdedev.com","main.corp.devqa");

/* QA Linux */
select ServerName from Host where OS = "Linux" and Active = 1 and 
Domain IN("ingqa.com","main.corp.qaint");

/* PRD */
select ServerName from Host where OS = "Linux" and Active = 1 and ServerName not like "%sn%" and
Domain IN("ingdirect.com","main.corp.int");

/* DMZ */
select ServerName from Host where OS = "Linux" and Active = 1 and (DMZ = 1);

/* SNORT */
select ServerName from Host where OS = "Linux" and Active = 1 and ServerName like "%sn%" and
Domain IN("ingdirect.com","main.corp.int");

/* filter out SB */
select ServerName from Host where Active = 1 and Domain not in ("sharebuilder.com","sbprod.com",
"brqa1.ds")  order by ServerName;

select distinct oslevel from Host;

/* GET RHEL by LEVEL */
select OSLevel, count(*) as total from Host where Active = 1 and OS = "Linux"
 and Domain not in ("sharebuilder.com","sbprod.com","brqa1.ds") group by OSLevel;

/* ALL DIRECT Servers BUT SNORT and VIO */
select ServerName,IPAddress,Domain,OS from Host where Active = 1 and ServerName not like "%sn%"
and (ServerName not like "%vio%") and (Domain NOT IN ("sharebuilder.com","sbprod.com","brqa1.ds") );

/* DMZ servers */
select ServerName,IPAddress,Domain,OS from Host where DMZ = 1;

select Servername, Domain, IPAddress from Host where Active = 1 and IPAddress like "10.159.3%"; 

select ServerName,OS from Host where Active=1 and ServerName not like "%vio%"
 and Domain IN ("ingdirect.com","ingdedev.com","ingqa.com");

select * from Frame where  SerialNumber like "%10FB53C%";

update Host set Active=0 where ServerName like "bqamnlxwrklt0%";





