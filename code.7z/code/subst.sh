#!/bin/sh
# FILE: "/export/home/jk24445/subst.sh"
# LAST MODIFICATION: "Sun, 29 Mar 2020 09:04:56 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
HOST_ENV=`hostname -s`
if [ ${HOST_ENV:3:1} == 'd' ]; then 
        R_USER='sd1tidap001' 
elif [ ${HOST_ENV:3:1} == 'q' ]; then
        R_USER='sq1tidap001'
elif [ ${HOST_ENV:3:1} == 'u' ]; then
        R_USER='sq1tidap001'
else 
         echo "Can't determine host environment"
         exit 1
fi
