#!/usr/bin/perl
###############################################################################
##                                                                           ##
##   usage: ing_ftp.pl [-h host] [-P port] [-u user] [-p pass] [-f from]     ##
##    [-t to] [-T days] [-m mode] [-d level] [-?] method files...            ##
##                                                                           ##
##   Command Line Options                                                    ##
##     -h host     : FTP Server hostname (DEFAULT: $ENV{UTILs_FTP_HOSTNAME})   ##
##     -P port     : FTP Server port     (DEFAULT: $ENV{UTILs_FTP_PORT})       ##
##     -u user     : FTP Server username (DEFAULT: $ENV{UTILs_FTP_USERNAME})   ##
##     -p pass     : FTP Server password (DEFAULT: $ENV{UTILs_FTP_PASSWORD})   ##
##     -f from     : User which error emails appear to be from (DEFAULT:     ##
##   		     commandcenterteam2)                                     ##
##     -t to       : Comma-separated list of email addresses where errors    ##
##                   are sent to                                             ##
##     -T days     : Offset from system date for regex replacements          ##
##     -m mode     : FTP Transfer mode.  You can also provide per-file       ##
##                   transfer modes by prepending the filename with (mode),  ##
##                   where mode is either 'a' or 'i' (ascii or binary)       ##
##     -d level    : Set the debugging level                                 ##
##     -?	   : Display this help message                               ##
##                                                                           ##
##   Command Line Arguments                                                  ##
##     method      : FTP method (PUT or GET)                                 ##
##     files...    : Comma separated list of files to be transferred.        ##
##                   Format is '/orig/path/to/file1=/dest/path/to/file1'.    ##
##                   If no destination path is given, then the orignal       ##
##                   filename minus the path, is used.  This is equivalent   ##
##                   to '/orig/path/to/file1=file1'.  You may also provide   ##
##                   the transfer mode for each file by prepending the       ##
##                   filename with (mode), where mode is either a (ascii)    ##
##                   or i (binary).                                          ##
##                                                                           ##
##   Additional Help                                                         ##
##      When providing the list of filenames to be transferred, you may use  ##
##   special keys which will be replaced at runtime.  Check out              ##
##   UTILs::Util::dateReplace for a list of valid keys.                        ##
##                                                                           ##
###############################################################################
use strict;
use UTILs;
use Data::Dumper;

my $rhOptions = {};

sub main {
  my $sHelpText = &getOptions( options    => [@main::cl_opts],
			       arguments  => [@main::cl_args],
			       additional => [@main::additional_help],
			       opts_ref   => $rhOptions
			     );

  # Set up error emails
  if ( $UTILs::Error::EmailTo = $rhOptions->{'t'} ) {
    $UTILs::Error::SendEmailOnError = 1;
    $UTILs::Error::EmailFrom        = $rhOptions->{'f'};
  }

  # Get ftp method
  my $sMethod=shift @ARGV;

  # Get file list
  my $sFiles=shift @ARGV;

  # Tranfer files and exit
  my $rhFiles = &UTILs::FTP::transferFiles(
			   files  => &dateReplace($sFiles, days => $rhOptions->{'T'}),
			   host   => $rhOptions->{'h'},
			   port   => $rhOptions->{'P'},
			   user   => $rhOptions->{'u'},
			   pass   => $rhOptions->{'p'},
			   type   => $rhOptions->{'m'},
			   method => $sMethod,
			   continue => $rhOptions->{'c'} ? 1 : 0
			  );

  &debug("The following files were transferred:\n  ".join("\n  ",@{$rhFiles->{success}})."\n\n") if @{$rhFiles->{success}};
  &debug("The following files were not transferred:\n  ".join("\n  ",@{$rhFiles->{failure}})."\n") if @{$rhFiles->{failure}};

  return 0;
}

################################################################
#
# Define all valid command line options and arguments here.
#
################################################################
@main::cl_opts = (
		  {
		   opt     => "h",
		   short   => "host",
		   long    => "FTP Server hostname",
		   default => $UTILs::FTP::HOSTNAME
		  },
		  {
		   opt     => "P",
		   short   => "port",
		   long    => "FTP Server port",
		   default => $UTILs::FTP::PORT
		  },
		  {
		   opt     => "u",
		   short   => "user",
		   long    => "FTP Server username",
		   default => $UTILs::FTP::USERNAME
		  },
		  {
		   opt     => "p",
		   short   => "pass",
		   long    => "FTP Server password",
		   default => $UTILs::FTP::PASSWORD
		  },
		  {
		   opt     => "f",
		   short   => "from",
		   long    => "User which error emails appear to be from",
		   default => $UTILs::Error::EmailFrom
		  },
		  {
		   opt     => "t",
		   short   => "to",
		   long    => "Comma-separated list of email addresses where errors are sent to"
		  },
		  {
		   opt     => "T",
		   short   => "days",
		   long    => "Offset from system date for regex replacements"
		  },
		  {
		   opt     => "m",
		   short   => "mode",
		   long    => "FTP Transfer mode.  You can also provide per-file transfer modes by prepending the filename with (mode), where mode is either 'a' or 'i' (ascii or binary)"
		  },
		  {
		   opt     => "c",
		   long    => "Continue transferring even if some files are not transferred successfully"
		  },
		 );

@main::cl_args = (
		  {
		   short  => "method",
		   long   => "FTP method (PUT or GET)"
		  },
		  {
		   short  => "files...",
		   long   => "Comma separated list of files to be transferred.  Format is '/orig/path/to/file1=/dest/path/to/file1'  If no destination path is given, then the orignal filename minus the path, is used.  This is equivalent to '/orig/path/to/file1=file1'.  You may also provide the transfer mode for each file by prepending the filename with (mode), where mode is either a (ascii) or i (binary)."
		  }
		 );

# Set up additional help
@main::additional_help = ("When providing the list of filenames to be transferred, you may use special keys which will be replaced at runtime.  Check out UTILs::Util::dateReplace for a list of valid keys."
			 );
exit &main;
