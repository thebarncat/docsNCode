#!/bin/bash

for i in `cat bad-encase`
	do 
		echo
		echo $i
		echo
		ssh $i "sudo /sbin/service xinetd restart; sudo /etc/init.d/Encase restart"
		#ssh $i "sudo /etc/init.d/Encase restart"
done

