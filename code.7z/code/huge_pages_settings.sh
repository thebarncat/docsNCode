#!/bin/bash

. /etc/init.d/functions

# Checking the user uid.
if [ -z "$EUID" ]
then
	EUID=`id -u`
fi

# Seeing if root is running the script.
if [ "$EUID" = "0" ]
then
	IAMROOT=1
fi

# No hugepage needed for REP or IQ servers.
if [ "X$type2" = "Xrep" -o "X$type2" = "Xiq" ]
then
	NO_HUGE_PAGES=1
else
	NO_HUGE_PAGES=0
fi

# Information message showing whether root is running the script or not.
$SETCOLOR_SUCCESS
[ ! $IAMROOT ] && echo -e "\n*** NOT running as root *** Settings will not take effect ***\n" || echo -e "\nI am running as root\n"
$SETCOLOR_NORMAL

# Function to check the system memory.
check_sys_mem()
{
	SYS_MEM=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}' )
	SYS_MEM=$(echo "$SYS_MEM/1000" | bc )
  
	TOT_MEM_PLUS_SYS=$(($TOT_MEM + 4000))
  
	if [ $TOT_MEM_PLUS_SYS -gt $SYS_MEM ]
	then
    		$SETCOLOR_FAILURE
		echo -e "\n*** NOT setting HUGEPAGES *** \n*** Requested HUGE PAGE value greater or very close to TOTAL SYSTEM allocated memory ***\n\n -
		--- Increase system memory first!! (suggested +4G or $TOT_MEM_PLUS_SYS kb) ---\n"
		$SETCOLOR_NORMAL
    		
		echo ""
    
		$SETCOLOR_SUCCESS
		[ ! $IAMROOT ] && echo -e "\n*** NOT running as root *** Settings will not take effect ***\n" || echo -e "\nI am running as root\n"
		$SETCOLOR_NORMAL
    
		exit 3
	fi
}

# Function to check the hugepage value in grub.
check-hugepages-in-grub()
{
	echo "Updating hugepages defined in current grub.conf kernel boot"
	if  [ $NO_HUGE_PAGES -eq 1 ]
	then
		if [ -f /etc/default/grub ]
                then
                        GRBY_CMD="/sbin/grubby --update-kernel=ALL --args=\"hugepages=1\""
                        [ $IAMROOT ] &&  sed -i "/^GRUB_CMDLINE_LINUX/s/ hugepages=[0-9]*/ hugepages=1/g" /etc/default/grub
                        [ $IAMROOT ] && grub2-mkconfig -o /boot/grub2/grub.cfg
                else
                        GRBY_CMD="/sbin/grubby --update-kernel=ALL --args=\"hugepages=1\""
                fi
	else
		if [ -f /etc/default/grub ]
                then
                        GRBY_CMD="/sbin/grubby --update-kernel=ALL --args=\"hugepages=$nr_hugepages\""
                        [ $IAMROOT ] && sed -i "/^GRUB_CMDLINE_LINUX/s/ hugepages=[0-9]*/ hugepages=$nr_hugepages/g" /etc/default/grub
                        [ $IAMROOT ] && grub2-mkconfig -o /boot/grub2/grub.cfg
                else
                        GRBY_CMD="/sbin/grubby --update-kernel=ALL --args=\"hugepages=$nr_hugepages\""
                fi
	fi
	echo $GRBY_CMD
	[ $IAMROOT ] && $GRBY_CMD
}

# Function to validate sysctl.conf.
check_sysctl_conf() {
	echo " Checking /etc/sysctl.conf ... for $1"
  
	CHANGED=0
	VAR=$1
	VAL=$2
  
	if  [ "X$(grep ^${VAR} /etc/sysctl.conf)" = "X" ]
  	then
    		VAL=$(echo $VAL | sed 's/,/ /g')
    		echo "appending \"${VAR} = ${VAL}\" in /etc/sysctl.conf"
    		[ $IAMROOT ] && echo "${VAR} = ${VAL}" >> /etc/sysctl.conf
    		[ $IAMROOT ] && sysctl -p
    		CHANGED=1
  	else
    		echo "$VAR is in /etc/sysctl.conf"
    		VAL_OLD=$(grep ^${VAR} /etc/sysctl.conf | sed 's/ = /=/g' | cut -d= -f2- | sed 's/ /,/g')
    		echo "Checking $VAR value in /etc/sysctl.conf"
    		if [ "x${VAL}" = "x${VAL_OLD}" ]
    		then
      			echo " $VAR value is correct"
    		else
      			echo " changing $VAL_OLD value to $VAL "
      			VAL=$(echo $VAL | sed 's/,/ /g')
      			CHANGED=1
      			[ $IAMROOT ] && sed -i "s/${VAR}.*/${VAR} = ${VAL}/g" /etc/sysctl.conf
      			[ $IAMROOT ] && sysctl -p
    		fi
  	fi
}

set_hugepages_default_to_50()
{
  	# set hugepages to 50% of allocated system memory:
  	PERCENT=50

  	mem=$(free -g | grep ^Mem:| awk '{print $2}')
  	percent_value=$( echo $mem*$PERCENT/100 | bc )
  
  	echo " $PERCENT percent = $percent_value "
  
  	hp_value=$(cat /proc/meminfo | grep Hugepagesize  | awk '{print $2}')
  
  	percent_value_megs=$( echo $percent_value*1024 | bc )
  
  	nr_hugepages=$( echo $percent_value_megs/2 | bc )
  
  	# be generous plus 50
  	nr_hugepages=$( echo $nr_hugepages+50 | bc )
  
  	echo " vm.nr_hugepages = $nr_hugepages "
  
  	soft_memlock=$(echo $nr_hugepages*2048 | bc)
  	hard_memlock=$soft_memlock
  
  	# In this case 1 huge page is 2 Mb, so the number of huge pages we need will be 471040 Mb / 2 Mb = 235520
  	check_sysctl_conf vm.nr_hugepages $nr_hugepages
  	# check_sysctl_conf vm.hugetlb_shm_group $hugetlb_shm_group
  	set_limits
}

# Function to add if $MEM_FILE exist.
add_all_sgas()
{
	echo "RUNNING ADD SGA...***"
	echo
	TOT_MEM=$(grep -v ^# $MEM_FILE | awk '{print $1}'| xargs| sed 's/ /+/g' | bc)
  
  	echo " Total MEM = $TOT_MEM "
  
  	check_sys_mem
  
  	nr_hugepages=$( echo $TOT_MEM/2 | bc )
  
  	# be generous plus 50
  	nr_hugepages=$( echo $nr_hugepages+50 | bc )
  
  	echo " vm.nr_hugepages = $nr_hugepages "
  
  	soft_memlock=$(echo $nr_hugepages*2048 | bc)
  	hard_memlock=$soft_memlock
  
  	# In this case 1 huge page is 2 Mb, so the number of huge pages we need will be 471040 Mb / 2 Mb = 235520
  	check_sysctl_conf vm.nr_hugepages $nr_hugepages
  	# check_sysctl_conf vm.hugetlb_shm_group $hugetlb_shm_group
  	set_limits
}

# Function to set the soft/hard memlock.
set_limits()
{
	echo "RUNNING SET LIMITS...***"
	echo
	if [ "X$CHANGED" = "X1" ]
	then
    		echo "Setting sybase soft memlock to $soft_memlock "
    		echo "Setting sybase hard memlock to $hard_memlock "
    
		for file in /etc/security/limits.d/*
    		do
      			[ $IAMROOT ] && sed -i "s/sybase soft memlock.*/sybase soft memlock $soft_memlock/" $file
      			[ $IAMROOT ] && sed -i "s/sybase hard memlock.*/sybase hard memlock $hard_memlock/" $file
    		done
    
		grep -q "sybase soft memlock" /etc/security/limits.d/*
		if ! [ $? -eq 0 ] && [ $IAMROOT ]
		then
			touch /etc/security/limits.d/10-sybase.conf
			cat >> /etc/security/limits.d/10-sybase.conf <<-EOF1
				sybase soft memlock $soft_memlock
			EOF1
    		fi
    
		grep -q "sybase hard memlock" /etc/security/limits.d/*
		if ! [ $? -eq 0 ] && [ $IAMROOT ]
		then
      			touch /etc/security/limits.d/10-sybase.conf
			cat >> /etc/security/limits.d/10-sybase.conf <<-EOF1
				sybase hard memlock $hard_memlock
			EOF1
    		fi
  	fi
  
  	check-hugepages-in-grub
}

# Function to set the hugepages.
set_hugepages()
{
	if  [ $NO_HUGE_PAGES -eq 1 ]
	then
    		$SETCOLOR_WARNING
    		echo In a REP server or IQ server hugepages are not being used.
    		$SETCOLOR_NORMAL
    		check_sysctl_conf vm.nr_hugepages 1
    		[ $IAMROOT ] && [ -f /etc/security/limits.d/10-sybase.conf ] && rm -f /etc/security/limits.d/10-sybase.conf
    		for file in /etc/security/limits.d/*
    		do
      			[ $IAMROOT ] && sed -i "/sybase soft memlock.*/d" $file
      			[ $IAMROOT ] && sed -i "/sybase hard memlock.*/d" $file
    		done
    		check-hugepages-in-grub
  	else
    		$SETCOLOR_WARNING
		echo $MEM_FILE does not exist. Defaulting to 50% of system memory.
    		$SETCOLOR_NORMAL
    		set_hugepages_default_to_50
  	fi
}

# Location of the MEM_FILE.
MEM_FILE_D=/export/local/sybase/hugepages
MEM_FILE=$MEM_FILE_D/$(hostname -s).cfg

# Starting the work.
if [ -f $MEM_FILE ]
then
	echo $MEM_FILE exists
	add_all_sgas
else
	set_hugepages
fi

$SETCOLOR_SUCCESS
[ ! $IAMROOT ] && echo -e "\n*** NOT running as root *** Settings will not take effect ***\n" || echo -e "\nI am running as root\n"
$SETCOLOR_NORMAL
