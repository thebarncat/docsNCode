/* program forks and execs for EVERY arg at the command line, creating a
 * proc for each. processes are executed in the same time, instead of linearly
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (int ac, char * av[])
{ 
	if(ac < 3)
	{
		printf("usage : multifork command arg1 arg2 ...n");
		exit(EXIT_FAILURE); 
	}else{
		int i;
		char *command = av[1];
		char  *arg; 
		for(i = 2; i < ac; i++) 
		{
			arg = av[i]; 
			if(!fork()) 
				execl(command, "", arg, NULL); 
		}
		for(i = 2; i < ac; i++)
	    { 
			int status;
			wait(&status); 
		}
		exit(EXIT_SUCCESS); 
	}
}

