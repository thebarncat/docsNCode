
#include <stdio.h>

int main(int argc, char **argv)
{
	int   i;
    char *cmd = *++argv;  

	/*
	for (i = 0; i < argc; i++)      
     	printf("argv[%d]: %s\n", i, argv[i]);
	*/

	*argv = '\0';

	printf("cmd is: %s\n", cmd); 
	printf("current argv is: %s\n", *argv);
	printf("argv[1] is %s\n", argv[1]);
	exit(0);
}

