
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <grp.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <pwd.h>

int main(void) {
	struct passwd   *ptr;
	char *login;
	ptr = getpwent(); 
 	printf ("Gecos: %s\n", ptr->pw_gecos);
	login = getlogin();
	printf("Login: %s\n", login);
}


