/********************************************************************
***  Usage :    asroot <command>                                  ***
***                                                               ***
********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <grp.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>


int main ( int argc, char *argv[] ) 
{
	if (argc < 2) {
        printf("USAGE : asroot <cmd> \n");
        exit(EXIT_FAILURE);
    }
   
 	uid_t  uid;
 	pid_t  pid;
	int    status;
	int    UnixAdmin=0;  /* boolean */
	char *user;
	
	/* get  current user info */
	uid = getuid();
	user = getenv("LOGNAME"); 

   /* skip over prog name(argv[0]) and get cmd and args to pass to exec */
	char *cmd = *++argv;

	/* iterate thru unixadm grp and make sure user is one */
	char *ux_grp = "unixadm";
    struct group *group;
    char **members;

    group = getgrnam(ux_grp);
    if (group == NULL) {
		printf("get groups failed: is there unixadm grp on this host?\n");
		exit(EXIT_FAILURE);
	}

    members = group->gr_mem;
    while (*members) {
         if (strcmp (*members, user ) == 0)  {
            UnixAdmin=1;
         }
        members++;
    }

	/* if user is a unix admin, proceed */
	if (UnixAdmin || uid == 0)
	{
		if ( setuid(0) == -1 && (seteuid(0) == -1) )
			perror("setuid failed");

		if ( (pid = fork()) < 0)
			perror("fork error");
		else if (pid == 0)         /* child */
			execvp(cmd, argv);

		/* parent */
		if ( (pid = waitpid(pid, &status, 0)) < 0)
			perror("waitpid error");

		/* log cmd run as root */
		openlog("asroot", LOG_PID, LOG_AUTH);
		syslog(LOG_ALERT, "User:%s Successfully Ran Command: %s",user,cmd);
		closelog();
	}
	else
	{
		/* Log the attempt and denial to execute "Command" to syslog */
		openlog("asroot", LOG_PID, LOG_AUTH);
		syslog(LOG_ALERT, "User:%s Denied to run Command: %s",user,cmd);
		printf("User:%s Denied to run Command: %s\n",user,cmd);
		closelog();
    }

    exit(0);
}
