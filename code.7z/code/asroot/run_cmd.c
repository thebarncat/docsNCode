#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

int main(void)
{
	pid_t	pid;
	int		status;

	if ( (pid = fork()) < 0)
		perror("fork error");

	else if (pid == 0) {		/* child */
			execlp("ls", "ls", "-l", "-a", NULL); 
			exit; 
	}
	/* parent */
	if ( (pid = waitpid(pid, &status, 0)) < 0)
		perror("waitpid error");
	
	exit(0);
}
