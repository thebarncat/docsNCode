
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

int main(void) {
	int i;
	int max = 8;
	/* char **args; */
	char *args[16];

	args[0] = "ls";
	printf("%s\n", args[0]);
	for (i=1; i<max; i++) {
		args[i] = "xx";
		printf("%s\n", args[i]);
	}
	*args = '\0';
}



