#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	if (argc < 2) {
		printf("USAGE : asroot <cmd> [args..] \n");
	    exit(EXIT_FAILURE);
	}

	int i;
	/* skip over prog name(argv[0]) and get the shell cmd to run */
	char *cmd = *++argv;

	pid_t	pid;
	int		status;

	if ( (pid = fork()) < 0)
		perror("fork error");

	else if (pid == 0) {		/* child */
			execvp(cmd, argv);
	}
	/* parent */
	if ( (pid = waitpid(pid, &status, 0)) < 0)
		perror("waitpid error");

	exit(0);
}
