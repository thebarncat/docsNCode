#!/bin/sh

# Colors
NC='\033[00m'
RED='\033[01;31m'
YELLOW='\033[01;33m'

ps ax | sed "s/^ *//" > /tmp/ps_ax.output  
for x in $(grep Swap /proc/[1-9]*/smaps | grep -v '\W0 kB' | sort -k2 -n | tr -s ' ' | cut -d' ' -f-2 | sort -t' ' -k2 -n | tr -d ' ' | tail -10)
do
        swapusage=$(echo $x | cut -d: -f3)
        pid=$(echo $x | cut -d/ -f3)
        procname=$(cat /tmp/ps_ax.output | grep ^$pid)
        echo "============================"  
        echo "Process   : $procname"  
        echo -e "Swap usage: ${YELLOW}$swapusage kB${NC}"
        echo "============================"
        echo ""
        let sumswapusage+=$swapusage
done
echo -e "Sum of 10 Swap usage: ${RED}$sumswapusage kB${NC}"

for x in $(grep Swap /proc/[1-9]*/smaps | grep -v '\W0 kB' | sort -k2 -n | tr -s ' ' | cut -d' ' -f-2 | sort -t' ' -k2 -n | tr -d ' ')
do
        swapusageall=$(echo $x | cut -d: -f3)
        let sumswapusageall+=$swapusageall
done
sumswapinMB=`echo "scale=2; $sumswapusageall/1024" | bc -l`
echo -e "Sum of ALL Swap usage: ~ $sumswapinMB MB"

rm -f /tmp/ps_ax.output

echo ""
echo -e "If you're not seeing output above ${YELLOW}(**Could be a good thing...might not be swapping.**)${NC}, would you like see ALL the swap usage per pid?"
while true
do
        echo -e "${YELLOW}WARNING: This could produce a lot of output on your screen! (y or n) :${NC}"
        read ANS
        case $ANS in
         y|Y|YES|yes|Yes)
                grep Swap /proc/[1-9]*/smaps | grep -v '\W0 kB' | sort -k2 -n 
                break
         ;;
         n|N|no|NO|No)
                break
         ;;
         *) echo "Please enter only y or n."
        esac
done
