> dmz_output
for i in `cat ./check_dmz.txt`
do 
#   IP=`ssh $i "/sbin/ifconfig eth0 |grep 'inet addr' | awk '{ print $2 }' |cut -f2 -d:"`
IP=`ssh $i "/sbin/ifconfig |grep -B1 "inet addr" |awk '{ if ( $1 == "inet" ) { print $2 } else if ( $2 == "Link" ) { printf "%s:" ,$1 } }' |awk -F: '{ print $1 ": " $3 }' | grep -v lo: | awk '{ print $2 }'"`
#IP=`/usr/bin/dig $i +short`
echo " $i : $IP" >> dmz_output
done
