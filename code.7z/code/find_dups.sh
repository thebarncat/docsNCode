#!/bin/sh
# FILE: "/export/home/jk24445/find_dups.sh"
# LAST MODIFICATION: "Fri, 02 Apr 2021 07:49:16 -0400 (jk24445)"
# (C) 2021 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$

#!/bin/sh 
dirname=.
find $dirname -type f | sed 's_.*/__' | sort|  uniq -d| 
	while read fileName
	do
		find $dirname -type f | grep "$fileName"
	done
