#!/bin/bash
for x in 1 2 3 4 5 6 7 8 9
do
  echo -n "x is ${x}. "
  if [ "$x" -eq "4" ]; then
    # Don't process this loop for "4" any further  ... instead, move on to "5".
    echo
    continue
  fi
  echo "Here now"
  if [ "$x" -eq "7" ]; then
    # Once we get to 7, exit the loop completely.
    break
  fi
done
echo "We have finished the loop now."
echo "As an aside, x is now ${x}."
