select ServerName, OS, OSLevel, SerialNumber FROM Host where OS is not null;
select ServerName, OS, OSLevel, SerialNumber FROM Host where ServerName like '%vio%' and OS = "";
update Host SET OS = "Linux", OSLevel = "RHEL 5" where ServerName = "bprcalxl8sn80";
select concat(ServerName,".",Domain) as hostname from Host where Active = 1;
select Servername,Domain,OS,OSLevel from Host where Active = 1 order by OS asc;
select OS, count(*) as total from Host where Active = 1 group by OS;
select IFNULL(OS,"Total"), count(*) as count from Host where Active = 1 group by OS with rollup;

select Name, Frame.SerialNumber FROM Frame LEFT OUTER JOIN Host on Frame.SerialNumber=Host.SerialNumber
order by Name;

SELECT ServerName,Frame.Name,Host.SerialNumber FROM Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber order by ServerName;

select ServerName, SerialNumber from Host where Servername like "axdepdw%";
update Host set Active = 1 where ServerName = "lxdepsbtlf";
/* DEV SERVERS */
select * from Host where Domain = "ingdedev.com" and Active = 1;

SELECT ServerName,Active,Host.Cores,Host.Mode,ClockSpeed,Host.Memory,
Frame.Name,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,SANSpace,Description,Rack,Virtual,
Status,Note FROM Host LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber where Active =1
order by ServerName;

select Frame.Name, Host.ServerName from Frame,Host where Frame.SerialNumber = Host.SerialNumber;
select Frame.Name, Host.ServerName from Frame INNER JOIN Host ON Frame.SerialNumber = Host.SerialNumber;

SELECT ServerName,Active,Host.Cores,Host.Mode,ClockSpeed,Host.Memory,
Frame.Name,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,SANSpace,Description,Rack,Virtual,
Status,Note FROM Host LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber
where ServerName = "axdedora1";

/* UPDATE Join! */
update Host,Frame set Host.Virtual = 1 where (Frame.SerialNumber = Host.SerialNumber)
  and Make = "VMware";

select Name, SerialNumber, Location, Note from Frame where Make = "VMware";
select ServerName, SerialNumber from Host where OS="Linux" and Virtual = 1;

update Frame,Host set Name = "YY" where (Frame.SerialNumber = Host.SerialNumber)
   and Host.Servername = "lxdepbb1" and Make = "VMware";

select Name,Domain,ServerName,Frame.SerialNumber, Location from Frame,Host where
   (Frame.SerialNumber = Host.SerialNumber) and Make = "VMware";

update Frame,Host set Location = "WA" where (Frame.SerialNumber = Host.SerialNumber)
   and Host.Domain IN ("sbprod.com", "sharebuilder.com");

update Frame,Host set Location = "DE" where (Frame.SerialNumber = Host.SerialNumber)
   and Host.Domain = "ingdedev.com";

select distinct Make from Frame;
update Frame set Make = "IBM" where Name IN ("cpaixrep001", "cpaixdblp001", "cpaixdblp003")
update Frame set Make = replace(make,"9117","IBM") where Make like "IBM%";

select Name,Make,ServerName from Frame, Host where
   (Frame.SerialNumber = Host.SerialNumber) and Make = "Dell";

update Frame, Host set Name = "B80-103C9CF" where (Frame.SerialNumber = Host.SerialNumber)
  and ServerName = "sbaix3";

/* get all hosts on frame x */
SELECT ServerName,Name,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame, Host where Frame.SerialNumber=Host.SerialNumber and Name = "DE550E";

SELECT Name,Make,Model,Cores,ClockSpeed,Memory,Rack,SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame  WHERE Name = "DE550F";

select * from Frame where Status in(0,2) order by Name;

SELECT ServerName,Name,Status,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Note
FROM Frame, Host where Frame.SerialNumber=Host.SerialNumber and Status in(0,2);

update Frame set Status = 1 where Name = "DE505J";

SELECT ServerName,Name,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame, Host where (Frame.SerialNumber=Host.SerialNumber) and Name = "WA550A";

select Name from Frame where status = 1 order by Name;

SELECT ServerName,Name,Make,Model,Frame.Cores,ClockSpeed,Frame.Memory,Rack,
Frame.SerialNumber,AvailCores,AvailMem,Status,Note
FROM Frame LEFT OUTER JOIN Host on Frame.SerialNumber=Host.SerialNumber where Name = "WA550A";

SELECT ServerName,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,Description FROM Host
LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber where Active = 1 and
Domain IN("sharebuilder.com","sbprod.com","brqa1.ds") order by Domain,OS asc;

select ServerName,Cores,Memory,SANSpace from Host where (Cores = 0 or Memory = 0 or SANSpace = 0)
and OS = "Linux" and (Active = 1);

select ServerName from Host where (Cores = 0 or Memory = 0) and OS = "Linux" and (Active = 1);

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber
where (Host.Cores = 0 or Host.Memory = 0) and OS = "Linux" and (Active = 1);

insert into Frame (Name,Make,Model,SerialNumber) values ("GX520-GQM35BX","Dell","OptiPlex GX520","GQM35BX");

update Frame set Memory = 81920, Cores = "8.00" where Name = "DE570C";
update Host set Memory = 3920, Cores = "2.00"  where ServerName = "bprdeaxnim01";

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber
where (Host.Cores = 0 or Host.Memory = 0) and (Active = 1);
select Name,Make,Model from Frame where make like "IBM%";
select distinct Model from Frame;

select ServerName,SerialNumber from Host where  ServerName like "bdrmnlxprs%";
update Host set ServerName = "bdrmnlxprs01" where SerialNumber = "52LC5L1";

update Frame set Memory = 64000, AvailMem = 47616, Cores = "8.00" where Name = "WA550E";
update Host set Memory = 27648, Cores = 4 where ServerName = "rq1mnaxperf01";

select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where (Host.Cores = 0 or Host.Memory = 0)
and (Host.Active = 1) and ServerName not like "%vio%";

update Frame set Cores = "2.00", Memory = 32144 where Name = "DE505A";

/* dates: */
insert into Host (ServerName,Domain,BuildDate)
  values ("foo","bar", curdate() );
delete from Host where ServerName = "foo";

update Host set BuildDate = curdate() where ServerName = "bqamnlxsfg01";
select ServerName,Domain,BuildDate from Host where ServerName = "bprdelxstail06";

select ServerName from Host where Active=1 and OSLevel = "RHEL 3";
/* DELETE VMs: */
/* Frame Status Update: 0=intactive 1=active */
select ServerName,Frame.Name, Rack from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where ServerName = "bprdelxclone01";

delete from Host where ServerName = "bprdelxclone01";
delete from Frame where Name = "VM-E07D1F5556A1";

update Frame set Status = 0 where Name = "2650-34W5P21";
/* END */

update Frame set Status = 0 where Name = "1850-4XXFKB1";
update Frame set Name = "MN550-10F76C1" where Name = "SIQ01";

update Host set Active =1 where ServerName = "lxcaptlf";

/* all active servers for push outs */
select ServerName,OS from Host where Active=1 and ServerName not like "%vio%"
 and Domain IN ("ingdirect.com","ingdedev.com","ingqa.com");

select ServerName,BuildDate from Host where BuildDate > DATE_SUB(NOW(),INTERVAL 3 MONTH)
 order by BuildDate Desc;

select ServerName,BuildDate,OS,Domain,Description from Host where BuildDate < curdate()
   order by BuildDate Desc LIMIT 10;

/* all active Linux servers for push outs */
select ServerName from Host where Active=1 and OS = "Linux"
 and Domain IN ("ingdirect.com","ingdedev.com","ingqa.com");
 
select * from Host where ServerName = "rq1mnlxtlf01";
update Host set IPAddress = "10.155.16.110" where ServerName like "rd1waaxsyb01%";
 
 /* get physical servers in prd */
select ServerName from Host where Active=1 and OS = "Linux" and Domain = "ingdirect.com"
    and SerialNumber not like "VM%" and (ServerName not like "%sn%");
    
select ServerName,Cores,Memory,SANSpace from Host where (Cores = 0 or Memory = 0 or SANSpace = 0)
and OS = "Linux" and (Active = 1);

select Servername from Host where VM = 1;
select count(*) as col1 from Host where ServerName like "%sn%";
select count(*) as col2 from Host where Active =1 and VM = 1;

desc Host;
Alter table Host MODIFY VM int(1) DEFAULT 0;

select Name,Model,Status from Frame where Status in (0,2);

select * from Host where ServerName = "lxdepwk2";
select distinct Virtual from Host;

update Host set Virtual = 1 where VM = 1;

