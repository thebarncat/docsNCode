DELIMITER $$
DROP PROCEDURE IF EXISTS getHosts $$
CREATE PROCEDURE getHosts()
BEGIN 
    DECLARE cnt_total INT;
    DECLARE outstr VARCHAR(30);
    /* SELECT count(*) INTO cnt_total from Host */
    SELECT count(*) INTO cnt_total from Host
    where Active=1 and domain in ( "ingdirect.com", "main.corp.int")  and OS = "Linux";
  
END $$
DELIMITER ;
 
CALL GetHosts();
 
 
