=     #!/usr/bin/perl -w
=     use strict;
=     $|++;
=     
=     use File::Find qw(find finddepth);
=     use File::Copy qw(copy);
=     use File::Compare qw(compare);
=     
=     ## todo:
0=    ##  symlinks (must determine sensible rewrite rules)
1=    ##  hardlinks (maintain dev/ino maps for source and dest)
2=    ##  sparse files?
3=    
4=    ## start config
5=    
6=    my $SRC = ["/home/merlyn/www-src",
7=               sub { # ignore source-management things:
8=                 return 1 if $_[0] =~ /~\z/; # files ending in tilde
9=                 return 1 if $_[1] =~ m{/CVS(\z|/)}; # CVS files
0=                 0;
1=               },
2=              ];
3=    my $DST = ["/home/merlyn/public_html",
4=               sub { # ignore web-management things:
5=                 return 1 if $_[0] eq ".htaccess"; # sacred
6=                 0;
7=               }];
8=    
9=    my $DELETE_EXCLUDED = 1;
0=    my $CHECK_CONTENT = 1;
1=    my $CHECK_ATIME = 0;
2=    
3=    my $TRACE = 1;
4=    
5=    ## end config
6=    
7=    ## delete phase:
8=    walk (1, $DST, $SRC, \&delete_compare, \&delete_action, $DELETE_EXCLUDED);
9=    
0=    ## copy directories/files phase:
1=    walk (0, $SRC, $DST, \&copy_compare, \&copy_action);
2=    
3=    ## clean up meta-stuff phase:
4=    walk (1, $SRC, $DST, \&cleanup_compare, \&cleanup_action);
5=    
6=    exit 0;
7=    
8=    ## subroutines:
9=    
0=    sub walk {
1=      my $find_func = shift(@_) ? \&finddepth : \&find;
2=      my ($from, $from_ignore) = walk_expand(shift);
3=      my ($to, $to_ignore) = walk_expand(shift);
4=      my $compare = shift;
5=      my $action = shift;
6=      my $delete_excluded = shift;
7=    
8=      $find_func->
9=        (sub {
0=           return if $from_ignore and $from_ignore->($_, $File::Find::name);
1=           my $to_name = $to.substr($File::Find::name, length($from));
2=           if (not -e $to_name
3=               or $delete_excluded and $to_ignore->($_, $File::Find::name)
4=               or $compare->($File::Find::name, $to_name)
5=              ) {
6=             $action->($File::Find::name, $to_name);
7=           }
8=         }, $from);
9=    }
0=    
1=    sub walk_expand {
2=      ref($_[0]) ? @{$_[0]} : $_[0];
3=    }
4=    
5=    sub delete_compare {            # compare two existing files for differences
6=      my ($dst, $src) = @_;
7=      my @s = map [stat $_], @_;
8=      return 1 if ($s[0][2] >> 12) <=> ($s[1][2] >> 12); # not the same type
9=      return 0;
0=    }
1=    
2=    sub delete_action {
3=      my ($dst, $src) = @_;
4=      if (unlink $dst) {
5=        warn "rm $dst\n" if $TRACE;
6=      } elsif (rmdir $dst) {
7=        warn "rmdir $dst\n" if $TRACE;
8=      } else {
9=        warn "#ERROR# cannot eliminate $dst\n";
0=      }
1=    }
2=    
3=    sub copy_compare {
4=      my ($src, $dst) = @_;
5=      my @s = map [stat $_], @_;
6=      return 1 if ($s[0][2] >> 12) <=> ($s[1][2] >> 12); # not the same type
7=      if (not -l $src and -f _) {   # plain files both of ya
8=        return 1 if $s[0][9] <=> $s[1][9]; # not same mtime
9=        return 1 if $CHECK_ATIME
00=         and $s[0][8] <=> $s[1][8]; # not same atime
01=       return 1 if $CHECK_CONTENT
02=         and compare $src, $dst;   # not same content
03=     }
04=     0;                            # not different
05=   }
06=   
07=   sub copy_action {
08=     my ($src, $dst) = @_;
09=     if (-l $src) {
10=       warn "#ERROR# cannot symlink from $src to $dst (yet)\n";
11=     } elsif (-f $src) {
12=       if (copy $src, my $new = "$dst.$$.".time) {
13=         warn "cp $src $new\n" if $TRACE;
14=         if (rename $new, $dst) {
15=           warn "mv $new $dst\n" if $TRACE;
16=         } else {
17=           warn "#ERROR# cannot mv $new $dst: $!\n";
18=         }
19=       } else {
20=         warn "#ERROR# cannot cp $src $new: $!\n";
21=       }
22=     } elsif (-d $src) {
23=       if (mkdir $dst, 0777) {
24=         warn "mkdir $dst\n" if $TRACE;
25=       } else {
26=         warn "#ERROR# cannot mkdir $dst: $!\n";
27=       }
28=     } else {
29=       warn "#ERROR# don't know how to copy $src to $dst\n";
30=     }
31=   }
32=   
33=   sub cleanup_compare {
34=     my ($src,$dst) = @_;
35=     my @s = map [(lstat $_)[4,5,8,9], (stat _)[2] & 07777], @_;
36=     return "@{$s[0]}" cmp "@{$s[1]}";
37=   }
38=   
39=   sub cleanup_action {
40=     return if grep -l, @_;
41=     my ($src, $dst) = @_;
42=     my @s = map [lstat $_], @_;
43=     if ((my $oldperm = $s[0][2] & 07777) != ($s[1][2] & 07777)) {
44=       warn "setting perms on $dst\n" if $TRACE;
45=       chmod $oldperm, $dst
46=         or warn "#ERROR# can't update perms on $dst: $!";
47=     }
48=   
49=     if ("$s[0][8] $s[0][9]" ne "$s[1][8] $s[1][9]") {
50=       warn "setting times on $dst\n" if $TRACE;
51=       utime $s[0][8], $s[0][9], $dst
52=         or warn "#ERROR# can't update times on $dst: $!";
53=     }
54=   
55=     if ("$s[0][4] $s[0][5]" ne "$s[1][4] $s[1][5]") {
56=       $< and chown $s[0][4], $s[0][5], $dst
57=         or warn "#ERROR# can't update ownership of $dst: $!";
58=     }
59=   }

