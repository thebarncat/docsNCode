#!/usr/bin/perl -w

# sets CPU, Mem, and SAN stats for newly added hosts to inventory
use DBI;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","")
    or die "Cannot open $DBI::errstr\n";

my %server;
my $OS;

# get hosts/frames that don't stats yet  
my $sql = qq [ select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where Host.OS = "Linux" and (Host.Active = 1)  ];

my $sth = $dbh->prepare($sql) or die "Cannot prepare SQL statements from $DBI::errstr\n";
$sth->execute();
my $array_ref = $sth->fetchall_arrayref();
foreach my $row (@$array_ref) {
    my ($host, $frame) = @$row;
    $server{$host} = $frame;
}

foreach $host ( keys %server) {
	#next if $host =~ /tlf|sn|uxfgl|aix6|lxdepprs|pdaix|perf/;
	next if $host =~ /bprdelxs1sn1|lxdepsbtlf|qpage|lxdepqpg|bprdelxo5sn1/;
	my $ssh = "ssh $host";
	chomp($OS = `$ssh "uname -s"`);
	my $frame = $server{$host};
	print "Updating Host: $host and Frame: $frame..\n";
	my ($cores,$mem,$speed) = getStats($host,$OS);
   	my $sql = qq [ update Frame set Cores = "$cores", Memory = "$mem", ClockSpeed = "$speed" where Name = "$frame" ];
	$frame_row = $dbh->do($sql);
	print "update successful\n" if $frame_row;
}

sub getStats {
	my ($host,$OS) = @_;
    my $ssh = "ssh $host";
	my @info;
	my $cores; my $mem; my $speed;
	if ($OS =~ /linux/i) {
		@info = `$ssh "/bin/grep processor /proc/cpuinfo | wc -l ; /bin/grep MemTotal /proc/meminfo ;
	       /bin/grep MHz /proc/cpuinfo |head -1"`;
		$cores = $info[0];
		chomp($cores);
		$mem = $1 if ($info[1] =~ /(\d+)/);
		$speed = $1 if ($info[2] =~ /(\d+)\..*/);
		return $cores, int($mem/1024), $speed;

	} elsif ($OS =~ /aix/i) {
		 @info = `$ssh "lparstat -i | grep Entitled | grep -v Pool ; sudo /usr/sbin/bootinfo -r ; pmcycles"`;	
		 $cores = $1 if ($info[0] =~ /(\d+\.\d+)/);
		 $cores = 1 if $cores < 1;
		 # mem in MB
		 $mem = $info[1]/1024;
		 $speed = $1 if ($info[2] =~ /(\d+ \w+)/);
	     return $cores, $mem, $speed;	
	}
}

