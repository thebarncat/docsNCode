#!/usr/bin/perl -w

# sets FrameName,SerialNum,Virtual Status, and other Frame info for newly added hosts 

use DBI;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","")
    or die "Cannot open $DBI::errstr\n";

# get hosts that don't have serial 
my $sql = qq [ select ServerName FROM Host where Active = 1 and SerialNumber = "" ];
my $sth = $dbh->prepare($sql) or die "Cannot prepare SQL statements from $DBI::errstr\n";
$sth->execute();
my $array_ref = $sth->fetchall_arrayref();
my @hosts = map {$_->[0]} @$array_ref;


foreach  $host (@hosts) {
	print "Updating $host..\n\n";
	$ssh = "ssh $host";
	my ($sn,$model,$make,$rack,$location);
	chomp($OS = `$ssh "uname -s"`); 
	# boolean flag for VMs
	my $virtual = 0;
	if ($OS =~ /linux/i) {
		chomp($info = `$ssh "sudo /usr/sbin/dmidecode |grep -A5 'System Information'"`);
		if ( $info =~ /VMware/) { 
			$sn = $1 if ($info =~ /UUID:.*-(.*)/);
			$make = "VMware";
			$model = "VMware Virtual Platform";
			$frameName = "VM-$sn";
			$virtual = 1;
		} 
		else {
			$make = "Dell";
            ($type,$num) = ($1,$2) if ($info =~ /Product Name: (\w+)\s*(\w+)/);
            $sn = $1 if ($info =~ /Serial Number: (\w+)/);
            $model = "$type $num";
            $frameName = "$num-$sn";
		}
		
	} elsif ($OS =~ /aix/i) {
	    chomp($info = `$ssh "lsattr -El sys0 -a systemid -a modelname"`);
		#($sn,$model) = ($1,$2) if ($info =~ /IBM,\w{2}(\w{7}).*IBM,.*-(\d{3})/s);
		($sn,$model) = ($1,$2) if ($info =~ /IBM,\w{2}(\w{7}).*IBM,(.*?)\s+/s);
		$make = "IBM";
		$frameName = "$model-$sn";
	}

    my $sql =  qq[ update Host SET SerialNumber = "$sn", Virtual = "$virtual" where ServerName = "$host" ];
	$row = $dbh->do($sql);
	print "$host serial number and virtual status added\n\n" if $row;

    $sql2 = qq [ select Name,SerialNumber from Frame where SerialNumber = "$sn" ];
	($frame) = $dbh->selectrow_array($sql2); 
	unless ($frame) {
		print "No frame found for this host, add it now\n";
		print "Enter Rack: \n";
		chomp($rack = <STDIN>);
		print "Enter Location(DE,MN,WA,CA): \n";
		chomp($location = <STDIN>);
		$rows = $dbh->do("INSERT INTO Frame
          (Name,Make,Model,Rack,SerialNumber,Location) VALUES ('$frameName','$make','$model','$rack','$sn','$location')");
        print "Frame $frameName info inserted\n" if $rows;
	}
		
}


__DATA__
Serial Number: VMware-50 00 01 21 5d 31 0c 45-c9 3f 9a 40 de b4 01 5b
UUID: 50000121-5D31-0C45-C93F-9A40DEB4015B
Serial Number: CS5D5L1
systemid IBM,0210FB53C Hardware system identifier False

