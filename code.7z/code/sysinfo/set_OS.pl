#!/usr/bin/perl 

use DBI;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","")
    or die "Cannot open $DBI::errstr\n";

# get hosts that don't have OS assigned
my $sql = qq [ select ServerName FROM Host where Active = 1 and OS = "" ];
my $sth = $dbh->prepare($sql) or die "Cannot prepare SQL statements from $DBI::errstr\n";
$sth->execute();
my $array_ref = $sth->fetchall_arrayref();
my @hosts = map {$_->[0]} @$array_ref;
#my @hosts = qw ( rprmnaxsyb02 );

foreach  $host (@hosts) {
	$ssh = "ssh $host";
	chomp($OS = `$ssh "uname -s"`); 
	if ($OS =~ /linux/i) {
	    chomp($level = `$ssh "cat /etc/redhat-release"`);
		$level = $1 if ($level  =~ /(\d+?)/);
		$level = "RHEL ". $level;
	} elsif ($OS =~ /aix/i) {
	    chomp($level = `$ssh "oslevel -r"`);
	}
    my $sql =  qq[ update Host SET OS = "$OS", OSLevel = "$level" where ServerName = "$host" ];
	$row = $dbh->do($sql);
	print "$host updated\n" if $row;
}


__DATA__
Red Hat Enterprise Linux Server release 5.2 (Tikanga)
Red Hat Enterprise Linux AS release 4 (Nahant Update 2)
Red Hat Enterprise Linux AS release 3 (Taroon Update 8)
