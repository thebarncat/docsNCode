#!/usr/bin/perl -w

# sets CPU, Mem, and SAN stats for newly added hosts to inventory

use DBI;
use Mail::Sender;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","")
    or die "Cannot open $DBI::errstr\n";

#my $log = '/home/cmsys/update-frame.err';
#open STDERR, ">$log" or die $!;

# get hosts/frames that don't stats yet  
my $sql = qq [ select Name from Frame where Status = 1 and make = "IBM" and Name not like "%D20%" ];

my $sth = $dbh->prepare($sql) or die "Cannot prepare SQL statements from $DBI::errstr\n";
$sth->execute();
my $array_ref = $sth->fetchall_arrayref();
my @frames = map {$_->[0]} @$array_ref;

foreach $frame (@frames) {
	# skip stand alone servers and HMCs in WA we cant get to and skip 505s
	#next if $frame =~ /B80|6C1|H70|55A-105|WA550C|WA550D|DE505F|DE505E/;
	next if $frame =~ /B80|6C1|H70|55A-105|WA550C|WA550D|505/;
	print "Checking Frame: $frame\n";
	my ($tot_cores,$avail_cores,$tot_mem,$avail_mem) = getIBMframeStuff($frame);
	print "CORES: $tot_cores  MEM: $tot_mem ACORES: $avail_cores AMEM:  $avail_mem\n"; 
    my $sql = qq [ update Frame set Cores = $tot_cores, Memory = $tot_mem, AvailCores = $avail_cores, AvailMem = $avail_mem where Name = "$frame" ];
	$frame_row = $dbh->do($sql);
	print "update successful\n" if  $frame_row;
}

sub getIBMframeStuff {
	my $frame = shift;
	my %hmc_hash;
	my $hmc_key; 
	my $target_hmc;
	#my @hmcs = qw( hmdep001 hmdep002 hmdep003 hmmnp001 hmmnp002 pdlinhmc002 rprmnaxhmc01 cplinhmc001 );
	my @hmcs = qw( hmdep001 hmdep002 hmdep003 hmmnp001 hmmnp002 rprmnaxhmc01 cplinhmc001 );
	# build data struct of systems per each hmc
	for my $hmc (@hmcs) {
    	my $ssh = "ssh $hmc";
    	my @systems = `$ssh "lssyscfg -r sys -F name"`;
    	chomp @systems;
    	$hmc_hash{$hmc} = [ @systems ];
	}

	for $key (keys %hmc_hash) {
    	if ( grep {/$frame/}  @{ $hmc_hash{$key} } ) {
			$target_hmc = $key;
    	}
	}
	#return unless $target_hmc;
	unless ($target_hmc) { print "problem with HMC: $key .. skipping ..\n"; return }

	my $ssh = "ssh $target_hmc";
	my $cpu_cmd = "lshwres -r proc --level sys -m $frame -F configurable_sys_proc_units:curr_avail_sys_proc_units";
    my $mem_cmd = "lshwres -r mem --level sys -m $frame -F configurable_sys_mem:curr_avail_sys_mem";
	chomp( my $c = `$ssh $cpu_cmd` );
    my ($tot_cores, $avail_cores) = split( /:/, $c );
    chomp( my $m = `$ssh $mem_cmd` );
    my ($tot_mem, $avail_mem) = split( /:/, $m );

	return($tot_cores,$avail_cores,$tot_mem,$avail_mem);
}
