#!/usr/bin/perl -w

# will correct Linux Fram Names after Ron screws them up

use DBI;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","")
    or die "Cannot open $DBI::errstr\n";

# get Linux hosts  (non VMs)
my $sql = qq [ select ServerName FROM Host where OS="Linux" and Virtual = 0 ];
my $sth = $dbh->prepare($sql) or die "Cannot prepare SQL statements from $DBI::errstr\n";
$sth->execute();
my $array_ref = $sth->fetchall_arrayref();
my @hosts = map {$_->[0]} @$array_ref;

foreach $host (@hosts) {
	next if $host eq "rq1mnlxtlf01";
	print "$host:\n";
	$ssh = "ssh $host";
	chomp($info = `$ssh "sudo /usr/sbin/dmidecode |grep -A4 'System Information'"`); 
	$model =  $1 if ($info =~ /Product Name: \w+\s*(\w+)/);
	$sn = $1 if ($info =~ /Serial Number: (.*)/);
	$Name = "$model-$sn";
	print "$Name\n";
    my $sql =  qq[ update Frame,Host set Name = "$Name" where (Frame.SerialNumber = Host.SerialNumber) and Host.Servername = "$host" ];
	$row = $dbh->do($sql);
	print "$host frame name updated\n" if $row;
}

__DATA__
Product Name: PowerEdge 1750 
Serial Number: BS0N641
AIX: 6C1-100211A
