#!/usr/bin/perl -w

# sets CPU, Mem, and SAN stats for newly added hosts to inventory

use DBI;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","")
    or die "Cannot open $DBI::errstr\n";

my %server;
my $OS;

# get hosts/frames that don't stats yet  
my $sql = qq [ select ServerName,Frame.Name from Host LEFT OUTER JOIN Frame
on Host.SerialNumber=Frame.SerialNumber where (Host.Cores = 0 or Host.Memory = 0) and (Host.Active = 1) and ServerName not like "%vio%" ];


my $sth = $dbh->prepare($sql) or die "Cannot prepare SQL statements from $DBI::errstr\n";
$sth->execute();
my $array_ref = $sth->fetchall_arrayref();
foreach my $row (@$array_ref) {
    my ($host, $frame) = @$row;
    $server{$host} = $frame;
}

foreach $host ( keys %server) {
	#next if $host =~ /tlf|sn|uxfgl|aix6|lxdepprs|pdaix|perf/;
	next if $host =~ /uxfgl|aix6|lxdepprs|pdaix|perf|lxdepsbtlf|sn/;
	my $ssh = "ssh $host";
	chomp($OS = `$ssh "uname -s"`);
	my $frame = $server{$host};
	print "Updating Host: $host and Frame: $frame..\n";
	my $san =  getSAN($host,$OS);
	#$san *= 1024; # in MB
	my ($cores,$mem,$speed) = getStats($host,$OS);

	my($sql, $sql2);
	# populate host info AIX or Linux
	$sql = qq [ update Host set Cores = "$cores", Memory = "$mem", SANSpace = "$san" where ServerName = "$host" ];

	# populate Linux frame info 
	if ($OS =~ /linux/i) {
    	 $sql2 = qq [ update Frame set Cores = "$cores", Memory = "$mem", ClockSpeed = "$speed" where Name = "$frame" ];
	}
	# populate IBM frame info  
	if($OS =~ /aix/i) {
		my ($tot_cores,$avail_cores,$tot_mem,$avail_mem) = getIBMframeStuff($frame);
    	 $sql2 = qq [ update Frame set Cores = "$tot_cores", Memory = "$tot_mem", AvailCores = "$avail_cores", AvailMem = "$avail_mem",  ClockSpeed = "$speed" where Name = "$frame" ];
	}

	$host_row = $dbh->do($sql);
	$frame_row = $dbh->do($sql2);
	print "update successful\n" if ($host_row and $frame_row);
}

sub getSAN {
	my ($host,$OS) = @_;
	my $ssh = "ssh $host";
	my $total = 0; 
	my $size; my $lun;
	if ($OS =~ /linux/i) {
		@info = `$ssh "sudo /usr/sbin/pvs 2>/dev/null"`;	
		for my $line (@info) {
			next unless $line =~ /emcpower/;
			$size = (split(/\s+/,$line))[5];
			$size =~ s/G//i;
			$total += $size;
		}
		$total *= 1024; # in MB

	} elsif ($OS =~ /aix/i) {
		@info = `$ssh "lspv | grep power"`;
		for my $line (@info) {
			$lun = (split(/\s+/,$line))[0];
			# OUCH, i know this is bad 
			$size = `$ssh "sudo /usr/sbin/bootinfo -s $lun"`; 
			$total += $size;
		}
	}

	$total ? return $total :  return "0";
}

sub getStats {
	my ($host,$OS) = @_;
    my $ssh = "ssh $host";
	my @info;
	my $cores; my $mem; my $speed;
	if ($OS =~ /linux/i) {
		@info = `$ssh "/bin/grep processor /proc/cpuinfo | wc -l ; /bin/grep MemTotal /proc/meminfo ;
	       /bin/grep MHz /proc/cpuinfo |head -1"`;
		$cores = $info[0];
		chomp($cores);
		$mem = $1 if ($info[1] =~ /(\d+)/);
		$speed = $1 if ($info[2] =~ /(\d+)\..*/);
		return $cores, int($mem/1024), $speed;

	} elsif ($OS =~ /aix/i) {
		 #@info = `$ssh "lparstat -i | grep Entitled | grep -v Pool ; sudo /usr/sbin/bootinfo -r ; pmcycles"`;	
		 @info = `$ssh "lparstat -i | grep Entitled | grep -v Pool;  lsattr -El mem0 | head -1| awk '{print \\\$2}'; pmcycles"`;
		 $cores = $1 if ($info[0] =~ /(\d+\.\d+)/);
		 $cores = 1 if $cores < 1;
		 # mem in MB
		 $mem = $info[1];
		 $speed = $1 if ($info[2] =~ /(\d+ \w+)/);
	     return $cores, $mem, $speed;	
	}
}

sub getIBMframeStuff {
	my $frame = shift;
	my %hmc_hash;
	my $hmc_key;
	my $target_hmc;
	#my @hmcs = qw( hmdep001 hmdep002 hmdep003 hmmnp001 hmmnp002 rprmnaxhmc01 pdlinhmc002 );
	my @hmcs = qw( hmdep001 hmdep002 hmdep003 hmmnp001 hmmnp002 rprmnaxhmc01 );
	# build data struct of systems per each hmc
	for my $hmc (@hmcs) {
    	my $ssh = "ssh $hmc";
    	my @systems = `$ssh "lssyscfg -r sys -F name"`;
    	chomp @systems;
    	$hmc_hash{$hmc} = [ @systems ];
	}

	for my $key (keys %hmc_hash) {
    	if ( grep {/$frame/}  @{ $hmc_hash{$key} } ) {
			$target_hmc = $key;
    	}
	}

	my $ssh = "ssh $target_hmc";
	my $cpu_cmd = "lshwres -r proc --level sys -m $frame -F configurable_sys_proc_units:curr_avail_sys_proc_units";
    my $mem_cmd = "lshwres -r mem --level sys -m $frame -F configurable_sys_mem:curr_avail_sys_mem";
	chomp( my $c = `$ssh $cpu_cmd` );
    my ($tot_cores, $avail_cores) = split( /:/, $c );
    chomp( my $m = `$ssh $mem_cmd` );
    my ($tot_mem, $avail_mem) = split( /:/, $m );

	return($tot_cores,$avail_cores,$tot_mem,$avail_mem);
}


