#!/bin/bash
#  The - option to a here document <<-
#+ suppresses leading tabs in the body of the document, but *not* spaces.

mem=1024
cat >> file1 <<-EOF
	This is line 1 of the message.
	mem is: $mem
EOF
# The output of the script will be flush left.
# Note that this option has no effect on *embedded* tabs.


