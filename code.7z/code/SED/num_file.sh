#!/bin/ksh
# usage: num_file.sh file(s) 
# put line numbers at the start of each line
# creates a new file with extension ln

for x
do
	sed '/./=' $x | sed '/./N; s/\n/ /' > $x.ln
done
