#!/bin/ksh
# usage: strip_html.sh file(s) 
# strips html tags from the file

for x
do
	sed -e :a -e 's/<[^>]*>//g;/</N;//ba' $x > $x.txt
done
