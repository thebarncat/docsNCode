#!/bin/ksh
# usage: doublespace.sh file 
# creates a new file with extension dub

for x
do
	sed 'n;d' $x > $x.nodub

done
