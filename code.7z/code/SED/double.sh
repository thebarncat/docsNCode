#!/bin/ksh
# usage: doublespace.sh file 
# creates a new file with extension dub

for x
do
	sed G $x > $x.dub
done
