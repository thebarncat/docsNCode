#!/bin/ksh
# usage: commafy.sh file(s) 
# puts standard commans in a number string
# creates a new file with extension com 

for x
do
	sed -e :a -e 's/\(.*[0-9]\)\([0-9]\{3\}\)/\1,\2/;ta' $x > $x.com 
done
