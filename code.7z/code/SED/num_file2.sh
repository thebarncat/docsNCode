#!/bin/ksh
# same as numfile, but numbers blank lines as well
# usage: num_file.sh file(s) 
# creates a new file with extension ln

for x
do
	sed = $x | sed 'N;s/\n/ /' > $x.ln	
done
