#!/bin/bash

for i in `cat bad-encase`
	do 
		echo $i
		#scp COF_Encase_Servlet-1-7.i586.rpm $i:/tmp
		#ssh $i "sudo /bin/rpm -e EnCase; sudo /sbin/service xinetd restart; sudo /bin/rpm --nodeps -Uvh /tmp/COF_Encase_Servlet-1-7.i586.rpm"
		ssh $i "sudo netstat -anp |  grep -i listen| grep 4445"
		#ssh $i "sudo /bin/rpm --nodeps -Uvh /tmp/COF_Encase_Servlet-1-7.i586.rpm"
		
done

