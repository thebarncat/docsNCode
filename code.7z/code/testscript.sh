#!/bin/bash

WD=`date +%w`

if [ $WD == '4' ]; then
	echo 'yup'
else 
	echo 'nope'
fi

foo[0]='hi'
foo[1]='there'
printf "${foo[1]}\n"

