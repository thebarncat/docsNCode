#!/usr/bin/perl -w
use DBI;

$dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","cmsys")
  or die "Cannot open $DBI::errstr\n";

open (F, "arch.csv") or die "$!";

while (<F>) {
	chomp;
	next if /^\s+$/;
	($HostName,$Domain,$OS,$desc,$active) = split(/,\s?/,$_);
	$rows = $dbh->do("INSERT INTO Host
		(ServerName,Domain,OS,Description,Active) VALUES ('$HostName','$Domain','$OS','$desc','$active')");
	print "$rows inserted\n";
}

close F;

$dbh->disconnect or warn "failed: $DBI::errstr\n";


