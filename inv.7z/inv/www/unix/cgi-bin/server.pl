#!/usr/bin/perl
#
# usage vpage.pl <successfull pages> <failures>


$HOME="/var/www/unix";
$LOGFILE=">>$HOME/logs/inv.log";
$FiveSpaces="&nbsp&nbsp&nbsp&nbsp&nbsp";
$TenSpaces="&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
$TwentySpaces=$TenSpaces.$TenSpaces;
$ThirtySpaces=$TenSpaces.$TenSpaces.$TenSpaces;
$FiftySpaces=$TwentySpaces.$TwentySpaces.$TenSpaces;

open LOGFILE or die "Couldn't open $LOGFILE";
print LOGFILE "After LOGFILE \n";


use CGI qw(param);
my $Selection = param("selection");
my $ServerName = param("ServerName");
my $Search = param("search");
my $ServerSearchPattern = param("serverpattern");
my $DECOM = param("Decom");
my $Active = param("ACTIVE");
my $InActive = param("INACTIVE");


#
# Connect to MySQL database which contains server information
#
use DBI;
$DB="ServerInventory";
$HostName="lxdepinv";
$UserID="root";
$Passwd="";
$ConnectionInfo="dbi:mysql:$DB;$HostName";

# Connect to MySQL database
$DBH = DBI->connect($ConnectionInfo,$UserID,$Passwd);

#if ($Search =~ "Search") {
   BuildServerHash();
   # create array of servernames.  must sort it 
   @Hosts = sort { lc($a) cmp lc($b) } ( keys %SERIALNUM );
   
#   } 

if ($Selection =~ "ING Reports") {
   system("$HOME/cgi-bin/ING.pl");
   exit; 
   }

if ($Selection =~ "Frame Info") {
   print LOGFILE "Calling frame.pl\n";
   system("$HOME/cgi-bin/frame.pl");
   exit; 
   }

if ($Selection =~ "Sharebuilder Reports") {
   print LOGFILE "Calling sharebuiler.pl\n";
   system("$HOME/cgi-bin/sharebuilder.pl");
   exit; 
   }

if ($Selection =~ "Supply") {
   print LOGFILE "Calling supply.pl\n";
   system("$HOME/cgi-bin/supply.pl");
   exit; 
   }


#
# Display Menu Bar at Top of Page
#
print "Content-type: text/html\n\n";
print <<"EOF";
<HTML><head><title>Server Inventory</title></head>
<HTML>
<BODY bgcolor=\"#FFFBF0\">

<FORM METHOD=SUBMIT ACTION=/cgi-bin/server.pl >\n
<TABLE WIDTH=600 CELLPADDING=2 MAXSIZE=60>\n
  <TR>
    <TD>
      <CENTER><H1>Unix Server Inventory </H1></CENTER><BR>
        <INPUT TYPE=\"SUBMIT\" STYLE=\"background-color: #FFAD78\" name=\"selection\" VALUE=\"Server Info\"> 
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"Frame Info\"> 
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"ING Reports\"> 
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"Sharebuilder Reports\"> 
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"Supply\"> 
      <FONT color="ff000">\n
    </TD>\n
  </TR>\n
</TABLE>\n
</FORM>\n
</BODY></HTML>
EOF


#
# Start Form
#
print "<FORM METHOD=SUBMIT ACTION=/cgi-bin/server.pl >\n "; 

print "<TABLE WIDTH=600 CELLPADDING=2 MAXSIZE=60>\n";
print "  <TR>\n";
print "    <TD>\n"; 
#print "<CENTER><H1>Unix Server Inventory </H1></CENTER>\n";
print " <FONT SIZE=2>";  
print " </FONT>";  
print "    </TD>\n"; 
print "  </TR>\n";
print "</TABLE>\n";
print "<BR>\n";
print "<TABLE BORDER=4 WIDTH=600 CELLPADDING=2 MAXSIZE=60>\n";
print "  <TR>\n";
print "    <TD>\n"; 
print "    <FONT color=\#FF6647\"> \n"; 
print "    <B> &nbsp  Servers </B><BR> \n";
print "    </FONT> \n"; 

print "    <SELECT SIZE=6 NAME=\"ServerName\"  WIDTH=250 MULTIPLE >\n";

foreach $Server (@Hosts)
  {
  # if ServerSearchPattern != "" and Server doesn't match search pattern
  if (!($ServerSearchPattern eq "" || $Server =~ /$ServerSearchPattern/i))
     {
     next;
     }

  if ( $DECOM eq "F" && $ACTIVE{$Server} eq "Decommissioned" )
        {
        next;
        }
  if ( $Active eq "F" && $ACTIVE{$Server} eq "Active" )
        {
        next;
        }
  if ( $InActive eq "F" && $ACTIVE{$Server} eq "In-Active" )
        {
        next;
        }

        print "    <OPTION>$Server";
     print "\n";
  }

print "    </SELECT><BR><BR>\n\n\n";

print "&nbsp <INPUT TYPE=\"TEXT\" NAME=\"serverpattern\" MAXLENGTH=\"15\" SIZE=\"15\" VALUE=\"$ServerSearchPattern\" >";
print "&nbsp<INPUT TYPE=\"SUBMIT\"  NAME=\"search\" VALUE=\"Search\">\n"; 
print "    <BR><BR>\n\n";

print "<INPUT TYPE=\"SUBMIT\" NAME=\"quarytype\" VALUE=\"Show Server Info\"><BR> ";
print "    </TD>\n\n\n";
#print "  <TR>\n";

print "    <TD>\n\n\n";
print " <FONT COLOR=000000 SIZE=-2>";
print " <center>\n";
print " <FONT SIZE=3>";  
print "    <FONT color=\#FF6647\"> \n"; 
print "    <B> &nbsp  Additional Search Criteria </B><BR> \n";
print "    </FONT> \n"; 
print " <FONT SIZE=3>";  
#
# Select Active Servers?
#
print "<BR>Include Active Servers $TenSpaces\n";
if ($Active =~ "F")
   {
   print "&nbsp&nbsp <INPUT TYPE=\"radio\" NAME=\"ACTIVE\" VALUE=\"T\" > Yes\n";
   print "&nbsp <INPUT TYPE=\"radio\" NAME=\"ACTIVE\" VALUE=\"F\" CHECKED> No\n";
   }
else
   {
   print "&nbsp&nbsp <INPUT TYPE=\"radio\" NAME=\"ACTIVE\" VALUE=\"T\" CHECKED> Yes\n";
   print "&nbsp <INPUT TYPE=\"radio\" NAME=\"ACTIVE\" VALUE=\"F\" > No\n";
   }
#
# Select InActive Servers?
#
print "<BR>Include In-Active Servers $FiveSpaces\n";
if ($InActive =~ "F")
   {
   print "&nbsp&nbsp <INPUT TYPE=\"radio\" NAME=\"INACTIVE\" VALUE=\"T\" > Yes\n";
   print "&nbsp <INPUT TYPE=\"radio\" NAME=\"INACTIVE\" VALUE=\"F\" CHECKED> No\n";
   }
else
   {
   print "&nbsp&nbsp <INPUT TYPE=\"radio\" NAME=\"INACTIVE\" VALUE=\"T\" CHECKED> Yes\n";
   print "&nbsp <INPUT TYPE=\"radio\" NAME=\"INACTIVE\" VALUE=\"F\" > No\n";
   }
#
# Select Decommissioned Servers?
#
print "<BR>Include Decommissioned Servers";
if ($DECOM =~ "F")
   {
   print "&nbsp&nbsp <INPUT TYPE=\"radio\" NAME=\"Decom\" VALUE=\"T\" > Yes\n";
   print "&nbsp <INPUT TYPE=\"radio\" NAME=\"Decom\" VALUE=\"F\" CHECKED> No\n";
   }
else
   {
   print "&nbsp&nbsp <INPUT TYPE=\"radio\" NAME=\"Decom\" VALUE=\"T\" CHECKED> Yes\n";
   print "&nbsp <INPUT TYPE=\"radio\" NAME=\"Decom\" VALUE=\"F\" > No\n";
   }

print "    </TD>\n\n\n";
print "  <TR>\n";
print "</TABLE>\n";

print "</TABLE>\n";



#print " <FONT SIZE=-1>";  
print "<BR><table>\n";

print "<tr><td><B>Server Name$TenSpaces</B></td><td>$ServerName $ThirtySpaces</td>\n"; 
print "<td><B>Server State &nbsp</B></td><td><FONT SIZE=3 COLOR=000000> $ACTIVE{$ServerName} </td></tr>\n";

print "<tr><td><B>Frame </B></td>\n ";
print "<td><A HREF=\"/cgi-bin/frame.pl?FrameName=$FRAME{$ServerName}\" style=\"text-decoration:none\"> $FRAME{$ServerName} </A></td> \n";

print "<td><B>Serial Number </B></td><td><FONT SIZE=3 COLOR=000000> $SERIALNUM{$ServerName}</td></tr>\n";

print "<tr><td><B>Make/Model </B></td><td><FONT SIZE=3 COLOR=000000>$MAKE{$ServerName} / $MODEL{$ServerName} </td>\n ";
print "<td><B>Virtual</B></td><td><FONT SIZE=3 COLOR=000000> $VIRTUAL{$ServerName}</td></tr>\n";

print "<tr><td><B>Cores</B></td><td>$CORES{$ServerName} @ $CLOCKSPEED{$ServerName}</td>\n"; 
print "<td><B>CPU Mode &nbsp</B></td><td><FONT SIZE=3 COLOR=000000> $MODE{$ServerName} </td></tr>\n";


print "<tr><td><B>Memory </B></td><td><FONT SIZE=3 COLOR=000000> $MEMORY{$ServerName}</td>\n";
print "<td><B>Domain $TenSpaces&nbsp</B></td><td>$DOMAIN{$ServerName} &nbsp<BR></td>\n";
print "<tr><td><B>Total SAN Space </B></td><td><FONT SIZE=3 COLOR=000000>$SANSPACE{$ServerName} Megabytes</td>\n ";
print "<td><B>Operating System &nbsp</B></td><td><FONT SIZE=3 COLOR=000000> $OS{$ServerName} $OSLEVEL{$ServerName}</td></tr>\n";


print "</table>\n";
print "<table>\n";
print "<tr><td><B>Description &nbsp&nbsp</B></td><td>$DESCRIPTION{$ServerName}</td></tr><BR>\n";
print "<tr><td><B>Contact </B></td><td>$CONTACT{$ServerName}</td></tr><BR>\n";
print "<tr><td><B>Rack </B></td><td>$RACK{$ServerName}</td></tr>\n";



print"</FORM></BODY></HTML>\n";


$DBH->disconnect;


#####################################################################
# Build a hash table of all Servers in database
#####################################################################
sub BuildServerHash
   {
   my $ServerName="";
   my $Active="";
   my $Cores="";
   my $Mode="";
   my $ClockSpeed="";
   my $Memory="";
   my $Frame="";
   my $Domain="";
   my $Line="";
   my $OS="";
   my $TempName="";
   my $SANSpace="";
   my $SerialNumber="";
   my $Description="";
   my $Contact="";
   my $Rack="";
   my $Virtual="";
   my $Status="";
   my $Note="";


   $Statement = "SELECT ServerName,Active,Host.Cores,Host.Mode,ClockSpeed,Host.Memory,Frame.Name,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,SANSpace,Description,Contact,Rack,Virtual,Status,Note FROM Host LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber order by ServerName;";

   $Result = ProcessStatement($Statement);

   # Initialize hash tables
   %CORES = ();
   %MODE = ();
   %ACTIVE = ();
   %CLOCKSPEED = ();
   %MEMORY = ();
   %FRAME = ();
   %DOMAIN = ();
   %MAKE = ();
   %MODEL = ();
   %SERIALNUM = ();
   %OS = ();
   %OSLEVEL = ();
   %SANSPACE = ();
   %DESCRIPTION = ();
   %CONTACT = ();
   %RACK = ();
   %VIRTUAL = ();
   %STATUS = ();
   %NOTE = ();


   foreach $Line (@{$Result})
    {
    ($ServerName,$Active,$Cores,$Mode,$ClockSpeed,$Memory,$Frame,$Domain,$Make,$Model,$SerialNum,$OS,$OSLevel,$SANSpace,$Description,$Contact,$Rack,$Virtual,$Status,$Note) = @{$Line};
    # printf ("   %10s  %4s \n",$ServerName,$Rack);

    print LOGFILE "adding server : $ServerName \n";
    $CORES{$ServerName} = $Cores;
    $MODE{$ServerName} = $Mode;
    $CLOCKSPEED{$ServerName} = $ClockSpeed;
    $MEMORY{$ServerName} = $Memory;
    $FRAME{$ServerName} = $Frame;
    $DOMAIN{$ServerName} = $Domain;
    $MAKE{$ServerName} = $Make;
    $MODEL{$ServerName} = $Model;
    $SERIALNUM{$ServerName} = $SerialNum;
    $OS{$ServerName} = $OS;
    $OSLEVEL{$ServerName} = $OSLevel;
    $SANSPACE{$ServerName} = $SANSpace;
    $DESCRIPTION{$ServerName} = $Description;
    $CONTACT{$ServerName} = $Contact;
    $RACK{$ServerName} = $Rack;
    $NOTE{$ServerName} = $Note;
    if ($Virtual eq 1)
        {
        $VIRTUAL{$ServerName} = "True";
        }
    else
        {
        $VIRTUAL{$ServerName} = "False";
        }
    if ($Active eq 1)
        {
        $ACTIVE{$ServerName} = "Active";
        }
    elsif ($Active eq 0)
        {
        $ACTIVE{$ServerName} = "In-Active";
        }
    else
        {
        $ACTIVE{$ServerName} = "Decommissioned";
        }

    if ($Status eq 1)
        {
        $STATUS{$ServerName} = "Active";
        }
    elsif ($Status eq 0)
        {
        $STATUS{$ServerName} = "InActive";
        }
    else
        {
        $STATUS{$ServerName} = "Decommissioned";
        }


    }

   }



#####################################################################
# Returns the date
#####################################################################
sub GetDate
   {
   local($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
   local($Month) = (Jan,Feb,Mar,Apr,May,June,Jul,Aug,Sep,Oct,Nov,Dec)[$mon];
   local($WeekDay) = (Sunday,Monday,Tuesday,Wednessday,Thursday,
                      Friday,Saturday)[$wday];
   local($Date) = "$hour:$min $WeekDay $Month $mday";
   return ($Date);
   }


#####################################################################
# In : an array
# Out : The same array but all elements are unique
#####################################################################
sub Unique
   {
   my @UniqueArray = ();
   my $Element1=""; 

   foreach $Element1 (@_)
      {

      $Skip=0;
      # If $Element is in UniqueArray, skip it 
      foreach $Element2 (@UniqueArray)
          {
          if ($Element1 eq $Element2)
             {
             $Skip=1;
             }
          }
 
      if ($Skip == 0)
         { 
         push @UniqueArray, $Element1;
         }

      }

     return(@UniqueArray);
   }

##########################################
# Subroutine to execute a MySQL statement
##########################################
sub ProcessStatement
  {
        my @Result;
        $SQLStatement = $_[0];
        #print "$SQLStatement\n";

        # Prepare and execute updates
        $STH = $DBH->prepare("$SQLStatement");
        $STH->execute();
        $Result = $STH->fetchall_arrayref;

         return $Result;

        } # End ProcessStatement


