#!/usr/bin/perl
#
# usage vpage.pl <successfull pages> <failures>
#

$HOME="/var/www/unix";
$LOGFILE=">>$HOME/logs/frame.log";
$TenSpaces="&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
$TwentySpaces=$TenSpaces.$TenSpaces;
$ThirtySpaces=$TenSpaces.$TenSpaces.$TenSpaces;
$FiftySpaces=$TwentySpaces.$TwentySpaces.$TenSpaces;
open LOGFILE or die "Couldn't open $LOGFILE";
print LOGFILE "After LOGFILE \n";


use CGI qw(param);
my $Selection = param("selection");
my $FrameName = param("FrameName");
my $Search = param("search");
my $FrameSearchPattern = param("framepattern");
my $AIX = param("AIX");
my $Linux = param("Linux");


# Connect to MySQL database which contains server information
#
use DBI;
$DB="ServerInventory";
$HostName="lxdepinv";
$UserID="root";
$Passwd="";
$ConnectionInfo="dbi:mysql:$DB;$HostName";

# Connect to MySQL database
$DBH = DBI->connect($ConnectionInfo,$UserID,$Passwd);


#if ($Search =~ "Search") {
   BuildServerHash();
   BuildFrameHash();
   # create array of framenames.  must sort it 
   @Frames = sort { lc($a) cmp lc($b) } ( keys %SERIALNUM );
   
#   } 

if ($Selection =~ "ING Reports") {
   system("$HOME/cgi-bin/ING.pl");
   exit; 
   }
if ($Selection =~ "Server Info") {
   system("$HOME/cgi-bin/server.pl");
   exit; 
   }
if ($Selection =~ "Sharebuilder Reports") {
   system("$HOME/cgi-bin/sharebuilder.pl");
   exit; 
   }
if ($Selection =~ "Supply") {
   system("$HOME/cgi-bin/supply.pl");
   exit; 
   }

#
# Display Menu Bar at Top of Page
#
print "Content-type: text/html\n\n";
print <<"EOF";
<HTML><head><title>Unix Server Inventory</title></head>
<HTML>
<body bgcolor=\"#FFFBF0\">

<FORM METHOD=SUBMIT ACTION=/unix/cgi-bin/frame.pl >\n
<TABLE WIDTH=600 CELLPADDING=2 MAXSIZE=60>\n
  <TR>
    <TD>
      <CENTER><H1>Unix Server Inventory </H1></CENTER><BR>
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"Server Info\"> 
      <INPUT TYPE=\"SUBMIT\" STYLE=\"background-color: #FFAD78\" name=\"selection\" VALUE=\"Frame Info\"> 
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"ING Reports\"> 
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"Sharebuilder Reports\"> 
      <INPUT TYPE=\"SUBMIT\" name=\"selection\" VALUE=\"Supply\"> 
    </TD>\n
  </TR>\n
</TABLE>\n
</FORM>\n
</BODY></HTML>
EOF


#
# Start Form
#
print "<FORM METHOD=SUBMIT ACTION=/unix/cgi-bin/frame.pl >\n "; 

print "<TABLE WIDTH=600 CELLPADDING=2 MAXSIZE=60>\n";
print "  <TR>\n";
print "    <TD>\n"; 
#print "<CENTER><H1>Unix Server Inventory </H1></CENTER>\n";
print " <FONT SIZE=2>";  
print " </FONT>";  
print "    </TD>\n"; 
print "  </TR>\n";
print "</TABLE>\n";
print "<BR>\n";
print "<TABLE BORDER=4 WIDTH=600 CELLPADDING=2 MAXSIZE=60>\n";
print "  <TR>\n";
print "    <TD>\n"; 
print "    <FONT color=\#FF6647\"> \n";
print "    <B>&nbsp Frames </B><BR> \n";
print "    <SELECT SIZE=6 NAME=\"FrameName\"  WIDTH=250 MULTIPLE >\n";
print "    </FONT> \n";


foreach $Frame (@Frames)
  {
  # if FrameSearchPattern != "" and Server doesn't match search pattern
  if (!($FrameSearchPattern eq "" || $Frame =~ /$FrameSearchPattern/i))
     {
     next;
     }

     print "    <OPTION>$Frame";

  }

print "    </SELECT><BR><BR>\n\n\n";

print "&nbsp <INPUT TYPE=\"TEXT\" NAME=\"framepattern\" MAXLENGTH=\"15\" SIZE=\"15\" VALUE=\"$FrameSearchPattern\" >";
print "&nbsp<INPUT TYPE=\"SUBMIT\"  NAME=\"search\" VALUE=\"Search\">\n"; 
print "    <BR><BR>\n\n";

print "<INPUT TYPE=\"SUBMIT\" NAME=\"quarytype\" VALUE=\"Show Frame Info\"><BR> ";
print "    </TD>\n\n\n";
#print "  <TR>\n";

print "    <TD>\n\n\n";
print " <FONT COLOR=000000 SIZE=-2>";
print " <center>\n";
print " <FONT SIZE=3>";  

print "    </TD>\n\n\n";
print "  <TR>\n";
print "</TABLE>\n";

print "</TABLE>\n";



#print " <FONT SIZE=-1>";  
print "<BR><table>\n";

print "<tr><td><B>Frame $TenSpaces</B></td><td>$FrameName $ThirtySpaces</td><tr>\n"; 
print "<tr><td><B>Make/Model &nbsp</B></td><td><FONT SIZE=3 COLOR=000000>$MAKE{$FrameName} / $MODEL{$FrameName} </td>\n ";
print "<td><B>Serial Number</B></td><td>$SERIALNUM{$FrameName}</td></tr>\n"; 
print "<tr><td><B>Cores</B></td><td>$CORES{$FrameName} @ $CLOCKSPEED{$FrameName}</td>\n"; 
print "<td><B>Available Cores</B></td><td>$AVAILCORES{$FrameName}</td></tr>\n"; 
print "<td><B>Memory </B></td><td><FONT SIZE=3 COLOR=000000> $MEMORY{$FrameName}</td>\n";
print "<td><B>Available Memory</B></td><td>$AVAILMEM{$FrameName}</td></tr>\n"; 

print "</tr>\n";
print "<tr><td><B>Rack </B></td><td>$RACK{$FrameName}</td>\n";
print "<td><B>Status</B></td><td>$STATUS{$FrameName}</td></tr>\n"; 

#
# Only display LPars which are currently active
#
print "<tr><td><B>Virtual Servers </B></td>\n";
@ServerList = BuildLPARList($FrameName);
foreach $LPar (@ServerList)
    {
    if ($ACTIVE{$LPar} eq "Active")
       {
       print "<td><A HREF=\"/unix/cgi-bin/server.pl?ServerName=$LPar\" style=\"text-decoration:none\"> $LPar </A></td></tr><td></td> \n";
       }
    else
       {   
       print "<td> $LPar &nbsp&nbsp&nbsp $ACTIVE{$LPar}</td></tr><td></td>\n";
       }
    }
print "<tr><td><B>Notes </B></td><td>$NOTE{$FrameName}</td>\n";
print "</table>\n";



print"</FORM></BODY></HTML>\n";

print "</table>\n";



print"</FORM></BODY></HTML>\n";


$DBH->disconnect;

# call with name of a frame
sub BuildLPARList
   {
   my $FrameName = $_[0];
   my $Statement = "";
   my $ServerName = "";
   my @ServerList = ();

   my $SerialNumber = $SERIALNUM{$FrameName};
   
   $Statement = "SELECT ServerName FROM Host WHERE Host.SerialNumber='$SerialNumber' and (Host.Active='1' or Host.Active='0') order by ServerName;";
   print LOGFILE "$Statement\n";

   $Result = ProcessStatement($Statement);
   foreach $Line (@{$Result})
      {
      ($ServerName) = @{$Line};
      push @ServerList, $ServerName;
      #print LOGFILE "Servername: $ServerName\n";
      }
   # return an array of server names
   return @ServerList;
   
   }

sub BuildFrameHash
   {
   my $FrameName="";
   my $SerialNumber="";
   my $Statement = "";

   $Statement = "SELECT Name,Make,Model,Rack,Frame.Cores,MaxCores,AvailCores,ClockSpeed,Frame.Memory,AvailMem,Frame.SerialNumber,Status,Note,Frame.LOB FROM Frame LEFT OUTER JOIN Host on Frame.SerialNumber=Host.SerialNumber order by Name;";

   $Result = ProcessStatement($Statement);

   # Initialize hash tables
   %FRAMENAME=();
   %SERIALNUM=();
   %MAKE=();
   %MODEL=();
   %RACK=();
   %CORES=();
   %MAXCORES=();
   %AVAILCORES=();
   %CLOCKSPEED=();
   %MEMORY=();
   %AVAILMEMORY=();
   %STATUS=();
   %NOTE=();
   %LOB=();


   foreach $Line (@{$Result})
      {
      ($FrameName,$Make,$Model,$Rack,$Cores,$MaxCores,$AvailCores,$ClockSpeed,$Memory,$AvailMem,$SerialNum,$Status,$Note,$Lob) = @{$Line};
      # printf ("   %10s  %4s \n",$ServerName,$Rack);

      print LOGFILE "adding frame : $FrameName \n";
      $FRAMENAME{$SerialNum} = $FrameName;
      $MAKE{$FrameName} = $Make;
      $MODEL{$FrameName} = $Model;
      $RACK{$FrameName} = $Rack;
      $CORES{$FrameName} = $Cores;
      $AVAILCORES{$FrameName} = $AvailCores;
      $CLOCKSPEED{$FrameName} = $ClockSpeed;
      $MEMORY{$FrameName} = $Memory;
      $AVAILMEM{$FrameName} = $AvailMem;
      $SERIALNUM{$FrameName} = $SerialNum;
      $NOTE{$FrameName} = $Note;
      $LOB{$FrameName} = $Lob;
      if ($Status == 1)
        {
        $STATUS{$FrameName} = "Active";
        }
      elsif ($Status == 0)
        {
        $STATUS{$FrameName} = "InActive";
        }
      else
        {
        $STATUS{$FrameName} = "Decommissioned";
        }



      }
   }



#####################################################################
# Build a hash table of all Servers in database
#####################################################################
sub BuildServerHash
   {
   my $ServerName="";
   #my $Cores="";
   #my $ClockSpeed="";
   #my $Memory="";
   #my $Frame="";
   #my $Domain="";
   #my $Line="";
   #my $OS="";
   #my $TempName="";
   #my $SerialNumber="";
   #my $Description="";
   #my $Contact="";
   #my $Rack="";
   #my $Virtual="";
   my $Active="";
   #my $Note="";

   $Statement = "SELECT ServerName,Host.Cores,ClockSpeed,Host.Memory,Frame.Name,Domain,Make,Model,Host.SerialNumber,OS,OSLevel,Description,Contact,Rack,Virtual,Host.Active,Note FROM Host LEFT OUTER JOIN Frame on Host.SerialNumber=Frame.SerialNumber order by ServerName;";

   $Result = ProcessStatement($Statement);

   # Initialize hash tables
   %CORES = ();
   %CLOCKSPEED = ();
   %MEMORY = ();
   %FRAME = ();
   %DOMAIN = ();
   %MAKE = ();
   %MODEL = ();
   %SERIALNUM = ();
   %OS = ();
   %OSLEVEL = ();
   %DESCRIPTION = ();
   %CONTACT = ();
   %RACK = ();
   %VIRTUAL = ();
   %ACTIVE = ();
   %NOTE = ();

   foreach $Line (@{$Result})
    {
    ($ServerName,$Cores,$ClockSpeed,$Memory,$Frame,$Domain,$Make,$Model,$SerialNum,$OS,$OSLevel,$Description,$Contact,$Rack,$Virtual,$Active,$Note) = @{$Line};
    # printf ("   %10s  %4s \n",$ServerName,$Rack);

    #print LOGFILE "adding server : $ServerName \n";
    #$CORES{$ServerName} = $Cores;
    #$CLOCKSPEED{$ServerName} = $ClockSpeed;
    #$MEMORY{$ServerName} = $Memory;
    #$FRAME{$ServerName} = $Frame;
    #$DOMAIN{$ServerName} = $Domain;
    #$MAKE{$ServerName} = $Make;
    #$MODEL{$ServerName} = $Model;
    #$SERIALNUM{$ServerName} = $SerialNum;
    #$OS{$ServerName} = $OS;
    #$OSLEVEL{$ServerName} = $OSLevel;
    #print LOGFILE "      OSLevel : $OSLEVEL{$ServerName} \n";
    #$DESCRIPTION{$ServerName} = $Description;
    #$CONTACT{$ServerName} = $Contact;
    #$RACK{$ServerName} = $Rack;
    #$NOTE{$ServerName} = $Note;
    #if ($Virtual == 1)
    #    {
    #    $VIRTUAL{$ServerName} = "True";
    #    }
    #else
    #    {
    #    $VIRTUAL{$ServerName} = "False";
    #    }
    if ($Active == 1)
        {
        $ACTIVE{$ServerName} = "Active";
        }
    elsif ($Active == 0)
        {
        $ACTIVE{$ServerName} = "InActive";
        }
    else
        {
        $ACTIVE{$ServerName} = "Decommissioned";
        }


    }

   }



#####################################################################
# Returns the date
#####################################################################
sub GetDate
   {
   local($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
   local($Month) = (Jan,Feb,Mar,Apr,May,June,Jul,Aug,Sep,Oct,Nov,Dec)[$mon];
   local($WeekDay) = (Sunday,Monday,Tuesday,Wednessday,Thursday,
                      Friday,Saturday)[$wday];
   local($Date) = "$hour:$min $WeekDay $Month $mday";
   return ($Date);
   }


#####################################################################
# In : an array
# Out : The same array but all elements are unique
#####################################################################
sub Unique
   {
   my @UniqueArray = ();
   my $Element1=""; 

   foreach $Element1 (@_)
      {

      $Skip=0;
      # If $Element is in UniqueArray, skip it 
      foreach $Element2 (@UniqueArray)
          {
          if ($Element1 eq $Element2)
             {
             $Skip=1;
             }
          }
 
      if ($Skip == 0)
         { 
         push @UniqueArray, $Element1;
         }

      }

     return(@UniqueArray);
   }

##########################################
# Subroutine to execute a MySQL statement
##########################################
sub ProcessStatement
  {
        my @Result;
        $SQLStatement = $_[0];
        #print "$SQLStatement\n";

        # Prepare and execute updates
        $STH = $DBH->prepare("$SQLStatement");
        $STH->execute();
        $Result = $STH->fetchall_arrayref;

         return $Result;

        } # End ProcessStatement


