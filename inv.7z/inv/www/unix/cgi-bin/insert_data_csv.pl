#!/usr/bin/perl -w
use DBI;

$dbh = DBI->connect("dbi:mysql:linuxHosts;lxdepcfg","cmsys")
  or die "Cannot open $DBI::errstr\n";

open (F, "alerts.csv") or die "$!";

while (<F>) {
	chomp;
	next if /^\s+$/;
	@values = split(/,\s?/,$_);
	$placeholders =  join(', ', ('?') x @values);
	$rows = $dbh->do("INSERT INTO updates VALUES ($placeholders)", undef, @values );
	print "$rows inserted\n";

}

close F;

$dbh->disconnect or warn "failed: $DBI::errstr\n";


