#!/usr/bin/perl  

use strict;
use Net::Ping;
use Net::SSH::Perl;
use Socket;
use DBI;
use Mail::Sender;

my $blacklist = "/var/www/cgi-bin/blacklist";
open(LIST,"<$blacklist") or die "cannot open: $!";
# slurp entire file
my @skip = <LIST>;
#chomp @skip;
close LIST;

# begin HTML message body
my $msg = qq ( <p><b><font size="4" color="#800000">Found these new hosts:</font></b></p> );

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","") or die "Cannot open $DBI::errstr\n";

# parse the seen hosts and build a hash to get rid of dups
my %hosts;
chomp(my @seen = `/bin/ls -l /var/cfengine | awk "{print \\\$9}"`);
for my $seen  (@seen) {
	next if $seen =~ /(cf_LastSeen\.db$|10\.\d+)/;
	next unless $seen =~ /cf_LastSeen/;
	(my $host = $seen) =~ s/cf_LastSeen\.db\.(.*?)\..*/$1/;
	next if grep /$host/, @skip;
	$hosts{$host} = 1;
}

# filter out hosts that cant't ping and cant SSH to 
print "New Hosts: \n";
for my $host (keys %hosts) {
	my $ssh;
	eval {
    	local $SIG{ALRM} = sub {die "timed out" };
		alarm 5;
		$ssh = Net::SSH::Perl->new($host);
		alarm 0;
	 };

	if ($@ and $@ =~ /timed out/) {  print "TIMED OUT connecting to: $host\n"; }
	next unless $ssh;
	#(my $sname = $name) =~ s/\..*//;
	# GET HOSTS NOT FOUND IN THE DB
	my $sql = qq [ select ServerName from Host where ServerName = "$host" ];
	(my $hostname) = $dbh->selectrow_array($sql);
	unless ($hostname) {
		print "$host\n";
		$msg .= qq( <p><b>$host: </b><br> );
		$msg .= qq( Click <a href="http://lxdepinv/ux-bin/add_host.cgi?host=$host">here</a> to add to inventory<br> );
		$msg .= qq( Click <a href="http://lxdepcfg/cgi-bin/blacklist.cgi?host=$host">here</a> to Black List it.<br> );
	}
	undef $ssh;
}


#send report
my $sender = new Mail::Sender {smtp => 'smtp.ingdirect.com', from => 'cmsys@ingdirect.com'};
die "Error in mailing : $Mail::Sender::Error\n" unless ref $sender;
$sender->MailFile( {
	to => 'unix-alerts@ingdirect.com',
    ctype => "text/html",
    subject => "Daily Host Scan Report",
    msg => $msg,
    file => $blacklist,
} );

