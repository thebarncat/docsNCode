#!/usr/bin/perl  -w

use WWW::Shorten 'TinyURL';

my $long = "http://news.yahoo.com/s/ap/20110209/ap_on_re_us/us_crime_family_feud";
my $short_url = makeashorterlink($long);

print $short_url;
