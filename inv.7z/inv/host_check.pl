#!/usr/bin/perl 

use strict;
use Net::Ping;
use Net::SSH::Perl;
use Socket;
use DBI;
use CGI;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","diamond81") or die "Cannot open $DBI::errstr\n";

# parse the seen hosts and build a hash to get rid of dups
my %hosts;
chomp(my @seen = `sudo /usr/local/sbin/cfshow --last-seen`);
for (@seen) {
	next if /Non reg/;
	my (undef, undef, $host) = (split(/\s+/))[0,1,2];
	next if $host =~ /(?:\d{1,3}\.){3}/;
	($host = $host) =~ s/\..*//;
	$hosts{$host} = 1;
}

# filter out hosts that aren't alive and cant SSH to and get the FQDNs
my $p = Net::Ping->new();
for my $host (keys %hosts) {
	my $name = gethostbyaddr(inet_aton($host), AF_INET);
	next unless $p->ping($name, 2);
	my $ssh;
	eval {
		local $SIG{ALRM} = sub {die "timed out" };
		alarm 5;
		$ssh = Net::SSH::Perl->new($name);
		alarm 0;
	};
	#if ($@ and $@ =~ /timed out/) {  print "TIMED OUT connecting to: $name\n"; }
	next unless $ssh;
	(my $sname = $name) =~ s/\..*//; 
	my $sql = qq [ select concat(ServerName,".", Domain) as hostname from Host where ServerName = "$sname" ];
	(my $hostname) = $dbh->selectrow_array($sql);
	$hostname ? print "match on $hostname\n" :  print "*NO MATCH* on $name\n";
	undef $ssh;
}

$p->close();


