#!/usr/bin/perl -w
# FILE: "/home/jkipp/test.pl"
# LAST MODIFICATION: "Wed, 09 Dec 2015 12:07:51 -0500 (jkipp)"
# (C) 2014 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

$|++;
 while( <DATA> ) {
	 print ".";
	 print "\n" unless ++$count % 50;
	 #... expensive line processing operations
 }


__DATA__
hi there
by now
by now
by now
by now
by now
by now
by now
by now
by now
by now
by now
by now
by now
by now
by now
by now
