#####################################################################
# FILENAME: redhat_sys_backup.sh
# AUTHOR: tom.dorn@upnettec.com <Tom Dorn>
# DATE: 
# PROVIDES:
# 	This is a redhat system backup script.  The idea is to take the
# 	base system files that are customized or configured as a system
# 	is setup and as changes take place over time.  These files are 
#	captured and put into a tar ball where they can be used to 
#	restore directly or the tar ball can be pushed to a central 
#	location and filed with other server's tar balls.  If needed, the
# 	tar balls can be restored over a "fresh" installation and all the
# 	system config stuff (hostname, ip address, gateway, cronjobs, 
#	users, passwords, vsftp and ssh configs, etc. are call 
#	re-captured and you are back to where you were.  This script does
#  	not include any 3rd party apps, custom apps or databases.  Only 
#	system file stuff.  This script is customized to work with UpNet 
#	Linux Servers, but should work on any generic RedHat Enterprise 
#	4 server.
# MODIFICATION HISTORY:
#	luke.bearl@upnettec.com <Luke Bearl>
#	11 June 2009 Added this header comment and also modified the 
#	script such that it now can be used with production or test 
# 	machines.  A deal of error checking was also included to make
# 	the scripts more user friendly.
#	luke.bearl@upnettec.com <Luke Bearl>
#	15 June 2009 - Modified logging so that in the event of an error
#	the last line printed on the log file an error statement
#	24 November 2009 - Modified this script such that it only prints
#	true error conditions to the console (so that MAILTO= will pick
#	it up and deliver it to me).
#       11/11/11/ added crontab file to backup
# USAGE:
# 	./redhat_sys_backup.sh <NFS Mount>
# 	NFS Mount option should be in form server:share.
#####################################################################
HOST=`hostname`
BACKUPDIR=/usr/local/backup/$HOST
LOGFILE=/var/log/redhat_sys_backup.log
ADMIN=sysadmin@upnettec.com
NFSDIR="/nfsosbkup$$"
NFSMOUNT=$1
ERROR=0

###########################################################
#Function exit_error()
#	Provides a nice way to print a message and then exit
#	with error status.
###########################################################
function exit_error {
	echo "AN ERROR OCCURED!" >>$LOGFILE
	exit $1
}

echo "`date` :STARTED REDHAT OS BACKUP OF $HOST ...." >>$LOGFILE
if [ ! -d $BACKUPDIR ]
  then
   mkdir -p $BACKUPDIR
fi

if	[ -z $NFSMOUNT ]
	then
		echo "NFS Mount not specified! Fatal error">>$LOGFILE
		echo "$HOST:REDHATSYSBU failed! NFS Mount not specified!." | mail -s "$HOST:OS BACKUP FAILED" $ADMIN
		exit_error 1
fi
######################3#######
#Build temp store dirs
##############################
mkdir -p  $BACKUPDIR/root $BACKUPDIR/etc $BACKUPDIR/usr $BACKUPDIR/usr/local $BACKUPDIR/var $BACKUPDIR/var/spool $BACKUPDIR/var/spool/cron $BACKUPDIR/etc/sysconfig $BACKUPDIR/etc/httpd $BACKUPDIR/usr/share/ssl/certs $BACKUPDIR/etc/ssh $BACKUPDIR/etc/vsftpd $BACKUPDIR/etc/lvm $BACKUPDIR/etc/snmp $BACKUPDIR/etc/sysconfig $BACKUPDIR/etc/sysconfig/network-scripts $BACKUPDIR/etc/profile.d 2>/dev/null
#############################################
# copy system files into them
###########################################
# backup crontab file#
crontab -l > $BACKUPDIR/backcron

cp -Lrf /root/* $BACKUPDIR/
#the following two lines are redundant from above...
#cp -Lrf /root/.vnc $BACKUPDIR/root/.vnc
#cp -Lfr /root/.ssh $BACKUPDIR/root/.ssh

cp -f /etc/passwd $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/shadow $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/group $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f  /etc/gshadow $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f  /etc/sudoers $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/hosts.allow $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/hosts.deny $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/hosts $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/resolv.conf $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/ntp.conf $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/inittab $BACKUPDIR/etc/ >/dev/null 2>&1
cp -Lrf /etc/rc.d $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/vsftpd/*.conf $BACKUPDIR/etc/vsftpd/ >/dev/null 2>&1
cp -f /etc/ssh/sshd_config $BACKUPDIR/etc/ssh/ >/dev/null 2>&1
cp -f /etc/ssh/ssh_config $BACKUPDIR/etc/ssh/ >/dev/null 2>&1
cp -f /etc/sysconfig/vncservers $BACKUPDIR/etc/sysconfig/ >/dev/null 2>&1
cp -f /etc/logrotate.conf $BACKUPDIR/etc/logrotate.conf >/dev/null 2>&1
cp -f /etc/fstab $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/exports $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/ls.so.conf $BACKUPDIR/etc/ >/dev/null 2>&1
cp -Lrf /etc/httpd $BACKUPDIR/etc/ >/dev/null 2>&1
cp -f /etc/snmp/snmpd.conf $BACKUPDIR/etc/snmp/ >/dev/null 2>&1
cp  -f /etc/sysconfig/network-scripts/ifup-routes $BACKUPDIR/etc/sysconfig/network-scripts/ >/dev/null 2>&1
cp -f /etc/sysconfig/network-scripts/ifcfg-eth0 $BACKUPDIR/etc/sysconfig/network-scripts/ >/dev/null 2>&1
cp -f /etc/sysconfig/network-scripts/ifcfg-eth1 $BACKUPDIR/etc/sysconfig/network-scripts/ >/dev/null 2>&1
cp -f /etc/profile.d/java.sh $BACKUPDIR/etc/profile.d/ > /dev/null 2>&1
if [ -a /etc/vsftpd.chroot_list ]
	then
		cp -f /etc/vsftpd.chroot_list $BACKUPDIR/etc/
fi
cp -Lrf /var/spool/cron $BACKUPDIR/var/spool/cron >/dev/null 2>&1

cp -Lrf /usr/local/etc $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/local/lib $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/local/libexec $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/local/scripts $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/local/bin $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/local/sbin $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/local/include $BACKUPDIR/usr/local/ >/dev/null 2>&1
#cp -Lrf /usr/local/mysql $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/local/share $BACKUPDIR/usr/local/ >/dev/null 2>&1
cp -Lrf /usr/share/ssl/certs $BACKUPDIR/usr/share/ssl/ >/dev/null 2>&1

# Store the services that are set to run w/runlevels
/sbin/chkconfig --list > $BACKUPDIR/chkconfig.list
# Capture kernal level and hostname
uname -a > $BACKUPDIR/uname.list
# Capture list of all rpms
rpm -aq > $BACKUPDIR/rpm.list
# Capture filesystems, sizes, usage, etc.
df -h > $BACKUPDIR/df.list
# capture partition info on system disk
which parted  1> /dev/null 2> /dev/null
RET_CODE=$?
if [ "$RET_CODE" -eq "0" ]; then
	parted -s /dev/sda print > $BACKUPDIR/parted.list
fi
# capture info on scsi devices
cat /proc/scsi/scsi > $BACKUPDIR/scsi.list
# capture volume group info
which vgs >/dev/null 2>&1
RET_CODE=$?
if [ "$RET_CODE" -eq "0" ]; then
	vgs > $BACKUPDIR/vgs.list
fi
# capture lovigcal volume info
which lvs >/dev/null 2>&1
RET_CODE=$?
if [ "$RET_CODE" -eq "0" ]; then
	lvs > $BACKUPDIR/lvs.list
fi
# capture physical voluem info
which pvs >/dev/null 2>&1
RET_CODE=$?
if [ "$RET_CODE" -eq "0" ]; then
	pvs > $BACKUPDIR/pvs.list
fi
cd $BACKUPDIR
# save previous for an online backup
if [ -f ../$HOST.tgz ]
 then
  mv -f ../$HOST.tgz ../$HOST.tgz.old 
fi
# build tarball
tar -czf ../$HOST.tgz * 1>/dev/null 2>&1
RET_CODE=$?
if [ "$RET_CODE" != "0" ]
   then
   echo "ERROR $HOST:OSBKUP Unable to build tarball ...." >> $LOGFILE
   echo "$HOST:OSBKUP Unalbe to build tarball" | mail -s "$HOST:OS BACKUP FAILED" $ADMIN 
   exit_error 1
else
   echo "$HOST:OSBKUP tarball created successfully ...." >> $LOGFILE
fi  
###############################
#move the tarball to nfs backup repository          
###############################
if [ ! -d $NFSDIR ]
 then
  mkdir $NFSDIR
fi
		mount -t nfs $NFSMOUNT $NFSDIR
RET_CODE=$?
if [ "$RET_CODE" != "0" ]
 then
   echo "ERROR $HOST:OSBKUP Unable to mount $NFSDIR ...." >> $LOGFILE
   echo "$HOST:OSBKUP Unalbe to mount $NFSDIR" | mail -s "$HOST:OS BACKUP FAILED" $ADMIN 
  exit_error 1
fi

if [ ! -d $NFSDIR/osbackup/redhat/$HOST ]
  then
  mkdir -p $NFSDIR/osbackup/redhat/$HOST
fi
cd $BACKUPDIR
cd ..
cp -f $HOST.tgz $NFSDIR/osbackup/redhat/$HOST
RET_CODE=$?
if [ "$RET_CODE" != "0" ]
 then
  echo "ERROR $HOST:OSBKUP Unable to move ..." >> $LOGFILE
  echo "$HOST:OSBKUP Unable to move " | mail -s "$HOST:OS BACKUP FAILED" $ADMIN
  ERROR=1
 else
  echo "$HOST:OSBKUP tarball moved successfully .... " >> $LOGFILE
fi
cd /
umount $NFSDIR
RET_CODE=$?
if [ "$RET_CODE" != "0" ]
 then
  echo "ERROR $HOST:OSBKUP Unable to unmount $NFSDIR ..." >> $LOGFILE
  echo "$HOST:OSBKUP Unable to unmount $NFSDIR" | mail -s "$HOST:OS BACKUP UMNT FAILED" $ADMIN
  ERROR=1
 else
  echo "$HOST:OSBKUP $NFSDIR unmounted successfully .... " >> $LOGFILE
fi
# housecleaning
rm -rf $BACKUPDIR 2>>$LOGFILE
rmdir $NFSDIR 2>>$LOGFILE
if [ "$ERROR" != "0" ]
	then
		echo "AN ERROR OCCURED!" >>$LOGFILE
fi
echo "`date`:FINISHED REDHAT OS BACKUP of $HOST ..." >>$LOGFILE
