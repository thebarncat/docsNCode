#!/bin/sh
# reverse the sleeps for NOT interrupted and cmd finish before  timeout(20sec)
( sleep 20 ) & pid=$!
( sleep 10 && kill -HUP $pid ) 2>/dev/null & watcher=$!
if wait $pid 2>/dev/null; then
    echo "your_command finished"
    pkill -HUP -P $watcher
    wait $watcher
else
    echo "your_command interrupted"
fi
