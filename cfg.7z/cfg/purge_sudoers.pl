#!/usr/bin/perl -w
use strict;
use DBI;

my $dbh = DBI->connect("dbi:mysql:ServerInventory;lxdepinv","jkipp","") or die "Cannot open $DBI::errstr\n";

my @hosts;
my $unpurged = 'sudoers';
# can switch it around to see if anything got missed:
#my $unpurged = 'sudoers.purged';
open (F, "<", $unpurged) or die "can't open: $!";
while ( my $line = <F>) {
	next unless $line =~ /^Host_Alias/;
	next if $line =~ /\*./;
	$line =~ s/^.*=\s*?//;
	$line =~ s/,/ /g;
	my @items = split(/\s+/,$line);
	push(@hosts,@items);
}
close F;

@hosts = dedup(@hosts);

my @purge;
for my $host (@hosts)  {
	$host  =~ s/\..*//;
	my $sql = qq [ select ServerName from Host where ServerName = "$host" and Active=1 ];
	(my $hostname) = $dbh->selectrow_array($sql);
	push(@purge,$host) unless $hostname;
}

print "$_\n" for @purge;

sub dedup {
	# get rid of empty lines too 
	@_ = grep /\S/, @_;
	my %seen;
	grep !$seen{$_}++, @_;
}

my $purged = "sudoers.purged";
for my $old (@purge) {
	print "purging: $old\n";
	system("perl -pi -e 's/$old,\\s+//g' $purged") ==0  or die "failed: $?";
	system("perl -pi -e 's/,\\s+$old//g' $purged") ==0  or die "failed: $?";
}



