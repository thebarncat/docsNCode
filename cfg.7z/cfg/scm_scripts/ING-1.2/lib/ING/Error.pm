###############################################################################
##                                                                           ##
##    Copyright (c) 2000-2002 ING Bank, fsb.                                 ##
##    All Rights Reserved.                                                   ##
##                                                                           ##
##    Version : $Revision: 1.11 $                                             ##
##    Date    : $Date: 2003/02/24 21:08:51 $                                 ##
##                                                                           ##
##    Contains error handling subroutines                                    ##
##                                                                           ##
###############################################################################
package ING::Error;

BEGIN {
  require Exporter;
#  our (@ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  @ISA         = qw(Exporter);
  @EXPORT      = qw(&handleError);
  %EXPORT_TAGS = ();
  @EXPORT_OK   = qw(&handleError);
}

use strict;
use Sys::Hostname;
use Text::Wrap;
use ING::Email;
use ING::Util;

# If true, email error messages, otherwise print to STDERR
$ING::Error::SendEmailOnError  = 0;

# Set up default 'from' and 'to' for emails
$ING::Error::EmailFrom         = "commandcenterteam2";
$ING::Error::EmailTo           = $ENV{USER};

# Total width of error reports
$ING::Error::Width             = 80;

# Severity Mappings
%ING::Error::Severity = (
			 crit  => "Critical",
			 warn  => "Warning "
                        );

################################################################
#
# Subroutine:  handleError
#
# Description: Handle error processing
#
# Params:
#  msg       -
#  caller    -
#  code      -
#  severity  - crit(ical) or warn(ing)
#  emailFrom -
#  emailTo   -
#  append    -
#
################################################################
sub handleError {
  my %hParams=@_;
  $hParams{severity} = ($hParams{severity} ? lc(substr($hParams{severity},0,4)) : "crit");
  my $sSeverityString = $ING::Error::Severity{$hParams{severity}};
  my $sNow = localtime;
  chomp $hParams{msg};
  my $nTextWidth=$ING::Error::Width-10;
  local($Text::Wrap::columns)=$nTextWidth;
  my $sFull='#'x$ING::Error::Width;
  my $sEmpty='###'.' 'x($ING::Error::Width-6).'###';
  my $nHeaderHalf=int( ($ING::Error::Width - 6 - length($sSeverityString)) / 2);
  my $sHeader='###'.(' 'x$nHeaderHalf).uc($sSeverityString).(' 'x$nHeaderHalf).'###';
  my $sTime     = sprintf("###  %-${nTextWidth}s  ###","WHEN:     ".$sNow);
  my $sHostname = sprintf("###  %-${nTextWidth}s  ###","HOST:     ".&hostname);
  my $sUser     = sprintf("###  %-${nTextWidth}s  ###","USER:     ".getpwuid($>) );
  my $sGroup    = sprintf("###  %-${nTextWidth}s  ###","GROUP:    ".getgrgid($)) );
  my $sScript   = sprintf("###  %-${nTextWidth}s  ###","SCRIPT:   ".$0);
  my $sParent   = sprintf("###  %-${nTextWidth}s  ###","PARENT:");
  my $sPPid     = getppid;
  unless ($sPPid == 1) {
    my ($nRc,$sStdout,$sStderr) = &ING::Util::execute("ps $sPPid");
    my @aParentLines = map { sprintf("###  %-${nTextWidth}s  ###",$_) } split /\n/, $sStdout;
    $sParent  .= "\n".join("\n", @aParentLines);
  }
  my $sSub      = sprintf("###  %-${nTextWidth}s  ###","SUB:      ".$hParams{caller}->[3]);
  my @aMessageLines = split(/\n/,wrap("","","MESSAGE:  $hParams{msg}"));
  @aMessageLines = map { sprintf("###  %-${nTextWidth}s  ###",$_) } @aMessageLines ;
  my $sMessage=join("\n",@aMessageLines);

  my $sErrorText = sprintf <<__EOF__;
$sFull
$sFull
$sEmpty
$sHeader
$sEmpty
$sFull
$sFull
$sEmpty
$sTime
$sEmpty
$sHostname
$sEmpty
$sUser
$sEmpty
$sGroup
$sEmpty
$sScript
$sEmpty
$sParent
$sEmpty
$sSub
$sEmpty
$sMessage
$sEmpty
$sFull
$sFull
__EOF__

  # Append any additional messages
  $sErrorText .= join("\n", @{$hParams{append}}) if $hParams{append};

  # Send email or print message
  if ($ING::Error::SendEmailOnError or $hParams{emailTo}) {
    &ING::Email::sendMail(
			  from     => $hParams{emailFrom} || $ING::Error::EmailFrom,
			  to       => $hParams{emailTo}   || $ING::Error::EmailTo,
			  subject  => uc($sSeverityString).": $0",
			  message  => $sErrorText
			 );
  } else {
    print STDERR $sErrorText;
  }

  unless ($hParams{severity} =~ m/warn/) {
    exit(defined($hParams{code}) ? $hParams{code} : 1);
  }
}

1;
