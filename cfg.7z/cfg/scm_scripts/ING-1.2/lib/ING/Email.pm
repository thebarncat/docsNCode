###############################################################################
##                                                                           ##
##    Copyright (c) 2000-2002 ING Bank, fsb.                                 ##
##    All Rights Reserved.                                                   ##
##                                                                           ##
##    Version : $Revision: 1.10 $                                             ##
##    Date    : $Date: 2004/09/27 15:28:19 $                                 ##
##                                                                           ##
##    Contains subroutines for tasks involving email.                        ##
##                                                                           ##
###############################################################################
package ING::Email;

BEGIN {
  require Exporter;
#  our (@ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  @ISA         = qw(Exporter);
  @EXPORT      = qw(&sendMail);
  %EXPORT_TAGS = ();
  @EXPORT_OK   = qw(&sendMail);
}

use strict;
use Mail::Sender;
use ING::Util qw(&debug);
use ING::Error;
use Sys::Hostname;

$ING::Email::SMTPHost = "smtp.ingdirect.com";                # CNAME for SMTP Server
$ING::Email::From     = $ENV{LOGNAME}.'@'.&hostname;         # Current user
$ING::Email::To       = $ENV{LOGNAME}.'@ingdirect.com';      # Current user

################################################################
#
# Subroutine:  sendMail
#
# Description: Send error message via email.
#
# Params:
#  smtp      - SMTP host to use (default: $ING::Email::SMTPHost)
#  from      - Email appears from (default: $ING::Email::From)
#  to        - Email sent to (default: $ING::Email::To)
#  cc        - Email cc to
#  bcc       - Email bcc to
#  subject   - Subject of email
#  message   - Message body of email
#  files     - Files to be attached (Comma separated list of files,
#              or a reference to a perl list)
#
################################################################
sub sendMail {
  my %hParams=@_;

  # Use the defaults if not explicitly set
  $hParams{smtp}     ||= $ING::Email::SMTPHost;
  $hParams{from}     ||= $ING::Email::From;
  $hParams{to}       ||= $ING::Email::To;

  # Initialize the error message
  my $sErrorStr;
  $sErrorStr .= "Could not send email:\n\n";
  $sErrorStr .= "From: $hParams{from}\n";
  $sErrorStr .= "To: $hParams{to}\n";
  $sErrorStr .= "Cc: $hParams{cc}\n" if $hParams{cc};
  $sErrorStr .= "Bcc: $hParams{bcc}\n" if $hParams{bcc};
  $sErrorStr .= "Subject: $hParams{subject}\n\n";
  $sErrorStr .= $hParams{message}."\n\n";

  # Initialize mail hash
  my %hMailDetails;
  $hMailDetails{smtp} = $hParams{smtp};
  $hMailDetails{from} = $hParams{from};
  $hMailDetails{to}   = $hParams{to};

  # Set cc
  $hMailDetails{cc} = $hParams{cc} if $hParams{cc};

  # Set bcc
  $hMailDetails{bcc} = $hParams{bcc} if $hParams{bcc};

  # Set subject
  $hMailDetails{subject} = $hParams{subject} if $hParams{subject};

  # Set message
  $hMailDetails{msg} = $hParams{message} if $hParams{message};

  # Attach files
  $hMailDetails{file} = $hParams{files} if $hParams{files};

  # Create new Mail::Sender object
  my $oSender = new Mail::Sender;
  &debug("Sending email to $hParams{to} ... ");
  if (! $oSender) {
    &debug("ERROR!\n");
    &handleError(
		 msg    => $sErrorStr."Error creating new Mail::Sender object.  The system message was '$Mail::Sender::Error'.",
		 caller => [caller(0)]
		)
  }

  # Send message
  my $bResult;
  if ($hMailDetails{file}) {
    $bResult = $oSender->MailFile(\%hMailDetails);
  } else {
    $bResult = $oSender->MailMsg(\%hMailDetails);
  }
  unless (ref $bResult) {
    &debug("ERROR!\n");
    &handleError(
		 msg    => $sErrorStr."Error sending email message.  The system message was '".$Mail::Sender::Error."'.",
		 caller => [caller(0)]
		)
  }
  &debug("done\n");

}

1;

=head1 NAME

ING::Email - Collection of ING Perl 5 modules related to Email, used by the Command Center

=head1 SYNOPSIS

  # Import the module
  use ING::Email;

  # Send an email
  ING::Email::sendMail(from    => 'agelwarg@ingdirect.com',
	               to      => 'jdoe@somewhere.com',
	               subject => 'This is a test subject',
	               message => 'This is a test message');

=head1 DESCRIPTION

ING::Email is a collection of subroutines which allow you to interact with email.  In order to send any emails, a working SMTP server must be available.  By default, INGDEXCHANGEC1 is used.

=head1 CLASS VARIABLES

The following variables are used for default settings.

=head2 ING::Email::SMTPHost

The default SMTP server to use for sending email.  The default is smtp.ingdirect.com.

=head2 ING::Email::From

The default user whom emails appear to be from.  The default is the current user, as taken from $ENV{USER}.

=head2 ING::Email::To

The default list of users where emails are sent to.  The default is the current user, as taken from $ENV{USER}.

=head1 METHODS

=head2 sendMail

Used to send an email.

=head1 AUTHOR

Adam Gelwarg <agelwarg@ingdirect.com>

=head1 VERSION

Version cvs (unreleased)

=head1 SEE ALSO

ING

=cut
