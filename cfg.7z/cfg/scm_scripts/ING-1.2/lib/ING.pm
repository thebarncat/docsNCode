###############################################################################
##                                                                           ##
##    Copyright (c) 2000-2002 ING Bank, fsb.                                 ##
##    All Rights Reserved.                                                   ##
##                                                                           ##
##    Version : $Revision: 1.26 $                                             ##
##    Date    : $Date: 2004/09/27 15:26:36 $                                 ##
##                                                                           ##
##    This is the meta module which contains access to all ING modules       ##
##                                                                           ##
###############################################################################
package ING;

BEGIN {
  require Exporter;
  #our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  $VERSION     = '1.2';
  # makes module inherit methods from the exporter class
  @ISA         = qw(Exporter);
  # export these symbols by default
  @EXPORT      = qw(&debug &lpad &rpad &getOptions &help &readConfig &dateReplace &handleError &sendMail &getFiles &putFiles &transferFiles &getProfileDateFromDate &getDateFromProfileDate &reportToBigBrother &execute &getMD5 &listFiles);
  %EXPORT_TAGS = ();
  # export these on demand only (use ING qa(help)
  @EXPORT_OK   = qw(&debug &lpad &rpad &getOptions &help &readConfig &dateReplace &handleError &sendMail &getFiles &putFiles &transferFiles &getProfileDateFromDate &getDateFromProfileDate &reportToBigBrother &execute &getMD5 &listFiles);
}

# get all of the subs from these sub modules
use ING::Util   qw(&debug &lpad &rpad &getOptions &help &readConfig &dateReplace &getProfileDateFromDate &getDateFromProfileDate &reportToBigBrother &execute &getMD5);
use ING::Error  qw(&handleError);
use ING::Email  qw(&sendMail);
use ING::FTP    qw(&getFiles &putFiles &transferFiles &listFiles);

1;

=head1 NAME

ING - Collection of ING Perl 5 modules used by the Command Center

=head1 SYNOPSIS

  # Import all ING::* modules
  use ING;

  # Send an email
  sendMail(from    => 'agelwarg@ingdirect.com',
	   to      => 'jdoe@somewhere.com',
	   subject => 'This is a test subject',
	   message => 'This is a test message');

=head1 DESCRIPTION

ING is a meta-module.  It imports and quotes all exported
subroutines from the other ING::* modules.  Currently, these include
ING::Util, ING::Error, ING::Email, and ING::FTP.

=head1 AUTHOR

Adam Gelwarg <agelwarg@ingdirect.com>

=head1 VERSION

Version 1.2

=head1 SEE ALSO

ING::Util, ING::Error, ING::Email, ING::FTP

=cut
