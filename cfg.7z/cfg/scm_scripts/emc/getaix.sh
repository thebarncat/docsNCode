#!/bin/ksh

for i in `cat aix`; do
	scp -r emcgrab grab.sh $i:/home/jkipp
	ssh $i '/home/jkipp/grab.sh'
	scp $i:/home/jkipp/emcgrab/outputs/* ~/tmp
done

