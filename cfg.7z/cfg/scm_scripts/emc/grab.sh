cd /home/jkipp/emcgrab
echo "xxxxxx" | sudo -S /home/jkipp/emcgrab/emcgrab.sh -autoexec
asroot chmod -R 777 /home/jkipp/emcgrab/outputs
