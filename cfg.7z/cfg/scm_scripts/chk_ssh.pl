#!/usr/bin/perl 
use Net::SSH::Perl;
use Net::Ping;

my $host = "bqamnlxupf02";
#my $host = "lxdepcsd";
#my $cmd = q!perl -e '@luns = `lspv|grep power |awk "{print \\$1}"`; foreach(@luns) { system "sudo /usr/sbin/bootinfo -s $_" }'!;
#my $cmd  =  "grep processor /proc/cpuinfo | wc -l; grep MemTotal /proc/meminfo; grep MHz /proc/cpuinfo |head -1";
#my $cmd = "lparstat -i | grep Entitled | grep -v Pool; sudo /usr/sbin/bootinfo -r; pmcycles"; 

#my $cmd = "lsattr -El mem0 | head -1 | awk \"{print \\\$2}\"";
my $cmd = "lparstat -i | grep Entitled | grep -v Pool; lsattr -El mem0 | head -1 | awk \"{print \\\$2}\"; pmcycles";           

my $p = Net::Ping->new();
#warn "can't ping" unless $p->ping($host, 2);
print "NOT " unless $p->ping($host, 2);
$p->close();

my $ssh;
eval {
	local $SIG{ALRM} = sub {die "timed out" };
	alarm 5;
	$ssh = Net::SSH::Perl->new($host, protocol => '2', debug => 0); 
	alarm 0;
};

if ($@ and $@ =~ /timed out/) {  print "TIMED OUT connecting to: $host\n"; }
warn "didn't work: $!" unless $ssh;


print "blah\n";

#$ssh->login($ENV{USER});

#my ($out, $err, $exit) = undef;
#($out, $err, $exit) = $ssh->cmd($cmd);
#if ($exit) { print "failed on $host: $err"; }
#print $out if $out;

=cut
my @out = split(/\n/,$out);
$cores = $1 if ($out[0] =~ /(\d+\.\d+)/);
$cores = 1 if $cores < 1;
$mem = $out[1]/1024;
$speed = $1 if ($out[2] =~ /(\d+ \w+)/);
print $cores, " ", $mem," ", $speed;   
=cut

