#!/usr/bin/perl
chomp(my $OS = `uname -s`);
my @aFile = ();
my $rhSysInfo = {};

sub generate {

  #Gather information
  &_parseSystemInfo;
  &_getConfig;
  &_getPKGs;
  &_getFilesystems;
  &_getServices;
  &_getOpenPorts;

  # Dump information
  &_dump;

  # Success
  return 0;

}

sub _getConfig {
  &_getHostname;
  &_getModel;
  &_getSerialNo;
  &_getFirmware;
  &_getCpu;
  &_getMemory;
  &_getNet;
  &_getOS;
}

sub _getModel {
  my ($sModel);

  if ($OS =~ m/linux/i) {
    $sModel = $rhSysInfo->{"0x0100"}->{"values"}->{"Product Name"} || $rhSysInfo->{"0x0100"}->{"values"}->{"Product"};
  } elsif ($OS =~ m/aix/i) {
    $sModel = $rhSysInfo->{"modelname"};
  }

  _conf("MODEL", $sModel);
}

sub _getSerialNo {
  my ($sSerialNo);

  if ($OS =~ m/linux/i) {
    $sSerialNo = $rhSysInfo->{"0x0100"}->{"values"}->{"Serial Number"} || $rhSysInfo->{"0x0300"}->{"values"}->{"Serial Number"};
  } elsif ($OS =~ m/aix/i) {
    $sSerialNo = $rhSysInfo->{"systemid"};
  }

  _conf("SERIAL-NO", $sSerialNo);
}

sub _getFirmware {
  my ($sFirmware, $sFirmwareDate);

  if ($OS =~ m/linux/i) {
    $sFirmware = $rhSysInfo->{"0x0000"}->{"values"}->{"Version"};
    $sFirmwareDate = $rhSysInfo->{"0x0000"}->{"values"}->{"Release Date"};
  } elsif ($OS =~ m/aix/i) {
    $sFirmware = $rhSysInfo->{"fwversion"};
  }

  _conf("FIRMWARE", $sFirmware);
  _conf("FIRMWARE-DATE", $sFirmwareDate);
}

sub _getHostname {
  my ($sHostname, $sArgs);

  if ($OS =~ m/linux/i) {
    $sArgs = "-f";
  }
  chomp($sHostname = `hostname $sArgs`);

  _conf("HOSTNAME", $sHostname);
}

sub _getCpu {

  if ($OS =~ m/linux/i) {

    chomp(my @aVals = `cat /proc/cpuinfo`);
    my @aCpuNames  = grep /^model name/, @aVals;
    my @aCpuSpeeds = grep /^cpu MHz/, @aVals;
    my @aCpuFlags  = grep /^flags/, @aVals;
    my ($sKey,$sValue);
    for (my $i=0; $i<scalar(@aCpuNames); $i++) {
      ($sKey,$sValue) = split /\s*:\s*/, $aCpuNames[$i];
      _conf("CPU-TYPE",$sValue);
      ($sKey,$sValue) = split /\s*:\s*/, $aCpuSpeeds[$i];
      _conf("CPU-SPEED",$sValue);
      ($sKey,$sValue) = split /\s*:\s*/, $aCpuFlags[$i];
      _conf("CPU-FLAGS",$sValue);
    }

  } elsif ($OS =~ m/aix/i) {

    chomp(my @aVals = `lsdev -C | grep -i proc | awk "{print \\\$1}"`);
    foreach my $sVal (@aVals) {
      chomp (my $sType = `lsattr -El $sVal | awk "/^type/ {print \\\$2}"`);
      _conf("CPU-TYPE",$sType);
    }

  }
}

sub _getMemory {
  my ($sMemory);

  if ($OS =~ m/linux/i) {
    chomp($sMemory = `cat /proc/meminfo |grep MemTotal | sed -e 's/MemTotal:\s*//'`);
  } elsif ($OS =~ m/aix/i) {
    $sMemory = $rhSysInfo->{"realmem"}." Kbytes";
  }

  _conf("MEMORY", $sMemory);
}

sub _getNet {

  if ($OS =~ m/linux/i) {

      # Retrieve information about all network interfaces
      chomp(my @aVals = `cat /proc/net/dev`);
      @aVals = map { $_ =~ m/(eth\d+)/} grep /^\s*eth/, @aVals;
      foreach my $sVal (@aVals) {
	  _conf("IFACE-NAME",$sVal);
	  chomp(my $sStdout = `/sbin/ifconfig $sVal`);
	  my ($sMac) = ($sStdout =~ m/HWaddr ([^\s]*)/);
	  _conf("IFACE-MAC",uc($sMac));
	  my ($sIp) = ($sStdout =~ m/inet addr:([^\s]*)/);
	  _conf("IFACE-IP",$sIp);
      }

  } elsif ($OS =~ m/aix/i) {

    # Retrieve information about all network interfaces
	chomp(my @aVals = `lsdev -Cc adapter | grep -i "^ent"`);
    chomp(my @aValsAvailable = `lsdev -Cc if -S A`);
    foreach my $sVal (@aVals) {
      my @aParts = split /\s+/, $sVal;
      my $sDevice = $aParts[0];
      _conf("IFACE-NAME",$sDevice);
      chomp (my $sDeviceDetails = `lscfg -vl $sDevice`);
      my ($sMac) = ($sDeviceDetails =~ m/Network Address\.+(.*)$/m);
      my @o = split / */,$sMac;
      $sMac = "$o[0]$o[1]:$o[2]$o[3]:$o[4]$o[5]:$o[6]$o[7]:$o[8]$o[9]:$o[10]$o[11]";
      _conf("IFACE-MAC",uc($sMac));
      $sDevice =~ s/ent/en/;
      my $sIface = $sDevice;
      if (grep /$sIface/, @aValsAvailable) {
	chomp(my $sIfDetails = `ifconfig $sIface`);
	my ($sIp) = ($sIfDetails =~ m/inet ([^\s]*)/);
	_conf("IFACE-IP",$sIp);
      }
    }

  }
}

sub _getOS {
  my ($sOsName, $sOsKernel);

  if ($OS =~ m/linux/i) {
    chomp($sOsName = `cat /etc/redhat-release`);
    chomp($sOsKernel = `uname -r`);
  } elsif ($OS =~ m/aix/i) {
    chomp($sOsName = `uname -s`);
    chomp($sOsKernel = `oslevel -r`);
  }

  _conf("OS-NAME", $sOsName);
  _conf("OS-KERNEL", $sOsKernel);
}

sub _getPKGs {
  if ($OS =~ m/linux/i) {
    &_getRPMs;
  } elsif ($OS =~ m/aix/i) {
    &_getLPPs;
    &_getRPMs;
  }
}

sub _getLPPs {
  _conf("__SECTION__","<PKG-LPP>");
  chomp(my @aVals = `lslpp -Lcq`);
  @aVals = map( [split(/:/)], @aVals );
  foreach my $sVal ( sort { lc("$a->[1] $a->[2]") cmp lc("$b->[1] $b->[2]") } @aVals) {
    &_line;
    _conf("PKG-NAME",$sVal->[1]." ".$sVal->[2]);
    _conf("PKG-STATE",$sVal->[5]);
    _conf("PKG-SUMMARY",$sVal->[7]);
  }
}

sub _getRPMs {
  _conf("__SECTION__","<PKG-RPM>");
  # Retrieve RPM listing and process
  chomp(my @aRPMs = `rpm -qa --qf "%{NAME}|%{VERSION}|%{RELEASE}|%{INSTALLTIME:date}|%{SUMMARY}\n"`);
  foreach my $sRPM (sort {lc($a) cmp lc($b)} @aRPMs) {
    my ($sName,$sVersion,$sRelease,$sInstall,$sSummary) = split /\|/, $sRPM;
    &_line;
    _conf("PKG-NAME","$sName $sVersion $sRelease");
    _conf("PKG-INSTALL",$sInstall);
    _conf("PKG-SUMMARY",$sSummary);
  }
}

sub _getFilesystems {
  _conf("__SECTION__","<FILESYSTEMS>");
  if ($OS =~ m/linux/i) {
    chomp(my @aFilesystems = `df -kTP`);
    shift @aFilesystems;
    foreach my $sFilesystem (sort @aFilesystems) {
      my ($sDev,$sType,$sSize,$sUsed,$sAvail,$sPct,$sMnt) = split /\s+/, $sFilesystem;
      next unless ($sType =~ m/^(jfs)|(ext)|(reiser)|(smbfs)|(nfs)|(vxfs)/);
      &_line;
      _conf("FS-DEVICE","$sDev");
      _conf("FS-TYPE","$sType");
      _conf("FS-SIZE","$sSize");
      _conf("FS-MOUNTED","$sMnt");
    }
  } elsif ($OS =~ m/aix/i) {
    chomp(my @aFilesystems = `mount`);
    shift @aFilesystems;
    foreach my $sFilesystem (sort @aFilesystems) {
      my ($sNode,$sDev,$sMnt,$sType,$sOther1) = split /\s+/, $sFilesystem, 5;
      next unless ($sType =~ m/^(jfs)|(ext)|(reiser)|(nfs)/);
      chomp(my $sStats = `df -kP $sMnt | grep -v Filesystem`);
      my ($sDevFull,$sSize,$sOther2) = split /\s+/, $sStats, 3;
      &_line;
      _conf("FS-DEVICE","$sDevFull");
      _conf("FS-TYPE","$sType");
      _conf("FS-SIZE","$sSize");
      _conf("FS-MOUNTED","$sMnt");
    }
  }
}

sub _getServices {
  _conf("__SECTION__","<SERVICES>");

  if ($OS =~ m/linux/i) {
    chomp(my $sServicesAll=`/sbin/chkconfig --list`);
    my ($sServicesStandard,$sServicesXinetd) = split /xinetd based services:\n\s*/, $sServicesAll;
    my @aServicesStandard=split /\n/, $sServicesStandard;
    foreach my $sService (sort @aServicesStandard) {
      my ($sName,$sStatus)=split /\s+/, $sService, 2;
      &_line;
      _conf("SVC-NAME",$sName);
      _conf("SVC-TYPE","standard");
      _conf("SVC-STATUS",$sStatus);
    }
    if ($sServicesXinetd) {
      my @aServicesXinetd=split /\n\s*/, $sServicesXinetd;
      foreach my $sService (sort @aServicesXinetd) {
	my ($sName,$sStatus)=split /:\s+/, $sService, 2;
	&_line;
	_conf("SVC-NAME",$sName);
	_conf("SVC-TYPE","xinetd");
	_conf("SVC-STATUS",$sStatus);
      }
    }
  } elsif ($OS =~ m/aix/i) {
    chomp(my @aServicesAll=`lssrc -a | grep -v Subsystem`);
    foreach my $sService (sort @aServicesAll) {
      my ($sBlah,$sName,$sGroup,$sPid,$sStatus)=split /\s+/, $sService;
      &_line;
      $sStatus ||= $sPid;
      _conf("SVC-NAME",$sName);
      _conf("SVC-TYPE",$sGroup);
      _conf("SVC-STATUS",$sStatus);
    }
  }
}

sub _getOpenPorts {
  _conf("__SECTION__","<PORTS>");
  chomp(my @aNetstat = `netstat -an | grep LISTEN | grep -v 127.0.0.1 | awk "{print \\\$4}"`);
  foreach my $sNetstat (sort @aNetstat) {
    my ($sAddress,$sPort,$sName);
    if ($OS =~ m/linux/i) {
      ($sAddress,$sPort) = split /:/, $sNetstat;
      chomp($sName = `getent services $sPort | awk "{print \\\$1}"`);
    } elsif ($OS =~ m/aix/i) {
      ($sAddress,$sPort) = split /\./, $sNetstat;
      chomp($sName = `grep tcp /etc/services | awk "{print \\\$1 \\\" \\\" \\\$2}" | grep " $sPort/" | awk "{print \\\$1}"`);
    }
    next unless $sPort;
    &_line;
    _conf("ADDRESS",$sAddress);
    _conf("PORT",$sPort);
    _conf("NAME",$sName);
  }
}

sub _parseSystemInfo {
  if ($OS =~ m/linux/i) {
    # Retrieve and parse all DMI information
	# remove ALL new lines from each line (record) and trailing new line 
    chomp(my @aSysInfo = `sudo /usr/sbin/dmidecode`);
	# put the new line back(except of course for the trailing new line)
    my $sContents = join("\n",@aSysInfo);
    my @aHandles = split /^Handle /m, $sContents;
	# shift off the header stuff
    shift @aHandles;
    foreach my $sRecord (@aHandles) {
      my ($sHandle,$sType,$sBytes,$sDesc,$sValues) = ($sRecord =~ m/(.*)\n\s+DMI type (\d+), (\d+) bytes.\n\s+([^\n]*)\n\t\t(.*)/s);
      my $rhHandle = {};
      $rhHandle->{type}  = $sType;
      $rhHandle->{bytes} = $sBytes;
      $rhHandle->{desc}  = $sDesc;
      $sValues =~ s/\n\s\s/\n/g;
      $sValues =~ s/\n\s/\t/g;
      my @aValues = split /\n/, $sValues;
      my %hValues = map {
	my ($sKey,$sValue) = split /:\s*/;
	$sValue =~ s/\t/\n/g;
	$sKey => $sValue;
      } @aValues;
      $rhHandle->{values} = \%hValues;
      $rhSysInfo->{$sHandle} = $rhHandle;
    }
  } elsif ($OS =~ m/aix/i) {
    chomp(my @aSysInfo = `lsattr -EOl sys0`);
    $aSysInfo[0] =~ s/^#//;
    my @aKeys = split /:/, $aSysInfo[0];
    my @aValues = split /:/,$aSysInfo[1];
    my %hSysInfo = map {
      my ($sKey,$sValue) = (shift @aKeys,shift @aValues);
      $sKey => $sValue;
    } @aValues;
    $rhSysInfo = \%hSysInfo;
  }
}

sub _conf {
  my ($sKey,$sValue) = @_;
  $sValue =~ s/^\s*//;
  $sValue =~ s/\s*$//;
  push(@aFile, sprintf "%-15s = %s", $sKey, $sValue) if $sValue;
}

sub _line {
  push(@aFile, "--------------------------------------------------");
}

sub _dump {
  print join("\r\n",@aFile)."\r\n";
}

exit &generate;
