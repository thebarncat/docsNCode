#!/bin/sh

EMAIL=jkipp@ingdirect.com
OS="aix linux"
DIR="/tmp"
COLLECT="${DIR}/collect.$$.txt"
CHANGES="${DIR}/changes.$$.txt"
DIFFS="${DIR}/differences.$$.txt"
LDAPUSER=$1
LDAPPASSWD=$2

printf "Host information can be found here:\n" | tee $COLLECT
printf "    http://cvs.ingdirect.com/viewcvs/scm/hosts\n\n" | tee -a $COLLECT
printf "DNS information can be found here:\n" | tee -a $COLLECT
printf "    http://cvs.ingdirect.com/viewcvs/scm/services/dns\n\n" | tee -a $COLLECT
printf "Active Directory information can be found here:\n" | tee -a $COLLECT
printf "    http://cvs.ingdirect.com/viewcvs/scm/services/active_directory\n\n" | tee -a $COLLECT
# change to the directory of this script: /home/cmsys/scm/scripts
cd `dirname $0`
printf "=====================\n" | tee -a $COLLECT
printf "COLLECTION LOG\n" | tee -a $COLLECT
printf "=====================\n" | tee -a $COLLECT
printf "Collecting AD groups\n" | tee -a $COLLECT
ldapsearch -LLL -h ingdedc01 -D "$LDAPUSER@ingdirect.com" -w "$LDAPPASSWD" -x -b "dc=ingdirect,dc=com" "objectCategory=CN=Group,CN=Schema,CN=Configuration,DC=ingdirect,DC=com" dn > ../services/active_directory/groups 2>&1
printf "Collecting AD group membership\n" | tee -a $COLLECT
ldapsearch -LLL -h ingdedc01 -D "$LDAPUSER@ingdirect.com" -w "$LDAPPASSWD" -x -b "dc=ingdirect,dc=com" "objectCategory=CN=Group,CN=Schema,CN=Configuration,DC=ingdirect,DC=com" member > ../services/active_directory/membership 2>&1
printf "Collecting Host information\n" | tee -a $COLLECT
cat ../hosts/hosts.csv | ./cm-hosts.pl $OS 2>&1 | tee -a $COLLECT
printf "Collecting DNS information\n" | tee -a $COLLECT
./cm-dns.pl ../services/dns 10.152.5.17=ingdedev.com 10.20.1.10=ingqa.com 10.152.7.101=ingdirect.com 2>&1 | tee -a $COLLECT
#export CVS_RSH=ssh
#export CVSROOT=:ext:cvs.ingdirect.com:/home/cvsroot
export CVSROOT=/home/cvsroot
printf "=====================\n"
printf "FILE CHANGES\n"
printf "=====================\n\n"
# change to the /home/cmsys/scm master dir
cd ..
# update these working dir to the specified repos,(-d), prune empty # dirs (-P) 
# outputs the folder/file where that have changes
cvs -q update -dPA hosts services/dns services/active_directory 2>&1 | tee $CHANGES
printf "=====================\n"
printf "FILE DIFFERENCES\n"
printf "=====================\n\n"
# shows the changes were made to updated files:  -u unified output 
cvs -q diff -u hosts services/dns services/active_directory 2>&1 | perl -pe 's/Index/\n\n===================================================================\nIndex/g' | tee $DIFFS
cvs commit -m "Daily commit `date +'%Y-%m-%d %X'`" hosts services/dns services/active_directory
cd -

/usr/bin/ing-mail.pl -F "Configuration Management <cmsys@ingdirect.com>" -t "$EMAIL" -s "Configuration Monitoring" -M "$COLLECT" -f "$CHANGES,$DIFFS"
rm -f $COLLECT $CHANGES $DIFFS
