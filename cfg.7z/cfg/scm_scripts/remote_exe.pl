#!/usr/bin/perl -w
use strict;
use POSIX qw(:sys_wait_h);
use Net::SSH::Perl;
my $MAX_KIDS = 10;
# PUT YOUR PW HERE
my $pw = "";

############################################
# INSTALL RPM OR RUN REMOTE CMD
#my $cmd = "sudo rpm -U --force http://kickstart.ingdirect.com/misc/ots-1.2-1.noarch.rpm";
#my $cmd = "sudo rpm -i --nodeps http://kickstart.ingdirect.com/misc/FileSystemScanner-1.0-1.aix5.3.noarch.rpm";
#my $cmd = "asroot rm -rf /var/cfengine; sudo rpm -U --force cfengine-2.2.10-1.aix5.3.ppc.rpm";
my $cmd = "sudo rpm -e cfengine";
#my $cmd = "sudo yum -y install cfengine";

#my $key = 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAIEAwbctW7WGtOmH5WfZ6N00YywDEnF4P77X0uoM98d5WcNGcBpLRE7LYuKny3AeID05QpbkN9bdkBMB8F9NCyVqBML+zuSJdo68UcDrqkDpcp7/UbdtqjAL8EerjfaN4cNWUAwBtX6r92NmNBFEk2reLd78SzmDwmr7slDq6keETUM= jkipp@lxdepcfg.ingdirect.com'; 
#my $cmd = "mkdir ~/.ssh; touch ~/.ssh/authorized_keys2; echo $key >> ~/.ssh/authorized_keys2";

#my $cmd = q!perl -e '@users=("uucp","lp","rpm"); foreach(@users) { system "/usr/bin/getent passwd | grep $_" }'!;

# SEND KEYy cmds, keys must be on onle line:
my $key = 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAxaYK1UqKLUCyiP+v52J87EGV761naymGZbzAdSTU5CfAubNMsYiMV2BNDgOR9fi3RbvMOykZavTfyyFivC4Hbjyfb77oMiU+W5Z wYz6zOMSsdmf2kbma6KN3asm0crZZnrlKppV1/euu7FhZtsKr1KQOj0XwBCXke5m7lh3838lmILqMeHG1ZBcYXSN5C8TSskQ0Chsxr7AtwZqCPSPGpU1SGryZjeIsbgfj2ZwU9E+1Y1enEeJoV q+cyu3WcC644UKPcKdH6BCMm7NYuEObN5XD15dKnpGLNQxyn/7CDkyLqnSWZBXBuarbRyjBL3oUd92uS/7zSlo7C2y0d0qUdw== jkipp@J5JW6C1';
#my $key2 = 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAIEAwbctW7WGtOmH5WfZ6N00YywDEnF4P77X0uoM98d5WcNGcBpLRE7LYuKny3AeID05QpbkN9bdkBMB8F9NCyVqBML+zuSJdo68Uc DrqkDpcp7/UbdtqjAL8EerjfaN4cNWUAwBtX6r92NmNBFEk2reLd78SzmDwmr7slDq6keETUM= jkipp@lxdepcfg.ingdirect.com';
#my $cmd = "mkdir ~/.ssh; touch ~/.ssh/authorized_keys2; echo $key >> ~/.ssh/authorized_keys2; echo $key2 >> ~/.ssh/authorized_keys2";

############################################

open(F, "<hosts.txt") or die "cant read file: $!";
my @hosts = <F>;
my $kids = 0;
foreach my $host (@hosts) {
	    # wait returns the deceased kid proc and it's exit stat is in $?
		my $dead_pid = wait if ( $kids  >= $MAX_KIDS );
		my $msg = '';
	 	my $pid = fork; # child PID in the parent
		#warn "$pid is processing $host\n";
		if ($pid == 0) {  # child continue and execute
			$host =~ s/\r\n$//;
			$host =~ s/^\s+|\s+$//;
			#system("scp cfengine-2.2.10-1.aix5.3.ppc.rpm $host:") ==0 or die "cmd fialed: $?";
			my ($rc,$err,$out) = rmt_cmd($host);
			if ($rc) {
				$msg = "\tFAILURE: $host\n"; 
				$msg .= "\t\t $out" if $out;
				$msg .= "\t\t $err" if $err;
			} else {
				$msg = "\tSUCCESS: $host\n";
				#$msg = $out;
			}
			#open (F, ">$host") or die "cant open: $!";
			#print F $msg;
			print  $msg;
			#close F;
			# if the child returns, then just exit;
			exit;
		} else { # next if parent
			$kids++;
		}
}

# wait for ANY child proc to die and do a non blocking wait for pending  zombies
# $SIG{CHLD} = sub { 1 while ( waitpid(-1, WNOHANG)) > 0 };
# waitpid( -1, &WNOHANG );

# reap child - make sure it exits. this is just a safety check for # errant kids 
# keep going until there are no children left (wait returns -1 when this happens)
#waitpid( $pid, 0 );
1 until -1 == wait;

sub rmt_cmd  {
	my $host = shift;
	my $ssh = eval { Net::SSH::Perl->new($host, protocol => '2', debug => 0) };
	# eval returns true on success
	# if eval returns not true: return an error code(1), error msg, and out which is always 0  
	unless ($ssh) { 
		return (1, "Could not CONNECT to $host.  SYS MSG: $@",0);
	}

	my $rc =  eval { $ssh->login( $ENV{USER}, $pw ) };
	unless ($rc) {
		return (1,"Could not LOGIN to host '$host'.  SYS MSG: $@", "");
	}

	my ($out,$err,$exit_rc) = $ssh->cmd($cmd);
	$err = "CMD FAILURE: " . $err if $exit_rc;
	return ($exit_rc,$err,$out);
}
