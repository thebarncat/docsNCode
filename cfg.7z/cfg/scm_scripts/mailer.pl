#!/usr/bin/perl

use strict;
use Mail::Sender;
use Getopt::Std;
use Sys::Hostname;

my $usage = <<HELP;
usage: mailer.pl [-F from] [-t to] [-c cc] [-s subject] [-m message] [-f files]           
                                                                           
Command Line Options                                                    
     -F from     : User which email appears to be from (DEFAULT:           
                   $ENV{USER}                                              
     -t to       : Comma-separated list of email addresses (DEFAULT:       
                   $ENV{USER}                                              
     -c cc       : Comma-separated list of email addresses                 
     -s subject  : Subject of email message                                
     -m message  : Body of email message                                   
     -f files    : Comma-separated list of files to attach                 
     -h          : this help message                

e.g. mailer.pl -t jkipp\@ingdirect.com -s "test mail"  -m "blah blah"

HELP

my $smtp = "smtp.ingdirect.com";
my %opts;
getopts("H:F:t:c:s:m:f:h",\%opts);
die $usage if $opts{h};


sendMail( from    => $opts{'F'},
	   to      => $opts{'t'},
	   cc      => $opts{'c'},
	   subject => $opts{'s'},
	   msg     => $opts{'m'},
	   file    => $opts{'f'},
);


sub sendMail{
	my %params = @_;	
	$params{smtp} = $smtp;
	$params{from} = $ENV{USER}.'@'.hostname() unless $params{from}; 
	$params{subject} = "no subject" unless $params{subject}; 
	$params{msg} = "no message" unless $params{msg}; 
	
	my $sender = new Mail::Sender;
	my $mail;
	if ($params{file}) {
		$mail = $sender->MailFile(\%params);
     } else {
	    $mail = $sender->MailMsg(\%params);
    }

	warn $Mail::Sender::Error unless (ref $mail); 

}

