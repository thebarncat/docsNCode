#!/usr/bin/perl 
use strict;
use Net::SSH::Perl;
my $pw = "xxxxxx";

############################################
# INSTALL RPM OR RUN REMOTE CMD
#my $cmd = "sudo rpm -U --force http://kickstart.ingdirect.com/misc/ots-1.2-1.noarch.rpm";
#my $cmd = "sudo rpm -i --nodeps http://kickstart.ingdirect.com/misc/FileSystemScanner-1.0-1.aix5.3.noarch.rpm";
#my $cmd = "sudo rpm -U http://kickstart/aix/5.3/ing/RPMS/cfengine-2.2.10-1.aix5.3.ppc.rpm";
#my $cmd = "sudo rpm -U cfengine-2.2.10-1.aix5.3.ppc.rpm";
#my $cmd = "rpm -q httpd";
#my $cmd = "sudo rpm -e cfengine; sleep 2; asroot rm -rf /var/cfengine";

my $key = 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAIEAwbctW7WGtOmH5WfZ6N00YywDEnF4P77X0uoM98d5WcNGcBpLRE7LYuKny3AeID05QpbkN9bdkBMB8F9NCyVqBML+zuSJdo68UcDrqkDpcp7/UbdtqjAL8EerjfaN4cNWUAwBtX6r92NmNBFEk2reLd78SzmDwmr7slDq6keETUM= jkipp@lxdepcfg.ingdirect.com ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAxaYK1UqKLUCyiP+v52J87EGV761naymGZbzAdSTU5CfAubNMsYiMV2BNDgOR9fi3RbvMOykZavTfyyFivC4Hbjyfb77oMiU+W5ZwYz6zOMSsdmf2kbma6KN3asm0crZZnrlKppV1/euu7FhZtsKr1KQOj0XwBCXke5m7lh3838lmILqMeHG1ZBcYXSN5C8TSskQ0Chsxr7AtwZqCPSPGpU1SGryZjeIsbgfj2ZwU9E+1Y1enEeJoVq+cyu3WcC644UKPcKdH6BCMm7NYuEObN5XD15dKnpGLNQxyn/7CDkyLqnSWZBXBuarbRyjBL3oUd92uS/7zSlo7C2y0d0qUdw== jkipp@J5JW6C1';

my $cmd = "mkdir ~/.ssh; touch ~/.ssh/authorized_keys2; echo $key >> ~/.ssh/authorized_keys2";

# as cmsys can do like this:  sudo su nezumiu -c "mkdir /tmp/fuzz" 

my $cmd = q!perl -e '@users=("uucp","lp","rpm"); foreach(@users) { system "/usr/bin/getent passwd | grep $_" }'!;
#my $cmd = "sudo /usr/sbin/dmidecode | grep \"Product Name\" | head -1 |awk \"{print \\\$3}\"| sed -e 's/-.*//'";
#my $cmd = "sudo /usr/sbin/dmidecode | grep \"Product Name\" | head -1 | sed -e 's/Product Name: //'";

# USE YUM NEXT TIME FOR Linux
#my $cmd = "sudo rpm -U http://kickstart/redhat/sysinfo-1.0-2.i386.rpm";
#my $cmd = "asroot rm -f /var/run/infod.pid; sudo rpm -e sysinfo; sudo rpm -U http://kickstart/aix/5.3/ing/RPMS/sysinfo-1.0-2.aix5.3.ppc.rpm"; 

############################################

open(F, "<snorts") or die "cant read file: $!";
my @hosts = <F>;
foreach my $host (@hosts) {
     		my $msg = '';
			$host =~ s/\r\n$//;
			$host =~ s/^\s+|\s+$//;
			my ($rc,$err,$out) = rmt_cmd($host);
			if ($rc) {
				$msg = "\tFAILURE: $host\n"; 
				$msg .= "\t\t $out" if $out;
				$msg .= "\t\t $err" if $err;
			} else {
				#$msg = "SUCCESS: $host:$out";
				#$msg = "$host:$out";
				#$msg = $out;
			}
			print  $msg;
			sleep 2;
}

sub rmt_cmd  {
	my $host = shift;
	my $ssh = eval { Net::SSH::Perl->new($host, protocol => '2', debug => 0) };
	# eval returns true on success
	# if eval returns not true: return an error code(1), error msg, and out which is always 0  
	unless ($ssh) { 
		return (1, "Could not CONNECT to $host.  SYS MSG: $@",0);
	}

	my $rc =  eval { $ssh->login( $ENV{USER}, $pw ) };
	unless ($rc) {
		return (1,"Could not LOGIN to host '$host'.  SYS MSG: $@", "");
	}

	my ($out,$err,$exit_rc) = $ssh->cmd($cmd);
	#  **** ADD BACK IF NEEDED ****
	#$err = "CMD FAILURE: " . $err if $exit_rc;
	return ($exit_rc,$err,$out);
}
