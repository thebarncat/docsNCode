#!/bin/ksh

NimServer="axdepnim"   # production nim server
MountPoint="/tmp/mksysb"

# Create the Image Name
Date=`date +"%m%d%y"`
Server=`uname -n`
ImageName="mksysb_$Server.$Date"

# If /tmp/mksysb is not mounted, Mount it.
Test=`mount | grep $MountPoint | wc -l`
if ((! $Test))
then
  echo "Mounting $MountPoint..."
  mount $NimServer:/nim/mksysb $MountPoint

  # Check to see if it mounted
  Test=`mount | grep $MountPoint | wc -l`
  if ((! $Test))
  then
    echo "$MountPoint Not Mounted"
    exit;
  fi

fi

# Create MKSYSB Image on $MountPoint. umount when done
echo "Creating Image..."
mksysb -e -i $MountPoint/$ImageName
sleep 5
umount $MountPoint
