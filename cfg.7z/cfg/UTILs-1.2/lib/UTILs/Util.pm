package UTILs::Util;

BEGIN {
  require Exporter;
  #our (@ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  @ISA         = qw(Exporter);
  @EXPORT      = qw(&debug &lpad &rpad);
  %EXPORT_TAGS = ();
  @EXPORT_OK   = qw(&debug &lpad &rpad &help &readConfig &getOptions &dateReplace &getProfileDateFromDate &getDateFromProfileDate &reportToBigBrother &execute &getMD5);
}

#use strict;
use UTILs::Error qw(&handleError);
use Text::Wrap;
use Getopt::Std;
use Time::Local;
use Digest::MD5;

# Debugging level
$UTILs::Util::DebugLevel = 0;

# Define full month names
%UTILs::Util::Months = (
		      1   => "January",
		      2   => "February",
		      3   => "March",
		      4   => "April",
		      5   => "May",
		      6   => "June",
		      7   => "July",
		      8   => "August",
		      9   => "September",
		      10  => "October",
		      11  => "November",
		      12  => "December"
		     );

# Define full day names
%UTILs::Util::Days = (
		    0 => "Sunday",
		    1 => "Monday",
		    2 => "Tuesday",
		    3 => "Wednesday",
		    4 => "Thursday",
		    5 => "Friday",
		    6 => "Saturday"
		   );

################################################################
#
# Subroutine:  getOptions
#
# Description: Process the command line options, arguments, and
#              additional help messages.
#
# Params:
#  options      - Array of command line option hashes (keys: opt,short,long,default)
#  arguments    - Array of command line argument hashes (keys: short,long)
#  additional   - Any additional help to be displayed
#  opts_ref     - Reference to options hash to be set (else use $main::opts)
#  args_ref     - Reference to argument array (else leaves @ARGV)
#
# Returns:
#  1            - Help text
################################################################
sub getOptions {
  my %hParams=@_;
  unless ($hParams{opts_ref}) {
    $main::opts = {};
    $hParams{opts_ref} = $main::opts;
  }
  my $sUsage = "usage: $0";
  my $nShortLen=10;
  my (@aHelp, $sGetoptString);

  # Add default options
  push @{$hParams{options}}, (
			      {
			       opt     => "d",
			       short   => "level",
			       long    => "Set the debugging level",
			       default => "0"
			      },
			      {
			       opt     => "?",
			       long    => "Display this help message"
			      }
			     );

  # Add the 'options' to the usage string
  if ( $hParams{options} ) {
    push @aHelp, "\nCommand Line Options";
    foreach my $hOption (@{$hParams{options}}) {
      $sUsage .= " [-".$hOption->{opt};
      $sGetoptString .= $hOption->{opt};
      if ( $hOption->{short} ) {
	$sUsage .= " ".$hOption->{short};
	$sGetoptString .= ":";
      }
      $sUsage .= "]";
      push @aHelp, wrap(""," " x ($nShortLen+6),sprintf("  -%-${nShortLen}s : %s %s",
							$hOption->{opt}." ".($hOption->{short} ? $hOption->{short} : ""),
							$hOption->{long},
							$hOption->{default} ? "(DEFAULT: $hOption->{default})" : ""
						       ));
      # Set up default values if provided
      $hParams{opts_ref}->{ $hOption->{opt} } = $hOption->{default} if defined($hOption->{default});
    }
  }

  # Add the 'arguments' to the usage string
  if ( $hParams{arguments} ) {
    push @aHelp, "\nCommand Line Arguments";
    foreach my $hArgument (@{$hParams{arguments}}) {
      $sUsage .= " ".$hArgument->{short};
      push @aHelp, wrap(""," " x ($nShortLen+6),sprintf("  %-${nShortLen}s  : %s %s",$hArgument->{short},$hArgument->{long}));
    }
  }

  # Add any additional help messages
  if ( $hParams{additional} ) {
    push @aHelp, "\nAdditional Help";
    foreach my $hAdditional (@{$hParams{additional}}) {
      push @aHelp, wrap("   ","",$hAdditional);
    }
  }

  # Join all help text
  my $sHelpText = join("\n", $sUsage, @aHelp);

  # Process the command line options
  getopts($sGetoptString, $hParams{opts_ref}) || &help( text => "\n".$sHelpText, code => 1 );

  # Set the debugging level
  $UTILs::Util::DebugLevel = $hParams{opts_ref}->{d};

  # Display Help if that's what we want
  &help( text => $sHelpText ) if $hParams{opts_ref}->{'?'};

  # If a reference is provided, set it
  if ($hParams{args_ref}) {
    $hParams{args_ref} = \@ARGV;
  }

  # Return the help text
  return $sHelpText;
}

################################################################
#
# Subroutine:  help
#
# Description: Display help message, along with optional
#              error message.  Also exits with the given
#              error code.
#
# Params:
#  msg          - Error message to display
#  text         - Main help text
#  code         - Exit code which will be returned to calling script
#
################################################################
sub help {
  my %hParams=@_;

  print "\nERROR: $hParams{msg}\n\n" if $hParams{msg};
  print "$hParams{text}\n";

  exit $hParams{code};
}

################################################################
#
# Subroutine:  debug
#
# Description: Display debugging information based on
#              debugging level
#
# Params: (non-hash)
#  1 = Debugging message to be displayed
#  2 = Debugging level required for display of message
#
################################################################
sub debug {
  my $sMsg = shift;
  my $nLevel = shift || 1;
  print STDERR wrap("  "x($nLevel-1),"  "x($nLevel-1),"$sMsg") if ($nLevel <= $UTILs::Util::DebugLevel);
}

################################################################
#
# Subroutine:  lpad
#
# Description: Left pad a given string using the given
# character.  If no character is given, '0' is assumed.
#
# Params: (non-hash)
#  1 = string  - String to pad
#  2 = length  - Desired pad length
#  3 = char    - Character to pad with
#
################################################################
sub lpad {
  my ($string, $length, $char) = (shift,shift,shift || '0');
  return $char x ($length - length($string)) . $string;

}

################################################################
#
# Subroutine:  rpad
#
# Description: Right pad a given string using the given
# character.  If no character is given, '0' is assumed.
#
# Params: (non-hash)
#  1 = string  - String to pad
#  2 = length  - Desired pad length
#  3 = char    - Character to pad with
#
################################################################
sub rpad {
  my ($string, $length, $char) = (shift,shift,shift || '0');
  return $string . $char x ($length - length($string));

}

################################################################
#
# Subroutine:  readConfig
#
# Description: Reads a configuration file and returns a hash
# of all the sections.  Any values that do not belong to a
# section are placed in a special section called 'GLOBAL'.
#
# Params: (non-hash)
#  1 = filena  - name of configuration file to read
#
################################################################
sub readConfig {
  my $sFilename=shift;
  my %hConfig;

  # Open the config file
  &debug("Opening configuration file: $sFilename ... ",2);
  unless (open(CONFIG,$sFilename)) {
    &debug("ERROR!\n",2);
    &handleError(
		 msg  => "Could not open configuration file '$sFilename'.  The system reported: $!",
		 caller => [caller(0)]
		);
  }
  &debug("done\n",2);

  # Initialize the section name for GLOBAL
  my $sSection="GLOBAL";

  # Process each line of the config file
  &debug("Reading configuration file\n",2);
  while (<CONFIG>) {
    chomp;
    ($_) = split /#/;
    next if /^\s*$/;
    if (/^\[/) {
      ($sSection) = /\[(.*)\]/;
      $hConfig{$sSection} = {SECTION => $sSection};
      &debug("SECTION: $sSection\n",3);
      next;
    }
    my ($sKey,$sValue) = /^([^=]*)=([^#]*)/;
    $sKey =~ s/^\s*//;
    $sKey =~ s/\s*$//;
    $sValue =~ s/^\s*//;
    $sValue =~ s/\s*$//;
    $hConfig{$sSection}->{$sKey} = $sValue;
    &debug("  ".$sKey." = ".$hConfig{$sSection}->{$sKey}."\n",3);
  }

  # Close file
  close(CONFIG);

  return %hConfig;
}

################################################################
#
# Subroutine:  dateReplace
#
# Description: Replaces date/time patterns in a string.  Patterns
#              are surrounded by braces.  Valid patterns and how
#              they would be replaced for Tuesday, January
#              8, 2002 at 3:45:37pm are:
#
#              yyyy    : 4-digit year          2002
#              yy      : 2-digit year          02
#              m       : non-padded month      1
#              mm      : 2-digit month         01
#              Mon     : 3-letter month        Jan
#              mon     : 3-letter month        jan
#              MON     : 3-letter month        JAN
#              Month   : month                 January
#              month   : month                 january
#              MONTH   : month                 JANUARY
#              d       : non-padded day        8
#              dd      : 2-digit day           08
#              Day     : 3-letter day          Tue
#              day     : 3-letter day          tue
#              DAY     : 3-letter day          TUE
#              Dayfull : day of week           Tuesday
#              dayfull : day of week           tuesday
#              DAYFULL : day of week           TUESDAY
#              wd      : 1-digit day of week   2
#              hh      : 2-digit 24-hour       15
#              HH      : 2-digit 12-hour       03
#              h       : 24-hour of day        15
#              H       : 12-hour of day        3
#              mi      : 2-digit minute        45
#              ss      : 2-digit second        37
#              ap      : am or pm              pm
#              AP      : AM or PM              PM
#
# Params: (non-hash)
#  1      = string containing patterns
#
#         (hash)
#  time   - Date to use for replacement (array from localtime)
#  days   - Offset in days from now (or time) for replacement
#
################################################################
sub dateReplace {
  my $sString=shift;
  my %hParams=@_;
  my @aDate;

  @aDate = $hParams{time} ? @{$hParams{time}} : localtime;
  @aDate = localtime(timelocal(@aDate) + ($hParams{days} * 86400));
  my ($year,$month,$day) = ($aDate[5]+1900, $aDate[4]+1, $aDate[3]);
  my %hPatterns;
  $hPatterns{'yyyy'}     = &lpad($year,4);
  $hPatterns{'yy'}       = substr($hPatterns{'yyyy'},2);
  $hPatterns{'m'}        = $month;
  $hPatterns{'mm'}       = &lpad($hPatterns{'m'},2);
  $hPatterns{'Month'}    = $UTILs::Util::Months{$hPatterns{'m'}};
  $hPatterns{'month'}    = lc($hPatterns{'Month'});
  $hPatterns{'MONTH'}    = uc($hPatterns{'Month'});
  $hPatterns{'Mon'}      = substr($hPatterns{'Month'},0,3);
  $hPatterns{'mon'}      = lc($hPatterns{'Mon'});
  $hPatterns{'MON'}      = uc($hPatterns{'Mon'});
  $hPatterns{'d'}        = $day;
  $hPatterns{'dd'}       = &lpad($hPatterns{'d'},2);
  $hPatterns{'wd'}       = $aDate[6];
  $hPatterns{'Dayfull'}  = $UTILs::Util::Days{$hPatterns{'wd'}};
  $hPatterns{'dayfull'}  = lc($hPatterns{'Dayfull'});
  $hPatterns{'DAYFULL'}  = uc($hPatterns{'Dayfull'});
  $hPatterns{'Day'}      = substr($hPatterns{'Dayfull'},0,3);
  $hPatterns{'day'}      = lc($hPatterns{'Day'});
  $hPatterns{'DAY'}      = uc($hPatterns{'Day'});
  $hPatterns{'h'}        = $aDate[2];
  if ($hPatterns{'h'} < "12") {
    $hPatterns{'H'}      = $hPatterns{'h'} eq "0" ? 12 : $hPatterns{'h'};
    $hPatterns{'ap'}     = "am";
  } else{
    $hPatterns{'H'}      = $hPatterns{'h'} eq "12" ? 12 : $hPatterns{'h'} - 12;
    $hPatterns{'ap'}     = "pm";
  }
  $hPatterns{'HH'}       = &lpad($hPatterns{'H'},2);
  $hPatterns{'AP'}       = uc($hPatterns{'ap'});
  $hPatterns{'hh'}       = &lpad($hPatterns{'h'},2);
  $hPatterns{'mi'}       = &lpad($aDate[1],2);
  $hPatterns{'ss'}       = &lpad($aDate[0],2);

  foreach my $sKey (keys %hPatterns) {

    $sString =~ s/\{$sKey\}/$hPatterns{$sKey}/g || next;
    &debug("Replacing {".$sKey."} with ".$hPatterns{$sKey}."\n",3); 

  }

  return $sString;
}

################################################################
#
# Subroutine:  getProfileDateFromDate
#
# Description: Given a date string (yyyymmddhhmiss), this
# function returns the equivalent profile date string
#
# Params: (non-hash)
#  1 = Datestring to convert
#
################################################################
sub getProfileDateFromDate {
  my $sDate=shift;
  # Calculate the Profile Date based on the provided process date.
  # This is from Tom Hirt
  my $nProfileJulian=47117;
  my @aTimeParts = ( $sDate =~ m/(\d\d\d\d)(\d\d)(\d\d)(\d\d)?(\d\d)?(\d\d)?/ );
  @aTimeParts = ($aTimeParts[5],$aTimeParts[4],$aTimeParts[3],$aTimeParts[2],$aTimeParts[1]-1,$aTimeParts[0]-1900);
  my $nTime=timelocal(@aTimeParts) - 18000;
  my $nEpoch = int($nTime/(60*60*24));
  my $nProfileDate=$nProfileJulian+$nEpoch;

  return $nProfileDate;
}

################################################################
#
# Subroutine:  getDateFromProfileDate
#
# Description: Given a profile date string, this
# function returns the equivalent date string (yyyymmddhhmiss)
#
# Params: (non-hash)
#  1 = Profile Date to convert
#
################################################################
sub getDateFromProfileDate {
  my $nProfileDate=shift;

  my $nProfileJulian=47117;
  my $nEpoch = $nProfileDate - $nProfileJulian;
  my $nTime  = ($nEpoch * (60 * 60 * 24)) + 18000;

  my @aDate = localtime($nTime);
  return &lpad($aDate[5]+1900,2).&lpad($aDate[4]+1,2).&lpad($aDate[3],2).&lpad($aDate[2],2).&lpad($aDate[1],2).&lpad($aDate[0],2);

}


################################################################
#
# Subroutine:  execute
#
# Description: Used to execute an external program either on
# the local machine, or on a remote machine.  It returns the
# exit value, STDOUT, and STDERR.
#
# Returns:
#  1 = Return value of the script
#  2 = STDOUT
#  3 = STDERR
#
# Params: (non-hash)
#  name       - name of executable program to run
#
# Params: (hash)
#  args       - Reference to a list of command line
#               arguments for the external program
#  host       - Hostname to execute script on (else localhost)
#  port       - SSH Port on remote host (else 22)
#  user       - Username to execute remote program
#  pass       - Password to execute remote program
#
################################################################
sub execute {
  my ($sCommand,%hParams) = (shift,@_);
  my ($nRC,$sStdout,$sStderr);

  if ($hParams{host}) {
    ($nRC,$sStdout,$sStderr) = &_executeRemote($sCommand,%hParams);
  } else {
    ($nRC,$sStdout,$sStderr) = &_executeLocal($sCommand,%hParams);
  }

  return ($nRC,$sStdout,$sStderr);
}

################################################################
#
# Subroutine:  _executeLocal
#
# Description: see execute
#
################################################################
sub _executeLocal {
  my ($sCommand,%hParams) = (shift,@_);
  my $sRedirectPrefix="/tmp/.UTILs-Util-_executeLocal";
  my $sStdoutFile = "$sRedirectPrefix.stdout.$$";
  my $sStderrFile = "$sRedirectPrefix.stderr.$$";
  my ($nRC,$sStdout,$sStderr);

  # Build command line
  $sCommand .= " \"".join("\" \"",@{$hParams{args}})."\"" if $hParams{args};
  $sCommand .= " > $sStdoutFile 2> $sStderrFile";

  &debug("Executing $sCommand ... ",2);
  my $nRC=(system($sCommand))/256;
  &debug("returned $nRC\n",2);

  ### Get STDOUT
  unless ( open(FH_STDOUT, $sStdoutFile) ) {
    &handleError(
		 msg  => "Could not open file '$sStdoutFile'.  The system reported: $!",
		 caller => [caller(0)]
		);
  }
  my @aContents=<FH_STDOUT>;
  $sStdout=join('',@aContents);
  close FH_STDOUT;
  unlink $sStdoutFile;

  ### Get STDERR
  unless ( open(FH_STDERR, $sStderrFile) ) {
    &handleError(
		 msg  => "Could not open file '$sStderrFile'.  The system reported: $!",
		 caller => [caller(0)]
		);
  }
  my @aContents=<FH_STDERR>;
  $sStderr=join('',@aContents);
  close FH_STDERR;
  unlink $sStderrFile;

  return ($nRC, $sStdout, $sStderr);

}

################################################################
#
# Subroutine:  _executeRemote
#
# Description: see execute
#
################################################################
sub _executeRemote {
  my ($sCommand,%hParams) = (shift,@_);
  $hParams{user} ||= $ENV{USER};
  $hParams{port} ||= 22;

  # We will execute the remote command via SSH
  require Net::SSH::Perl;

  &debug("Connecting to $hParams{host}:$hParams{port} ... ",2);
  my $oSsh = eval { Net::SSH::Perl->new($hParams{host},
					protocol => '2',
					port     => $hParams{port},
					debug    => ($UTILs::Util::DebugLevel > 3 ? 1 : 0),
					privileged => 0) };
  unless ($oSsh) {
    &debug("ERROR!\n",2);
    if ($hParams{continue}) {
	return (1,"","Could not connect to host '$hParams{host}'.  The system reported: $@");
    } else {
	&handleError(
		     msg  => "Could not connect to $hParams{host}.  The system reported: $@",
		     caller => [caller(0)]
		     );
    }
  }
  &debug("done\n",2);

  &debug("Logging in as $hParams{user} ... ",2);
  my $bSuccess = eval { $oSsh->login($hParams{user}, $hParams{pass}) };
  unless ( $bSuccess ) {
    &debug("ERROR!\n",2);
    if ($hParams{continue}) {
	return (1,"","Could not login to host '$hParams{host}' as user '$hParams{user}'.  The system reported: $@");
    } else {
	&handleError(
		     msg  => "Could not login to $hParams{host} as user '$hParams{user}'.  The system reported: $@",
		     caller => [caller(0)]
		     );
    }
  }
  &debug("done\n",2);

  # Build command line
  $sCommand .= " \"".join("\" \"",@{$hParams{args}})."\"" if $hParams{args};

  # Execute the remote command
  &debug("Executing $hParams{user}\@$hParams{host}:\"$sCommand\" ... ",2);
  my ($sStdout,$sStderr,$nRC) = eval { $oSsh->cmd($sCommand) };
  &debug("returned $nRC\n",2);

  return ($nRC,$sStdout,$sStderr);
}

################################################################
#
#  Subroutine: getMD5
#
#  Description: Retrieve's an md5sum for a given file
#
################################################################s
sub getMD5 {
  my $sFilename=shift;

  unless (open(FILE, $sFilename)) {
    &handleError(
		 msg    => "Could not open file '$sFilename' to check MD5.  The system reported: $!",
		 caller => [caller(0)]
		);
  }

  # Check in binary mode if it's a binary file
  binmode(FILE) if (-B $sFilename);

  my $oMD5 = Digest::MD5->new;
  while (<FILE>) {
    $oMD5->add($_);
  }

  close(FILE);

  my $sMD5= $oMD5->hexdigest;
  &debug("md5: $sMD5\n");

  return $sMD5;
}

1;
