package UTILs::FTP;

BEGIN {
  require Exporter;
#  our (@ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  @ISA         = qw(Exporter);
  @EXPORT      = qw();
  %EXPORT_TAGS = ();
  @EXPORT_OK   = qw(&getFiles &putFiles &transferFiles &listFiles);
}

use strict;
use UTILs::Error;
use UTILs::Util;
use Net::FTP;

# Pull default values from the environment
$UTILs::FTP::HOSTNAME   = $ENV{FTP_HOSTNAME};
$UTILs::FTP::PORT       = $ENV{FTP_PORT} || '21';
$UTILs::FTP::USERNAME   = $ENV{FTP_USERNAME} || $ENV{USER};
$UTILs::FTP::PASSWORD   = $ENV{FTP_PASSWORD};

# Keep global list of connections
%UTILs::FTP::ghConnections;

################################################################
#
# Subroutine:  getFiles
#
# Description: See transferFiles
#
################################################################
sub getFiles {
  return transferFiles(@_, method => "GET");
}

################################################################
#
# Subroutine:  putFiles
#
# Description: See transferFiles
#
################################################################
sub putFiles {
  return transferFiles(@_, method => "PUT");
}

################################################################
#
# Subroutine:  transferFiles
#
# Description: Transfer files from/to a remote server (FTP GET/PUT).
# The {files} key is the list of files to be transfered.  The transfer
# mode may also be provided by prepending (mode) to the filename,
# where mode is either a (ascii) or i (binary).
# So a filename to be transferred in binary mode could
# be provided with:
#    files => ["(i)/path/to/file1=newFilename"]
#
# Params:
#  files       - List of files to transfer
#  host        - Hostname of FTP server
#  port        - Port of FTP server
#  user        - Remote username on FTP server
#  pass        - Remote password for user on FTP server
#  type        - Transfer type (a, i, etc.)
#  method      - Transfer method (put, get)
#  continue    - Whether or not to continue when transferring
#                multiple files when encountering an error
#
################################################################
sub transferFiles {
  my %hParams=@_;
  my ($oFtp, $bResult);
  my $sFtpMethod=lc($hParams{method});
  my (@aFilesTransferred,@aFilesNotTransferred);
  my $sTransferSeverity=$hParams{continue} ? "warn" : "crit";

  # If a scalar is given for a filename, convert it to an array
  unless (ref($hParams{files})) {
    $hParams{files} = [split(/\s*,\s*/, $hParams{files})];
  }

  # Expand any wildcards (for a put only)
  if ($sFtpMethod =~ /put/) {
    my @aFilesExpanded;
    foreach my $sFile (@{$hParams{files}}) {
      if ($sFile =~ m/[\*\?]/) {
	my ($sMode,$sFilename) = ($sFile =~ m/(\([^\)]*\))?(.*)/);
	push @aFilesExpanded, map(sprintf($sMode.$_), glob($sFilename));
      } else {
	push @aFilesExpanded, $sFile;
      }
    }
    $hParams{files} = \@aFilesExpanded;
  }

  # Build files hash
  if (ref($hParams{files}) eq "ARRAY") {
    my %hFiles = map { _getLocalAndRemoteFilename($_) } @{$hParams{files}};

    $hParams{files} = \%hFiles;
  }

  # Set up the transfer mode for each of the files
  my %hFilesFixed;
  foreach my $sKey (keys %{$hParams{files}}) {
    my ($sMode,$sFilename) = ($sKey =~ m/(\([^\)]*\))?(.*)/);
    $sMode =~ s/^\(//g;
    $sMode =~ s/\)$//g;
    $sMode = ($sMode =~ m/(^i$)|(^b$)|(^bin(ary)?$)/i ? "binary" : $sMode =~ m/(^a$)|(^asci{0,2}$)/i ? "ascii" : $sMode);
    unless ($sMode) {
      unless ($sMode = $hParams{type}) {
	$sMode = ($hParams{method} =~ m/^put$/i ? &_getFileType($sFilename) : "ascii");
      }
    }
    $hFilesFixed{$sFilename} = {mode => $sMode, file => $hParams{files}->{$sKey}};
  }
  $hParams{files} = \%hFilesFixed;
  
  # Initiate the FTP connection
  $oFtp = &_getConnection(@_);

  # Set up block to catch the errors
  {
    local $SIG{'__WARN__'} = sub {
      &debug("ERROR!\n");
      my $sMsg = join("\n",@_);
      $sMsg .= "\nThe following files have already been transferred:\n   ".join("\n   ",@aFilesTransferred) if @aFilesTransferred;
      $sMsg .= "\nThe following files have not been transferred successfully:\n   ".join("\n   ",@aFilesNotTransferred) if @aFilesNotTransferred;
      &handleError(
		   msg      => $sMsg,
		   caller   => [caller(0)],
		   severity => $sTransferSeverity
		  );
    };

    # Step through each of the files
    my $sCurrentMode="";
    foreach my $sFilename (keys %{$hParams{files}}) {

      # Unless the mode is the same as for the previous file, set it
      unless ($sCurrentMode eq $hParams{files}->{$sFilename}->{mode}) {
	$sCurrentMode = $hParams{files}->{$sFilename}->{mode};
	&_setMode($oFtp,$sCurrentMode);
      }

      # If this is a wildcard get, first retrieve the list of files
      if ($sFilename =~ m/[\*\?]/ && $sFtpMethod =~ /get/) {
	&debug("Retrieving the list of files that match '$sFilename' ... ");
	my @aFiles = eval { $oFtp->ls($sFilename) };

	# Check that the listing was a success
	unless ($oFtp->ok) {
	  &debug("ERROR!\n");
	  &handleError(
		       msg      => "Could not retrieve directory listing for '$sFilename'.  The system reported: ".$oFtp->message." $@",
		       caller   => [caller(0)]
		      );
	}
	&debug("done\n");

	# Check that at least one file was found
	unless (@aFiles) {
	  &debug("WARNUTILs: No files match '$sFilename'\n");
	}

	# Transfer each of the files
	foreach (@aFiles) {

	  # Transfer the file
	  &debug("Transferring '$_' as '$_' ... ");
	  eval {$bResult = $oFtp->$sFtpMethod($_);};

	  # Check that the transfer was a success
	  if (! $bResult) {
	    &debug("ERROR!\n");
	    push @aFilesNotTransferred, $hParams{files}->{$sFilename}->{file};
	    my $sMsg = "Could not transfer file '$_' ".($sFtpMethod =~ /get/ ? "from" : "to")." host '$hParams{host}'.  The system reported: ".$oFtp->message." $@";
	    $sMsg .= "\nThe following files have already been transferred:\n   ".join("\n   ",@aFilesTransferred) if @aFilesTransferred;
            $sMsg .= "\nThe following files have not been transferred successfully:\n   ".join("\n   ",@aFilesNotTransferred) if @aFilesNotTransferred;
	    &handleError(
			 msg      => $sMsg,
			 caller   => [caller(0)],
			 severity => $sTransferSeverity
			);
	  } else {
	    &debug("done\n");
	    push @aFilesTransferred, $bResult;
          }
	}

      } else {

	# Transfer the file
	&debug("Transferring '$sFilename' as '".$hParams{files}->{$sFilename}->{file}."' ... ");
	eval {$bResult = $oFtp->$sFtpMethod($sFilename, $hParams{files}->{$sFilename}->{file});};

	# Check that the transfer was a success
	if (! $bResult) {
	  &debug("ERROR!\n");
	  push @aFilesNotTransferred, $hParams{files}->{$sFilename}->{file};
	  my $sMsg = "Could not transfer file '$sFilename' ".($sFtpMethod =~ /get/ ? "from" : "to")." host '$hParams{host}'.  The system reported: ".$oFtp->message." $@";
	  $sMsg .= "\nThe following files have already been transferred:\n   ".join("\n   ",@aFilesTransferred) if @aFilesTransferred;
          $sMsg .= "\nThe following files have not been transferred successfully:\n   ".join("\n   ",@aFilesNotTransferred) if @aFilesNotTransferred;
	  &handleError(
		       msg      => $sMsg,
		       caller   => [caller(0)],
		       severity => $sTransferSeverity
		      );
	} else {
	  &debug("done\n");
	  push @aFilesTransferred, $bResult;
	}
      }
    }
  }

  return {success => [@aFilesTransferred],
	  failure => [@aFilesNotTransferred]};
}

################################################################
#
# Subroutine:  _getLocalAndRemoteFilename
#
# Description: Separate filename string into local and remote
# filenames
#
################################################################
sub _getLocalAndRemoteFilename {
  my $sFileString=shift;
  my ($sLocal,$sRemote) = split(/=/,$sFileString,2);
  unless ($sRemote) {
    ($sRemote) = ($sLocal =~ m/([^\/]*)$/);
  }
  return ($sLocal,$sRemote);
}

################################################################
#
# Subroutine:  _getConnection
#
# Description: Initiate an FTP connection, and log in
#
# Params:
#  host     - Hostname of FTP server
#  port     - Port of FTP server
#  user     - Remote username on FTP server
#  pass     - Remote password for user on FTP server
#  options  - Any other options to pass to Net::FTP->new
#
################################################################
sub _getConnection {
  my %hParams=@_;
  $hParams{host} ||= $UTILs::FTP::HOSTNAME;
  $hParams{port} ||= $UTILs::FTP::PORT;
  $hParams{user} ||= $UTILs::FTP::USERNAME;
  $hParams{pass} ||= $UTILs::FTP::PASSWORD;
  my $sConnectionKey = join(':',$hParams{host}, $hParams{port}, $hParams{user}, $hParams{pass});

  # If the connection already exists, return it
  if ($UTILs::FTP::ghConnections{$sConnectionKey}) {
    return $UTILs::FTP::ghConnections{$sConnectionKey};
  }

  # Since the connection does not already exist, we need to create it
  my ($oFtp, $bResult);

  # Open an FTP Connection
  &debug("Connecting to FTP Server: $hParams{host} ... ");
  $oFtp = Net::FTP->new($hParams{host}, Port => $hParams{port}, Debug => $UTILs::Util::DebugLevel ? $UTILs::Util::DebugLevel - 1 : 0, %{$hParams{options}} );
  if (! $oFtp) {
    &debug("ERROR!\n");
    &handleError(
		 msg      => "Could not connect to FTP Server on $hParams{host}.  The system reported: $@",
		 caller   => [caller(0)]
		);
  }
  &debug("done\n");

  # Login
  &debug("Logging in as $hParams{user} ... ");
  $bResult = $oFtp->login($hParams{user}, $hParams{pass});
  if (! $bResult) {
    &debug("ERROR!\n");
    &handleError(
		 msg      => "Could not login to FTP Server on $hParams{host} as user $hParams{user}.  The system reported: ".$oFtp->message,
		 caller   => [caller(0)]
		);
  }
  &debug("done\n");

  $UTILs::FTP::ghConnections{$sConnectionKey} = $oFtp;
  return $oFtp;
}

################################################################
#
# Subroutine:  _getFileType
#
# Description: Gets the file type, either ascii or binary
#
# Params: (non-hash)
#  1  - Filename
################################################################
sub _getFileType {
  my $sFilename=shift;
  my $sMode;
  if (-f $sFilename) {
    if (-T $sFilename) {
      $sMode="ascii";
    } else {
      $sMode="binary";
    }
  } else {
    &handleError(
		 msg      => "$sFilename is not a plain file",
		 caller   => [caller(0)]
		);
  }

  return $sMode;
}

################################################################
#
# Subroutine:  _setMode
#
# Description: Set the transfer mode
#
# Params: (non-hash)
#  1  - FTP Connection Object
#  2  - Transfer mode (ascii or binary)
################################################################
sub _setMode {

  my ($oFtp,$sMode)=@_;
  my $bResult;

  &debug("Setting transfer mode to $sMode ... ");
  if ($sMode =~ /^ascii$/i) {
    $bResult = eval {$oFtp->ascii};
  } elsif ($sMode =~ /^binary$/i) {
    $bResult = eval {$oFtp->binary};
  } else {
    &debug("ERROR!\n");
    &handleError(
		 msg      => "Unknown tranfer mode: $sMode",
		 caller   => [caller(0)]
		);
  }

  unless ($bResult) {
    &debug("ERROR!\n");
    &handleError(
		 msg      => $@,
		 caller   => [caller(0)]
		);
  }

  &debug("done\n");

}

################################################################
#
# Subroutine:  listFiles
#
# Description: List files in a remote directory
#
# Params:
#  dir         - Which directory to list the files in
#  host        - Hostname of FTP server
#  port        - Port of FTP server
#  user        - Remote username on FTP server
#  pass        - Remote password for user on FTP server
#  continue    - Whether or not to continue when transferring
#                multiple files when encountering an error
#
################################################################
sub listFiles {
  my %hParams=@_;
  my ($oFtp, $bResult);
  my $sTransferSeverity=$hParams{continue} ? "warn" : "crit";

  # Initiate the FTP connection
  $oFtp = &_getConnection(@_);

  if ($hParams{dir}) {
      return $oFtp->ls($hParams{dir});
  } else {
      return $oFtp->ls;
  }

}

1;
