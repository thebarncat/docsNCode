package UTILs::Email;

BEGIN {
  require Exporter;
#  our (@ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  @ISA         = qw(Exporter);
  @EXPORT      = qw(&sendMail);
  %EXPORT_TAGS = ();
  @EXPORT_OK   = qw(&sendMail);
}

use strict;
use Mail::Sender;
use UTILs::Util qw(&debug);
use UTILs::Error;
use Sys::Hostname;

$UTILs::Email::SMTPHost = "ponyex-dqa.kdc.capitalone.com";                # CNAME for SMTP Server
$UTILs::Email::From     = $ENV{LOGNAME}.'@'.&hostname;         # Current user
$UTILs::Email::To       = $ENV{LOGNAME}.'@ingdirect.com';      # Current user

################################################################
#
# Subroutine:  sendMail
#
# Description: Send error message via email.
#
# Params:
#  smtp      - SMTP host to use (default: $UTILs::Email::SMTPHost)
#  from      - Email appears from (default: $UTILs::Email::From)
#  to        - Email sent to (default: $UTILs::Email::To)
#  cc        - Email cc to
#  bcc       - Email bcc to
#  subject   - Subject of email
#  message   - Message body of email
#  files     - Files to be attached (Comma separated list of files,
#              or a reference to a perl list)
#
################################################################
sub sendMail {
  my %hParams=@_;

  # Use the defaults if not explicitly set
  $hParams{smtp}     ||= $UTILs::Email::SMTPHost;
  $hParams{from}     ||= $UTILs::Email::From;
  $hParams{to}       ||= $UTILs::Email::To;

  # Initialize the error message
  my $sErrorStr;
  $sErrorStr .= "Could not send email:\n\n";
  $sErrorStr .= "From: $hParams{from}\n";
  $sErrorStr .= "To: $hParams{to}\n";
  $sErrorStr .= "Cc: $hParams{cc}\n" if $hParams{cc};
  $sErrorStr .= "Bcc: $hParams{bcc}\n" if $hParams{bcc};
  $sErrorStr .= "Subject: $hParams{subject}\n\n";
  $sErrorStr .= $hParams{message}."\n\n";

  # Initialize mail hash
  my %hMailDetails;
  $hMailDetails{smtp} = $hParams{smtp};
  $hMailDetails{from} = $hParams{from};
  $hMailDetails{to}   = $hParams{to};

  # Set cc
  $hMailDetails{cc} = $hParams{cc} if $hParams{cc};

  # Set bcc
  $hMailDetails{bcc} = $hParams{bcc} if $hParams{bcc};

  # Set subject
  $hMailDetails{subject} = $hParams{subject} if $hParams{subject};

  # Set message
  $hMailDetails{msg} = $hParams{message} if $hParams{message};

  # Attach files
  $hMailDetails{file} = $hParams{files} if $hParams{files};

  # Create new Mail::Sender object
  my $oSender = new Mail::Sender;
  &debug("Sending email to $hParams{to} ... ");
  if (! $oSender) {
    &debug("ERROR!\n");
    &handleError(
		 msg    => $sErrorStr."Error creating new Mail::Sender object.  The system message was '$Mail::Sender::Error'.",
		 caller => [caller(0)]
		)
  }

  # Send message
  my $bResult;
  if ($hMailDetails{file}) {
    $bResult = $oSender->MailFile(\%hMailDetails);
  } else {
    $bResult = $oSender->MailMsg(\%hMailDetails);
  }
  unless (ref $bResult) {
    &debug("ERROR!\n");
    &handleError(
		 msg    => $sErrorStr."Error sending email message.  The system message was '".$Mail::Sender::Error."'.",
		 caller => [caller(0)]
		)
  }
  &debug("done\n");

}

1;

=head1 NAME

UTILs::Email - Collection of Perl  modules related to Email, used by the Command Center

=head1 SYNOPSIS

  # Import the module
  use UTILs::Email;

  # Send an email
  UTILs::Email::sendMail(from    => 'me@ingdirect.com',
	               to      => 'jdoe@somewhere.com',
	               subject => 'This is a test subject',
	               message => 'This is a test message');

=head1 DESCRIPTION

UTILs::Email is a collection of subroutines which allow you to interact with email.  In order to send any emails, a working SMTP server must be available. 

=head1 CLASS VARIABLES

The following variables are used for default settings.

=head2 UTILs::Email::SMTPHost

The default SMTP server to use for sending email.  The default is smtp.ingdirect.com.

=head2 UTILs::Email::From

The default user whom emails appear to be from.  The default is the current user, as taken from $ENV{USER}.

=head2 UTILs::Email::To

The default list of users where emails are sent to.  The default is the current user, as taken from $ENV{USER}.

=head1 METHODS

=head2 sendMail

Used to send an email.

=head1 AUTHOR

Bugs Bunny 

=head1 VERSION

Version cvs (unreleased)

=head1 SEE ALSO

UTILs

=cut
