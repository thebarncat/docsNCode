package UTILs;

BEGIN {
  require Exporter;
  #our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);
  $VERSION     = '1.2';
  @ISA         = qw(Exporter);
  @EXPORT      = qw(&debug &lpad &rpad &getOptions &help &readConfig &dateReplace &handleError &sendMail &getFiles &putFiles &transferFiles &getProfileDateFromDate &getDateFromProfileDate &reportToBigBrother &execute &getMD5 &listFiles);
  %EXPORT_TAGS = ();
  @EXPORT_OK   = qw(&debug &lpad &rpad &getOptions &help &readConfig &dateReplace &handleError &sendMail &getFiles &putFiles &transferFiles &getProfileDateFromDate &getDateFromProfileDate &reportToBigBrother &execute &getMD5 &listFiles);
}

use UTILs::Util   qw(&debug &lpad &rpad &getOptions &help &readConfig &dateReplace &getProfileDateFromDate &getDateFromProfileDate &execute &getMD5);
use UTILs::Error  qw(&handleError);
use UTILs::Email  qw(&sendMail);
use UTILs::FTP    qw(&getFiles &putFiles &transferFiles &listFiles);

1;

=head1 NAME

UTILs - Collection of Perl 5 modules 

=head1 SYNOPSIS

  use UTILs;

  # Send an email
  sendMail(from    => 'me@ingdirect.com',
	   to      => 'jdoe@somewhere.com',
	   subject => 'This is a test subject',
	   message => 'This is a test message');

=head1 DESCRIPTION

this is a meta-module.  It imports and quotes all exported
subroutines from the other modules.  

=head1 AUTHOR

Bugs Bunny 

=head1 VERSION

Version 1.2

=cut
