#! /bin/sh
size=5539840
TVERSION=2.3
COMPN=TIDAL
ECHO=echo
ECHO1=""
ECHO2="\c"
ECHO3="-n"
tempfile=/tmp/tidal.tmpfile
RM=/bin/rm
_instdir=
_user=
_userpass=
_group=
_instconf=$TDLAGTINSTCONF
###------------------------
#---------------------------------------------------------------------
#       Function Definitions
#---------------------------------------------------------------------
exp_inst()
{
	### start the install
	_maindone=
	while ([ -z "$_maindone" ] ) do
		showmenu
		if [ "$_answer" = "q" ]
		then
			_maindone=true
		else
			domenu $_answer
		fi
	done

	exit 0
}

### ask a question
### $1=prompt  $2=default $3=valid entry list
ask()
{
	_answer=
	while ( [ -z "$_answer" ] ) do
		if [ "$PLATFORM" = "LINUX" -o "$PLATFORM" = "Linux" -o "$PLATFORM" = "LINUX-PPC" ]
		then
			$ECHO $ECHO3 $ECHO1 "$1 [$2]:"
			read _answer
		else
			if [ "$PLATFORM" = "ZOS" ]
			then
				$ECHO $ECHO1 "$1 {$2}:" $ECHO2
			else
				$ECHO $ECHO1 "$1 [$2]:" $ECHO2
			fi
			_answer=`line`
		fi
		if [ -z "$_answer" -a ! -z "$2" ]  ; then
			_answer=$2
			break
		elif [ ! -z "$3" ] ; then
			for _verify in $3
			do
				if [ "$_verify" = "$_answer" ] ; then
					_answer=$_verify
					break 2
				fi
			done
			_answer=
		fi
		if [ -z "$_answer" ] ; then
			$ECHO "Invalid entry.  Please try again."
		fi
	done
}

### askp a question (do not echo the user entry)
### $1=prompt  $2=default $3=valid entry list
askp()
{
	_answer=
	while ( [ -z "$_answer" ] ) do
		if [ "$PLATFORM" = "LINUX" -o "$PLATFORM" = "Linux" ]
		then
			$ECHO $ECHO3 $ECHO1 "$1 [*****]:"
			stty -echo
			read _answer
			stty echo
		else
			if [ "$PLATFORM" = "ZOS" ]
			then
				$ECHO $ECHO1 "$1 {*****}:" $ECHO2
			else
				$ECHO $ECHO1 "$1 [*****]:" $ECHO2
			fi
			stty -echo
			_answer=`line`
			stty echo
		fi
		if [ -z "$_answer" -a ! -z "$2" ]  ; then
			_answer=$2
			break
		elif [ ! -z "$3" ] ; then
			for _verify in $3
			do
				if [ "$_verify" = "$_answer" ] ; then
					_answer=$_verify
					break 2
				fi
			done
			_answer=
		fi
		if [ -z "$_answer" ] ; then
			$ECHO "Invalid entry.  Please try again."
		fi
	done
}

### print a single separator line
sep()
{
	$ECHO "--------------------------------------------------------------------"
}

### Home the cursor and clear the screen
clear_screen()
{
	case $PLATFORM in
 ZOS)
 $ECHO ""
 $ECHO ""
 $ECHO ""
 ;;
	MPEIX)
	$ECHO '\033h\033J'
	;;
	*)
	clear
	;;
	esac
}
### very crude but effective check for root privs
check_privs()
{
	if [ "$PLATFORM" != "ZOS" ]
	then
		touch $tempfile
	fi

	case $PLATFORM in
	ZOS)
		_result=`id|grep uid=0`
 		;;
	HIMALAYA|HIMALAYAi)
		_result=`ls -l $tempfile | grep SUPER.SUPER`
		;;
	MPEIX)
		_result=`ls -l $tempfile | grep MANAGER.SYS`
		;;
	*)
		_result=`ls -l $tempfile | grep root`
		;;
	esac

	if [ "$PLATFORM" != "ZOS" ]
	then
		$RM -f $tempfile
	fi

	if [ -z "$_result" ]
	then
		if [ "$_instconf" != "USER" ]
		then
 			case $PLATFORM in
			ZOS)
				$ECHO "You must have SUPERUSER privileges to run install"
				;;
			HIMALAYA|HIMALAYAi)
				$ECHO "You must have SUPER.SUPER privileges to run install"
				;;
			MPEIX)
				$ECHO "You must be MANAGER.SYS to run install"
				;;
			*)
				$ECHO "You must have root privileges to run install"
				;;
			esac
	        	exit 1
	        fi
	fi

	if [ "$PLATFORM" = "ZOS" ]
	then
		extattr +aps $0 2> /dev/null
		if [ "$?" != "0" ]
		then
			$ECHO "To be able to install the agent you must have atleast READ access to"
			$ECHO "the BPX.FILEATTR.APF FACILITY and BPX.FILEATTR.PROGCTL FACILITY class"
			$ECHO "For more information, see z/OS UNIX System Services Planning."
			exit 1
		fi
	fi
}

domenu()
{
	_rerun=
	clear_screen
	dotypicalinstall
	$ECHO ""
}

dotypicalinstall()
{
	_done=

		sep
		$ECHO ""
		$ECHO ""
		$ECHO "We recommend the use of the following dir for installation: "
		$ECHO ""
		if [ $PLATFORM != "ZOS" ]
		then
		
			$ECHO "    Installation Dir ............. [/opt/$COMPN/Agent]"
		fi
		if [ $PLATFORM = "ZOS" ]
		then
				
			$ECHO "    Installation Dir ............. (/$COMPN/Agent)"
		fi
		$ECHO ""
		$ECHO ""
		sep

		ask "Are these selections OK? (y/n/q) " "y" "y n q"
  if [ "$_answer" = "q" ]
  then
    exit 1
  fi

			if [ "$_answer" = "n" ]
			then
			while [ "$_answer" = "n" ]
			do
				ask "Installation dir for $COMPN Agent" "$_instdir"
				_instdir=$_answer
				
				sep
				$ECHO ""
				$ECHO ""
				$ECHO "Confirm the following dir for installation: "
				$ECHO ""
				if [ $PLATFORM = "ZOS" ]
				then
					$ECHO "    Installation Dir ............. ($_instdir)"
				else
					$ECHO "    Installation Dir ............. [$_instdir]"
				fi
				$ECHO ""
				$ECHO ""
				sep 			
				
				ask "Are these selections OK? (y/n/q) " "y" "y n q"
                                if [ "$_answer" = "q" ]
                                then
                                     exit 1
                                fi
			done
			if [ ! -d $_instdir ]
			then
					mkdir -p $_instdir	
				fi
			elif [ "$_answer" = "y" ]
			then
				_instdir="/opt/$COMPN/Agent"
				if [ $PLATFORM = "ZOS" ]
				then								
					_instdir="/$COMPN/Agent"
				fi
				if [ ! -d $_instdir ]
				then
					mkdir -p $_instdir	
				fi
			fi

		unpack $_instdir
		setagtown $_instdir $_user
}

unpack()
{
	_aghome=$1
#        echo $_aghome
#	__c=c
#	case $PLATFORM in
#	SOL2)
#	tail -$size$__c $_thisfilename > $_aghome/TAgent.tar.Z
#	tail -$size$__c $_thisfilename > $_aghome/TAgent.tar
#	;;
#	*)
#	tail -c -$size $_thisfilename > $_aghome/TAgent.tar.Z
#	tail -c -$size $_thisfilename > $_aghome/TAgent.tar
#	;;
#	esac
	if [ $_aghome != "`pwd`" ]
	then
	  cp install.tar $_aghome
	fi
	cd $_aghome
#	uncompress TAgent.tar.Z
#	tar xvf $_aghome/TAgent.tar
    rm -rf $_aghome/lib/jagent.jar
    rm -rf $_aghome/lib/taservices.jar
    rm -rf $_aghome/lib/js.jar
    rm -rf $_aghome/lib/jpython.jar
 	tar xvf $_aghome/install.tar
	cd bin
	if [ ! -f tagent.ini ]
	then
		mv _tagent.ini tagent.ini
	fi
	if [  -f _tagent.ini ]
	then
		rm -rf _tagent.ini
	fi
	cd ..
	rm -rf install.tar
}

setagtown()
{
	_aghome=$1
	__usr=$2

	__pwd=`pwd`
	cd $_aghome
	chmod -R 777 $_aghome/*

	chown -R $__usr $_aghome


 	case $PLATFORM in
 	HIMALAYA|HIMALAYAi|ZOS|MPEIX|LINUX)
 		chgrp -R `id $__usr | cut -f3 -d"(" | cut -f1 -d")" ` $_aghome
 		;;
 	*)
 		chgrp -R `su $__usr -c "id" | cut -f3 -d"(" | cut -f1 -d")" ` $_aghome
 		;;
 	esac

	chmod -R 711 $_aghome/lib

	if [ "$_instconf" != "USER" ]
	then
 		case $PLATFORM in
 		ZOS)
 			chown `whoami` `find $_aghome/lib -name "tjb" -print`
 			chown `whoami` `find $_aghome/lib -name "mvslnk" -print`
 			;;
 		MPEIX)
 			chown MANAGER.SYS `find $_aghome/lib -name "tjb" -print`
 			;;
 		HIMALAYA|HIMALAYAi)
 			chown SUPER.SUPER  `find $_aghome/lib -name "tjb" -print`
 			;;
 		*)
 			chown root  `find $_aghome/lib -name "tjb" -print`
 			;;
 		esac
 	fi
 	

	chgrp `id | cut -f3 -d"(" | cut -f1 -d")"` `find $_aghome/lib -name "tjb" -print`
	chmod 6111  `find $_aghome/lib -name "tjb" -print`
	chmod 6111  `find $_aghome/lib -name "job" -print`	
	chmod 6111  `find $_aghome/lib -name "setexit" -print`
		
	if [ "$PLATFORM" = "ZOS" ]
	then
		chmod 6555  `find $_aghome/lib -name "tjb" -print`
		chmod 6555  `find $_aghome/lib -name "mvslnk" -print`
		chmod 6555  `find $_aghome/lib -name "job" -print`	
		chmod 6555  `find $_aghome/lib -name "setexit" -print`
		extattr +aps `find $_aghome/lib -name "tjb" -print`
		extattr +aps `find $_aghome/lib -name "mvslnk" -print`
	fi

	chmod -R 700 $_aghome/bin
 	jars=`find $_aghome/lib -name "*.jar" -print`
 	for jar in $jars
 	do
 	  if [ -f $jar ]
 	  then
 	    chmod 744 $jar
 	  fi
 	done
	chmod 555 $_aghome/lib/setexit $_aghome/lib/job $_aghome/lib/ocsexit
	chmod 777 $_aghome/lib
	cd $_aghome/bin
	cd $__pwd
}

### determine group based on username supplied; uses /etc/passwd OR ypcat
getgroup()
{
	case $PLATFORM in
	HIMALAYA|HIMALAYAi)
	_group=`id $_user | cut -f3 -d"(" | cut -f1 -d")" `
	;;
	ZOS|MPEIX)
	_group=`id $_user | cut -f3 -d"(" | cut -f1 -d")" `
	;;
 	LINUX)
	_group=`id $_user | cut -f3 -d"(" | cut -f1 -d")" `
	;;
	*)
	_group=`su $_user -c "id" | cut -f3 -d"(" | cut -f1 -d")" `
	;;
	esac
}
get_defowner()
{
	_defuser="tidal"
	return

	if [ -d $ownership ]
	then
		_defuser=`$LSDG $ownership | awk '{print $3}'`
	else
		_defuser="tidal"
	fi

	if [ "$PLATFORM" = "MPEIX" ]
	then
		_defuser="$EXUSR.$EXACCT"
	fi
}
### ask for owner of all files
getowner()
{
	clear_screen
	if [ -z "$_user" ]
	then
	get_defowner
  	if [ "$PLATFORM" != "ZOS" ]
  	then
    		if [ "$PLATFORM" != "HIMALAYA" ] && [ "$PLATFORM" != "HIMALAYAi" ]
    			then
			   $ECHO "Users on this system:"
			   sep
			   showusers
			   $ECHO ""
			   sep
			   _userlist=`showusers`
    			fi
  		fi
		__user=$defuser
		fileok=false
		while ( [ "$fileok" = "false" ] )
		do
			ask "Which user should own the $SHORTPROD files?" "$__user"
			__user=$_answer
			if [ "$PLATFORM" = "HIMALAYA" ] || [ "$PLATFORM" = "HIMALAYAi" ]
			then
				askp "Enter user password (needed on $PLATFORM)" "" 
				_userpass=$answer
				su $__user,$_userpass -c "echo test > .tmpperm"
				if [ $? -ne 0 ]
				then
					$ECHO "Can not su to user, using secondary test..."
					echo "" > .tmpperm
					chown $__user .tmpperm
				fi
			else
				echo "" > .tmpperm
				chown $_answer .tmpperm
			fi

			if [ $? -ne 0 ]
			then
				echo "User $_answer could not be found."
			else
				fileok="true"
			fi
		done
		_user=$__user
		$RM -f .tmpperm
	fi
}

### list users on this system, eight across
showusers()
{

	case $PLATFORM in
	HIMALAYA|HIMALAYAi)
		;;
	MPEIX)
		callci "listuser @.$EXACCT"|grep USER:|cut -f2 -d " "| \
		awk '{if (NR%4==0) {printf "%-19s\n", $1} else {printf "%-19s", $1}}'
		;;
	*)
		cat /etc/passwd | awk -F: '{print $1}' | \
		awk '{if (NR%5==0) {printf "%-12s\n", $1} else {printf "%-12s", $1}}'
		;;
	esac
}


#-------------------------------------------------------------------------------------
ocs_logo()
{
	$ECHO "+--------------------------------------+"
	$ECHO "|@@@@@@ @@@@@@ @@@@@@    @@@@   @@     |      -> Warning <-"
	$ECHO "|  @@     @@    @@  @@  @@  @@  @@     |"
	$ECHO "|  @@     @@    @@  @@  @@  @@  @@     |   Make sure you  have"
	$ECHO "|  @@     @@    @@  @@  @@@@@@  @@     |   a  current   backup"
	$ECHO "|  @@     @@    @@  @@  @@  @@  @@     |   before   installing"
	$ECHO "|  @@   @@@@@@ @@@@@@   @@  @@  @@@@@@ |   any new products or"
	$ECHO "|                                      |   upgrades!"
	$ECHO "|@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ |"
	$ECHO "|@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ |"
	$ECHO "+--------------------------------------+"
	$ECHO ""
	$ECHO ""
}
#-------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------
# Figure out the Platform
#------------------------------------------------------------------------------------------------------
# NCR does not report platform in uname...duh
if [ -f /etc/.relid ]
then
	PLATFORM=NCR
else
	PLATFORM=`uname`
	SEQUENT=`uname -s`
fi

# Sequent DYNIX/ptx4 does report platform in uname, but ptx2 does not...
if [ "$SEQUENT" = "DYNIX/ptx" ]
then
        PLATFORM=PTX4
fi

# check for Solaris, allow for fake to devel on SunOS
if [ "$PLATFORM" = "SunOS" ]
then
		release=`uname -r | cut -c1`
		machine=`uname -m`
		if [ -n "$release" -a "$release" = "5" ] || [ -f $HOME/_solaris_ ]
		then
			if [ -n "$machine" -a "$machine" = "i86pc" ]
			then
				PLATFORM=SOL2X86
			else
				PLATFORM=SOL2
			fi
		fi
fi

# check if we're running HP-UX, and if so, which version of OS
if [ "$PLATFORM" = "HP-UX" ]
then
		os_version=`uname -r | cut -f2 -d.`
		machine=`uname -m`
		if [ -n "$os_version" -a "$os_version" = "10" ]
		then
			PLATFORM=HP-UX10
		elif [ -n "$os_version" -a "$os_version" = "11" ]
		then
			if [ -n "$machine" -a "$machine" = "ia64" ]
			then
				PLATFORM=HP-UX11i
			else
				PLATFORM=HP-UX11
			fi
		else
			PLATFORM=HP-UX
		fi
fi

# check for Digital UNIX, former DEC OSF/1
if [ "$PLATFORM" = "OSF1" ]
then
	PLATFORM=DU32
fi

if [ "$PLATFORM" = "Linux" ]
then
	mtype=`uname -m`
	if [ "$mtype" = "i386" ] || [ "$mtype" = "i486" ] || [ "$mtype" = "i586" ] || [ "$mtype" = "i686" ] || [ "$mtype" = "i786" ] || [ "$mtype" = "x86_64" ] || [ "$mtype" = "ia64" ]
	then
		PLATFORM=LINUX
	elif [ "$mtype" = "ppc64" ]
	then
		PLATFORM=LINUX-PPC
	else
		PLATFORM=LINUX-$mtype
	fi
fi

# check for Compaq Himalaya
if [ "$PLATFORM" = "NONSTOP_KERNEL" ]
then
	mtype=`uname -r | grep "^H"`
	if [  "$?" != "0" ]
	then
		PLATFORM=HIMALAYA
	else
		PLATFORM=HIMALAYAi
	fi
fi


# check for SCO UNIX
if [ "$PLATFORM" = "SCO_SV" ]
then
	PLATFORM=SCO
fi

if [ "$PLATFORM" = "OS/390" ]
then
	PLATFORM=ZOS
fi

if [ "$PLATFORM" = "MPE/iX" ]
then
	PLATFORM=MPEIX
fi

pyramid=`echo $PLATFORM | grep "DC/OS"`
pyramid=`echo $PLATFORM | grep "DC/OS"`
if [ -n "$pyramid" ]
then
	PLATFORM=PYRAMID
fi
#------------------------------------------------------------------------------------------------------
###main script
clear_screen
_thisfilename=$0
$ECHO ========================================
case $PLATFORM in
ZOS)
	$ECHO $COMPN Agent For z/OS, Version $TVERSION
	;;
HIMALAYA|HIMALAYAi)
	$ECHO $COMPN Agent For Himalaya, Version $TVERSION
	;;
MPEIX)
	$ECHO $COMPN Agent For MPE/iX, Version $TVERSION
	;;
*)
	$ECHO $COMPN Agent For Unix, Version $TVERSION
	;;
esac
$ECHO ========================================
ocs_logo
case $PLATFORM in
MPEIX)
 _user=$1
 if [ "@$_user" = "@" ]
 then
   $ECHO Aborting Install, User not specified
   $ECHO ========================================
   exit 1
 fi
 ;;
 *)
 ask "Continue to install? (y/n)" "n" "y n"
 if [ "$_answer" = "n" ]
 then
   exit
 fi
 check_privs
 clear_screen
 getowner
 ;;
esac
getgroup
case $PLATFORM in
 MPEIX)
 _instdir=`pwd`
 unpack $_instdir
 $ECHO ========================================
 setagtown $_instdir $_user
 ;;
 *)
 dotypicalinstall
 ;;
esac

cd $_instdir/bin
case $PLATFORM in
 ZOS|HIMALAYA|HIMALAYAi)
 $ECHO Installed, Starting Agent Configuration
 ./tagent config
 setagtown $_instdir $_user
 ;;
 MPEIX)
 $ECHO Installed
 $ECHO ========================================
 ;;
 *)
 $ECHO Installed, Starting Agent Configuration
 su $_user -c "./tagent config"
 ;;
esac
exit 0
