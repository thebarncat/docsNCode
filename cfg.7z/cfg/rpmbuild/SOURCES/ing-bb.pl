#!/usr/bin/perl

use strict;
use ING;
use Sys::Hostname;

my $rhOptions = {};

sub main {
  my $sHelpText = &getOptions( options    => [@main::cl_opts],
			       arguments  => [@main::cl_args],
			       additional => [@main::additional_help],
			       opts_ref   => $rhOptions
			     );

  # Get the name of the Big Brother area
  my $sTest   = shift @ARGV;

  # Perform the Big Brother test
  my ($sColor,$sMsg);
  if ($rhOptions->{M}) {
    ($sColor,$sMsg) = &testAsModule;
  } else {
    ($sColor,$sMsg) = &testAsScript;
  }

  # Report back to Big Brother
  return &reportToBigBrother( host  => $rhOptions->{h},
			      test  => $sTest,
			      color => $sColor,
			      text  => $sMsg
			    );


}

sub testAsModule {
  my $sModule=shift @ARGV;

  # Try and load the required module
  unless ( eval "require $sModule" ) {
    &handleError(
		 msg  => "Could not load module '$sModule'.  The system reported: $@",
		 caller => [caller(0)]
		);
  }
}

sub testAsScript {
  my $sScript=shift @ARGV;
  my $sMessage;
  my ($nRC,$sStdout,$sStderr)=execute( $sScript, args => [@ARGV] );
  my $sColor = ($nRC == 0 ? 'green' : ($nRC == 1 ? 'yellow' : 'red'));

  $sMessage .= "$sStdout\n\n" if ($sStdout);
  $sMessage .= "$sStderr\n\n" if ($sStderr);

  return ($sColor,$sMessage);
}

sub getHostname {
  my $sHostname = &hostname;
  $sHostname .= ".ingdirect.com" unless ($sHostname =~ m/\./);
  return $sHostname;
}

################################################################
#
# Define all valid command line options and arguments here.
#
################################################################
@main::cl_opts = (
		  {
		   opt     => "h",
		   short   => "hostname",
		   long    => "Hostname to report for",
		   default => &getHostname
		  },
#		  {
#		   opt    => "M",
#		   long   => "Treat first argument as a perl module instead of a script"
#		  },
#		  {
#		   opt     => "s",
#		   short   => "sub",
#		   long    => "Name of perl subroutine used to perform test.  This is only used when -M is set.",
#		   default => "test"
#		  }
		 );

@main::cl_args = (
		  {
		   short  => "area",
		   long   => "Name of Big Brother area"
		  },
		  {
		   short  => "source",
		   long   => "Script to use for processing."
		  }
		 );
# Set up additional help
@main::additional_help = ("When [source] is a script name, the script must conform to the following standard so as to report back to Big Brother in the proper way.  STDOUT from the script is the message that will be printed, and the return value from the script is used to determine the color which should be reported to Big Brother as follows:\n   0 = GREEN\n   1 = YELLOW\n   2 = RED");

exit &main;

