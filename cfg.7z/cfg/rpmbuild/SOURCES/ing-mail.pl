#!/usr/bin/perl
###############################################################################
##                                                                           ##
##    Copyright (c) 2000-2003 ING Bank, fsb.                                 ##
##    All Rights Reserved.                                                   ##
##                                                                           ##
##    Version : $Revision: 1.1 $                                             ##
##    Date    : $Date: 2004/04/09 15:29:49 $                                 ##
##                                                                           ##
##   usage: sysnotify.pl [-H host] [-F from] [-t to] [-c cc] [-b bcc]        ##
##   [-s subject] [-m message] [-f files] [-T days] [-d level] [-?]          ##
##                                                                           ##
##   Command Line Options                                                    ##
##     -H host     : SMTP Server hostname (DEFAULT: $ING::Email::SMTPHost)   ##
##     -F from     : User which email appears to be from (DEFAULT:           ##
##                   $ENV{USER}                                              ##
##     -t to       : Comma-separated list of email addresses (DEFAULT:       ##
##                   $ENV{USER}                                              ##
##     -c cc       : Comma-separated list of email addresses                 ##
##     -b bcc      : Comma-separated list of email addresses                 ##
##     -s subject  : Subject of email message                                ##
##     -m message  : Body of email message                                   ##
##     -M file     : Text file to use as body of email message               ##
##     -f files    : Comma-separated list of files to attach                 ##
##     -T days     : Offset from system date for regex replacements          ##
##     -d level    : Set the debugging level                                 ##
##     -?          : Display this help message                               ##
##                                                                           ##
##   Additional Help                                                         ##
##      When providing the list of filenames to be attached, you may use     ##
##   special keys which will be replaced at runtime.  Check out              ##
##   ING::Util::dateReplace for a list of valid keys.                        ##
##                                                                           ##
###############################################################################
use strict;
use ING;

my $rhOptions = {};

sub main {
  my $sHelpText = &getOptions( options    => [@main::cl_opts],
			       additional => [@main::additional_help],
			       opts_ref   => $rhOptions
			     );

  # If -M is provided, append to message body
  if ($rhOptions->{'M'}) {

    my $sFilename=&dateReplace($rhOptions->{'M'}, days => $rhOptions->{'T'});

    if ( open(BODY,$sFilename)  ) {

      my @aBodyFile = <BODY>;
      chomp @aBodyFile;
      $rhOptions->{'m'} .= "\n".join("\n",@aBodyFile);
      close BODY;

    } else {

      my $sErrorMsg = "Could not open '".$sFilename."' to append to message body.  The system reported: $!";
      &handleError(
		   msg      => $sErrorMsg."\nThe message will still be sent",
		   caller   => [caller(0)],
		   severity => 'warn'
		  );
      $rhOptions->{'m'} .= "\n".('#'x80)."\nERROR:  $sErrorMsg\n".('#'x80);
    }

  }

  # Send email
  sendMail(smtp    => $rhOptions->{'H'},
	   from    => $rhOptions->{'F'},
	   to      => $rhOptions->{'t'},
	   cc      => $rhOptions->{'c'},
	   bcc     => $rhOptions->{'b'},
	   subject => $rhOptions->{'s'},
	   message => $rhOptions->{'m'},
	   files   => &dateReplace($rhOptions->{'f'}, days => $rhOptions->{'T'}),
	  );

  return 0;
}

################################################################
#
# Define all valid command line options and arguments here.
#
################################################################
@main::cl_opts = (
		  {
		   opt     => "H",
		   short   => "host",
		   long    => "SMTP Server hostname",
		   default => $ING::Email::SMTPHost
		  },
		  {
		   opt     => "F",
		   short   => "from",
		   long    => "User which email appears to be from",
		   default => $ING::Email::From
		  },
		  {
		   opt     => "t",
		   short   => "to",
		   long    => "Comma-separated list of email addresses",
		   default => $ING::Email::To
		  },
		  {
		   opt     => "c",
		   short   => "cc",
		   long    => "Comma-separated list of email addresses"
		  },
		  {
		   opt     => "b",
		   short   => "bcc",
		   long    => "Comma-separated list of email addresses"
		  },
		  {
		   opt     => "s",
		   short   => "subject",
		   long    => "Subject of email message"
		  },
		  {
		   opt     => "m",
		   short   => "message",
		   long    => "Body of email message"
		  },
		  {
		   opt     => "M",
		   short   => "file",
		   long    => "Text file to use as body of email message"
		  },
		  {
		   opt     => "f",
		   short   => "files",
		   long    => "Comma-separated list of files to attach"
		  },
		  {
		   opt     => "T",
		   short   => "days",
		   long    => "Offset from system date for regex replacements"
		  }
		 );

# Set up additional help
@main::additional_help = ("When providing the list of filenames to be attached, you may use special keys which will be replaced at runtime.  Check out ING::Util::dateReplace for a list of valid keys."
			 );

exit &main;
