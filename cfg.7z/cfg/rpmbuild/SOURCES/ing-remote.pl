#!/usr/bin/perl
use ING;

my $rhOptions = {};

sub main {
  my $sHelpText = &getOptions( options    => [@main::cl_opts],
			       additional => [@main::additional_help],
			       opts_ref   => $rhOptions
			     );

  # Set up error emails
  if ( $ING::Error::EmailTo = $rhOptions->{'t'} ) {
    $ING::Error::SendEmailOnError = 1;
    $ING::Error::EmailFrom        = $rhOptions->{'f'};
  }

  # Check environment variables
  my @aEnv = ('ING_REMOTE_HOSTNAME',
	      'ING_REMOTE_USERNAME',
	      'ING_REMOTE_PASSWORD',
	      'ING_REMOTE_SCRIPT');

  foreach my $sEnv (@aEnv) {
    unless ($ENV{$sEnv}) {
      &handleError(
		   msg    => "You must set the environment variable $sEnv",
		   caller => [caller(0)]
		  );
    }
  }

  # Execute remote script
  my ($nRC,$sStdout,$sStderr) = &execute($ENV{ING_REMOTE_SCRIPT},
					 host => $ENV{ING_REMOTE_HOSTNAME},
					 user => $ENV{ING_REMOTE_USERNAME},
					 pass => $ENV{ING_REMOTE_PASSWORD});
  if ($nRC != 0) {

    &handleError(
		 msg    => "There was an error when executing '$ENV{ING_REMOTE_SCRIPT}' on $ENV{ING_REMOTE_HOSTNAME}",
		 caller => [caller(0)],
		 append => [$sStdout,$sStderr]
		);
  }

  return 0;
}

################################################################
#
# Define all valid command line options and arguments here.
#
################################################################
@main::cl_opts = (
		  {
		   opt     => "f",
		   short   => "from",
		   long    => "User which error emails appear to be from",
		   default => $ING::Error::EmailFrom
		  },
		  {
		   opt     => "t",
		   short   => "to",
		   long    => "Comma-separated list of email addresses where errors are sent to"
		  }
		 );

# Set up additional help
@main::additional_help = ("Uses the environment variables ING_REMOTE_HOSTNAME, ING_REMOTE_USERNAME, ING_REMOTE_PASSWORD, and ING_REMOTE_SCRIPT."
			 );
exit &main;
