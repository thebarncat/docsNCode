##############################################################
packages:
	linux::
		bash pkgmgr=rpm define=has_bash

copy:

	redhat_s_5::
		$(master_files)/rpms/bash-3.2-33.el5_11.4.x86_64.rpm
		dest=/tmp/bash-3.2-33.el5_11.4.x86_64.rpm
		server=$(policyhost)
		type=checksum
		action=silent
		backup=false
		inform=false

	redhat_s_6::
		$(master_files)/rpms/bash-4.1.2-15.el6_5.2.x86_64.rpm
		dest=/tmp/bash-4.1.2-15.el6_5.2.x86_64.rpm
		server=$(policyhost)
		type=checksum
		action=silent
		backup=false
		inform=false

	 aix_5_3::
		$(master_files)/rpms/bash-4.2-3.aix5.3.ppc.rpm
		dest=/tmp/bash-4.2-3.aix5.3.ppc.rpm
		server=$(policyhost)
		type=checksum
		action=silent
		backup=false
		inform=false

	 aix_6_1::
		$(master_files)/rpms/bash-4.2-3.aix6.1.ppc.rpm
		dest=/tmp/bash-4.2-3.aix6.1.ppc.rpm
		server=$(policyhost)
		type=checksum
		action=silent
		backup=false
		inform=false

shellcommands:

	#linux.!has_bash::
	redhat_s_5::
		"/bin/rpm -Uvh /tmp/bash-3.2-33.el5_11.4.x86_64.rpm"
		"/bin/rm -f /tmp/bash-3.2-33.el5_11.4.x86_64.rpm"
		inform=false
	redhat_s_6::
		"/bin/rpm -Uvh /tmp/bash-4.1.2-15.el6_5.2.x86_64.rpm"
		"/bin/rm -f /tmp/bash-4.1.2-15.el6_5.2.x86_64.rpm"
		inform=false
	aix_5_3::
		"/bin/rpm -Uvh /tmp/bash-4.2-3.aix5.3.ppc.rpm"
		"/bin/rm -f /tmp/bash-4.2-3.aix5.3.ppc.rpm"
		inform=true
	aix_6_1::
		"/bin/rpm -Uvh /tmp/bash-4.2-3.aix6.1.ppc.rpm"
		"/bin/rm -f /tmp/bash-4.2-3.aix6.1.ppc.rpm"
		inform=true

# END 
