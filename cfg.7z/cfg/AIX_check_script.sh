#!/bin/sh
##################################################################################################
#
#    This is an AIX validation script, AIX_check_script.sh to be used before, & after OS patching or to capture, & compare the system configuration.
#
#
#    Author = Barry Lowrance    Barry.Lowrance@CapitalOne.com
#    Group = "OSH IT" Unix Engineering   UNIXEngineering@CapitalOne.com
#
#
#                       ©Capital One
#
#    Revision History
#    Initial Creation on 1/3/2014
#
#
##################################################################################################
if [ $(id -u) != "0" ]; then
    echo "Must be ran as root"
    exit 1
fi

if [ -z "$1" ];then
    echo " Please select Pre-check, or Post-check "
    echo " AIX_check_script.sh "
    exit 1
fi

SName=` hostname -s `
DT=$(date +%d%b%y"_"%H%M)
FL=/tmp/$SName"_config_"$DT".txt"; touch ${FL}

_GET_CONFIG () {

export LANG=C
echo "\n     Generating SW/HW configuration"

echo "\n\n\n        C O N F I G U R A T I O N     S  U  M  M  A  R  Y     O  U  T  P  U  T\n\n\n" > ${FL}
echo "# date" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  date >> ${FL} 2>&1
echo " " >> ${FL} 2>&1


echo "# hostname -s" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  hostname -s >> ${FL} 2>&1
echo " " >> ${FL} 2>&1


echo "# ifconfig -a  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  ifconfig -a >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1

echo "# cat /etc/inittab  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  cat /etc/inittab |egrep -v "^#|^:" >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# cat /etc/ntp.conf  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  cat /etc/ntp.conf |egrep -v "^#|^$" >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# cat /etc/passwd  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  cat /etc/passwd >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1

echo "# netstat -r  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  netstat -r |cut -c1-45,60-85 >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# netstat -rn  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  netstat -rn |cut -c1-45,60-85 >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# netstat -in  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  netstat -in |cut -c1-41,50-56,65-76 >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lssrc -a on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  lssrc -a >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# Running processes sorted & unique" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  ps -afe -o "args" |egrep -v "tail|sleep|@pts|ps|vmstat|iostat|ksh|sh|pbrun|defunct|wlmassign|netstat|awk|grep|sort|idle" |sort -u >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# netstat -an  grep LISTEN on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  netstat -an |grep LISTEN >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lsattr -El mem0  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  lsattr -El mem0 >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lsattr -El sys0  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  lsattr -El sys0 >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1

echo "# lparstat -i  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  lparstat -i >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


cd /
echo "# ls -l under /  on $SName " >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  #Removed listing of directories which are expected to change regularly with recent time stamps.
  ls -l|egrep -v "proc|tmp|dev|etc" >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# ls -l under /dev  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  #Removed listing if things which are expected to change regularly with recent time stamps.
  cd /dev
  ls -l |egrep -v ".SRC-unix|null" >> ${FL} 2>&1
  cd /
echo "\\n\\n" >> ${FL} 2>&1


echo "# showmount -e  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  showmount -e >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# cat /etc/exports  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  cat /etc/exports >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# cat /etc/hosts  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  cat /etc/hosts |egrep -v "^#|^$" >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lsuser -a id home ALL on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  lsuser -a id home ALL >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# cat /etc/group  on $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  cat /etc/group >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lsgroup -a id ALL on  $SName" >> ${FL} 2>&1
  echo "###############################################################" >> ${FL} 2>&1
  lsgroup -a id ALL >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# oslevel   on $SName" >> ${FL} 2>&1
   echo "###############################################################" >> ${FL} 2>&1
   echo "oslevel " `oslevel` >> ${FL} 2>&1
   echo "oslevel -r " `oslevel -r` >> ${FL} 2>&1
   echo "oslevel -s " `oslevel -s` >> ${FL} 2>&1
   echo "\\n\\n" >> ${FL} 2>&1


echo "# instafix -i |grep ML  on $SName" >> ${FL} 2>&1
   echo "###############################################################" >> ${FL} 2>&1
   instfix -i |grep ML >> ${FL} 2>&1
   echo "\\n\\n" >> ${FL} 2>&1



echo "# User license  on $SName" >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
lslicense >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# vmo  on $SName" >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
#Ignoring pinnable as this is expected to change regularly.
vmo -a |grep -v pinnable >> ${FL} 2>&1
echo >> ${FL} 2>&1
vmo -L |grep -v pinnable>> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# ioo  on $SName" >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
ioo -a >> ${FL} 2>&1
echo >> ${FL} 2>&1
ioo -L >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# ulimits on $SName" >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
ulimit -a >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1

cd /var/spool/cron/crontabs
for i in $(ls)
do
      echo "# crontab -l of $i  on $SName" >> ${FL} 2>&1
      echo "###############################################################" >> ${FL} 2>&1
      cat $i >> ${FL} 2>&1
      echo "\\n\\n" >> ${FL} 2>&1
done


cd /var/spool/cron/atjobs
for i in $(ls)
do
      echo "# atjobs -l of $i  on $SName" >> ${FL} 2>&1
      echo "###############################################################" >> ${FL} 2>&1
      cat $i >> ${FL} 2>&1
      echo "\\n\\n" >> ${FL} 2>&1
done
cd


echo "# errpt " >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
errpt > /tmp/$SName"_errpt_"$DT".txt"
chmod o+r /tmp/$SName"_errpt_"$DT".txt"
cat /tmp/$SName"_errpt_"$DT".txt" >> ${FL} 2>&1
rm /tmp/$SName"_errpt_"$DT".txt"
echo "\\n\\n" >> ${FL} 2>&1


echo "# errpt -a " >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
errpt -a > /tmp/$SName"_errpta_"$DT".txt"
chmod o+r /tmp/$SName"_errpta_"$DT".txt"
cat /tmp/$SName"_errpta_"$DT".txt" >> ${FL} 2>&1
rm /tmp/$SName"_errpta_"$DT".txt"
echo "\\n\\n" >> ${FL} 2>&1


_CLUSTPKG=$(lslpp -l |grep cluster.es)
if [ -n "$_CLUSTPKG" ];then
   echo "# lslpp -l |grep cluster.es* on $SName " >> ${FL} 2>&1
   echo "###############################################################" >> ${FL} 2>&1
   lslpp -l |grep clust >> ${FL} 2>&1
   echo "\\n\\n" >> ${FL} 2>&1


   echo "# lssrc -g cluster on $SName " >> ${FL} 2>&1
   echo "###############################################################" >> ${FL} 2>&1
   lssrc -g cluster >> ${FL} 2>&1
   echo "\\n\\n" >> ${FL} 2>&1


   echo "# HACMP Cluster Config info $SName " >> ${FL} 2>&1
   echo "###############################################################" >> ${FL} 2>&1
   /usr/es/sbin/cluster/utilities/cltopinfo >> ${FL} 2>&1
   RGP=$(/usr/es/sbin/cluster/utilities/cltopinfo|grep "Resource Group"|cut -f3 -d" ")
   echo >> ${FL} 2>&1
   /usr/es/sbin/cluster/utilities/clshowres -g $RGP >> ${FL} 2>&1
   echo "\\n\\n" >> ${FL} 2>&1
fi

echo "# lslpp -l " >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
lslpp -l >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lscfg -vp " >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
lscfg -vp >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# prtconf " >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
prtconf >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lppchk -v" >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
lppchk -v >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "# lppchk -c" >> ${FL} 2>&1
echo "###############################################################" >> ${FL} 2>&1
#lppchk -c >> ${FL} 2>&1
echo "\\n\\n" >> ${FL} 2>&1


echo "\n\nHostname:  "  `/bin/hostname -s` >> ${FL} 2>&1
echo     "Time config run:  " `/bin/date` >> ${FL} 2>&1
echo     "AIX VRLM (oslevel):  " `oslevel` >> ${FL} 2>&1

echo "\n\nPROCESSOR TYPE  (uname -m)" >> ${FL} 2>&1
echo     "--------------------------\n" >> ${FL} 2>&1
uname -m  >> ${FL} 2>&1
echo     "        ## = model" >> ${FL} 2>&1

echo "\n\nMEMORY  (bootinfo -r):  " `bootinfo -r`  >> ${FL} 2>&1
echo     "MEMORY  (lscfg -l memN)" >> ${FL} 2>&1
echo     "-----------------------\n"  >> ${FL} 2>&1
lscfg -l mem* >> ${FL} 2>&1

# get current paging space info
echo "\n\nPAGING SPACES  (lsps -a)" >> ${FL} 2>&1
echo     "------------------------\n" >> ${FL} 2>&1
lsps -a  >> ${FL} 2>&1

echo "\n\nPAGING SPACES  (lsps -s)" >> ${FL} 2>&1
echo     "------------------------\n" >> ${FL} 2>&1
lsps -s  >> ${FL} 2>&1

# get detail device info
echo "\f\n\nPHYSICAL / LOGICAL DEVICE DETAILS  (lsdev -C)" >> ${FL} 2>&1
echo       "---------------------------------------------\n" >> ${FL} 2>&1
lsdev -C >> ${FL} 2>&1

# get current physical volume names
echo "\f\n\nPHYSICAL VOLUMES  (lspv)" >> ${FL} 2>&1
echo       "------------------------\n" >> ${FL} 2>&1
lspv  >> ${FL} 2>&1

# get detail physical volume info
for i in `lspv | /bin/cut -c1-15`
  do
    echo "\n\nPHYSICAL VOLUME DETAILS FOR $i  (lspv -l $i)" >> ${FL} 2>&1
    echo     "------------------------------------------------------\n" >> ${FL} 2>&1
    lspv -l $i >> ${FL} 2>&1

    echo "\n\nPHYSICAL VOLUME LAYOUT FOR $i (lspv -p $i )" >> ${FL} 2>&1
      echo "------------------------------------------------------\n" >> ${FL} 2>&1
      lspv -p $i >> ${FL} 2>&1
      echo "\\n\\n" >> ${FL} 2>&1
  done

# get detail volume group info
for i in `lsvg -o`
  do
  echo "\n\nVOLUME GROUP DETAILS  (lsvg -l $i)" >> ${FL} 2>&1
  echo     "---------------------------------------\n" >> ${FL} 2>&1
  lsvg -l $i >> ${FL} 2>&1
  done

# get current mount info
echo "\f\n\nMOUNTED FILESYSTEMS  (mount)" >> ${FL} 2>&1
echo       "----------------------------\n" >> ${FL} 2>&1
mount  >> ${FL} 2>&1

echo "\n\nFILE SYSTEM INFORMATION:  (lsfs -q)"  >> ${FL} 2>&1
echo     "-----------------------------------\n" >> ${FL} 2>&1
lsfs -q  >> ${FL} 2>&1   2>&1

echo "\n\nFILE SYSTEM LOW SPACE:  (df -g)"  >> ${FL} 2>&1
echo     "------------------------\n" >> ${FL} 2>&1
df -g |egrep "9[0-9]%"  >> ${FL} 2>&1

for LV in $(lsvg -o|lsvg -il|awk '{print $1}'|egrep -v ':|LV')
   do
      echo "\n\nLOGICAL VOLUME DETAILS   (lslv $LV)"
      echo     "---------------------------------------\n"
      lslv $LV
      echo
   done >> ${FL} 2>&1


# get system dump config info
echo "\n\nSYSTEM DUMP INFO (sysdumpdev -l;sysdumpdev -e)" >> ${FL} 2>&1
echo     "----------------------------------------------\n" >> ${FL} 2>&1
sysdumpdev -l >> ${FL} 2>&1
sysdumpdev -e >> ${FL} 2>&1

# get ulimit values
echo "\n\nulimit values" >> ${FL} 2>&1
echo     "----------------------------------------------\n" >> ${FL} 2>&1
ulimit -a >> ${FL} 2>&1

# get syslog setup
echo "\n\nis syslog daemon running " >> ${FL} 2>&1
echo     "----------------------------------------------\n" >> ${FL} 2>&1
ps -ef |grep -v grep | grep syslo* >> ${FL} 2>&1
echo "\n\nsyslog setup " >> ${FL} 2>&1
echo     "----------------------------------------------\n" >> ${FL} 2>&1
cat /etc/syslog.conf |egrep -v "^#|^$" >> ${FL} 2>&1

# Users on system
echo "\n\nUsers on system" >> ${FL} 2>&1
echo     "----------------------------------------------\n" >> ${FL} 2>&1
w -u >> ${FL} 2>&1



chmod o+r ${FL}
chmod o+r ${FL}
echo "\\n"
echo " The following configuration files have been generated "
echo "\\n"
ls -ltr /tmp/*$DT* |awk '{print $9}'
echo "\\n"
}

###############################  Main ##################################

if [ "$1" = "Pre-check" ];then
    _GET_CONFIG
    echo "\n"
    echo " Please verify all filesets are found, & no broken filesets exist before proceeding with maintenance "
    echo "\n"
    cat ${FL} |grep -v "rw" |egrep -p "oslevel|All filesets|lppchk -v"
    echo "\n"
fi

if [ "$1" = "Post-check" ];then
    _GET_CONFIG
    echo "\n"
    echo "#####################   START of Post maintenance configuration comparison   #######################"
    echo "\\n\\n"
    ls /tmp/`hostname`_config* |grep -v diff |tail -n2 |xargs diff -U0 >> /tmp/$SName"_config_"$DT.diff.results 2>&1
    sleep 1
    cat /tmp/$SName"_config_"$DT.diff.results
    echo "\\n\\n"
    echo "#####################   END of Post maintenance configuration comparison   #######################"
    echo "\\n\\n"
fi
