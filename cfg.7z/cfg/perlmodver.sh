#!/bin/sh
# FILE: "/home/jkipp/permodver.sh"
# LAST MODIFICATION: "Tue, 16 Feb 2016 15:43:25 -0500 (jkipp)"
# (C) 2016 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

perl -le'eval qq{require $ARGV[0]; } 
	? print ( "Found $ARGV[0] Version: ", eval "$ARGV[0]->VERSION" ) 
	: print "Not installed" ' $1
