#/bin/bash
for i in `omconfig system alertaction | sed 's/ *(.*)//; s/>.*//; s/.*[:<] *// ; s/|/ /g;'`; do 
echo $i;
omconfig system alertaction event=$i alert=true broadcast=true execappath="/usr/local/bin/OM-Alert.pl"
done
#omconfig system alertlog action=clear
