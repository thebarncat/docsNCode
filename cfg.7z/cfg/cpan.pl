#!/usr/bin/perl -w
# FILE: "/home/jkipp/cpan.pl"
# LAST MODIFICATION: "Wed, 13 Apr 2016 14:37:41 -0400 (jkipp)"
# (C) 2016 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;
use ExtUtils::Installed;
my $inst  = ExtUtils::Installed->new();
my @modules = $inst->modules();
print join "\n", @modules;
