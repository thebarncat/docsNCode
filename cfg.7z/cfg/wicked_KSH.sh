#!/bin/ksh
# IBM_PROLOG_BEGIN_TAG 
# This is an automatically generated prolog. 
#  
# bos71H src/bos/usr/lpp/bos/pre_migration.sh 1.38.1.7 
#  
# Licensed Materials - Property of IBM 
#  
# COPYRIGHT International Business Machines Corp. 2003,2012 
# All Rights Reserved 
#  
# US Government Users Restricted Rights - Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
#  
# IBM_PROLOG_END_TAG 
# @(#)32        1.38.1.7  src/bos/usr/lpp/bos/pre_migration.sh, migration, bos71H, 1224A_71H 6/5/12 11:19:11
## pre_migration script

# function needed to check blv size, called by boot_lv_check
save_orig_blv_map ()
{
   for disk in $blv_disk_list; do
      #------------------------------------------------------------------
      # There could be more than one range of used PPs on a given disk in
      # event that the BLV mirrored onto the same disk.
      #------------------------------------------------------------------
      LANG=C lspv -p $disk | grep " $BLV " | \
      awk -v disk=$disk '{print disk":"$1}'
   done > $ORIG_MAPFILE
}

# function needed to check blv size, called by boot_lv_check
#-------------------------------------------------------------------------
# Given logical partition information (lp_info) of the form <disk>:<range>
# check to see if we can extend the logical volume to the next adjacent
# $pps_needed partitions.  If we cannot then return 1.
#-------------------------------------------------------------------------
can_extend ()
{
   lp_info=$1
   disk=`echo $lp_info | awk -F: '{print $1}'`
   lastpp=`echo $lp_info | awk -F- '{print $2}'`

   (( nextpp = lastpp + 1 ))

   grep "^$disk:" $FREE_MAPFILE | \
   while read location; do
      if `echo $location | egrep -q ":$nextpp-"`; then
         lower_limit=`echo $location | awk -F: '{print $2}' | \
                      awk -F- '{print $1}'`
         upper_limit=`echo $location | awk -F: '{print $2}' | \
                      awk -F- '{print $2}'`
         (( free_pps = upper_limit - lower_limit + 1 ))

         if [[ $free_pps -ge $pps_needed ]]; then

            # Make sure we are still in the first 4GB of the disk
            (( physical_upper_loc = upper_limit * pp_size ))
            if [[ $physical_upper_loc -gt 4096 ]]; then
               break
            fi

            #----------------------------------------------
            # Success!  Enough adjacent partitions are free
            #----------------------------------------------
            return 0
         else
            break
         fi
      fi
   done

   return 1
}

# function needed to check blv size, called by boot_lv_check
create_free_space_map ()
{
   for disk in $blv_disk_list; do
      LANG=C lspv -p $disk | grep " free " | \
      awk -v disk=$disk '{print disk":"$1}'
   done > $FREE_MAPFILE
}

#-------------------------------------------------------------------------
# Given a disk name check to see if we find $pps_needed free contiguous
# partitions for creating a new copy of the blv.  If we can then append
# the pp range map of the available space to the $NEW_MAPFILE, update the
# free space map and return 0.  If we cannot then return 1.  NOTE: If this
# function is called more than once for the same disk name then a separate
# pp range will be allocated for each call.  This will enable the code to
# handle multiple copies of the blv on the same disk.
#-------------------------------------------------------------------------
can_create_contig ()
{
   disk=$1

   grep "^$disk:" $FREE_MAPFILE | \
   while read location; do
      lower_limit=`echo $location | awk -F: '{print $2}' | awk -F- '{print $1}'`
      upper_limit=`echo $location | awk -F: '{print $2}' | awk -F- '{print $2}'`
      (( free_pps = upper_limit - lower_limit + 1 ))

      if [[ $free_pps -ge $pps_needed ]]; then

         # Make sure we are still in the first 4GB of the disk
		 (( upper_for_blv = lower_limit + pps_needed ))
         (( physical_upper_loc = upper_for_blv * pp_size ))
         if [[ $physical_upper_loc -gt 4096 ]]; then
            break
         fi
         return 0
      fi
   done

   return 1
}

#  Determines if the blv is large enough, and if not, if it can be
#  expanded.
function boot_lv_check
{
ODMDIR=/etc/objrepos

#----------------------------------------------------
# Get the boot disk which will be the first LP on PV1
#----------------------------------------------------
boot_disk=`LANG=C lslv -m $BLV | grep "^0001 " | awk '{print $3}'`

#--------------------------------------------
# Generate a list of all the disks in the blv
#--------------------------------------------
blv_disk_list=`LANG=C lslv -l $BLV | tail +3 | awk '{print $1}' | sort -u`

#-------------------------------------------------
# Get the number of physical partitions in the blv
#-------------------------------------------------
num_pps=`LANG=C lslv -l $BLV | grep -w $boot_disk | awk '{print $2}' | \
         awk -F: '{print $1}'`

#--------------------------------
# Get the physical partition size
#--------------------------------
pp_size=`LANG=C lsvg rootvg | grep " PP SIZE: " | awk '{print $6}'`

#-----------------------------
# Determine the blv size in MB
#-----------------------------
(( blv_size = pp_size * num_pps ))

#-----------------------------------------------------------------
# If the size of the blv is BLV_REQ_SPACE or greater then we don't
# need to do anything.
#-----------------------------------------------------------------
if [[ $blv_size -lt $BLV_REQ_SPACE ]]
then
    #----------------------------------------------------
    # Get the number of copies of the boot logical volume
    #----------------------------------------------------
    num_copies=`LANG=C lslv $BLV | grep "^COPIES:" | awk '{print $2}'`

    #------------------------------------
    # Save the original pp map of the blv
    #------------------------------------
    save_orig_blv_map

    #-----------------------------------------------------------
    # Create a pp map of the free space for each disk in the blv
    #-----------------------------------------------------------
    create_free_space_map

    # Need to see if enough room to expand and print message if not.
    #---------------------------------------------------------------------
    # Determine the number of physical partitions needed to extend the blv
    #---------------------------------------------------------------------
    (( pps_needed = ( BLV_REQ_SPACE - blv_size ) / pp_size ))
    (( pps_remain = ( BLV_REQ_SPACE - blv_size ) % pp_size ))
    if [[ $pps_remain -ne 0 ]]
    then
        (( pps_needed = pps_needed + 1 ))
    fi

    ABLE_TO_EXTEND=TRUE
    ABLE_TO_RELOCATE=TRUE

#-------------------------------------------------------------------
# For each copy of the blv check to see if we can extend that copy.
# If any copy cannot be extended then we'll have to remove the blv
# and recreate it.  This is because you can't extend one copy and
# relocate another - the same action has to be taken for all copies.
#-------------------------------------------------------------------
    for copy in `cat $ORIG_MAPFILE`; do
        if ! can_extend $copy; then
        ABLE_TO_EXTEND=
        break
        fi
    done

    if [ ! "$ABLE_TO_EXTEND" ]
    then
        # Need to see if there are enough free partitions elsewhere
        #-----------------------------------------------------------------
        # Convert BLV_REQ_SPACE to the total number of physical partitions
        # needed to create a new, larger blv.
        #-----------------------------------------------------------------
        (( pps_needed = BLV_REQ_SPACE / pp_size ))
        (( pps_remain = BLV_REQ_SPACE % pp_size ))
        if [[ $pps_remain -ne 0 ]]
        then
            (( pps_needed = pps_needed + 1 ))
        fi

        #----------------------------------------------------------------------
        # For each copy of the blv check to see if we can find space to create
        # that copy.  If any copy cannot be relocated due to lack of space then
        # we'll have to recreate the original blv from the pp map we saved off
        # earlier.
        #----------------------------------------------------------------------
        for copy in `cat $ORIG_MAPFILE | awk -F: '{print $1}'`; do
           if ! can_create_contig $copy; then
              ABLE_TO_RELOCATE=
              break
           fi
        done
    fi
    if [ ! "$ABLE_TO_RELOCATE" ]
    then
        echo "
The Boot Logical Volume is less than 28MB, and there are not
enough contiguous free partitions available to extend or move it.
Please see if you can free any partitions in the first 4GB of
the disk hd5 is currently on, or move the boot logical volume (hd5)
to another disk."
    fi

fi

}

# Determines which software will be removed during the migration
function removing_software
{
# Create a list of installed software
LANG=C /usr/bin/lslpp -qlc -Ous > /tmp/old.installed.$$

# List of filesets potentially to be removed
cat > /tmp/old.remove.$$ <<!!
bos.aixpert.websm
bos.cns.com.asw
bos.cns.p10.asw
bos.cns.p10.diag
bos.cns.p10.rte
bos.cns.p10.samples
bos.cns.p10.tools
bos.cns.s20.asw
bos.cns.s20.rte
bos.cns.s20.samples
bos.cns.s20des.asw
bos.compat.imk
bos.compat.lan
bos.compat.NetInstl
bos.ifor_ls.client
bos.ifor_ls.server
bos.info.en_US.adapters_gd_ref
bos.info.en_US.aix_tech_ref
bos.info.en_US.assemb_ref
bos.info.en_US.cmds_ref
bos.info.en_US.files_ref
bos.info.en_US.info_help
bos.info.en_US.keybd_tech_ref
bos.info.en_US.manage_gds
bos.info.en_US.probsolv_gds
bos.info.en_US.prog_gds
bos.info.en_US.smit_help
bos.info.en_US.update
bos.info.en_US.user_gds
bos.info.rte
bos.loc.pc_compat.com
bos.loc.pc_compat.fnt
bos.loc.pc_compat.Ar_AA
bos.loc.pc_compat.Iw_IL
bos.net.ipsec.websm
bos.perf.pmr
bos.pkcs11
bos.powermgt.rte
bos.rcs
bos.som.comp
bos.som.dsom
bos.som.rte
bos.som.util
bos.sysmgt.nim.master_gui
bos.sysmgt.smit.softlic
bos.txt.xpv.dps
bos.twintail
cifs.base.websm
cluster.vsm.es
cluster.vsm.server
csm.bluegene
csm.client
csm.core
csm.deploy
csm.diagnostics
csm.dsh
csm.essl
csm.gpfs
csm.gui.dcem
csm.gui.websm
csm.hams
csm.hc_utils
csm.hpsnm
csm.ll
csm.msg.fr_CA.core
csm.msg.FR_CA.core
csm.pe
csm.pessl
csm.server
devices.AS4D_rspc.base.rte
devices.base.rte
devices.base.diag
devices.buc.00004001.X11
devices.buc.00004001.X11.com
devices.buc.00004001.com
devices.buc.00004001.diag
devices.buc.00004001.rte
devices.buc.00004002.X11
devices.buc.00004002.diag
devices.buc.00004002.rte
devices.buc.00004005.X11
devices.buc.00004005.diag
devices.buc.00004005.rte
devices.buc.00004006.X11
devices.buc.00004006.diag
devices.buc.00004006.rte
devices.buc.00004007.X11
devices.buc.00004007.diag
devices.buc.00004007.rte
devices.chrp.IBM.HPS.rte
devices.chrp.IBM.HPS.hpsfu
devices.common.IBM.fddi.rte
devices.common.IBM.bbl.diag
devices.common.IBM.rby.diag
devices.common.IBM.ARTIC.diag
devices.common.IBM.fcs.rte
devices.common.IBM.ntx.asw
devices.common.IBM.ntx.rte
devices.common.IBM.pmmd_chrp.rte
devices.common.IBM.sni.rte
devices.common.IBM.sni.ntbl
devices.common.IBM.ssa.rte
devices.common.IBM.ssa.diag
devices.isa.c1x.rte
devices.isa.c1x.diag
devices.isa.cxia.rte
devices.isa.cxia.com
devices.isa.cxia.ucode
devices.isa.cxia.diag
devices.isa.cxia128.rte
devices.isa.cxia128.ucode
devices.isa.cxia128.diag
devices.isa.IBM0010.rte
devices.isa.mm2.rte
devices.isa.mm2.mpqp
devices.isa.mm2.diag
devices.isa.pc8s.rte
devices.isa.pc8s.diag
devices.isa.pcmcia.rte
devices.isa.PNP80CC.rte
devices.isa_sio.baud.rte
devices.isa_sio.IBM001C.rte
devices.isa_sio.IBM001E.rte
devices.isa_sio.IBM001E.diag
devices.isa_sio.IBM001F.rte
devices.isa_sio.IBM001F.diag
devices.isa_sio.PNP0303.diag
devices.isa_sio.PNP0303.rte
devices.isa_sio.PNP0400.rte
devices.isa_sio.PNP0400.diag
devices.isa_sio.PNP0401.rte
devices.isa_sio.PNP0401.diag
devices.isa_sio.PNP0501.rte
devices.isa_sio.PNP0501.diag
devices.isa_sio.PNP0600.com
devices.isa_sio.PNP0600.rte
devices.isa_sio.PNP0700.rte
devices.isa_sio.PNP0700.diag
devices.isa_sio.PNP0E00.rte
devices.isa_sio.PNP0F03.diag
devices.isa_sio.PNP0F03.rte
devices.isa_sio.km.diag
devices.isa_sio.km.rte
devices.isa_sio.pnpPNP.400.diag
devices.isa_sio.pnpPNP.400.rte
devices.isa_sio.IBM0005.IBM8301.rte
devices.isa_sio.IBM000E.rte
devices.mca.0072.diag
devices.mca.0072.rte
devices.mca.0095.diag
devices.mca.0095.rte
devices.mca.0200.rte
devices.mca.0200.diag
devices.mca.0210.rte
devices.mca.0210.diag
devices.mca.61fd.rte
devices.mca.61fd.diag
devices.mca.6336.rte
devices.mca.6336.diag
devices.mca.8787.rte
devices.mca.8787.diag
devices.mca.8787.ucode
devices.mca.8d77.rte
devices.mca.8d77.diag
devices.mca.8d77.ucode
devices.mca.8ee3.rte
devices.mca.8ee3.diag
devices.mca.8ee3.ucode
devices.mca.8ee3.X11
devices.mca.8ee4.rte
devices.mca.8ee4.diag
devices.mca.8ee4.X11
devices.mca.8ee5.rte
devices.mca.8ee5.diag
devices.mca.8ee5.X11
devices.mca.8ef2.rte
devices.mca.8ef2.com
devices.mca.8ef2.diag
devices.mca.8ef2.diag.com
devices.mca.8ef3.rte
devices.mca.8ef3.diag
devices.mca.8ef4.rte
devices.mca.8ef4.diag
devices.mca.8ef4.ucode
devices.mca.8ef5.rte
devices.mca.8ef5.diag
devices.mca.8ef5.com
devices.mca.8efc.rte
devices.mca.8efc.diag
devices.mca.8efc.com
devices.mca.8f61.rte
devices.mca.8f61.diag
devices.mca.8f61.X11
devices.mca.8f62.rte
devices.mca.8f62.diag
devices.mca.8f64.rte
devices.mca.8f64.diag
devices.mca.8f66.rte
devices.mca.8f66.diag
devices.mca.8f66.ucode
devices.mca.8f67.rte
devices.mca.8f67.diag
devices.mca.8f67.ucode
devices.mca.8f67.com
devices.mca.8f67.diag.com
devices.mca.8f70.rte
devices.mca.8f70.diag
devices.mca.8f70.mpqp
devices.mca.8f70.client
devices.mca.8f78.rte
devices.mca.8f78.diag
devices.mca.8f78.ucode
devices.mca.8f7f.rte
devices.mca.8f7f.diag
devices.mca.8f7f.ucode
devices.mca.8f95.rte
devices.mca.8f95.diag
devices.mca.8f96.rte
devices.mca.8f97.rte
devices.mca.8f97.diag
devices.mca.8f97.com
devices.mca.8f98.rte
devices.mca.8f98.diag
devices.mca.8f9a.rte
devices.mca.8f9a.diag
devices.mca.8f9a.ucode
devices.mca.8f9a.X11
devices.mca.8f9d.rte
devices.mca.8f9d.diag
devices.mca.8fa2.rte
devices.mca.8fa2.diag
devices.mca.8fba.rte
devices.mca.8fba.diag
devices.mca.8fba.com
devices.mca.8fbc.rte
devices.mca.8fbc.diag
devices.mca.8fbc.ucode
devices.mca.8fbc.X11
devices.mca.8fc3.rte
devices.mca.8fc3.diag
devices.mca.8fc3.ucode
devices.mca.8fc8.rte
devices.mca.8fc8.diag
devices.mca.8fc8.ucode
devices.mca.8fe2.diag
devices.mca.8fe2.rte
devices.mca.8fe2.ucode
devices.mca.8fe5.diag
devices.mca.8fe5.rte
devices.mca.8fe5.ucode
devices.mca.8fe5.api
devices.mca.8ff4.rte
devices.mca.8ff4.diag
devices.mca.8ffd.diag
devices.mca.8ffd.rte
devices.mca.8ffd.ucode
devices.mca.8ffd.X11
devices.mca.dee6.rte
devices.mca.deff.rte
devices.mca.deff.diag
devices.mca.deff.sdlc
devices.mca.df5f.rte
devices.mca.df5f.com
devices.mca.df9f.rte
devices.mca.df9f.diag
devices.mca.dfe5.rte
devices.mca.e1ff.rte
devices.mca.e1ff.diag
devices.mca.edd0.rte
devices.mca.edd0.diag
devices.mca.edd0.com
devices.mca.edd1.rte
devices.mca.edd1.diag
devices.mca.edd2.rte
devices.mca.edd2.diag
devices.mca.edd3.rte
devices.mca.edd3.diag
devices.mca.edd5.diag
devices.mca.edd5.com
devices.mca.edd5.rte
devices.mca.edd5.X11
devices.mca.edd6.rte
devices.mca.edd6.diag
devices.mca.efbd.rte
devices.mca.efbd.diag
devices.mca.efbd.ucode
devices.mca.eff0.rte
devices.mca.eff0.diag
devices.mca.eff0.ucode
devices.mca.eff0.c2x_x25
devices.mca.f6f8.diag
devices.mca.f6f8.rte
devices.mca.f6f4.diag
devices.mca.f6f4.rte
devices.mca.f6fe.rte
devices.mca.fe92.rte
devices.mca.fe92.diag
devices.mca.fe92.ucode
devices.mca.fe92.blkmux
devices.mca.fed9.rte
devices.mca.ffe1.rte
devices.mca.ffe1.diag
devices.mca.ffe1.ucode
devices.msg.en_US.as400.rte
devices.msg.en_US.chrp.IBM.HPS.rte
devices.msg.en_US.chrp.IBM.HPS.hpsfu
devices.msg.en_US.common.IBM.sni.rte
devices.msg.en_US.common.IBM.sni.ntbl
devices.pci.0e100091.X11
devices.pci.0e100091.diag
devices.pci.0e100091.rte
devices.pci.00100100.rte
devices.pci.00100300.rte
devices.pci.00100300.diag
devices.pci.14101800.diag
devices.pci.14101800.rte
devices.pci.14101b00.X11
devices.pci.14101b00.diag
devices.pci.14101b00.rte
devices.pci.14101c00.rte
devices.pci.14102000.X11
devices.pci.14102000.diag
devices.pci.14102000.rte
devices.pci.14102000.ucode
devices.pci.14102e00.vsmit
devices.pci.14103600.rte
devices.pci.14103c00.X11
devices.pci.14103c00.com
devices.pci.14103c00.diag
devices.pci.14103c00.rte
devices.pci.14104000.rte
devices.pci.14104000.X11
devices.pci.14104000.diag
devices.pci.14104000.ucode
devices.pci.14104300.rte
devices.pci.14104500.rte
devices.pci.14104500.diag
devices.pci.14104a00.com
devices.pci.14104a00.rte
devices.pci.14104a00.diag
devices.pci.14105300.diag
devices.pci.14105300.rte
devices.pci.14105400.X11
devices.pci.14105400.diag
devices.pci.14105400.rte
devices.pci.14105600.hostlan.rte
devices.pci.14105600.rte
devices.pci.14105600.vcdrom.rte
devices.pci.14105600.vcons.rte
devices.pci.14105600.vdasd.rte
devices.pci.14105e00.X11
devices.pci.14105e00.diag
devices.pci.14105e00.rte
devices.pci.14107800.rte
devices.pci.14107a01.rte
devices.pci.14107a01.X11
devices.pci.14107a01.diag
devices.pci.14107d01.rte
devices.pci.14107d01.X11
devices.pci.14107d01.diag
devices.pci.14108e00.rte
devices.pci.14108e00.X11
devices.pci.14108e00.diag
devices.pci.14109100.rte
devices.pci.14109100.diag
devices.pci.14109b01.rte
devices.pci.14109b01.X11
devices.pci.14109b01.diag
devices.pci.1410a500.com
devices.pci.1410a500.rte
devices.pci.1410a500.diag
devices.pci.1410a600.com
devices.pci.1410a600.rte
devices.pci.1410a600.diag
devices.pci.1410a800.com
devices.pci.1410a800.rte
devices.pci.1410a800.diag
devices.pci.1410b800.rte
devices.pci.1410b800.X11
devices.pci.1410b800.diag
devices.pci.1410be00.com
devices.pci.1410be00.rte
devices.pci.1410be00.diag
devices.pci.1c104ac2.X11
devices.pci.1c104ac2.rte
devices.pci.22100020.diag
devices.pci.22100020.rte
devices.pci.2b100010.rte
devices.pci.2b101a05.rte
devices.pci.2b101a05.X11
devices.pci.2b101a05.diag
devices.pci.2b102005.rte
devices.pci.2b102005.X11
devices.pci.2b102005.diag
devices.pci.31114571.rte
devices.pci.31114571.diag
devices.pci.31114671.rte
devices.pci.31114671.diag
devices.pci.331101e0.rte
devices.pci.331101e0.diag
devices.pci.33531188.rte
devices.pci.33531188.X11
devices.pci.33531188.diag
devices.pci.33531288.X11
devices.pci.33531288.rte
devices.pci.3353c088.rte
devices.pci.3353c088.com
devices.pci.3353c088.X11
devices.pci.3353c088.X11.com
devices.pci.3353c188.rte
devices.pci.3353c188.X11
devices.pci.3353c288.rte
devices.pci.3353c288.X11
devices.pci.3353c388.rte
devices.pci.3353c388.X11
devices.pci.48110040.diag
devices.pci.48110040.diagsa
devices.pci.48110040.rte
devices.pci.86806019.rte
devices.pci.86808404.rte
devices.pci.86808404.com
devices.pci.b315445a.rte
devices.pci.b315445a.diag
devices.pci.b7105090.diag
devices.pci.b7105090.rte
devices.pci.ed101073.rte
devices.pci.ibmccm.rte
devices.pci.PNP0A00.rte
devices.pci.PNP0A03.rte
devices.pciex.b3157862.rte
devices.pciex.b3157862.diag
devices.pciex.df1020e214103304.diag
devices.pciex.df1020e214103304.rte
devices.pcmcia.a4000200.rte
devices.pcmcia.a4001d00.rte
devices.pcmcia.a4001e00.rte
devices.pcmcia.a4003900.rte
devices.pcmcia.ethernet.com
devices.pcmcia.serial.com
devices.pcmcia.tokenring.com
devices.raid_vsm.rte
devices.rs6ksmp.base.rte
devices.rspc.base.rte
devices.rspc.base.diag
devices.scsi.scarray.vsm
devices.scsi.scarray.rte
devices.scsi.scarray.diag
devices.serial.gio.X11
devices.serial.gio.diag
devices.serial.gio.rte
devices.ssa.IBM_raid.vsm
devices.ssa.IBM_raid.rte
devices.ssa.disk.rte
devices.ssa.tm.rte
devices.ssa.network_agent.rte
devices.sio.ktma.diag
devices.sio.ktma.rte
devices.sio.fda.com
devices.sio.fda.rte
devices.sio.fda.diag
devices.sio.ppa.com
devices.sio.ppa.rte
devices.sio.ppa.diag
devices.sio.sa.rte
devices.sio.sa.diag
devices.sys.mca.rte
devices.sys.pci.rte
devices.sys.pci_AS4D_rspc.rte
devices.sys.PNP0A03.rte
devices.sys.sga.diag
devices.sys.sga.rte
devices.sys.sga.X11
devices.sys.sgabus.rte
devices.sys.slc.rte
devices.sys.slc.diag
devices.sys.wga.diag
devices.sys.wga.rte
devices.sys.wga.X11
Graphon.client
Graphon.server
icraft.rte
icraft.JP.rte
icraft.msg.ja_JP
icraft.msg.hu_HU
icraft.msg.Ja_JP
icraft.msg.En_US
icraft.msg.en_US
icraft.info.en_US.user_gd_ref
ICU4C.man.en_US
ifor_ls.base.cli
ifor_ls.base.gui
ifor_ls.client.base
ifor_ls.client.gui
ifor_ls.compat.cli
ifor_ls.compat.gui
ifor_ls.html.en_US.base.cli
ifor_ls.java.gui
ifor_ls.jcs
ifor_ls.msg.en_US.base.cli
ifor_ls.msg.en_US.base.gui
ifor_ls.msg.en_US.compat.cli
ifor_ls.msg.en_US.compat.gui
ifor_ls.msg.en_US.java.gui
ifor_ls.msg.Ja_JP.base.gui
ifor_ls.msg.Ja_JP.compat.cli
ifor_ls.msg.Ja_JP.compat.gui
ifor_ls.msg.de_DE.base.gui
ifor_ls.msg.de_DE.compat.cli
ifor_ls.msg.de_DE.compat.gui
ifor_ls.msg.es_ES.base.gui
ifor_ls.msg.es_ES.compat.cli
ifor_ls.msg.es_ES.compat.gui
ifor_ls.msg.fr_FR.base.gui
ifor_ls.msg.fr_FR.compat.cli
ifor_ls.msg.fr_FR.compat.gui
ifor_ls.msg.it_IT.base.gui
ifor_ls.msg.it_IT.compat.cli
ifor_ls.msg.it_IT.compat.gui
ifor_ls.msg.ko_KR.base.gui
ifor_ls.msg.ko_KR.compat.cli
ifor_ls.msg.ko_KR.compat.gui
ifor_ls.msg.pt_BR.base.gui
ifor_ls.msg.pt_BR.compat.cli
ifor_ls.msg.pt_BR.compat.gui
ifor_ls.msg.zh_CN.base.gui
ifor_ls.msg.zh_CN.compat.cli
ifor_ls.msg.zh_CN.compat.gui
ifor_ls.msg.zh_TW.base.gui
ifor_ls.msg.zh_TW.compat.cli
ifor_ls.msg.zh_TW.compat.gui
ifor_ls.ipf.en_US.base.gui
ifor_ls.ipf.Ja_JP.base.gui
ifor_ls.ipf.de_DE.base.gui
ifor_ls.ipf.es_ES.base.gui
ifor_ls.ipf.fr_FR.base.gui
ifor_ls.ipf.it_IT.base.gui
ifor_ls.ipf.ko_KR.base.gui
ifor_ls.ipf.pt_BR.base.gui
ifor_ls.ipf.zh_CN.base.gui
ifor_ls.ipf.zh_TW.base.gui
ifor_ls.server.base
ifor_ls.server.gui
ifor_ls.msg.en_US.client.base
ifor_ls.msg.en_US.client.gui
ifor_ls.msg.en_US.server.base
ifor_ls.msg.en_US.server.gui
ifor_ls.msg.Ja_JP.client.base
ifor_ls.msg.Ja_JP.client.gui
ifor_ls.msg.Ja_JP.server.base
ifor_ls.msg.Ja_JP.server.gui
ifor_ls.msg.de_DE.client.base
ifor_ls.msg.de_DE.client.gui
ifor_ls.msg.de_DE.server.base
ifor_ls.msg.de_DE.server.gui
ifor_ls.msg.es_ES.client.base
ifor_ls.msg.es_ES.client.gui
ifor_ls.msg.es_ES.server.base
ifor_ls.msg.es_ES.server.gui
ifor_ls.msg.fr_FR.client.base
ifor_ls.msg.fr_FR.client.gui
ifor_ls.msg.fr_FR.server.base
ifor_ls.msg.fr_FR.server.gui
ifor_ls.msg.it_IT.client.base
ifor_ls.msg.it_IT.client.gui
ifor_ls.msg.it_IT.server.base
ifor_ls.msg.it_IT.server.gui
ifor_ls.msg.ko_KR.client.base
ifor_ls.msg.ko_KR.client.gui
ifor_ls.msg.ko_KR.server.base
ifor_ls.msg.ko_KR.server.gui
ifor_ls.msg.pt_BR.client.base
ifor_ls.msg.pt_BR.client.gui
ifor_ls.msg.pt_BR.server.base
ifor_ls.msg.pt_BR.server.gui
ifor_ls.msg.zh_CN.client.base
ifor_ls.msg.zh_CN.client.gui
ifor_ls.msg.zh_CN.server.base
ifor_ls.msg.zh_CN.server.gui
ifor_ls.msg.zh_TW.client.base
ifor_ls.msg.zh_TW.client.gui
ifor_ls.msg.zh_TW.server.base
ifor_ls.msg.zh_TW.server.gui
infoxl
invscout.websm
ipx.rte
ldap.msg.zh_CN
ldap.html.ca_ES.config
ldap.html.ca_ES.man
ldap.msg.ca_ES
lum.base.cli
lum.base.gui
lum.html.en_US.base.cli
lum.msg.en_US.base.cli
lum.msg.en_US.base.gui
Netscape.communicator.com
Netscape.communicator.bidi
Netscape.communicator.plugins
Netscape.communicator.us
Netscape.communicator.wt
Netscape.communicator.fr
Netscape.communicator-fr.rte
Netscape.communicator-us.rte
Netscape.communicator-wt.rte
Netscape.navigator.rte
Netscape.nav-us.rte
Netscape.nav.rte
OpenGL.info.en_US.GL32
OpenGL.info.en_US.OpenGL_X
OpenGL.GL32.adt.demos
OpenGL.GL32.adt.include
OpenGL.GL32.adt.samples
OpenGL.GL32.adt.util
OpenGL.GL32.dev.mca.8ffd
OpenGL.GL32.dev.mca.8fbc
OpenGL.GL32.dev.mca.8ee3
OpenGL.GL32.dev.mca.8f61
OpenGL.GL32.dev.buc.00004002
OpenGL.GL32.dev.buc.00004002.com
OpenGL.GL32.dev.pci.14105e00
OpenGL.GL32.dev.pci.14105400
OpenGL.GL32.rte.base
OpenGL.msg.ca_ES.GL32.rte.base
OpenGL.msg.cs_CZ.GL32.rte.base
OpenGL.msg.de_DE.GL32.rte.base
OpenGL.msg.en_US.GL32.rte.base
OpenGL.msg.es_ES.GL32.rte.base
OpenGL.msg.fr_FR.GL32.rte.base
OpenGL.msg.hu_HU.GL32.rte.base
OpenGL.msg.it_IT.GL32.rte.base
OpenGL.msg.Ja_JP.GL32.rte.base
OpenGL.msg.ja_JP.GL32.rte.base
OpenGL.msg.ko_KR.GL32.rte.base
OpenGL.msg.pl_PL.GL32.rte.base
OpenGL.msg.pt_BR.GL32.rte.base
OpenGL.msg.ru_RU.GL32.rte.base
OpenGL.msg.sk_SK.GL32.rte.base
OpenGL.msg.sv_SE.GL32.rte.base
OpenGL.msg.Zh_CN.GL32.rte.base
OpenGL.msg.zh_CN.GL32.rte.base
OpenGL.msg.Zh_TW.GL32.rte.base
OpenGL.msg.zh_TW.GL32.rte.base
OpenGL.OpenGL_X.dev.pci.14103c00.PPC
OpenGL.OpenGL_X.dev.pci.14105400.PPC
OpenGL.OpenGL_X.dev.pci.14105400.PPC_mp
OpenGL.OpenGL_X.dev.pci.14105e00.PPC
OpenGL.OpenGL_X.dev.pci.14105e00.PPC_mp
OpenGL.OpenGL_X.dev.pci.14108e00.PPC
OpenGL.OpenGL_X.dev.pci.1410b800.PPC
OpenGL.OpenGL_X.dev.buc.00004002.PPC
OpenGL.OpenGL_X.dev.common.bbl
OpenGL.OpenGL_X.dev.common.rby
OpenGL.OpenGL_X.dev.mca.8f61
OpenGL.OpenGL_X.dev.pci.14104000.PPC
OpenGL.OpenGL_X.dev.pci.14107a01.PPC
OpenGL.OpenGL_X.rte.base_mp
OpenGL.OpenGL_X.tools.viewperf
ossc.vt.obj
ossc.x400.obj
ossc.x500.obj
PEX_PHIGS.dev.buc.00004002
PEX_PHIGS.dev.mca.8ee3
PEX_PHIGS.dev.mca.8fbc
PEX_PHIGS.dev.mca.8f61
PEX_PHIGS.dev.mca.8ffd
PEX_PHIGS.dev.pci.14103c00
PEX_PHIGS.dev.pci.14104000
PEX_PHIGS.dev.pci.14105400
PEX_PHIGS.dev.pci.14105e00
PEX_PHIGS.dev.pci.14107a01
PEX_PHIGS.dev.pci.14108e00
PEX_PHIGS.dev.pci.1410b800
PEX_PHIGS.info.en_US.PEX
PEX_PHIGS.info.en_US.graPHIGS
PEX_PHIGS.msg.ca_ES.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.Ca_ES.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.cs_CZ.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.de_DE.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.De_DE.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.en_US.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.En_US.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.es_ES.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.Es_ES.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.fr_FR.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.Fr_FR.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.hu_HU.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.it_IT.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.It_IT.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.ja_JP.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.Ja_JP.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.ko_KR.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.pl_PL.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.pt_BR.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.ru_RU.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.sv_SE.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.Sv_SE.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.zh_CN.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.ZH_CN.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.zh_TW.PEX.adt.si_phigs.lib
PEX_PHIGS.msg.Zh_TW.PEX.adt.si_phigs.lib
PEX_PHIGS.PEX.adt.pexlib.clients
PEX_PHIGS.PEX.adt.pexlib.include
PEX_PHIGS.PEX.adt.pexlib.util
PEX_PHIGS.PEX.adt.si_phigs.clients
PEX_PHIGS.PEX.adt.si_phigs.include
PEX_PHIGS.PEX.adt.si_phigs.lib
PEX_PHIGS.PEX.adt.si_phigs.man
PEX_PHIGS.PEX.adt.tools
PEX_PHIGS.PEX.rte.base
PEX_PHIGS.PEX.rte.soft
pkg_gd.html.sk_SK
pkg_gd.html.ru_RU
pkg_gd.html.pt_BR
pkg_gd.html.pl_PL
pkg_gd.html.ko_KR
pkg_gd.html.it_IT
pkg_gd.html.hu_HU
pkg_gd.html.fr_FR
pkg_gd.html.es_ES
pkg_gd.html.de_DE
pkg_gd.html.cs_CZ
pkg_gd.html.ca_ES
pkg_gd.html.Zh_TW
pkg_gd.html.Ja_JP
pkg_gd.html.en_US
pkg_gd
printers.ibm5575_JP.rte
printers.ibm5577_JP.rte
printers.ibm5585_JP.rte
printers.ibm5586_JP.rte
printers.ibm5588_JP.rte
rsct.lapi.bsr
rsct.lapi.rte
rsct.lapi.samp
rsct.vsd.vsdd
rsct.vsd.rvsd
rsct.vsd.cmds
rsct.vsd.vsdrm
sysmgt.sguide.rte
sysmgt.websm.ucf
sysmgt.websm.widgets
sysmgt.websm.accessibility
sysmgt.websm.apps
sysmgt.websm.diag
sysmgt.websm.diskarray.fc
sysmgt.websm.framework
sysmgt.websm.icons
sysmgt.websm.rte
sysmgt.websm.webaccess
sysmgt.websm.security
sysmgt.websm.security-us
sysmgt.websm.webaccess
sysmgt.pconsole.apps.websm
TNT.rte
UMS.demo
UMS.dictation
UMS.H_32x
UMS.info.en_US.user_gd
UMS.objects
UMS.samples
UMS.speech
UMS.video_ext
Wabi.Dt
Wabi.fnt
Wabi.info.en_US.usr_gd
Wabi.loc.en_US
Wabi.loc.En_UK
Wabi.man.en_US
Wabi.printers
Wabi.rte
Wabi.win
Welcome.arcade
Welcome.rte
Welcome.html.Ca_ES
Welcome.html.De_DE
Welcome.html.Es_ES
Welcome.html.Fr_CA
Welcome.html.Fr_FR
Welcome.html.ZH_CN
Welcome.html.de_DE
Welcome.html.fr_CA
Welcome.html.ja_JP
Welcome.html.ru_RU
Welcome.html.ru_RU.arcade
Welcome.html.sk_SK
Welcome.html.sk_SK.arcade
Welcome.html.en_US
Welcome.html.en_US.arcade
Welcome.html.zh_TW
Welcome.html.zh_TW.arcade
Welcome.html.zh_CN
Welcome.html.zh_CN.arcade
Welcome.html.pl_PL
Welcome.html.pl_PL.arcade
Welcome.html.ko_KR
Welcome.html.ko_KR.arcade
Welcome.html.hu_HU
Welcome.html.hu_HU.arcade
Welcome.html.fr_FR
Welcome.html.fr_FR.arcade
Welcome.html.es_ES
Welcome.html.es_ES.arcade
Welcome.html.ca_ES
Welcome.html.ca_ES.arcade
Welcome.html.Ja_JP
Welcome.html.Ja_JP.arcade
X11.apps.ims
X11.apps.pcmcia
X11.apps.pm
X11.compat.fnt.oldX
X11.compat.fnt.pc
X11.info.en_US.Dt
X11.info.en_US.prog_gds
X11.info.en_US.tech_ref
X11.info.en_US.x_st_mgr.manage_gd
X11.info.rte
X11.loc.ja_JP.info.rte
X11.loc.Ja_JP.info.rte
X11.man.en_US.base
X11.msg.sv_SE.vsm.rte
X11.samples.im
X11.vsm.helps
X11.vsm.icons
X11.vsm.rte
X11.x_st_mgr.compat
X11.x_st_mgr.rte
!!

# for when you are removing all msg filesets
LLIST="CA_ES CS_CZ DE_DE EN_US ES_ES FR_FR HU_HU IT_IT JA_JP KO_KR PL_PL PT_BR RU_RU SK_SK ZH_CN ZH_TW"

for LL in $LLIST
do
    cat >> /tmp/old.remove.$$ <<!!
Netscape.msg.$LL.communicator.rte
Netscape.help.$LL.communicator.rte
Netscape.msg.$LL.nav.rte
Netscape.msg.$LL.nav-us.rte
Netscape.help.$LL.nav.rte
Netscape.help.$LL.nav-us.rte
OpenGL.msg.$LL.GL32.rte.base
X11.msg.$LL.apps.ims
X11.msg.$LL.apps.pm
X11.msg.$LL.info.rte
X11.msg.$LL.x_st_mgr.rte
UMS.msg.$LL.objects
UMS.loc.$LL.objects
bos.msg.$LL.sysmgt.nim.master_gui
cifs.msg.$LL.compat
csm.msg.$LL.core
rsct.lapi.msg.$LL.rte
sysmgt.help.$LL.websm
sysmgt.help.msg.$LL.websm
sysmgt.msg.$LL.sguide.rte
sysmgt.msg.$LL.websm.apps
!!
done

# for when you are removing all msg filesets
LLIST="sv_SE zh_TW zh_CN sk_SK ru_RU pt_BR pl_PL no_NO nl_BE ko_KR ja_JP it_IT hu_HU fr_FR es_ES en_US de_DE cs_CZ ca_ES"

for LL in $LLIST
do
    cat >> /tmp/old.remove.$$ <<!!
Netscape.msg.$LL.communicator.rte
Netscape.help.$LL.communicator.rte
Netscape.msg.$LL.nav.rte
Netscape.msg.$LL.nav-us.rte
Netscape.help.$LL.nav.rte
Netscape.help.$LL.nav-us.rte
X11.msg.$LL.apps.ims
X11.msg.$LL.apps.pm
X11.msg.$LL.info.rte
X11.msg.$LL.x_st_mgr.rte
UMS.msg.$LL.objects
UMS.loc.$LL.objects
bos.msg.$LL.sysmgt.nim.master_gui
cifs.msg.$LL.compat
csm.msg.$LL.core
rsct.lapi.msg.$LL.rte
sysmgt.help.$LL.websm
sysmgt.help.msg.$LL.websm
sysmgt.msg.$LL.sguide.rte
sysmgt.msg.$LL.websm.apps
!!
done

# special list for Netscape
LLIST="ar_AA he_IL Ar_AA He_IL"
for LL in $LLIST
do
    cat >> /tmp/old.remove.$$ <<!!
Netscape.msg.$LL.communicator.rte
Netscape.help.$LL.communicator.rte
Netscape.msg.$LL.nav.rte
Netscape.msg.$LL.nav-us.rte
Netscape.help.$LL.nav.rte
Netscape.help.$LL.nav-us.rte
!!
done

# for when you are removing all msg filesets
LLIST="Zh_TW Zh_CN Ja_JP"

for LL in $LLIST
do
    cat >> /tmp/old.remove.$$ <<!!
Netscape.msg.$LL.communicator.rte
Netscape.help.$LL.communicator.rte
Netscape.msg.$LL.nav.rte
Netscape.msg.$LL.nav-us.rte
Netscape.help.$LL.nav.rte
Netscape.help.$LL.nav-us.rte
X11.msg.$LL.apps.ims
X11.msg.$LL.apps.pm
X11.msg.$LL.info.rte
X11.msg.$LL.x_st_mgr.rte
UMS.msg.$LL.objects
UMS.loc.$LL.objects
bos.msg.$LL.sysmgt.nim.master_gui
cifs.msg.$LL.compat
csm.msg.$LL.core
rsct.lapi.msg.$LL.rte
sysmgt.help.$LL.websm
sysmgt.help.msg.$LL.websm
sysmgt.msg.$LL.sguide.rte
sysmgt.msg.$LL.websm.apps
!!
done

# These locales no longer supported starting in 520
LLIST="Ca_ES Da_DK De_CH De_DE En_GB En_US Es_ES Fi_FI Fr_BE Fr_CA Fr_CH Fr_FR Is_IS It_IT Nl_BE Nl_NL No_NO Pt_PT Sv_SE"

for LL in $LLIST
do
    cat >> /tmp/old.remove.$$ <<!!
bos.loc.pc_compat.$LL
bos.help.msg.$LL.com
bos.msg.$LL.rte
bos.msg.$LL.mp
bos.msg.$LL.diag.rte
bos.msg.$LL.net.tcp.client
bos.msg.$LL.txt.tfs
bos.msg.$LL.docsearch.client.com
bos.msg.$LL.docsearch.client.Dt
bos.msg.$LL.docregister.com
bos.msg.$LL.svprint
bos.msg.$LL.INed
bos.msg.$LL.net.ipsec
bos.msg.$LL.alt_disk_install.rte
bos.msg.$LL.sysmgt.nim.master_gui
cifs.msg.$LL.compat
connect.msg.$LL
devices.msg.$LL.base.com
devices.msg.$LL.diag.rte
devices.msg.$LL.sys.mca.rte
devices.msg.$LL.rspc.base.com
db2_05_00.msg.$LL
db2_07_01.msg.$LL
dsmit.msg.$LL.server
dsmit.msg.$LL.sol
dsmit.msg.$LL.sun
dsmit.msg.$LL.hp
hcon.msg.$LL
invscout.msg.$LL.rte
ipfx.msg.$LL.rte
Java130.msg.$LL
krb5.msg.$LL.client.rte
ldap.msg.$LL
netbios.msg.$LL
Netscape.msg.$LL.communicator.rte
Netscape.help.$LL.communicator.rte
Netscape.msg.$LL.nav.rte
Netscape.msg.$LL.nav-us.rte
Netscape.help.$LL.nav.rte
Netscape.help.$LL.nav-us.rte
printers.msg.$LL.rte
OpenGL.msg.$LL.GL32.rte.base
PEX_PHIGS.msg.$LL.graPHIGS.rte
printers.msg.$LL.rte
rsct.msg.$LL.core.hostrm
rsct.msg.$LL.core.gui
rsct.msg.$LL.core.fsrm
rsct.msg.$LL.core.auditrm
rsct.msg.$LL.core.errm
rsct.msg.$LL.core.sec
rsct.msg.$LL.core.rmc
rsct.msg.$LL.core.utils
rsct.msg.$LL.core.sr
rsct.msg.$LL.core.sensorrm
sx25.msg.$LL.rte
sysmgt.help.msg.$LL.websm
sysmgt.msg.$LL.sguide.rte
sysmgt.msg.$LL.websm.apps
X11.help.$LL.Dt.helpinfo
X11.loc.$LL.base.lib
X11.loc.$LL.base.rte
X11.loc.$LL.Dt.rte
X11.msg.$LL.base.rte
X11.msg.$LL.base.common
X11.msg.$LL.motif.lib
X11.msg.$LL.motif.mwm
X11.msg.$LL.adt.ext
X11.msg.$LL.adt.imake
X11.msg.$LL.apps.clients
X11.msg.$LL.apps.config
X11.msg.$LL.apps.custom
X11.msg.$LL.apps.rte
X11.msg.$LL.apps.aixterm
X11.msg.$LL.apps.xdm
X11.msg.$LL.apps.pm
X11.msg.$LL.fnt.fontServer
X11.msg.$LL.fnt.util
X11.msg.$LL.vsm.rte
X11.msg.$LL.Dt.rte
X11.msg.$LL.Dt.helpmin
xlC.msg.$LL.rte
xlsmp.msg.$LL.rte
UMS.msg.$LL.objects
!!
done

# Search for obsoleted IDD filesets and remove for any languages
cat > /tmp/html.oldwild.$$ <<!!
bos.html.*.nav:
PEX_PHIGS.html.*.graPHIGS_gd:
PEX_PHIGS.html.*.graPHIGS_libs:
X11.html.*.cde_user:
X11.html.*.motif:
X11.html.*.aixwingd:
X11.html.*.specs.x11specs:
OpenGL.html.*.opengl:
OpenGL.html.*.gl32:
UMS.html.*.prog_gd
UMS.html.*.user_gd:
sx25.html.*.x25_gds:
hcon.html.*.hcon_gds:
bos.html.*.adapt.fibr1063:
bos.html.*.adapt.ssa4port:
bos.html.*.extnav.navigate:
bos.html.*.lowlevprg.assem:
bos.html.*.lowlevprg.diagunsd:
bos.html.*.lowlevprg.kerngd:
bos.html.*.lowlevprg.kerntech:
bos.html.*.lowlevprg.kybdgd:
bos.html.*.nettrans.netprg:
bos.html.*.C2.sfug:
bos.html.*.C2.tfm:
X11.html.*.specs.x11specs:
bos.html.*.adapt.async:
!!
# create empty file to be added to
> /tmp/old.html.$$
for each_file in $(cat /tmp/html.oldwild.$$)
do
    grep -e $each_file /tmp/old.installed.$$ | cut -d':' -f2 >> /tmp/old.html.$$
done

cat /tmp/old.html.$$ >> /tmp/old.remove.$$
rm /tmp/html.oldwild.$$


sort -u /tmp/old.remove.$$ > /tmp/old.remove.sorted.$$
[ $? -eq 0 ] && [ -f /tmp/old.remove.sorted.$$ ] && mv /tmp/old.remove.sorted.$$ /tmp/old.remove.$$

for each_file in $(cat /tmp/old.remove.$$)
do
	cut -d':' -f2 /tmp/old.installed.$$ | grep -q $each_file 
	if [[ $? = 0 ]] 
	then
        if [[ $each_file = devices* ]]
		then 
			echo $each_file >> $HOMEDIR/device_software_being_removed
		else
			echo $each_file >> $HOMEDIR/other_software_being_removed
		fi
	fi
done

# Save software installed for later use
mv /tmp/old.installed.$$ $HOMEDIR/software_installed_before_migration
}

# lists the configuration files that will need to be user merged
function user_merge
{
cat > /tmp/user_merge.$$ <<!!
/etc/motd
/etc/rc
/etc/tsh_profile
/sbin/rc.boot
/usr/sbin/skulker
!!

for each_file in $(cat /tmp/user_merge.$$)
do
	# if the file exists on the system, add it to the list
	if [[ -a $each_file ]]
	then
		echo $each_file >> $HOMEDIR/configuration_files_not_merged
	fi
done
}

# lists the configuration files that will be merged by the system
function system_merge
{
cat > /tmp/system_merge.$$ <<!!
/etc/csh.cshrc
/etc/csh.login
/etc/consdef
/etc/dlpi.conf
/etc/dumpdates
/etc/environment
/etc/filesystems
/etc/inittab
/etc/magic
/etc/shells
/etc/profile
/etc/pse.conf
/etc/qconfig
/etc/security/audit/objects
/etc/security/environ
/etc/security/lastlog
/etc/security/passwd
/etc/security/.profile
/etc/security/user.roles
/etc/swapspaces
/etc/trcfmt
/etc/uucp/Devices
/etc/uucp/Dialers
/etc/vfs
/etc/wlm/standard/classes
/etc/wlm/standard/limits
/etc/wlm/standard/shares
/etc/wlm/standard/rules
/etc/wlm/template/classes
/etc/wlm/template/limits
/etc/wlm/template/shares
/etc/wlm/template/rules
/etc/wlm/template/description
/etc/xrt.names
/etc/xtiso.conf
/var/adm/cron/at.deny
/var/adm/cron/log
/var/adm/ras/codepoint.cat
/var/adm/ras/errtmplt
/var/spool/cron/crontabs/adm
/var/spool/cron/crontabs/root
/var/spool/cron/crontabs/sys
/etc/objrepos/errnotify
/etc/passwd
/etc/security/login.cfg
/etc/security/user
/etc/security/limits
/etc/security/audit/bincmds
/etc/security/audit/config
/etc/security/audit/events
/etc/security/roles
/etc/security/audit/streamcmds
/usr/lib/security/mkuser.default
/etc/group
/etc/security/group
/etc/security/ldap/ldap.cfg
/var/adm/ras/errlog
!!

# ODM databases being merged
cat > /tmp/system_merge_ODM.$$ <<!!
/etc/objrepos/CDiagAtt
/etc/objrepos/CDiagAtt.vc
/etc/objrepos/CDiagDev
/etc/objrepos/Config_Rules
/etc/objrepos/CuAt
/etc/objrepos/CuAt.vc
/etc/objrepos/CuDep
/etc/objrepos/CuDv
/etc/objrepos/CuDvDr
/etc/objrepos/CuPath
/etc/objrepos/CuPath.vc
/etc/objrepos/CuPathAt
/etc/objrepos/CuPathAt.vc
/etc/objrepos/CuVPD
/etc/objrepos/SRCextmeth
/etc/objrepos/SRCnotify
/etc/objrepos/SRCsubsvr
/etc/objrepos/SRCsubsys
/etc/objrepos/SWservAt
/etc/objrepos/SWservAt.vc
/etc/objrepos/history
/etc/objrepos/history.vc
/etc/objrepos/inventory
/etc/objrepos/inventory.vc
/etc/objrepos/lpp
/etc/objrepos/lpp.vc
/etc/objrepos/product
/etc/objrepos/product.vc
/usr/lib/objrepos/DSMenu
/usr/lib/objrepos/DSMOptions
/usr/lib/objrepos/DSMOptions.vc
/usr/lib/objrepos/PDiagRes
/usr/lib/objrepos/PDiagRes.vc
/usr/lib/objrepos/PDiagTask
/usr/lib/objrepos/PDiagTask.vc
/usr/lib/objrepos/PDiagDev
/usr/lib/objrepos/PDiagDev.vc
/usr/lib/objrepos/PDiagAtt
/usr/lib/objrepos/PDiagAtt.vc
/usr/lib/objrepos/PdAtXtd
/usr/lib/objrepos/PdAtXtd.vc
/usr/lib/objrepos/PdCn
/usr/lib/objrepos/PdDv
/usr/lib/objrepos/PdDv.vc
/usr/lib/objrepos/XINPUT
/usr/lib/objrepos/XINPUT.vc
/usr/lib/objrepos/GAI
/usr/lib/objrepos/GAI.vc
/usr/lib/objrepos/PdAt
/usr/lib/objrepos/PdAt.vc
/usr/lib/objrepos/sm_cmd_hdr
/usr/lib/objrepos/sm_cmd_hdr.vc
/usr/lib/objrepos/sm_cmd_opt
/usr/lib/objrepos/sm_cmd_opt.vc
/usr/lib/objrepos/sm_menu_opt
/usr/lib/objrepos/sm_menu_opt.vc
/usr/lib/objrepos/sm_name_hdr
/usr/lib/objrepos/sm_name_hdr.vc
/usr/lib/objrepos/fix
/usr/lib/objrepos/fix.vc
/usr/lib/objrepos/history
/usr/lib/objrepos/history.vc
/usr/lib/objrepos/inventory
/usr/lib/objrepos/inventory.vc
/usr/lib/objrepos/lpp
/usr/lib/objrepos/lpp.vc
/usr/lib/objrepos/product
/usr/lib/objrepos/product.vc
/usr/lib/objrepos/vendor
/usr/lib/objrepos/vendor.vc
/usr/share/lib/objrepos/history
/usr/share/lib/objrepos/history.vc
/usr/share/lib/objrepos/inventory
/usr/share/lib/objrepos/inventory.vc
/usr/share/lib/objrepos/lpp
/usr/share/lib/objrepos/lpp.vc
/usr/share/lib/objrepos/product
/usr/share/lib/objrepos/product.vc
!!

# TCB related files merged
cat > /tmp/system_merge_TCB.$$ <<!!
/etc/security/sysck.cfg
!!

for each_file in $(cat /tmp/system_merge.$$)
do
	# if the file exists on the system, add it to the list
	if [[ -a $each_file ]]
	then
		echo $each_file >> $HOMEDIR/configuration_files_being_merged
	else
		echo $each_file >> $HOMEDIR/configuration_files_missing_from_system
	fi
done

for each_file in $(cat /tmp/system_merge_ODM.$$)
do
	# if the file exists on the system, add it to the list
	if [[ -a $each_file ]]
	then
		echo $each_file >> $HOMEDIR/configuration_files_being_merged
	else
		echo $each_file >> $HOMEDIR/configuration_files_missing_from_system
	fi
done

for each_file in $(cat /tmp/system_merge_TCB.$$)
do
	# if the file exists on the system, add it to the list
	if [[ -a $each_file ]]
	then
		echo $each_file >> $HOMEDIR/configuration_files_being_merged
	else
		echo $each_file >> $HOMEDIR/configuration_files_missing_from_system
	fi
done
}

# saves all the files to me merged (ascii files only)
function save_merged_files
{
cat > /tmp/save_merged.$$ <<!!
/etc/csh.cshrc
/etc/csh.login
/etc/consdef
/etc/dlpi.conf
/etc/dumpdates
/etc/environment
/etc/filesystems
/etc/inittab
/etc/magic
/etc/shells
/etc/profile
/etc/pse.conf
/etc/qconfig
/etc/security/audit/objects
/etc/security/environ
/etc/security/lastlog
/etc/security/passwd
/etc/security/.profile
/etc/security/user.roles
/etc/swapspaces
/etc/trcfmt
/etc/uucp/Devices
/etc/uucp/Dialers
/etc/vfs
/etc/wlm/standard/classes
/etc/wlm/standard/limits
/etc/wlm/standard/shares
/etc/wlm/standard/rules
/etc/wlm/template/classes
/etc/wlm/template/limits
/etc/wlm/template/shares
/etc/wlm/template/rules
/etc/wlm/template/description
/etc/xrt.names
/etc/xtiso.conf
/var/adm/cron/at.deny
/var/adm/cron/log
/var/spool/cron/crontabs/adm
/var/spool/cron/crontabs/root
/var/spool/cron/crontabs/sys
/etc/passwd
/etc/security/login.cfg
/etc/security/sysck.cfg
/etc/security/user
/etc/security/limits
/etc/security/audit/bincmds
/etc/security/audit/config
/etc/security/audit/events
/etc/security/roles
/etc/security/audit/streamcmds
/usr/lib/security/mkuser.default
/etc/group
/etc/security/group
/etc/security/ldap/ldap.cfg
!!

mkdir $HOMEDIR/saved_configuration_files
SAVEDDIR=$HOMEDIR/saved_configuration_files

for each_file in $(cat /tmp/save_merged.$$)
do
        # if the file exists on the system, add it to the list
        if [[ -a $each_file ]]
        then
				FILEDIR=`dirname $each_file`
				mkdir -p $SAVEDDIR$FILEDIR
                cp -p $each_file $SAVEDDIR$FILEDIR
        fi
done
}

function fileset_consistency
{
lppchk -v >$HOMEDIR/software_consistency 2>&1 &
echo $! >/tmp/lppchk.v.$$
}

function fileset_checksum
{
lppchk -c >$HOMEDIR/software_checksum_verification 2>&1 &
echo $! >/tmp/lppchk.c.$$
}

function fileset_filecheck
{
lppchk -f >$HOMEDIR/software_file_existence_check 2>&1 &
echo $! >/tmp/lppchk.f.$$
}

function fileset_linkcheck
{
lppchk -l >$HOMEDIR/software_link_existence_check 2>&1 &
echo $! >/tmp/lppchk.l.$$
}

function tcbck_check
{
ODMDIR=/etc/objrepos odmget -q attribute=TCB_STATE PdAt | grep -q "tcb_enabled"
if [[ $? = 0 ]]
then
    tcbck -n ALL >$HOMEDIR/tcbck.output 2>&1 &
    echo $! >/tmp/tcbck.pd.$$
fi
}

# Check_Down_Level - Determine if a fileset is installed at a level less
# than the required level.
#
# Returns zero if fileset is installed below minimum level
# Returns one otherwise
function Check_Down_Level
{
    fs=$1
    minlevel=$2

    installedlevel=`LANG=C /usr/bin/lslpp -qLc $fs 2>/dev/null | cut -d':' -f3`

    #If not installed, it's not down-level
    [[ -z "$installedlevel" ]]  && return 0

    # If it is installed, break apart the version, release, mod, and fix
    # portions of the minimal and installed levels

    # Cannot do mere alphabetical comparison because
    # there are no leading zeroes.  1.2.0.0 is 
    # alphabetically later than 1.13.0.0, but it is
    # a numerically earlier level.
    OIFS=$IFS
    IFS=.
    set -- $installedlevel
    instV=$1;instR=$2;instM=$3;instF=$4
    set -- $minlevel
    minV=$1;minR=$2;minM=$3;minF=$4
    IFS=$OIFS

    if ( [[ $instV -lt $minV ]] ||
        ( [[ $instV -eq $minV ]] && ( [[ $instR -lt $minR ]] ||
        ( [[ $instR -eq $minR ]] && ( [[ $instM -lt $minM ]] ||
        ( [[ $instM -eq $minM ]] && [[ $instF -lt $minF ]] ))))))
    then
        return 0
    fi

    return 1
}

function cleanup
{
rm /tmp/old.remove.$$
rm /tmp/old.html.$$
rm /tmp/user_merge.$$
rm /tmp/system_merge.$$
rm /tmp/system_merge_ODM.$$
rm /tmp/system_merge_TCB.$$
rm /tmp/save_merged.$$
}

function more_major_no_checks
{

value2=$(ODMDIR=/etc/objrepos odmget -q "resource=ddins and value1=rootvg" CuDvDr | grep value2 | cut -d\" -f2)
value3=$(ODMDIR=/etc/objrepos odmget -q "resource=ddins and value1=rootvg" CuDvDr | grep value3 | cut -d\" -f2)

[ "$value2" != "10" ] && echo "
The major number (value2) as in the CuDvDr ODM database for rootvg
is not equal to 10. 
This may cause your migration to fail.  
Please contact your support representative."

[ "$value3" != ";" ] && echo "
The value3 field in the CuDvDr ODM database for rootvg is not equal to ';'.
This may cause your migration to fail.  
Please contact your support representative."

}

# check if 7025s and 7026s need new firmware
function hardware_firmware_check
{
# systems needing firmware upgrade to boot from 5.3 media
systems="7025-F80 7025-6F0 7025-6F1 7026-H80 7026-6H0 7026-6H1 7026-M80 7026-6M1"
mysystem=`LC_ALL=C lsattr -E -l sys0 -a modelname | cut -d" " -f2 | cut -d"," -f2`
for name in $systems
do

    if [[ $mysystem = $name ]]
    then
        # this is one of the systems we need to check firmware for
        myfirmware=`LC_ALL=C lsmcode -r | cut -d":" -f3`
	# cut off first two letters ---- these machines have a format of XXnnnnnn,
        # where XX are alpha characters and nnnnnn represents the date in yymmdd format.
        myfirmware_orig=$myfirmware
        myfirmware_orig=${myfirmware_orig%% *}
	myfirmware=${myfirmware##[A-Z][A-Z]}
        myfirmware=${myfirmware%% *}
        if [[ $myfirmware -lt "040712" ]]
        then
            echo "
The system, model $mysystem, is expected to have a firmware level date 
equal to or greater than 04/07/12 (yy/mm/dd). 
The systems firmware level is $myfirmware_orig
(the last 6 digits represent the date).
Please consult the Release Notes for information on upgrading the firmware."
        fi
        break
    fi
done

}

# MAIN main Main

export PATH="/usr/bin:/usr/sbin:/etc:/bin:$PATH"

# Create directory for output
TIMESTAMP=`/usr/bin/date +"%y %m %d %H %M %S" | sed 's/ //g'`
mkdir /home/pre_migration.$TIMESTAMP
if [[ $? = 0 ]] 
then
	HOMEDIR=/home/pre_migration.$TIMESTAMP
else
	echo "
pre_migration: failed making directory /home/pre_migration.$TIMESTAMP"
	exit 1
fi

BLV=hd5                   # The boot logical volume
BLV_REQ_SPACE=28          # The boot logical volume space (in MB)

ORIG_MAPFILE=$TMPDIR/.map.orig.$$ # Original pp map of the boot logical volume
FREE_MAPFILE=$TMPDIR/.map.free.$$ # Map of free space on all disks on which
                                  # blv resides
SUPPORTED_SYSTEM=0

# Verify system supports 7.1
powertype=$( LC_ALL=C lsattr -El $(LC_ALL=C lsdev -cprocessor -Sa -Fname 2>/dev/null | sed -n '1p') -atype -Fvalue 2>/dev/null )
if [[ $powertype = PowerPC_POWER?([4567]) ]]
then
    SUPPORTED_SYSTEM=0
elif [[ $powertype = PowerPC_970* ]]
then
    SUPPORTED_SYSTEM=0
else
    is64bit=$( LC_ALL=C getconf HARDWARE_BITMODE 2>/dev/null )
    if [[ $? = 0 ]]
    then
        if [[ $is64bit = 64 ]]
        then
            echo "
The system does not appear to be POWER 4 or greater,
which is required to install version 7.   
If you are planning to use Mksysb Migration, please 
verify that the target system is POWER 4 or greater.
"
            echo "
The system does not appear to be POWER 4 or greater,
which is required to install version 7.   
If you are planning to use Mksysb Migration, please 
verify that the target system is POWER 4 or greater.
" >>$HOMEDIR/ATTENTION 
            SUPPORTED_SYSTEM=1
        else
            echo "
Only 64-bit, POWER 4 or greater systems, are supported
to install version 7.
If you are planning to use Mksysb Migration, please 
verify that the target system is POWER 4 or greater.
"
            echo "
Only 64-bit, POWER 4 or greater systems, are supported
to install version 7.
If you are planning to use Mksysb Migration, please 
verify that the target system is POWER 4 or greater.
" >>$HOMEDIR/ATTENTION
            SUPPORTED_SYSTEM=1
	fi
    else
        echo "
Only 64-bit, POWER 4 or greater systems, are supported
to install version 7.
If you are planning to use Mksysb Migration, please 
verify that the target system is POWER 4 or greater.
"
        echo "
Only 64-bit, POWER 4 or greater systems, are supported
to install version 7.
If you are planning to use Mksysb Migration, please 
verify that the target system is POWER 4 or greater.
" >>$HOMEDIR/ATTENTION
        SUPPORTED_SYSTEM=1
    fi
fi

# Tell where saved information is
echo "
All saved information can be found in: $HOMEDIR
"

# Check system firmware level
[[ $SUPPORTED_SYSTEM -eq 0 ]] && \
hardware_firmware_check

# Check that major number is 10 for /dev/rootvg and /dev/hd5
number=$(ls -al /dev/rootvg | awk -F' ' '{print $5}')
majornumber=${number%,}
if [[ $majornumber -ne 10 ]] 
then
    echo "
The major number of /dev/rootvg is not equal to 10.
This may cause the migration to fail."
    echo "
The major number of /dev/rootvg is not equal to 10.
This may cause the migration to fail." >>$HOMEDIR/ATTENTION
fi
number=$(ls -al /dev/hd5 | awk -F' ' '{print $5}')
majornumber=${number%,}
if [[ $majornumber -ne 10 ]]
then
    echo "
The major number of /dev/hd5 is not equal to 10.
This may cause the migration to fail."
    echo "
The major number of /dev/hd5 is not equal to 10.
This may cause the migration to fail." >>$HOMEDIR/ATTENTION
fi
more_major_no_checks

if [[ $SUPPORTED_SYSTEM -eq 0 ]]
then
    # check boot lv size
    echo "
Checking size of boot logical volume (hd5)."
    boot_lv_check
fi

# Check and inform user if kerberos is being used.
KID=`ODMDIR=/etc/objrepos odmget -q "attribute=authm" CuAt | grep value|cut -f2 -d=|cut -f2 -d'"'| cut -f1 -d,`
if [[ $KID = 131074 ]] || [[ $KID = 131073 ]]
then
    echo "
Kerberos is being used on your system.  During the migration you will 
be asked to install Kerberos 5 software from the Expansion Pack CD."
    echo "
Kerberos is being used on your system.  During the migration you will 
be asked to install Kerberos 5 software from the Expansion Pack CD." >>$HOMEDIR/ATTENTION
fi

# Check disk size (minimum 5GB required)
diskspace=`LANG=C lsvg rootvg | grep " TOTAL PPs: " | awk '{print $7}'`
disksize=${diskspace##\(}
if [[ $disksize -lt 5120 ]]
then
    echo "
The minimal disk requirement is 5GB.  Be sure
this much disk space is available."
    echo "
The minimal disk requirement is 5GB.  Be sure
this much disk space is available." >>$HOMEDIR/ATTENTION
fi

# Check memory size (minimum 512MB required for migrations) 
mem=`bootinfo -r`
if [[ $mem -lt 524288 ]] 
then
    echo "
512MB or more of memory is recommended to run AIX Version 7.1."
    echo "
512MB or more of memory is recommended to run AIX Version 7.1." >>$HOMEDIR/ATTENTION
fi

# Check that xlC.rte is not less than 4.0.2.0
Check_Down_Level xlC.rte 4.0.2.0
if [[ $? = 0 ]]
then
    echo "
xlC.rte is less than 4.0.2.0.  Please install APAR IY17981
before migrating."
    echo "
xlC.rte is less than 4.0.2.0.  Please install APAR IY17981
before migrating." >>$HOMEDIR/ATTENTION
fi

# Check that /usr/lib/security/fpm exists, and is in the inventory
if [[ -d /usr/lib/security/fpm ]]
then
    lslpp -w /usr/lib/security/fpm >/dev/null
    if [[ $? != 0 ]]
    then
        echo "
ATTENTION:
/usr/lib/security/fpm is a directory on your system, but
not in the inventory database, which will cause problems
migrating with NIM Alternate Disk Migration, NIMADM.
Please ensure you are using bos.alt_disk_install.rte at
level 6.1.2.0 or 5.3.9.0 for 6.1 systems or 5.3 systems
respectively. 
Else, if you are migrating a 5.2 system have bos.rte.security 
at level 05.02.0000.0110.
A 5300 TL6 system should have bos.rte.security at level 5.3.0.68
A 5300 TL7 system should have bos.rte.security at level 5.3.7.5
A 5300 TL8 system should have bos.rte.security at level 5.3.8.3
"
        echo "
ATTENTION:
/usr/lib/security/fpm is a directory on your system, but
not in the inventory database, which will cause problems
migrating with NIM Alternate Disk Migration, NIMADM.
Please ensure you are using bos.alt_disk_install.rte at
level 6.1.2.0 or 5.3.9.0 for 6.1 systems or 5.3 systems
respectively. 
Else, if you are migrating a 5.2 system have bos.rte.security 
at level 05.02.0000.0110.
A 5300 TL6 system should have bos.rte.security at level 5.3.0.68
A 5300 TL7 system should have bos.rte.security at level 5.3.7.5
A 5300 TL8 system should have bos.rte.security at level 5.3.8.3
" >>$HOMEDIR/ATTENTION
    fi
fi

# Check that xlC.aix50.rte is not greater than 10.1.0.0
Check_Down_Level xlC.aix50.rte 10.1.0.4
if [[ $? = 1 ]]
then
    echo "
ATTENTION:
xlC.aix50.rte is at a level greater than 10.1.0.3, but after
migration to 7100-00, xlC.aix61.rte, which replaces xlC.aix50.rte,
will be at 10.1.0.3.   You may wish to contact your service 
representative for a later level of xlC.aix61.rte."
    echo "
ATTENTION:
xlC.aix50.rte is at a level greater than 10.1.0.3, but after
migration to 7100-00, xlC.aix61.rte, which replaces xlC.aix50.rte,
will be at 10.1.0.3.   You may wish to contact your service 
representative for a later level of xlC.aix61.rte." >>$HOMEDIR/ATTENTION
fi

# List software being removed from the system
echo "
Listing software that will be removed from the system."
removing_software

# List configuration files not merged
echo "
Listing configuration files that will not be merged."
user_merge

# List configuration files merged
echo "
Listing configuration files that will be merged."
system_merge

# Saving configuration files that will be merged
echo "
Saving configuration files that will be merged."
save_merged_files

# fileset consistency check
echo "
Running lppchk commands. This may take awhile."
fileset_consistency
fileset_checksum
fileset_filecheck
fileset_linkcheck
tcbck_check

# check if bos.net.ipsec.keymgt is installed, and if so, does the DB dir. exist
grep -q ":bos.net.ipsec.keymgt:" $HOMEDIR/software_installed_before_migration
if [[ $? = 0 ]]
then
    if [[ ! -d /etc/ipsec/inet/DB ]]
    then
        echo "
The directory /etc/ipsec/inet/DB is missing, which
may cause problems during the migration of bos.net.ipsec.keymgt.
Please reinstall bos.net.ipsec.keymgt, at the current level, using
a force install, before migrating."
        echo "
The directory /etc/ipsec/inet/DB is missing, which
may cause problems during the migration of bos.net.ipsec.keymgt.
Please reinstall bos.net.ipsec.keymgt, at the current level, using
a force install, before migrating." >>$HOMEDIR/ATTENTION
    fi
fi

# verify checks complete before cleanup
while [[ -s /tmp/lppchk.l.$$ ]]
do
    ps -p $(cat /tmp/lppchk.l.$$) | grep -q lppchk
    if [[ $? != 0 ]]
    then
        rm /tmp/lppchk.l.$$
    fi
done
[ -s $HOMEDIR/software_link_existence_check ] && echo "
Please check $HOMEDIR/software_link_existence_check for possible errors.
"
while [[ -s /tmp/lppchk.f.$$ ]]
do
    ps -p $(cat /tmp/lppchk.f.$$) | grep -q lppchk
    if [[ $? != 0 ]]
    then
        rm /tmp/lppchk.f.$$
    fi
done
[ -s $HOMEDIR/software_file_existence_check ] && echo "
Please check $HOMEDIR/software_file_existence_check for possible errors.
"
while [[ -s /tmp/lppchk.c.$$ ]]
do
    ps -p $(cat /tmp/lppchk.c.$$) | grep -q lppchk
    if [[ $? != 0 ]]
    then
        rm /tmp/lppchk.c.$$
    fi
done
[ -s $HOMEDIR/software_checksum_verification ] && echo "
Please check $HOMEDIR/software_checksum_verification for possible errors.
"
while [[ -s /tmp/lppchk.v.$$ ]]
do
    ps -p $(cat /tmp/lppchk.v.$$) | grep -q lppchk
    if [[ $? != 0 ]]
    then
        rm /tmp/lppchk.v.$$
    fi
done
[ -s $HOMEDIR/software_consistency ] && echo "
Please check $HOMEDIR/software_consistency for possible errors.
"
while [[ -s /tmp/tcbck.pd.$$ ]]
do
    ps -p $(cat /tmp/tcbck.pd.$$) | grep -q tcbck
    if [[ $? != 0 ]]
    then
        rm /tmp/tcbck.pd.$$
    fi
done
[ -s $HOMEDIR/tcbck.output ] && echo "
Please check $HOMEDIR/tcbck.output for possible errors.
"

# Tell where saved information is
echo "
All saved information can be found in: $HOMEDIR
"
# Recommend mksysb
echo "
It is recommended that you create a bootable system backup of your system 
before migrating.
"
cleanup
exit 0
