#############################################################################
# PasswordStorage.pm - a package of functions which facilitate secure script access to stored credentials.
# Revision 1.1.1.1  2005/05/10 17:49:02  mschonba
# Password Storage Module
#  
#############################################################################

package PasswordStorage;

BEGIN {
  require Exporter;
  $VERSION     = '1.0';
  @ISA         = qw(Exporter);
  @EXPORT      = qw( getlogin getpassword );
  %EXPORT_TAGS = ();
  @EXPORT_OK   = qw( getlogin getpassword );
}

# Location of the password file - should not change
$PasswordStorage::PasswordFile = '/home/foo/foo/passwords';

###################################################################
#
# getlogin - retrieves a login (username) based on its unique id
# 
# usage:  getlogin(ID)
#   ID -> unique numeric identifier for the login
#
# returns:  login (username) for specified identifier or false if
#           an error occurs.
#
# example:
#   getlogin(-1);
#     > false
#   getlogin(2);
#     > usertwo
#
###################################################################

sub getlogin($) {
  my $id = shift or return;
  
  # read the list of passwords;
  $PasswordStorage::PasswordHash ||= readpasswords();
  if( !$PasswordStorage::PasswordHash->{$id} ) {
    return;
  }
  return $PasswordStorage::PasswordHash->{$id}->{'l'};
}


###################################################################
#
# getpassword - retrieves a password based on its unique id
# 
# usage:  getpassword(ID)
#   ID -> unique numeric identifier for the password
#
# returns:  password for specified identifier or false if
#           an error occurs.
#
# example:
#   getlogin(-1);
#     > false
#   getlogin(2);
#     > passtwo
#
###################################################################

sub getpassword($) {
  my $id = shift or return;

  # read the list of passwords;
  $PasswordStorage::PasswordHash ||= readpasswords();
  if( !$PasswordStorage::PasswordHash->{$id} ) {
    return;
  }
  return $PasswordStorage::PasswordHash->{$id}->{'p'};
}


###################################################################
#
# readpasswords - parses the password file and returns a hash of
#                 valid logins and passwords
# 
# usage:  readpasswords()
#
# returns:  hash (keyed by ID) of usernames and passwords
#
# example:
#   readpasswords();
#     > { '1' -> { 'l' -> 'userone', 'p' -> 'passone' }, '2' -> { 'l' -> 'usertwo', 'p' -> 'passtwo' } }
#
###################################################################

sub readpasswords() {
  my $passwords;

  # open the password file
  open(FILE, $PasswordStorage::PasswordFile) or
    warn "PasswordStorage:  Could not open password file '$PasswordStorage::PasswordFile': $!.\n" and return;

  # parse through each line of the password file
  while(<FILE>) {
    next if( m/^\s*$/ );  # blank lines
    next if( m/^\s*#/ );  # comments
    my ($i, $l, $p) = split /\|/;  # parse out id, login, and password
    # check to make sure all three fields are filled in
    if( $i && $l && $p && $i =~ /\d+/ && $i > 0 ) {
      chomp($p);
      if( $passwords->{$i} ) {
        warn "PasswordStorage:  Duplicate entry for ID '$i'.  Replacing earlier entry with later one.\n";
      }
      $passwords->{$i}->{'l'} = $l;
      $passwords->{$i}->{'p'} = $p;
    }
    else {
      warn "PasswordStorage:  Invalid syntax on line $. of the password file.\n";
    }
  }
  close(FILE);
  return $passwords;
}
