#!/usr/bin/perl -w
# FILE: "/home/jkipp/get-perl-mods.pl"
# LAST MODIFICATION: "Wed, 13 Apr 2016 14:37:15 -0400 (jkipp)"
# (C) 2016 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;
use File::Find;

my @files;
        find(
            {
            wanted => sub {
                push @files, $File::Find::fullname
                if -f $File::Find::fullname && /\.pm$/
            },
			# follow symLinks
            follow => 1,
			#ignore any duplicate files 
            follow_skip => 2,
            },
            @INC
        );
print join "\n", @files;
