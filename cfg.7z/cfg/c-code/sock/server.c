/* GENERIC CONNECTION SOCKET SERVER 
 * compile with COMPILE WITH tcp_win_lib.c  window sizes are needed
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>

#define PORT 3490 
#define BACKLOG 5 
#define MAXMSG  512

/*  request status info from a child process. Normally, the calling process is suspended until the child
 *  process makes status information available by terminating. value of -1 requests status information for any child process
 *  WNOHANG: should return immediately instead of waiting, if there is no child process ready to be noticed */
void sigchld_handler(int s)
{
		pid_t pid;
		int status;
		/* status gets filled with info from kid */
		while ( (pid = waitpid(-1, &status, WNOHANG)) > 0)
			 printf("child %d terminated with status of %d\n", pid,status);
}

/* subroutine to bail */
void error_msg(const char* msg, bool halt_flag) {
	perror(msg);
	if (halt_flag) exit(-1); 
}


void dostuff(int sock)
{
	int n;
    char buf[256];
    FILE* foo;
    foo = fopen("foo.txt", "w");
    if (!foo) {
		perror("Failed opening file for");
	    exit(1);
	}
    n = read(sock,buf,255); 
	if (n < 0) 
		error("ERROR reading from socket");
	printf("msg from cli: %s\n", buf);
	/* print same stuff to the file */
	fprintf(foo, "%s\n", buf);
}


/* generic signal catcher */
void catcher(int sig)
{
	printf("   Signal catcher called for signal %d\n", sig);
}


int main(void)
{
	int sockfd, conn_fd;  // listen on sock_fd, new client connection on conn_fd
	struct sockaddr_in serv_addr, client_addr;
	socklen_t sin_size;
	struct sigaction sa;
	/* for ALARM signal example */
	struct sigaction sact;
	time_t t;
	/***************************/
	struct hostent *h;
	int yes=1;
	char s[128]; /* server hostname buffer */
	char c[32]; /* client ip string buffer */
	pid_t pid;
	char buffer[MAXMSG];
    int nbytes;
	time_t now;
	struct tm *local;
	int min;
	/* int inTCPWin = 131071;  set to current MAX on system */

	memset(&serv_addr, 0, sizeof serv_addr);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(PORT);

	if ((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0) {
    	perror("server:socket");
	    exit(1);
	}

	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
    	perror("setsockopt");
	   	exit(1);
	}

	/* bind 32 bit adr and 16 bit port to unamed sock */
	if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
    	perror("server: bind");
	    exit(1);
	}

	/* setsock_tcp_windowsize( sockfd, inTCPWin ); */

	/* convert unconnected sock to a passive sock */
	if (listen(sockfd, BACKLOG) == -1) {
		perror("listen");
		exit(1);
	}

	 printf("listening on port: %i\n", PORT);

	/* the sigaction struct contains
	 * sa_flags
	 * sa_mask - a mask of the Signals that are blocked while processing this Signal
	 * sa_handler - the signal handler to call when the signal occurs 
	 */
	sa.sa_handler = sigchld_handler; // reap all dead processes
	/* initialise and empty a signal set : list of sigs that will be blocked when the sig handler is called 
       so no additional signals are blocked while our handler is running */
	sigemptyset(&sa.sa_mask);
	/* try to restart system calls across signals */
	sa.sa_flags = SA_RESTART;
	/* now act on the signal when recieved. must catch SIGCHILD when forking */
	if (sigaction(SIGCHLD, &sa, NULL) == -1) {
		perror("sigaction");
		exit(1);
	}

  	gethostname(s, sizeof s);
	printf("server %s: waiting for connections...\n", s);

	/* create an FD for each cli conn. */
	while(1) {  // main accept() loop
		 now = time(0);
		 local = localtime(&now);
		 min = local->tm_min;
		 /* printf("TIME minute %i\n", min); */
		 sin_size = sizeof client_addr;

		 /* for setting an ALARM: 
		printf("alarm will cause the blocked accept() to return a -1 and an errno value of EINTR.\n");
		sigemptyset(&sact.sa_mask);
	    sact.sa_flags = 0;
	    sact.sa_handler = catcher;
	    sigaction(SIGALRM, &sact, NULL);
	    alarm(5);
		time(&t);
		printf("Before accept(), time is %s", ctime(&t));
		*/

		 /* accept blocks waiting for a connection, Once there is a connection it forks, the child proc handles the connection and the main server is able to
		  * service new incoming requests.*/ 
		 conn_fd = accept(sockfd, (struct sockaddr *)&client_addr, &sin_size);
		 if (conn_fd == -1) {
			 perror("accept error ");
			 continue;
		 }

		inet_ntop(AF_INET, &client_addr.sin_addr, c, sizeof c); 
		/* if we want port info also, can do this:
		 * printf("connection from %s, port %d\n",inet_ntop(AF_INET, &client_addr.sin_addr, s, sizeof(s)),
		 *     ntohs(client_addr.sin_port));
		 */
		printf("got connection from %s\n", c);

		/* if we want to send time info: 
		 * ticks = time(NULL); 
		 * snprintf does bounds checking. 2nd arg is the size of the dest buffer and buffer can not overflow
		 * snprintf(buffer, sizeof(buff), "%.24s\r\n", ctime(&ticks));
		 */

		pid = fork();
		/* 0 to child, child's PID to parent */
		if (pid == 0) { // child 
			close(sockfd); // child doesn't need the listener
			
			/* SEND ROUTINES */
			/*
			strcpy(buffer,"hi there");
			nbytes = write(conn_fd, buffer, strlen(buffer));
			if (nbytes < 0) {
				perror ("error sending data");
				exit (EXIT_FAILURE);
			}
			printf("%d bytes sent\n", nbytes);
			*/
			/* END SEND ROUTINES */
			 
			/* RECV ROUTINES */
			/*
			nbytes = read(conn_fd, buffer, MAXMSG);
			if (nbytes < 0) {
		    	perror ("nothing read from socket");
				exit (EXIT_FAILURE);
			}
			printf ("Server: got message: `%s'\n", buffer);
			*/

			/* read socket and write data to file */
			dostuff(conn_fd);

			/* END RECV ROUTINES */

			close(conn_fd);
			exit(0);
		} /* end fork */
		/* can add this for extra measure: */
		//else /** parent **/
			//close(client); /* parent's read/write socket. */

			/* the close of the con socket does not always terminate the connection with the client. 
			 * the socket has a ref count of fd's that are currently open. after sock returns the ref count is 1
			 * for listef fd. after accept returns the ref count for connfd is 1. but after fork returns both fd's 
			 * are shared (duped) between parent and child. this bumps both counts to 2. so when  parent closed connfd
			 * it bumps down to 1. eventually when child closes connfd ref count goes to 0 and socket is really closed.
			 */
		/* parent doesnt need this:  
		  close(conn_fd); */ 

	} /* end of while loop */

} /* end of main  */


