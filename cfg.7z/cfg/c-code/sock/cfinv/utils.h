#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* Miscellaneous constants */
#define	MAXLINE		4096	/* max text line length */
#define	MAXSOCKADDR     128	/* max socket address structure size */
#define	BUFFSIZE	8192	/* buffer size for reads and writes */
#define LISTENQ  1024

/* some macros */
#define iswhite(c)  ((c)== ' ' || (c)=='\t')
#define SPACE        (char)' '
#define TAB          (char)'\t'
#define  ALLCHARS   ch = 0; isascii(ch); ch++
/* more handy macros:
 * http://www.iu.hio.no/~mark/CTutorial/CTutorial.html#Putting%20together%20a%20program
 * section: 'Character Identification'
 */

/* query functions */
int sendOSLevel (int, int);
int sendSerial (int, int);
int sendCPU (int, int);
int sendModel (int, int);
int sendMem (int, int); 
int sendLparType (int, int); 
int sendPowerpathVer (int, int);
int sendSAN (int, int); 

/* utility functions */
int rtrim (char *);
int squeeze (char *);
int squeeze_nl (char *);
int exists (const char *); 
char *chomp(char *);
