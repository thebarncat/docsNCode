/****************************************************************************
 * creates a socket connection to the server and requests system information 
 ****************************************************************************/

#include <stdio.h>      
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>      /* standard system types       */
#include <netinet/in.h>     /* Internet address structures */
#include <sys/socket.h>     /* socket interface functions  */
#include <netdb.h>      /* host to IP resolution       */
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include "utils.h"

#define BUFLEN 128   
#define PORT 5490

int main(int argc, char *argv[])
{
	int n, i;
	int len;
	char request[BUFLEN];
	char answer[BUFLEN];
	char *p;
	char hostname[64];
	int sockfd;
	struct hostent *h;
	struct sockaddr_in sin;

	if (argc < 3) {
		fprintf(stderr, "USAGE: cfinv <option> <hostname>\n");
		fprintf(stderr, "Options are 1 of:\n");
		fprintf(stderr, "\tOS       => OSLEVEL\n"); 
		fprintf(stderr, "\tSERIAL   => Serial Number\n"); 
		fprintf(stderr, "\tCPU      => CPU Cores and Speed\n"); 
		fprintf(stderr, "\tMEM      => Memory in MB\n"); 
		fprintf(stderr, "\tTYPE     => LPAR Type and Mode(AIX)\n"); 
		fprintf(stderr, "\tMODEL    => Make and Model\n"); 
		fprintf(stderr, "\tPPATH    => PowerPath Version\n"); 
		fprintf(stderr, "\tSAN      => Total SAN Spacen\n"); 
	    exit (1);
     }

	 /* Address resolution of Server we are connecting to */
	h = gethostbyname(argv[2]);
	if (!h) { 
		fprintf(stderr,"can not resolve host name\n"); 
		exit(EXIT_FAILURE);
	}

	strcpy(request,argv[1]);
	/* make sure send request in upper case */ 
	for (p = request; *p != '\0'; ++p)
		*p = toupper(*p);

  	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(PORT);
	memcpy(&sin.sin_addr,h->h_addr,h->h_length);

	/* open a socket */
	if ((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0) {
			perror("client:socket");
			exit(1);
	}
	
	/* connect to the socket */
	if (connect(sockfd, (struct sockaddr*)&sin, sizeof(sin)) < 0) {
			perror("client: connect");
			exit(1);
	}

	/* DEBUG:   
	printf ("gonna send %s\n", request);  
	*/

    /*  Send request TO host server OS,SerialNum,...   */
    n = write(sockfd, request, BUFLEN); 
	if (n < 0)
    	perror("writing request to socket");

	printf("recieved answer to query from %s:\n", h->h_name);

	/* READ response FROM server */
	len = read(sockfd, answer, BUFLEN); 
	if (len < 0)
		perror("Socket read error");

	/* DEBUG:   
	printf("read %d bytes from socket\n", len);
	printf("string length is %d\n", strlen(answer));
	*/

	/* need this because aix sends extra garbage in send and write calls */
	/* so we need to nullify any bytes after size len */
	answer[len] = '\0';
	printf("%s\n",answer);
	close(sockfd);
}

