#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/wait.h>
#include <syslog.h>
#include <pwd.h>
#include "utils.h" 

#define PORT 5490
#define BACKLOG 5 
#define BUFLEN  128 
#define DAEMON_NAME "cfinvd"
#define RUN_AS_USER "root"
#define PIDFILE "/var/run/cfinvd.pid"

/* globals */
char buf[64];
int pidFilehandle;

/* prototypes */
void sig_term (int sig);
void reaper (int sig);
char *getOS (void);

void reaper(int sig)
{
    pid_t pid;
    int status;
    /* get the status from all terminated childs without ever waiting */
    while ( (pid = waitpid(-1, &status, WNOHANG)) > 0)
		printf( "child %d terminated with status of %d\n", pid,status); 
}

/* need to add SIGKILL routine */
void sig_term(int sig)
{
	syslog(LOG_INFO, "Daemon exiting");
	close(pidFilehandle);
	closelog();
	unlink(PIDFILE);
    exit(EXIT_SUCCESS);
}

int main(void) {
    int sockfd, new_fd;
	int i;
    int yes=1;
    pid_t pid, sid;
    socklen_t sin_size;
    struct sockaddr_in serv_addr, cli_addr;
	struct sigaction sa;
	char pid_str[16];
    char request[BUFLEN]; 
    char*  pc;
    int rc;
    char OS[8]; /* buffer to hold OS */
    int OS_flag; /* boolean flag to tell this program the OS */

	/* daemonize */
	if(fork())
    	exit(0); // parent exits

	for (i = getdtablesize(); i >= 0; --i)
		        close(i);
   /* Redirect standard files to /dev/null */
	open("/dev/null", O_RDWR);
    dup2(0,1);
    dup2(0,2);

	/* child becomes session leader */
	sid = setsid();
    if (sid < 0) 
        exit(EXIT_FAILURE);
	
	signal(SIGHUP, SIG_IGN ); /* always ignore SIGUP */
	/*signal(SIGCHLD, reaper); */
	signal(SIGTERM, sig_term); 

	chdir("/");
	umask(0);

	openlog(DAEMON_NAME, LOG_CONS | LOG_PERROR, LOG_USER);

	/* Ensure only one daemon copy */
    pidFilehandle = open(PIDFILE, O_RDWR|O_CREAT, 0644);
    if (pidFilehandle == -1 ) {
    	syslog(LOG_INFO, "Could not open PID lock file %s, exiting", PIDFILE);
	    exit(EXIT_FAILURE);
	}

	 /* lock the  file */
	if (lockf(pidFilehandle,F_TLOCK,0) == -1) {
    	syslog(LOG_INFO, "Could not lock PID lock file %s, exiting", PIDFILE);
	    exit(EXIT_FAILURE);
	}

	/* Drop to USER if possible, and we were run as root */
	if ( getuid() == 0 || geteuid() == 0 ) {
		struct passwd *pw = getpwnam(RUN_AS_USER);
	    if ( pw ) {
	    	syslog( LOG_NOTICE, "setting user to " RUN_AS_USER );
		    setuid( pw->pw_uid );
	     }
	}

	 /* write pid to lock file */
	sprintf(pid_str,"%d\n",getpid());
	write(pidFilehandle, pid_str, strlen(pid_str));
   /* end deamonize */

	syslog(LOG_INFO, "Daemon running");

	/* set sock addrs info */
    memset(&serv_addr, 0, sizeof serv_addr);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(PORT);

	if ((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0) {
        perror("server:socket");
        exit(1);
    }

    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
        perror("setsockopt");
        exit(1);
    }

     /* bind 32 bit adr and 16 bit port to unamed sock */
     if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("server: bind");
        exit(1);
     }

     /* convert unconnected sock to a passive sock */
     if (listen(sockfd, BACKLOG) == -1) {
        perror("listen");
        exit(1);
     }

    /* always get OS to drive other functions */
    sprintf(OS, getOS());
    rtrim(OS);
    if (strcmp(OS,"Linux") == 0)
        OS_flag = 0;
    else if (strcmp(OS,"AIX") == 0)
        OS_flag = 1;
    else
         exit(EXIT_FAILURE);
 
	while(1) {
        sin_size = sizeof cli_addr;
        new_fd = accept(sockfd, (struct sockaddr *)&cli_addr, &sin_size);

		if (new_fd == -1) {
	    	if (errno == EINTR) {
		     	/* printf("EINTR errno * %d\n", errno); */
			    continue;
		     }
		     else {
		     	perror("accept got hosed");
			    exit(EXIT_FAILURE);
			}
        }

		pid = fork();
		if (pid <  0) 
			exit(EXIT_FAILURE);

		/* signal(SIGCHLD, reaper); */
		sa.sa_handler = reaper;  // reap all dead child procs
		sigemptyset(&sa.sa_mask);
		sa.sa_flags = SA_RESTART;
		if (sigaction(SIGCHLD, &sa, NULL) == -1) {
			perror("sigaction");
		    exit(1);
		}

		if(pid == 0) {
			close(sockfd); // child doesn't need the listener
			pc = request;
            while (rc = read(new_fd, pc, BUFLEN - (pc-request))) {
                  pc += rc;
            }
            *pc = '\0';			
			
			/* DEBUG:  
			printf("DEBUG: got request: %s\n", request);
			*/

			if (strcmp(request,"OS") == 0)
                sendOSLevel(new_fd, OS_flag);
            else if (strcmp(request,"SERIAL") == 0)
                sendSerial(new_fd, OS_flag);
            else if (strcmp(request,"CPU") == 0)
                sendCPU(new_fd, OS_flag);
            else if (strcmp(request,"MEM") == 0)
                sendMem(new_fd, OS_flag);
            else if (strcmp(request,"TYPE") == 0)
                sendLparType(new_fd, OS_flag);
			else if (strcmp(request,"MODEL") == 0)
				sendModel(new_fd, OS_flag);
			else if (strcmp(request,"PPATH") == 0)
				sendPowerpathVer(new_fd, OS_flag);
			else if (strcmp(request,"SAN") == 0)
				sendSAN(new_fd, OS_flag);
            else
                send(new_fd, "WTF?", 5,0);

			close(new_fd);
			exit(0);
		}
	}
}
			 

/***************************************************************************/
char *getOS() {
	FILE *FP;
    FP = popen("uname","r");
	/* readline from stream in to buffer */
	memset(buf,0,64);
    fgets(buf, 64, FP); 
	pclose(FP);
	return(buf);
}


