#include "utils.h"

/* notes:
 * fgets: reads until it sees '\n' and stores a '\0'after the last char
 * sometimes fgets stores a newline at the end, USE chomp or rtrim to  get rid of 
 * sprintf and strcat, : also appends a '\0'
 * strlen: length of the string s, not including the terminating null byte
 * RTRIM also appends a '\0'
 * DEBUG: add to functions for debug just before sending string
 * printf("str len before rtrim %d\n", strlen(string));
 * rtrim(string);
 * printf("str len after rtrim %d\n", strlen(string));
 * 
 */

int sendOSLevel(int socket, int flag) {
	FILE *FP;
    char string[32];  
	char LINUX[16] = "Linux: RHEL ";
	char AIX[16] = "AIX: ";
	/* flag on for AIX */
	if (flag) { 
    	FP = popen("oslevel -r","r");
    	fgets(string, 32, FP);
		strcat(AIX ,string);
		pclose(FP);
		strcpy(string, AIX);
	}
	else { 
		FP = popen("cat /etc/redhat-release | awk \'{print $7}\' | sed \'s/\\..*//\'","r");
    	fgets(string, 32, FP);
		strcat(LINUX ,string);
		strcpy(string, LINUX);
		pclose(FP);
	}

	/* let's check for and chop of any crud at the end of the string  */
	rtrim(string);
	if (send(socket, string, strlen(string), 0) == -1)
		perror("Writing String to client");
}

int sendSerial(int socket, int flag) {
	FILE *FP;
    char string[32];     
    char cmd[256];      
	/* flag on for AIX */
	if (flag) {
		sprintf(cmd, "lsattr -El sys0 -a systemid |awk \'{print $2}\'| sed \'s/IBM,[0-9][0-9]//\'");
		FP = popen(cmd,"r");
    	fgets(string, 32, FP);
		pclose(FP);
	}
	else {
		sprintf(cmd, "sudo /usr/sbin/dmidecode |grep \'Serial Number\' | head -1 | awk -F\': \' \'{print $2}\'");
		FP = popen(cmd,"r");
    	fgets(string, 32, FP);
		if (NULL != strstr(string, "VMware"))
			strcpy(string,"VMware");
		pclose(FP);
	}

	rtrim(string);
	if (send(socket, string, strlen(string), 0) == -1)
   		perror("Writing String to client");
}
	
int sendCPU(int socket, int flag) {
	FILE *FP;
	char string[32];
	char speed[16];   
	char cores[8];   

	/* flag on for AIX */
	if (flag) {
		FP = popen("lparstat -i | grep Entitled | grep -v Pool| awk \'{print $4}\'","r");
		fgets(cores, 8, FP);
		rtrim(cores);
		pclose(FP);
		FP = popen("pmcycles | cut -d\" \" -f5-","r");
		fgets(speed, 16, FP);
		sprintf(string, "%s @ %s", cores,speed);
		pclose(FP);
	}
	else {
		FP = popen("grep processor /proc/cpuinfo | wc -l","r");
		fgets(cores, 8, FP);
		rtrim(cores);
		pclose(FP);
		FP = popen("grep MHz /proc/cpuinfo |head -1|awk -F\': \' \'{print $2}\'","r");
		fgets(speed, 16, FP);
		sprintf(string, "%s @ %s", cores,speed);
		pclose(FP);
	}

	rtrim(string);
	if (send(socket, string, strlen(string), 0) == -1)
   		perror("Writing String to client");
}

int sendModel(int socket, int flag) {
	FILE *FP;
	char string[32];
	char make[8];
	char model[32];
	/* flag on for AIX */
	if (flag) {
		strcpy(make,"IBM");
		FP = popen ("uname -M | awk -F, \'{print $2}\'","r");
		fgets(model,32,FP);
		sprintf(string, "%s: %s", make,model);
		pclose(FP);
	}
	else {
		strcpy(make,"Dell");
		FP = popen("sudo /usr/sbin/dmidecode |grep Product|head -1|awk -F\': \' \'{print $2}\'","r");
		fgets(model,32,FP);
		if (NULL != strstr(model, "VMware")) 
			strcpy(model,"VMware");
		sprintf(string, "%s: %s", make,model);
		pclose(FP);
	}

	rtrim(string);
	if (send(socket, string, strlen(string), 0) == -1)
	 	perror("Writing String to client");

	return(1);
}

int sendMem(int socket, int flag) {
	FILE *FP;
	char string[32];
	int num;
	/* flag on for AIX */
	if (flag) {
		FP = popen("lsattr -El mem0 |grep good|awk \'{print $2}\'","r");
        fgets(string,16,FP);
		squeeze(string); 
	    pclose(FP);
	}
	else {
		FP = popen("grep MemTotal /proc/meminfo |awk -F: \'{print $2}\' |sed \'s/kB//\'","r");
		fgets(string,16,FP);
		squeeze(string); 
		num = atoi(string) / 1024;
		sprintf(string,"%d\n",num);
		pclose(FP);
	}

	rtrim(string);
	if (send(socket, string, strlen(string), 0) == -1)
		perror("Writing String to client");

	return(1);
}

int sendLparType(int socket, int flag) {
	FILE *FP;
	char string[128];
	char buf[64];
	int len;
    memset(string,0,128);
	if (!flag) {
		 strcpy(string,"HUH?, this is a Linux host");
	}
	else {
    	FP = popen("lparstat -i | head -5 | tail -2","r");
    	while(fgets(buf,64,FP) != NULL) {
    		strcat(string,buf);
		}
		pclose(FP);
		squeeze(string);
	}

	rtrim(string);
    if (send(socket, string, strlen(string) + 1, 0) == -1)
    	perror("Writing String to client");
}

int sendPowerpathVer(int socket, int flag) { 
	FILE *FP;
	char string[128];
	if (flag) {
		if (exists("/usr/sbin/powermt") ) {
			FP = popen("sudo /usr/sbin/powermt version","r");
			fgets(string,128,FP);
			pclose(FP);
		} else {
			strcpy(string,"Powerpath not installed\n");
		}
	}

	else {
		if (exists("sbin/powermt") ) {
			FP = popen("sudo /sbin/powermt version","r");
			fgets(string,128,FP);
			pclose(FP);
		} else {
			strcpy(string,"Powerpath not installed\n");
		}

	}

	rtrim(string);
	if (send(socket, string, strlen(string), 0) == -1)
		        perror("Writing String to client");
}


int sendSAN(int socket, int flag) {
	FILE *FP;
    FILE *bootinfoFP;
    char LUN[128];
    char SIZE[64];
    char string[128];
    char bootinfoCMD[128];
	char junk[32],pv[32],size[32],bytes[32];
    int total = 0;

	if (flag) {
		FP = popen("/usr/sbin/lspv |grep hdiskpower | awk \'{print $1}\'","r");
		while(fgets(LUN,128,FP) != NULL) {
			strcpy(bootinfoCMD,"sudo /usr/sbin/bootinfo -s ");
			strcat(bootinfoCMD,LUN);
			bootinfoFP = popen(bootinfoCMD,"r");
			fgets(SIZE,64,bootinfoFP);
			pclose(bootinfoFP);
			total += atoi(SIZE);
		}
	}
	else {
		FP = popen("sudo /sbin/fdisk -l /dev/emcpower* 2>/dev/null |grep power| grep Disk","r");
		while(fgets(LUN,128,FP) != NULL) {
			sscanf(LUN,"%s%s%s%s",junk,pv,size,bytes);
			total = (total + (1024 * atoi(size)));
		}
		pclose(FP);
	}

	sprintf(string,"%d MB\n",total);
	rtrim(string);
	if (send(socket, string, strlen(string), 0) == -1)
		perror("Writing String to client");
}

/* some toolbox functions */

/* trim trailing right space including new lines and tabs */
int rtrim(char *string)
{
	int len = strlen(string);
    while (isspace(string[len-1]))
    	len--;
	string[len] = '\0';
	return 0;
}


/* remove all spaces from string */
int squeeze(char *s) {
	char *t = s;
    for(;*s;(*s != ' ') ? *t++ = *s++ : *s++)
    	continue;
	*t = '\0';
}

/* removes ALL new lines */
int squeeze_nl(char *s)
{
	char *t = s;
    for(;*s;(*s != '\n') ? *t++ = *s++ : *s++)
    	continue;
	*t = '\0';
}

/* check for file existance */
int exists(const char *fname)
{
	if (access(fname, F_OK) != -1 ) {
    	return 1;
	}
	return 0;
}

/* chomp newline */
char *chmop(char *s)
{
	int len = strlen(s);
	if (len > 0 && s[len-1] == '\n')  // if there's a newline
		s[len-1] = '\0';          // truncate the string
	return s;
}


