#include <stdio.h>		/* Basic I/O routines          */
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>		/* standard system types       */
#include <netinet/in.h>		/* Internet address structures */
#include <sys/socket.h>		/* socket interface functions  */
#include <netdb.h>		/* host to IP resolution       */
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>

#define	HOSTNAMELEN	40	/* maximal host name length */
#define	BUFLEN		128	/* maximum response size    */
#define PORT 3490

void send_msg (int filedes, char *msg)
{
	int nbytes;
	nbytes = write(filedes, msg, strlen(msg) + 1);
	if (nbytes < 0) {
		perror ("write");
		exit (EXIT_FAILURE);
	}
}

int main(int argc, char *argv[])
{
    int			rc;            /* system calls return value storage */
    int        	sockfd;             /* socket descriptor */
    char		buf[BUFLEN]; /* buffer server answer */
    char*		pc;            /* pointer into the buffer */
	char msg[20] = "fun stuff";
	/* char *mesg = "more fun stuff";  */
    struct sockaddr_in	sa;            /* Internet address struct */
    struct hostent*     hen; 	       /* host-to-IP translation */
	/* struct in_addr **pptr;       for srv addr iteration example below */
	/* struct servent *sp;          if we want to use getservbyname */
	int len;

    if (argc < 2) {
		fprintf(stderr, "Missing host name\n");
		exit (1);
    }

    /* Address resolution of Server we are connecting to */
    hen = gethostbyname(argv[1]);
    if (!hen) { perror("couldn't resolve host name"); }

   	/* if we want to get service info from server. arg 2 is name of service, eg "daytime" 
	 * if ( (sp = getservbyname(argv[2], "tcp")) == NULL)
	 *    perror("error for %s", argv[2]);
	 */

    /* initiate machine's Internet address structure  first clear out the struct  */
    memset(&sa, 0, sizeof(sa));
	/* ipv4 address */
    sa.sin_family = AF_INET;
    /* load port number in network byte order */
    sa.sin_port = htons(PORT);
	/* can use the servent struct from getservbyname if we want
	 * sa.sin_port = sp->s_port */

    /* copy IP address into address struct */
    memcpy(&sa.sin_addr.s_addr, hen->h_addr_list[0], hen->h_length);

	if ((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0) {
		perror("server:socket");
	    exit(1);
	}

	/* if we wanted to interate thru all of the server's addr we do this:
	 * pptr points to an array of ptrs to addrs.  h_addr_list is the ptr to an array of addrs
	 *  pptr = (struct in_addr **) hen->h_addr_list;
	 *  for (; *pptr != NULL; pptr++) {
	 *     sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	 *     }
	 */

    /* now connect to the remote server. the system will	*/
	/* automatically bind to a random local port, dont need to call bind since we are a client */
    /* note the cast to a struct sockaddr pointer of the address of variable sa		*/
	if (connect(sockfd, (struct sockaddr *)&sa, sizeof(struct sockaddr)) == -1) {
	    perror("connect");
	    exit(1);
	}

	printf("client: connecting to %s\n", hen->h_name);

	/* SEND ROUTINES */
	/* send_msg(sockfd, msg); */

	/* this works as well for sending, try sending size of msg + 1 if dont work  */ 
	if (send(sockfd, msg, BUFLEN, 0) == -1) { perror("send"); }
	
	/* END SEND ROUTINES */


	/* RECV ROUTINES */ 
	/*
	len = read(sockfd, buf, BUFLEN);
	if (len < 0)
    	perror("Socket read error");
	printf("read from server: %s\n", buf);
	*/

	/* use this rcv with sel-non-blk-server program along with a send 
	 * if not use 1 or the other */
	if ((len = recv(sockfd, buf, sizeof(buf), 0)) == -1) {
	 	perror("recv");
	 	exit(1);
	 }
	buf[len] = '\0'; 
	printf("%d bytes received\n", len);
    printf("server ECHO back %s\n", buf);

	/* one more 
      bytesReceived = 0;
      while (bytesReceived < BUFFER_LENGTH)
      {
         rc = recv(sd, & buffer[bytesReceived], BUFFER_LENGTH - bytesReceived, 0);
         if (rc < 0)
         {
            perror("recv() failed");
            break;
         }
         else if (rc == 0)
         {
            printf("The server closed the connection\n");
            break;
         }
         bytesReceived += rc;
      }
   */

	/* END RECV ROUTINES */ 

    close(sockfd);
}


