/* TESTED: WORKS WITH GENERIC SERVER */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <string.h> 
#include <fcntl.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/time.h>
#include <errno.h>

#define PORT 3490

void error(char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    int sockfd, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;
	fd_set myset; 
	struct timeval tv; 
	int valopt; 
	int res;
	socklen_t lon; 
	long  arg;

    char buffer[256];
    if (argc < 2) {
       fprintf(stderr,"usage %s hostname\n", argv[0]);
       exit(0);
    }
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(PORT);

    /* Set non-blocking - http://www.aquaphoenix.com/ref/gnu_c_library/libc_141.html */
 	if( (arg = fcntl(sockfd, F_GETFL, NULL)) < 0) { 
    	fprintf(stderr, "Error fcntl-Cant get file status flags) (%s)\n", strerror(errno)); 
        exit(0); 
	} 
	arg |= O_NONBLOCK; 
    if( fcntl(sockfd, F_SETFL, arg) < 0) { 
    	fprintf(stderr, "Error fcntl-cant set file status flag (%s)\n", strerror(errno)); 
    	exit(0); 
	} 

	/* If you are using a non-blocking socket and then call connect, it  should return -1 and errno=EINPROGRESS */
	if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) {
		if (errno == EINPROGRESS) { 
			fprintf(stderr, "EINPROGRESS in connect() - selecting\n"); 
			do {
				tv.tv_sec = 15; 
           		tv.tv_usec = 0; 
              	FD_ZERO(&myset); 
             	FD_SET(sockfd, &myset); 
				/* try to select the socket for writing with the timeout */
            	res = select(sockfd+1, NULL, &myset, NULL, &tv); 
				if (res < 0 && errno != EINTR) { 
					fprintf(stderr, "Error connecting %d - %s\n", errno, strerror(errno)); 
				    exit(0); 
			    } 
				else if (res > 0) {
					/* socket selected for write */
					lon = sizeof(int); 
				/* SO_ERROR at the SOL_SOCKET level should be zero  if the connection was successful or set to an errno if not */
              	if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon) < 0) { 
                	fprintf(stderr, "Error in getsockopt() %d - %s\n", errno, strerror(errno)); 
                    exit(0); 
                } 

			    if (valopt) { 
		       		fprintf(stderr, "Error in delayed connection() %d - %s\n", valopt, strerror(valopt) ); 
					exit(0);
				}
				break;
		   	   }	
		      else {
				fprintf(stderr, "Timeout in select() - Cancelling!\n"); 
				exit(0);
		 	   }
	   		} while (1);
	    }
		else { 
        	fprintf(stderr, "Error connecting %d - %s\n", errno, strerror(errno)); 
        	exit(0); 
    	} 
	} 

	/* set back to blocking */
	if( (arg = fcntl(sockfd, F_GETFL, NULL)) < 0) { 
		fprintf(stderr, "Error fcntl(..., F_GETFL) (%s)\n", strerror(errno)); 
		exit(0); 
	} 
	arg &= (~O_NONBLOCK); 
	if( fcntl(sockfd, F_SETFL, arg) < 0) { 
	 	fprintf(stderr, "Error fcntl(..., F_SETFL) (%s)\n", strerror(errno)); 
    	exit(0); 
	} 

	strcpy(buffer,"hi");
    n = write(sockfd,buffer,strlen(buffer));
    if (n < 0) 
         error("ERROR writing to socket");
	/*
    bzero(buffer,256);
    n = read(sockfd,buffer,255);
    if (n < 0) 
         error("ERROR reading from socket");
    printf("from server%s\n",buffer);
	*/
    return 0;
}
