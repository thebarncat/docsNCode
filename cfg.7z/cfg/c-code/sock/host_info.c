#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> 

/* get host, ip, and any aliases for given host or IP adr */

int main(int argc, char **argv) {

	struct hostent *h;
	char **q;

	if (argc != 2) {  
		fprintf(stderr,"usage: getip address\n");
		exit(1);
	}

	if ((h = gethostbyname(argv[1])) == NULL) {  
		herror("gethostbyname");
		exit(1);
	}

	printf("Here is the host info for this machine\n");
	printf("Host name  : %s\n", h->h_name);
	printf("IP Address : %s\n", inet_ntoa(*((struct in_addr *)h->h_addr)));

	for (q = h->h_aliases; *q != 0; q++)
    	 printf("%s", *q);
     putchar('\n');

	return 0;

}
