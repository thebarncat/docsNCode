/* -*- C -*-
 * FILE: "/home/jkipp/c-code/sock/timeout.c"
 * LAST MODIFICATION: "Thu, 20 Dec 2012 13:56:26 -0500 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
*/

#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>

#define STDIN 0  // file descriptor for standard input

int main(void)
{
    struct timeval tv;
    fd_set readfds;
	time_t now;
	struct tm *local;
	int min;
	int n;

	now = time(0);
	local = localtime(&now);
	min = local->tm_min;
	if (min == 27)
		printf("gotca %i\n", min);

    tv.tv_sec = 60;
    tv.tv_usec = 0; 

    FD_ZERO(&readfds);
    FD_SET(STDIN, &readfds);

	// don't care about writefds and exceptfds:
	n = select(STDIN+1, &readfds, NULL, NULL, &tv);
	/* if (n == 0) return -2; // timeout! */
	/* if (n == -1) return -1; // error */
	/* data must be here, so do a normal recv() */
	/*  recv(s, buf, len, 0); */
	
    if (FD_ISSET(STDIN, &readfds))
    	printf("A key was pressed!\n");
    else 
		printf("timed out at  minute %i", min);
    return 0;
} 

