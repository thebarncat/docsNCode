#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <assert.h>

/* -------------------------------------------------------------------
 *  If inTCPWin > 0, set the TCP window size (via the socket buffer
 *   sizes) for inSock. Otherwise leave it as the system default.
 *  
 *  This must be called prior to calling listen() or connect() on
 *  the socket, for TCP window sizes > 64 KB to be effective.
 * 
 *  This prints a warning if the allocated buffer appears   different
 *  than the requested buffer. A better time to verify this is  after
 *  connection time though.
 *  This now works on AIX, by enabling RFC1323.
 *  returns -1 on error, 0 on no error.
 * 
 */

extern int setsock_tcp_windowsize( int inSock, int inTCPWin );
extern int getsock_tcp_windowsize( int inSock );

const char warn_window_recv[] =
"WARNING: attempt to set TCP window size (recv) to %d, but got %d\n";

const char warn_window_send[] =
"WARNING: attempt to set TCP window size (send) to %d, but got %d\n";

const char warn_no_rfc1323[] =
"WARNING: attempt to enable RFC 1323 TCP large window extensions failed\n";

int setsock_tcp_windowsize( int inSock, int inTCPWin )
{
#ifdef SO_SNDBUF
	int rc;
    int newTCPWin;
	socklen_t len;
    assert( inSock >= 0 );
	if ( inTCPWin > 0 ) {
#ifdef TCP_RFC1323
		/* mostly for AIX */
		if ( inTCPWin > 65535 ) {
			 /* enable RFC 1323 */
		      int on = 1;
			  rc = setsockopt( inSock, IPPROTO_TCP, TCP_RFC1323, (char*) &on, sizeof( on ));
			  if ( rc < 0 ) { return rc; }
			  /* verify RFC 1323 */
			  len = sizeof( on );
			  rc = getsockopt( inSock, IPPROTO_TCP, TCP_RFC1323, (char*) &on, &len );
			 if ( rc < 0 ) { return rc; }
		     if ( on == 0 ) {
		         fprintf( stderr, warn_no_rfc1323 );
		      }
		}
#endif /* TCP_RFC1323 */
		/* receive buffer -- set */
		 newTCPWin = inTCPWin;
		 rc = setsockopt( inSock, SOL_SOCKET, SO_RCVBUF, (char*) &newTCPWin, sizeof( newTCPWin ));
		 if ( rc < 0 ) { return rc; }
		 /* receive buffer -- verify results */
		  len = sizeof( newTCPWin );
		  rc = getsockopt( inSock, SOL_SOCKET, SO_RCVBUF, (char*) &newTCPWin, &len );
	     if ( rc < 0 ) { return rc; }
		 if ( newTCPWin != inTCPWin ) { fprintf( stderr, warn_window_recv, inTCPWin, newTCPWin ); }
		 /* send buffer -- set */
		 newTCPWin = inTCPWin;
		 rc = setsockopt( inSock, SOL_SOCKET, SO_SNDBUF, (char*) &newTCPWin, sizeof( newTCPWin ));
	     if ( rc < 0 ) { return rc; }

		 /* send buffer -- verify results */
		  len = sizeof( newTCPWin );
		  rc = getsockopt( inSock, SOL_SOCKET, SO_SNDBUF, (char*) &newTCPWin, &len );
	      if ( rc < 0 ) { return rc; }
		 if ( newTCPWin != inTCPWin ) { fprintf( stderr, warn_window_send, inTCPWin, newTCPWin ); }
   }
#endif /* SO_SNDBUF */

	  return 0;
} /* end setsock_tcp_windowsize */

/* -------------------------------------------------------------------
returns the TCP window size (on the sending buffer, SO_SNDBUF),  or -1 on error.  */

int getsock_tcp_windowsize( int inSock )
{
	int rc;
    int theTCPWin = 0;
	socklen_t len;
	int mySock = inSock;

#ifdef SO_SNDBUF
	if ( inSock < 0 ) {
    /* no socket given, return system default  allocate our own new socket */
     mySock = socket( AF_INET, SOCK_STREAM, 0 ); }
     assert( mySock >= 0 );
  /* send buffer -- query for buffer size */
     len = sizeof( theTCPWin );
	 rc = getsockopt( mySock, SOL_SOCKET, SO_SNDBUF, (char*) &theTCPWin, &len );
	 if ( rc < 0 ) { return rc; }
     if ( inSock < 0 ) {
	    /* we allocated our own socket, so  deallocate it */
      close( mySock );
	 }
#endif

	return theTCPWin;
} /* end getsock_tcp_windowsize */


