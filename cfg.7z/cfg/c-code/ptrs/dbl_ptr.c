/* -*- C -*-
 * FILE: "/home/jkipp/c-code/ptrs/dbl_ptr.c"
 * LAST MODIFICATION: "Wed, 19 Dec 2012 16:20:07 -0500 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdio.h>

void foo(int**p)
{
	int y = 5;  
	*p = &y; //assign value at address 
    /*note that we don't return the address of the int */
}

int main()
{
	int* p; 
	/* p points to nowhere right now */
	foo(&p); //we pass  p's address to foo()
	printf("%d",*p);
}

