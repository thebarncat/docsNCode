#include <stdio.h>
#include <stdlib.h>

/* declare an array of ints */
int array[] = {1,2,3,4,5,6};
int *ptr;

/* other fun stuff
 * int (*day)[13]	pointer to an array of 13 int:  
 * int *day[13]	an array of pointers to int:  
 *  *(*(multi + 3) + 1) :	get to the content of the 2nd element in the 4th
 * row we add 1 to this address and dereference the result.equivalent to
 * the address &multi[3][1] in a multidimensional array of multi[5][10]:
 * http://pw2.netcom.com/~tjensen/ptr/ch6x.htm
 */

int main(void)
{

	int *x;
	/* in this case the malloc call assigns the mem location */
	x = (int *)malloc(sizeof(int));
	*x = 10;
	printf("using malloc %d\n", *x);

    int i;
	/* declare ptr to array, same as saying ptr = array */
    ptr = &array[0];  

	/* get the number of elements */
	printf("elements: %d\n", sizeof(array)/sizeof(int) );

    for (i = 0; i < 6; i++)
    {

      /* just iterates the values of the array it points to */
      /* printf("array member %d = %d\n",i, *ptr++ ); */ 

      /* result is same as above, but it increments the ptr addr first, then derefes */ 
      /* printf("array member %d = %d\n",i, *(ptr++) ); */

      /* does same as first print statment */
      /* printf("array member %d = %d\n",i, *(ptr)++ ); */

      /* increments what the ptr points to! */
       printf("array memberBY value %d = %d\n",i, (*ptr)++ );

		/* increments the ptr addr element while deref */
	/*	printf("ptr + %d = %d\n",i, *(ptr + i) );        */ 

      /* this one does not deref, simply increment the adr */
       printf("array addr %d is %d\n",i, ptr++ ); 
    }
    return 0;
}

