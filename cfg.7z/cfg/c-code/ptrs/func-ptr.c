/* -*- C -*-
 * FILE: "/home/jkipp/c-code/ptrs/func-ptr.c"
 * LAST MODIFICATION: "Wed, 19 Dec 2012 15:56:54 -0500 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */
#include <stdio.h>

int deliver_fruit(char *address, float speed)
{
    printf("Delivering fruit to %s at speed %.2f\n", address, speed);
    return 3490;
}

func_ret_char( int i)
{
	return (char)i;
}


int main(void)
{
    int (*p)(char*,float);  // declare a function pointer variable
    p = deliver_fruit; // p now points to the deliver_fruit() function
    deliver_fruit("My house", 5280.0); // a normal call
    p("My house", 5280.0); // the same call, but using the pointer

	// ptr to func return chr
	int i = 65;
	char ch;
	char (*ptr)();
	ptr = func_ret_char;
	ch = ptr(i);
	// does same as above
	//ch = (*ptr)(i);
	printf("ascii code: %c\n", ch);
	// this would pass an array element to f function
	// f(&a[2]);
}

