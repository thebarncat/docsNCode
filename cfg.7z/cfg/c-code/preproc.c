/* -*- C -*-
 * FILE: "/home/jkipp/c-code/preproc.c"
 * LAST MODIFICATION: "Mon, 14 Apr 2014 11:58:03 -0400 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdio.h>

#define BELL '\007'
#define BELL '\x7'
#define ABS(x)  ((x) < 0) ? -(x) : (x)
#define MAX(a,b) (a < b) ? (b) : (a)
#define BIGGEST(a,b,c) (MAX(a,b) < c) ? (c) : (MAX(a,b))

int main(void)
{
	printf ("%d\n",ABS(-5));
	printf ("Biggest of 1 2  3 is %d\n",BIGGEST(1,2,3));

}
