#include <stdio.h>
#include <signal.h>
#include <unistd.h>


/* invoke this prog in bg and send it signals like:
 * kill -USR <pid> or kill -USR2, or just kill */

static void	sig_usr(int);	/* one handler for both signals */

int
main(void)
{
	if (signal(SIGUSR1, sig_usr) == SIG_ERR)
		perror("can't catch SIGUSR1");
	if (signal(SIGUSR2, sig_usr) == SIG_ERR)
		perror("can't catch SIGUSR2");

	for ( ; ; )
		/* puts the proc asleep waiting for the signal */
		sleep(1);
}

static void
sig_usr(int signo)		/* argument is signal number */
{
	if (signo == SIGUSR1)
		printf("received SIGUSR1\n");
	else if (signo == SIGUSR2)
		printf("received SIGUSR2\n");
	else
		perror("received signal\n");
	return;
}
