#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

#define MAXLINE 4096

int main(void)
{
	char	buf[MAXLINE];
	pid_t	pid;
	int		status;

	printf("%% ");	/* print prompt (printf requires %% to print %) */
	while (fgets(buf, MAXLINE, stdin) != NULL) {
		buf[strlen(buf) - 1] = 0;	/* replace newline with null */

		printf("CMD: %s\n",buf);

		if ( (pid = fork()) < 0)
			perror("fork error");

		else if (pid == 0) {		/* child */
			/* replaces the current process image with a new process
			 * image specified by file (eg: a program passed from stdin)
			 * and it args. new process is not started; the new process
			 * image simply overlays the original process image.  Uses
			 * the local env
			 * if (execlp("ls", "ls", "-l",(char *) 0) < 0)
			 */
			/* this wont work for commands with args need to use execvp
			 * or other exec func*/
			execlp(buf, buf, (char *) 0);
			perror("couldn't execute");
			exit(127);
		}
		/* specify which proc we want to wait for, returns the
		 * termination status of the child in statloc. suspends
		 * execution of the current process until a child as specified
		 * by the pid argument has exited. A value of  -1 says to wait
		 * for the 1st of the children to die. Gives us more control
		 * over which procs to wait for and whether or not to block
		 */
		/* parent */
		if ( (pid = waitpid(pid, &status, 0)) < 0)
			perror("waitpid error");
		printf("%% ");
	}
	exit(0);
}
