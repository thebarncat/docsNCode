#include	<sys/types.h>
#include	<signal.h>
#include	<stdio.h>

static void	sig_cld();

int
main()
{
	pid_t	pid;

	if (signal(SIGCHLD, sig_cld) == -1)
		perror("signal error");
	/* return 0 in child. Returns pid of child in parent. -1 on error.
	 * creates a child process that differs from the parent process only
	 * in its PID and PPID, and in the fact that resource utilizations
	 * are set to 0. Child gets a copy of parent data space, heap, and
	 * stack. File locks and pending signals are not inherited. All FD's
	 * open in the parent are duped in the child
	 */
	if ( (pid = fork()) < 0)
		perror("fork error");
	else if (pid == 0) {		/* child */
		sleep(2);
		_exit(0);
	}
	pause();	/* parent */
	exit(0);
}

static void
sig_cld()
{
	pid_t	pid;
	int		status;

	printf("SIGCLD received\n");
	if (signal(SIGCHLD, sig_cld) == -1)	/* reestablish handler */
		perror("signal error");

	/* suspends execution of the current process until a child has
	 * exited, or until a signal is delivered whose action is to
	 * terminate the current process or to call a signal handling
	 * function.  If a child  has already exited by the time of the call
	 * ("zombie"), the function returns immediately.  Any system resources 
	 * used by the child are freed. the termination  status is stored in statloc
	 */
	if ( (pid = wait(&status)) < 0)		/* fetch child status */
		perror("wait error");
	printf("pid = %d\n", pid);
	return;		/* interrupts pause() */
}
