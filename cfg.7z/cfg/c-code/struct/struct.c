#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	struct rec
	{
		char name[21];
		char city[21];
		char state[3];
	}; 

	/* declare the stuct and a ptr for it */
	struct rec my_rec, *r;  
	/* r = &my_rec; */
	/* OP can use malloc to allocate the mem and pt to * the struct*/	
	r = malloc(sizeof(my_rec));

	strcpy((*r).name, "Leigh");
	strcpy((*r).city, "Raleigh");
	strcpy(r->state, "NC");
	printf("%s\n", r->city);

	/* TAKE THIS OUT  if dont use malloc  */	
	free(r);
	return 0;
}

