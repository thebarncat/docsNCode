#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	struct rec
	{
		char s1[81];
		char s2[81];
	}; 

	/* declare the stuct and and array of 10 ptrs to the structs */
	struct rec my_rec, *a[10]; 

	/* allocate memory for first array ONLY */
	a[0] = malloc(sizeof(my_rec));
	/* allocate 1 rec in the first struct ptr */
	strcpy(a[0]->s1, "hello");
	strcpy(a[0]->s2, "bye");
	printf("%s\n", a[0]->s1);
	printf("%s\n", a[0]->s2);
	free(a[0]);

	/* work with 2nd array now r */
	a[1] = malloc(sizeof(my_rec));
	strcpy(a[1]->s1, "in 2nd array");
	printf("%s\n", a[1]->s1);
	free(a[1]);

	return 0;
}

