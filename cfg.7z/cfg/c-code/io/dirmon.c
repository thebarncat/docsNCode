/* This program grabs the, atime, mtime, and ctime of dirs, 
 * and the files under those dirs, it saves the output in
 * a flatfile, where another program will compare the files
 * in the database with those in the machine, and write a 
 * new db file, with the programs which MACtimes changed.
 * 
 */ 

#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

FILE *file;
char *db;
char *home;

void scan_dir(char *dir);

int main(int argc, char *argv[])
{
    if (argc != 2) 
	{
		fprintf(stderr, "Enter the full dir path\n");
		return -1;
    }

    home = getenv("HOME");
	/* append to home path */
    db = strcat(home, "/fmdb");

    printf("Scanning: %s \n", argv[1]);

	/* open file for appending - "a".     */
    if ((file = fopen(db, "a")) == NULL) 
	{
	    fprintf(stderr, "Failed openning: %s\n", db);
	    return -1;
    }

    scan_dir(argv[1]);
    fclose(file);
    return 0;
}

void scan_dir(char *dir)
{
	    DIR *name;
		/* readddir returns struct which represents the next directory entry in the directory stream */
        struct dirent *entry;
		/* the struct for stat info for the stat file/dir functions */
        struct stat stat_buf;
        mode_t modes;
        time_t atime;
        time_t mtime;
        time_t ctime;

    if ((name = opendir(dir)) == NULL) {
	    fprintf(stderr, "Failed to open directory: %s\n", dir);
	    exit(8);
    }

    chdir(dir);
    while ((entry = readdir(name)) != NULL) {
		/* same as stat, but returns info about a symlink as well */
	    lstat(entry->d_name, &stat_buf);
		/* collect all the stats */
	    modes = stat_buf.st_mode;
	    atime = stat_buf.st_atime;
	    mtime = stat_buf.st_mtime;
	    ctime = stat_buf.st_ctime;

		/* make sure entry is a dir */
		if (S_ISDIR(stat_buf.st_mode)) {
			/* compare the 2 strings. strcmp returns 0 if they match */ 
			if (strcmp(".", entry->d_name) == 0 || strcmp("..", entry->d_name) == 0)
				continue;
			/* the %#o will print the octal mode */
	    		fprintf(file, "%s/ %#o %d %d %d\n", entry->d_name, "   ", (modes & 0777), atime, mtime, ctime);
	    		scan_dir(entry->d_name);
		} else {
	    		fprintf(file, "%s %#o %d %d %d\n",
		    			entry->d_name, "   ", (modes & 0777), atime, mtime, ctime);
		}
    }

    chdir("..");
    closedir(name);
}
