#include	<sys/types.h>
#include	<sys/stat.h>
#include <fcntl.h>
#include  <stdio.h>


int
main(void)
{
	umask(0);
	if (creat("foo", S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) < 0)
		perror("creat error for foo");

   	/* this umask makes new files under THIS proc(shell) only rw for owner and none for grp and other */
	umask(S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH); 
	if (creat("bar", S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) < 0)
		perror("creat error for bar");

	/* we can remove the first 2 constants and make new files  have mask  of rw - rw -- */
	 umask(S_IROTH | S_IWOTH);
	if (creat("boo", S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) < 0)
		perror("creat error for bar");

	return 0;
}
