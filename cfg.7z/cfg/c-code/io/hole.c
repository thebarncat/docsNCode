#include <stdio.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	<fcntl.h>
#include <errno.h>


/* creates a file with a hole in it */
char	buf1[] = "abcdefghij";
char	buf2[] = "ABCDEFGHIJ";

int
main(void)
{
	int	 fd;

	/* create a new file with default perms */
	if ( (fd = creat("file.hole", S_IRWXU)) < 0)
		perror("creat error");

	/* write the 10 bytes of buf1 to the file */
	if (write(fd, buf1, 10) != 10)
		perror("buf1 write error");
	/* offset now = 10 */

	/* seek 40 more  into the file */
	if (lseek(fd, 40, SEEK_SET) == -1)
		perror("lseek error");
	/* offset now = 40 */

	/* write 10 bytes of buf2 to the file */
	if (write(fd, buf2, 10) != 10)
		perror("buf2 write error");
	/* offset now = 50 */

	 /* unlink("file.hole"); */

	return 0;
}
