/* -*- C -*-
 * FILE: "/home/jkipp/c-code/io/fread-ex.c"
 * LAST MODIFICATION: "Mon, 15 Oct 2012 16:42:09 -0400 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

/* read 10 numbers from a file and store them in an array */

#include  <stdio.h>
#include <unistd.h>

int main(void) 
{
	int i;
	int n[10];
	FILE *fp;

	/* open in binary */
	fp = fopen("inout", "rb");
	fread(n, sizeof(int), 10, fp);  // read 10 ints
	fclose(fp);

	for(i = 0; i < 10; i++)
		printf("n[%d] == %d\n", i, n[i]);

	return 0;

}
