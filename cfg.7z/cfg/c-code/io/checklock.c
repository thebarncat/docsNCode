/* add more error and reporting functionality */
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	 int fdread, fdwrite;
	 /* initialzie the flock structure for file locking properties */
	 struct flock lock;

	 if (argc != 2)
	 {
	    printf("Usage: checklock <filename>\n");
	    exit(EXIT_FAILURE);
	 }

	/* get a read only descriptor on the file from argv. file should already exist
	   error and exit if it does not (don't create new file) */
	if ((fdread = open(*++argv, O_RDONLY)) < 0)
	    perror("open for read error");

	/* get a writeable descriptor for the same file from argv */
	if  ((fdwrite = open( *argv, O_RDWR) ) < 0)
	    perror("open for write error");

	/* set whence to beggining of file (SEEK_SET) */
	 lock.l_whence = 0;
	 lock.l_start  = 0L;
	/* lock file to EOF (whole thing) */
	 lock.l_len = 0;
	 /* set an !ADVISORY! read lock (http://beej.us/guide/bgipc/output/html/multipage/flocking.html) */
	 lock.l_type = F_RDLCK;

	/* get the lock on the file, F_GETLK makes sure no current lock exists  
	   If there is a lock already  that would block the lock described 
	   by the &lock argument, information about that lock overwrites &lock
	   if no lock is found that would prevent this lock from being
	   created, then the structure  will be left unchanged */
	 if ((fcntl(fdread,F_GETLK,(void *)&lock) ) < 0)
	 	perror("fcntl failed on read lock");

	/* If no lock applies, the only change to the lock structure is to update the l_type to a value of F_UNLCK.  */
	 if (lock.l_type == F_UNLCK)
	 {
	    printf("Read lock is available.\n");
	 }
	 else
	 {
	    /* gets the PID of the proc that holds the lock */
	    printf("Read lock is blocked by %d\n",lock.l_pid);
	 }

	 /* now check for write lock */
	 if (fdwrite >= 0)
	 {
	    lock.l_whence = 0;
	    lock.l_start  = 0L;
	    lock.l_len = 0;
	    lock.l_type = F_WRLCK;

	    if ((fcntl(fdwrite,F_GETLK,(void *)&lock) ) < 0)
	    	perror("fcntl failes on write lock");

	    if (lock.l_type == F_UNLCK)
	    {
	       printf("Write lock is available.\n");
	    }
	    else
	    {
	       printf("Write lock is blocked by %d.\n",lock.l_pid);
	    }
	 }

}
