#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

/* test this in a couple of terminals . Notice that when one lockdemo has a read lock, other instances of the program can get
 * their own read locks with no problem. It's only when a write lock is obtained that other processes can't get a lock of any kind.
 * also notice that you can't get a write lock if there  are any read locks on the same region of the file. The process
 * waiting to get the write lock will wait until all the read locks are  cleared. 
 * One upshot of this is that you can keep piling on read locks (because a read lock doesn't stop other processes from getting read
 * locks) and any processes waiting for a write lock will sit there. There isn't a rule anywhere that keeps you from adding more
 * read locks if there is a process waiting for a write lock. You must  be careful.
 * Practically, you will probably mostly be using write locks to guarantee exclusive access to a file for an amount of time while
 * it's being updated */

int main(int argc, char *argv[])
{
 	                /* l_type   l_whence  l_start  l_len  l_pid   */
	struct flock fl = {F_WRLCK, SEEK_SET,   0,      0,     0 };
	int fd;

	fl.l_pid = getpid();

	/* with no args, it tries to grab a write lock. If there are any args, it tries to get a read lock */
	if (argc > 1) 
		fl.l_type = F_RDLCK;

	if ((fd = open("lockdemo.c", O_RDWR)) == -1) {
		perror("open");
		exit(1);
	}
	
	printf("Press <RETURN> to try to get lock: ");
	getchar();
    printf("Trying to get lock...");

	/* F_SETLKW tries to get a lock, if it cant, fcntl will block until lock has cleared, then set itself */
	if (fcntl(fd, F_SETLKW, &fl) == -1) {
    	perror("fcntl");
	    exit(1);
    }

	printf("got lock\n");
    printf("Press <RETURN> to release lock: ");
    getchar();

	fl.l_type = F_UNLCK;  /* set to unlock same region */

	if (fcntl(fd, F_SETLK, &fl) == -1) {
    	perror("fcntl");
	    exit(1);
    }

	printf("Unlocked.\n");
	close(fd);
    return 0;

}
