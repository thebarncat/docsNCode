#include <stdio.h>
#include <string.h>

#define FILENAME "read_lines.c" /* this file */

int main(void)
{
	FILE *file = fopen(FILENAME, "r"); /* open text file for reading */
	if(file != NULL)
	{
		char buffer[256]; /* max line length */
		/* line number iterator var */
        size_t line = 0;
		/* loop through file one line at a time */
		while(fgets(buffer, sizeof(buffer), file) != NULL)
		{
			char* newline = strchr(buffer, '\n');
			if(newline)
			{
				*newline = 0; /* strip off trailing '\n' */
			}
			printf("[%2u] %s\n", line++, buffer);
		}
		fclose(file);
	}
	return(0);
}


