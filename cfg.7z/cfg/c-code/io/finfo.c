/* 
 *   Note: The code below needs a slight modification, for it to work in win32, basically 
 *         the stat() function is implemented differently in win32, so that needs to be 
 *         done (i'm on it), the chkpos() routine needs to be written and all the user crap 
 *         too, but the main time consuming routines are done, and ready for action, i could 
 *         optimize them more, if need be.
 *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#define PROG finfo
#define BUFSIZ 256


char *substr(char *string, int offset, int length);
char *tail(char *tfile, int total_lines);
off_t size (char *file);
int usage(void);
	
char buffer[BUFSIZ];
char tail_buffer[BUFSIZ];

int main(int argc, char *argv[])
{
	FILE *fp;
	char *file;
	char head_buffer[BUFSIZ];
	int  num_lines = 0;
	argc--;argv++;
	if( argc < 1) {
		usage();
	}
	while(argc-- > 0) {
		file = argv[argc];
		fp = fopen(file,"r");
		if(fp == NULL){
			perror("fopen");
		}
		while((void *)fgets(buffer,BUFSIZ,fp) != NULL){ /* fp may become NULL */
			num_lines++;
			if(num_lines <= 5){	
				strcat(head_buffer,buffer);
			}
		}
			
		(void *)fclose(fp);
		printf(">> head of %s: <<\n %s",file,head_buffer);
		printf(">> tail of %s: <<\n %s",file,tail(file,num_lines));
		printf("%d\n",num_lines);
       	printf("size of %s: %ld\n",file,size(file));
		printf("substr of %s: %s\n",file,substr(file,0,3));
	}
	return(EXIT_SUCCESS);
}

char *tail(char *tfile, int total_lines)
{
	FILE *fp;
	int lines_read;
	int lines = 0;
	lines_read = total_lines - 5;
	fp = fopen(tfile,"r");
	if(fp == NULL) {
		perror("fopen");
	}
	while ((void *)fgets(buffer,BUFSIZ, fp) != NULL){  /* fp may become NULL */

		lines++;
		if ((lines - 1) >= lines_read && (lines - 1) != total_lines){ 
			strcat(tail_buffer,buffer);					
		}
	}
	(void *)fclose(fp);
	return(tail_buffer);
}

off_t size (char *file)
{
	struct stat statbuf;
	stat(file,&statbuf);
	if(!S_ISREG(statbuf.st_mode)) {
		fprintf(stderr,"%s is not a regular file\n",file);
	}
	return(statbuf.st_size);
}

int usage(void)
{
	fprintf(stderr,"Usage: %s <filename1> <filename2> ... \n\n","PROG");
	fprintf(stderr,"Three types of files are created: \n\n");
	fprintf(stderr,"\t1.   all.info containing fileinfo for all processed files.\n\n");
	fprintf(stderr,"\t2.   allinfo.csv containing a list of all processed files (for Media Create) with\n \
	     Vendorcode,ProjectCode,FileName,Path,Size,RecordLength, NumOfRecords,BlockSize.\n\n");
	fprintf(stderr,"\t3.   <filename>.info containing fileinfo for each file processed files.\n\n");
	exit(EXIT_FAILURE);
}

char *substr(char *string, int offset, int length)
{
	char *substring;

	while(offset--) 
		string++;
	substring = string;
	while(length--) 
		string++;
    	*string = '\0';

	return(substring);
}
