#include  <stdio.h>
#include <unistd.h>

#define BUFFSIZE 8192


int main(void)
{
	int n;
	char buf[BUFFSIZE];
	/* read stream file standard output into buf. Then write out  to STDOUT */
	while ( (n= read(STDIN_FILENO, buf, BUFFSIZE)) > 0)
		if (write(STDOUT_FILENO, buf, n) != n)
			perror("write error");

	if (n > 0)
		perror("read error");

}
