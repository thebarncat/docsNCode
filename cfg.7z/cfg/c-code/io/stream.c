/* best practices for opening a file  */

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

/* good example of a constant func */
#define ENUF(message, value)  { perror(message); exit(value); }
 
int main(int argc, char **argv)
{
  FILE *fileptr;
  char c;
  char s[127];
 
  if (argc !=  3) {
    fprintf(stderr, "Usage: %s option file (option = r, w, a) \n", argv[0]);
    exit(1); 
  }

 
  switch (*argv[1])  
  {
  case 'r': /* open file for reading */
            if ( (fileptr = fopen(argv[2], "r")) == NULL) {
              sprintf(s, "%s - read error ", argv[0]); 
			  ENUF(s, 2); 
			}
 
            /* close the file */
            if (fclose(fileptr) == EOF) 
				ENUF("error closing file ", 5);
            break;
 
  case 'w': /* open file for writing */
            if ( (fileptr = fopen(argv[2], "w")) == NULL) {
              sprintf(s, "%s - write error ", argv[0]); 
			  ENUF(s, 3); 
			}
 
            /* close the file */
            if (fclose(fileptr) == EOF) 
				ENUF("error closing file ", 5);
            break;
 
  case 's': /* generate a close error */
            if (fclose(fopen(argv[2], "r")) == EOF) {
              sprintf(s, "%s - close error ", argv[0]); 
			  ENUF(s, 5); 
			}
            break;
 
  case 'a': /* open file for appending */
            if ( (fileptr = fopen(argv[2], "a")) == NULL) {
              sprintf(s, "%s - append error ", argv[0]); 
			  ENUF(s, 4); 
			}
 
            fputs("Enter text (terminate with ^D) \n", stdout);
            while ( (c=getc(stdin)) != EOF) putc(c, fileptr);
 
            /* close the file */
            if (fclose(fileptr) == EOF) 
				ENUF("error closing file ", 5);
 
            /* if we get this far then file open/close should be safe */
            fopen(argv[2], "r");
            while ( (c=getc(fileptr)) != EOF)
              if (islower(c)) 
				  putc(toupper(c), stdout); 
			  else putc(c, stdout);
            fclose(fileptr);
            break;
 
  default: fprintf(stderr, "valid options are r, w and a \n");
           exit(5);
  }
  return 0; 

}

