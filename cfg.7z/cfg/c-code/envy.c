#include <errno.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

extern char **environ;

#define MAXENV 20
int myenv_used=0;
char *myenv[MAXENV+1];

/* #define DEBUG_PRINTS */

void mysetenv(const char *name, const char *value)
{
	int len;
	if (myenv_used >= MAXENV) {
		die("Environment overflow");
	}
	len = strlen(name) + strlen(value) + 2;
	myenv[myenv_used] = malloc(len);
	if (!myenv[myenv_used])
		die("Out of memory");
	sprintf(myenv[myenv_used], "%s=%s", name, value);
	myenv_used++;
}

int main(int argc, char **argv)
{
	const char *user;
	const char *logname;
	const struct passwd *pw;
	char **newargv;
	char envsh[BUFSIZ];
	char envhome[BUFSIZ];
	int i, j;
	char *neweviron[10];
	char *shell;
	char *argv0;
	char *newargv0;
#ifdef DEBUG_PRINTS
		fp = fopen("/var/log/chrootshell.log", "a");
#endif
	user = getenv("USER");
	if (!user)
		die("USER not set?!");
	logname = getenv("LOGNAME");
	if (logname && *logname && strcmp(user, logname))
		die("USER does not match LOGNAME\n");
	/* Look up user in outer /etc/passwd */
	pw = getpwnam(user);
	if (!pw)
		die2("no such user %s\n", user);

	shell = strrchr(pw->pw_shell, '/');
	if (!shell)
		die("shell contains no / ?");
	shell++;	/* skip slash */
	argv0 = argv[0];
	if (*argv0 == '-') {
		/* it's a login shell */
		argv0++;	/* skip dash */
	}
	if (strcmp(shell, argv0)) {
		fprintf(fp, "shell '%s', argv[0] '%s'\n", shell, argv[0]);
		die2("%s not chrootshell\n", shell);
	}

	/* Enter jail home dir */
	if (chdir(pw->pw_dir))
		die2("chdir(%s) fails", pw->pw_dir);
	if (chroot(pw->pw_dir))
		die2("chroot(%s) fails", pw->pw_dir);
	/* Permanently discard root privs */
	if (setuid(pw->pw_uid))
		die2("setuid(%d) fails", (void *)pw->pw_uid);

	/* Look up user in jail's /etc/passwd */
	endpwent();
	pw = getpwnam(user);
	if (!pw)
		die2("no such user %s in jail\n", user);
	/* Go to his home directory */
	if (chdir(pw->pw_dir))
		die2("chdir(%s) fails", pw->pw_dir);

	/* Fix up the environment. 
	  Clear the whole thing out for security reasons, and give him a minimal one */
	mysetenv("SHELL", pw->pw_shell);
	mysetenv("HOME", pw->pw_dir);
	mysetenv("PATH", "/bin:/usr/bin");
	mysetenv("USER", user);
	/* Note: rshd does not set LOGNAME, as the user hasn't really logged in... */
	if (logname && *logname)
		mysetenv("LOGNAME", user);

	myenv[myenv_used] = 0;
	/* yes, this is the posix way of replacing the entire environment */
	environ = myenv;

	/* Close the handle to the jail's /etc/passwd */
	endpwent();
	/* Finally, run the original command. */
	newargv = malloc((argc + 3) * sizeof(argv[0]));
	if (!newargv)
		die("malloc fails?!\n");
	j =0;
	i =1;
	if (argc == 1) {
	/* Case 1: interactive login; argv[0] is the shell,  there are no args */
		char *buf = malloc(strlen(pw->pw_shell) + 2);
		newargv0 = pw->pw_shell;
		sprintf(buf, "-%s", pw->pw_shell);
		newargv[j++] = buf;
	} else if (argc > 1 && !strcmp(argv[1], "-c")) {
	/* Case 2: non-interactive; argv[0] is the shell, * argv[1] is -c, argv[2] is the command */
		newargv[j++] = pw->pw_shell;
		newargv0 = pw->pw_shell;
		newargv[j++] = "-c";
		newargv[j++] = argv[2];
	} else
		die("Expected argc==1 || (argc==3 && argv[1] == '-c')");
		newargv[j++] = 0;
		execvp(newargv0, newargv);
		die2("exec %s fails", newargv[0]);
		/*notreached*/
		return 1;
}


