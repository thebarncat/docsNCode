#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <grp.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <pwd.h>

int main(void) {
	struct passwd   *ptr;
	char *login;
	/* first time it is called it returns the first entry in passwd file; then, it returns successive entries */
	ptr = getpwent(); 
 	printf ("Gecos: %s\n", ptr->pw_gecos);
	login = getlogin();
 	printf ("login: %s\n", login);
	/* populate the struct with a different call */
	ptr = getpwuid(geteuid());
	printf("Printing userid using getpwuid\n");
	printf("%s\n",ptr->pw_name);
}


