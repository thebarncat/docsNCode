#include	<stdio.h>
#include	<pwd.h>
#include	<signal.h>
#include    <sys/types.h>
#include    <unistd.h>

int main(void)
{
	/* struct pointer returned for the getpwnam func */ 
	struct passwd *ptr;
	if ( (ptr = getpwnam("jkipp")) == NULL)
			perror("getpwnam error");

	if (strcmp(ptr->pw_name, "jkipp") != 0)
			printf("return value corrupted!, pw_name = %s\n", ptr->pw_name);

	printf ("user: %s\n", ptr->pw_name);

	char *login;
	login = getlogin();
	printf("Login: %s\n", login);
	
}

