#include <sys/types.h>
#include <stdio.h>
#include <pwd.h>
#include <grp.h>

int main(void)
{
	struct passwd *ptr;
	while ( (ptr = getpwent() ) != NULL ) 
		 printf ("Gecos: %s\n", ptr->pw_gecos);
	endpwent();

	struct group *gptr;
	while ( (gptr = getgrent() ) != NULL ) 
		printf("Name: %s\n", gptr->gr_name);
	endgrent();

}

