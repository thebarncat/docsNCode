/* -*- C -*-
 * FILE: "/home/jkipp/c-code/static.c"
 * LAST MODIFICATION: "Fri, 13 Dec 2013 13:33:36 -0500 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

/* good explanation of static funcs:
 * http://codingfreak.blogspot.com/2010/06/static-functions-in-c.html
 */

#include <stdio.h>

void print_plus_one(void)
{
	/* try this with and without static!! */
    static int a=0; /* static storage class! */
    printf("%d\n", a);
    a++;  /* increment the static value */
}

int main(void)
{
    print_plus_one(); /* prints "0" */
    print_plus_one(); /* prints "1" */
    print_plus_one(); /* prints "2" */
    print_plus_one(); /* prints "3" */
    print_plus_one(); /* prints "4" */
    return 0;
}
