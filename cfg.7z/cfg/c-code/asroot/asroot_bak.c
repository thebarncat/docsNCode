#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <grp.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>

void  execute(char *cmd, char **argv)
{
	pid_t pid;
	int status;

	if ( (pid = fork()) < 0) {
    	perror("fork error");
		exit(1);
	}
	else if (pid == 0) {        /* child */
		if (execvp(cmd, argv) < 0) {
			perror("*** ERROR: exec failed");
			exit(1);
		}
	}
    /* parent: suspend calling proc until child exits or status change (by a signal) */
     if ( (pid = waitpid(pid, &status, 0)) < 0)
		perror("waitpid error");
   
	 /* while (wait(&status) != pid)       wait for completion  
		;
	*/
}

int main( int argc, char *argv[] ) 
{
	if (argc < 2) {
        printf("USAGE : asroot <cmd> \n");
        exit(EXIT_FAILURE);
    }
   
 	uid_t  uid;
	int    UnixAdmin=0;  /* boolean */
	char *user;
	
	/* get  current user info */
	uid = getuid();
	user = getenv("LOGNAME"); 

   /* skip over prog name(argv[0]) and get cmd and args to pass to exec */
	char *cmd = *++argv;

	/* iterate thru unixadm grp and make sure user is one */
	char *ux_grp = "unixadm";
    struct group *group;
    char **members;

	/* get unix grp name info struct */
    group = getgrnam(ux_grp);
    if (group == NULL) {
		printf("get groups failed: is there unixadm grp on this host?\n");
		exit(EXIT_FAILURE);
	}

	/* gr_mem is a list of pointers to the individual member names */
    members = group->gr_mem;
    while (*members) {
         if (strcmp (*members, user ) == 0)  {
            UnixAdmin=1;
         }
        members++;
    }

	/* if user is a unix admin, proceed */
	if (UnixAdmin || uid == 0)
	{
		/* seteuid probably not needed */
		if ( setuid(0) == -1 && (seteuid(0) == -1) ) {
			perror("setuid failed");
			exit(1);
		}

		 execute(cmd, argv);

		/* log cmd run as root */
		openlog("asroot", LOG_PID, LOG_AUTH);
		syslog(LOG_ALERT, "User:%s Successfully Ran Command: %s",user,cmd);
		closelog();
	}
	else
	{
		/* Log the attempt and denial to execute "Command" to syslog */
		openlog("asroot", LOG_PID, LOG_AUTH);
		syslog(LOG_ALERT, "User:%s Denied to run Command: %s",user,cmd);
		printf("User:%s Denied to run Command: %s\n",user,cmd);
		closelog();
    }

    exit(0);
}
