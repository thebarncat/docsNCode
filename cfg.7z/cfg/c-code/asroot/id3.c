/* -*- C -*-
 * FILE: "/home/jkipp/c-code/asroot/id3.c"
 * LAST MODIFICATION: "Tue, 03 Jun 2014 09:03:25 -0400 (jkipp)"
 * (C) 2014 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

// works as gid_t or int, they are the same
static char *print_group(gid_t gid)
{
	char *grp_name;
	struct group *grp = NULL;
	grp = getgrgid(gid);
	if (grp == NULL) {
		warn("cannot find name for group ID %u", gid);
		exit(EXIT_FAILURE);
	}
	 grp_name = grp->gr_name;
	 return grp_name;
}

int main(int argc, char *argv[])
{
	gid_t gid = 989;
	char *gname;
	//print_group(gid);
	gname = print_group(gid);
	printf("%s",gname);
	putchar('\n');
	exit(0);
}


