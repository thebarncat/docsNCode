/* -*- C -*-
 * FILE: "/home/jkipp/c-code/asroot/id2.c"
 * LAST MODIFICATION: "Fri, 09 May 2014 14:44:45 -0400 (jkipp)"
 * (C) 2014 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <err.h>


/* Print the name or value of group ID GID. */
static char *print_group(gid_t gid)
{
	char *grp_name;
	struct group *grp = NULL;
	grp = getgrgid(gid);
	if (grp == NULL) {
		warn("cannot find name for group ID %u", gid);
		exit(EXIT_FAILURE);
	}
	 grp_name = grp->gr_name;
	 printf("%s", grp_name);
	 return grp_name;
}

static int xgetgroups(int *n_groups, gid_t ** groups)
{
	int max_n_groups;
	int ng;
	gid_t *g;

	/* Add 1 just in case max_n_groups is zero.  */
	g = (gid_t *) malloc(max_n_groups * sizeof(gid_t) + 1);
	ng = getgroups(max_n_groups, g);

	if (ng < 0) {
		warn("cannot get supplemental group list");
		free(groups);
		exit(EXIT_FAILURE);
	}
	*n_groups = ng;
	*groups = g;
}

/* Print all of the distinct groups the user is in. */
int main(int argc, char *argv[])
{
	int n_groups = 0;
	gid_t *groups;
	int i;

	xgetgroups(&n_groups, &groups);

	for (i = 0; i < n_groups; i++)
		if (groups[i] != getgid() && groups[i] != getegid()) {
			putchar(' ');
			print_group(groups[i]);
			//gname = print_group(groups[i]);
			//printf("%s",gname);
		}

	free(groups);
	putchar('\n');
	exit(0);
}


