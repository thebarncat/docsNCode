/********************************************************************
***  This program allows the user to run commands as root.        ***
***  Usage :    asroot <command>                                  ***
***                                                               ***
********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <grp.h>

int main ( int argc, char *argv[] ) 
{
   if (argc < 2) {
        printf("USAGE : asroot <cmd> \n");
        exit(EXIT_FAILURE);
    }
   
   uid_t 	uid;
   uid_t 	euid;
   gid_t	gid;
   int      i;
   
   int		UnixAdmin=0;  /* Is unix admin 0 or 1 */
   int		UnixGID=989;
	
   char cmd[256] = "\0";
   char *user;
   /* get the id and group info for user */
   uid = getuid();
   gid = getgid();
   euid = geteuid(); 
   user = getenv("LOGNAME"); 

  /* Build cmd into a string from argument list array*/
  for (i=1; i<argc; i++)
        {
        strcat(cmd,argv[i]);  
        strcat(cmd," ");  
        }

  /* Get the groups the user belongs to. set mem buf to GROUPS_MAX  def */
  gid_t *groups;
  int max;
  int ngroups;
  max = sysconf(_SC_NGROUPS_MAX) + 1; 
  groups = (gid_t *)malloc(max *sizeof(gid_t));
  ngroups = getgroups(max, groups);
  if (ngroups == -1) {
	  printf("getgroups failed\n");
	  free(groups);
      exit(EXIT_FAILURE);
  }

  /* Check to see if the user has permission to run asroot */
  for (i=0; i < ngroups; i++)
	{
	if (groups[i] == UnixGID)
            UnixAdmin=1;
    }

   if (UnixAdmin || uid == 0)
   {
	   if ( setuid(0) == -1 && (seteuid(0) == -1) )
		   printf ("setuid failed\n");
		
     	system(cmd);

   		/* log cmd run as root */
   		openlog("asroot", LOG_PID, LOG_AUTH);
   		syslog(LOG_ALERT, "User:%s Successfully Ran Command: %s",user,cmd);
   		closelog();
   }
   else
   {
  		/* Log the attempt and denial to execute "Command" to syslog */
	    openlog("asroot", LOG_PID, LOG_AUTH);
        syslog(LOG_ALERT, "User:%s Denied to run Command: %s",user,cmd);
	    printf("User:%s Denied to run Command: %s\n",user,cmd);
	    closelog();
    }


  free(groups);
  return 0;
  
}
