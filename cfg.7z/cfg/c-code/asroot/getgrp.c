
#include <sys/types.h>          /* UNIX types      POSIX */
#include <grp.h>                /* UNIX groups     POSIX */
#include <stdlib.h>             /* Standard Lib    C89   */
#include <unistd.h>             /* UNIX std stf    POSIX */
#include <stdio.h>              /* I/O lib         C89   */
#include <sys/param.h>          /* UNIX Params     ????  */
#include <errno.h>              /* error stf       POSIX */

int main(int argc, char *argv[]) {
  int numGroups, i;
  long ngroups_max; 
  gid_t *gidList;
  struct group *grEnt;

  ngroups_max = sysconf(_SC_NGROUPS_MAX);
  gidList = (gid_t *)malloc(sizeof(gid_t)*ngroups_max);
  numGroups = getgroups(ngroups_max, gidList);

    printf("The group ID list: ");
    for(i=0; i<numGroups; i++) {
      printf("%i ", gidList[i]);
    } /* end for */
    printf("\n");
    /* Convert the group IDs into group names. */
    printf("The group name list: ");
    for(i=0;i<numGroups;i++) {
      if((grEnt = getgrgid(gidList[i])) == NULL) {
        printf("??? ");
      } else {
        printf("%s ", grEnt->gr_name);
      } /* end if/else */
    } /* end for */
    printf("\n");

  return 0;
} 
