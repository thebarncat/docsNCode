/********************************************************************
***  This program allows the user to run commands as root.        ***
***  Usage :    asroot <command>                                  ***
***                                                               ***
********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <grp.h>

/*
static char *print_group(gid_t gid)
{
    char *grp_name;
    struct group *grp = NULL;
    grp = getgrgid(gid);
    if (grp == NULL) {
		warn("cannot find name for group ID %u", gid);
		exit(EXIT_FAILURE);
	}
	//grp_name = grp->gr_name;
	//return grp_name;
	printf("%s", grp->gr_name);
}
*/

int main ( int argc, char *argv[] ) 
{
  int   i;
  gid_t *groups;
  long max;
  int ngroups;
  max = sysconf(_SC_NGROUPS_MAX) + 1; 
  groups = (gid_t *)malloc(max *sizeof(gid_t));
  ngroups = getgroups(max,groups);
  if (ngroups == -1) {
	  printf("getgroups failed\n");
      exit(EXIT_FAILURE);
  }

  struct group *grp;
  char *ux_grp;
  for (i=0; i < ngroups; i++) {
		//printf("%i:", groups[i]);
		grp = getgrgid(groups[i]);
		//ux_grp = grp->gr_name;
		if ( strcmp(grp->gr_name,"unixadm") == 0 && groups[i] == 989 )
			ux_grp = "unixadm";
		if ( strcmp(grp->gr_name,"unix") == 0 && groups[i] == 208 )
			ux_grp = "unix";
		//printf("%s ", grp->gr_name);
		//print_group(groups[i]);
    }

  	ux_grp = "unixy";
  	printf("%s\n",ux_grp);
  	
	 if ( strcmp(ux_grp,"unixadm") !=0 && strcmp(ux_grp,"unix") !=0)  {
		printf("bad groups\n");
		exit(EXIT_FAILURE);
	}
		printf("set to go\n");
}





