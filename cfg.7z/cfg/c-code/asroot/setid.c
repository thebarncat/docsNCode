#include <stdio.h> 
#include <unistd.h> 

/* run this as root or make setuid */

int main () 

{
	printf ( "uid=%d euid=%d\n", (int) getuid(), (int) geteuid() ); 
		if ( setuid(0) == -1 && (seteuid(0) == -1) ) {
		error("setuid failed");
	}
	printf ("uid=%d euid=%d\n", (int) getuid(), (int) geteuid() ); 
  return 0; 
} 
