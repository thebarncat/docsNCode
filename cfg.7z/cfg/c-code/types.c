/* -*- C -*-
 * FILE: "/home/jkipp/c-code/types.c"
 * LAST MODIFICATION: "Tue, 25 Jun 2013 09:37:09 -0400 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdio.h>

char castit( int i ) {
	/* typecast to char */
	return (char)i;
}

int main(void)
{
	// shows chr is just an it. int i='0'; is the same as: int i= 48; (ASCII for the 0 char)
	//int i = 48;
	//char a = 0;
	int i; char ch = 'A'; i = ch;
	printf ("ASCII code of %c is %d\n",ch,i);

	typedef float real;
	real r1 = 4.57;
    printf("%.2f\n", r1);

	char c = '4';
    printf("char is %c\n", c);
	if (c >= '0' && c <= '9')
		   c - '0'; /* get numeric value of digit */
    printf("numeric value is %d\n", c);

	/* cast operator */
	float f;
	/* 10 converted to float before the division */
	f=(float)10/3;
    printf("%.2f\n", f);

	int d = 65;
	char ch1;
	ch1 = castit(d);
	printf("ascii code: %c\n", ch1);

	/* some hexy stuff */
	int type =  0x0010;
	int flags = type & 0xFF;
	printf("%d\n", flags);
	printf("%#x ", flags);

}
