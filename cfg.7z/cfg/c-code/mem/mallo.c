/* -*- C -*-
 * FILE: "/home/jkipp/c-code/mem/mallo.c"
 * LAST MODIFICATION: "Wed, 19 Dec 2012 16:47:47 -0500 (jkipp)"
 * $Id:$
 */

#include <stdio.h>

int main()
{
		int *p;
		/* returns the location of the beginning of the allocated mem */
	    if ( (p = (int *)malloc(sizeof(int)) )  == NULL)
			{
				printf("ERROR: Out of memory\n");
	    		return 1;
			}
		printf("we put the memory here: 0x%x\n", &p);
		free(p);
		return 0;
}

