
#include <stdio.h>

#define MEM_SIZE 120*1024*1024
#define NPAGES MEM_SIZE/4096

main(int argc, char **argv)
{
        int32 i;

        char *buf_base, *buf;
        buf_base = (char *) malloc( (uint)MEM_SIZE );
        if (buf_base==NULL)
        {
                printf("Error- Cannot malloc memory");
                exit(1);
        }
        buf=buf_base;
        printf("Allocating memory\n");
        while(1)
        {
                buf=buf_base;
                for (i=0;i< NPAGES-1;i++) {
                        buf+=4096;
                        *buf = 'a'; /* touch the page */
                }
                sleep(7);
        }
}

