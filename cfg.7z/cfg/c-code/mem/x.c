#include <stdio.h>
#include <string.h>

int main(void)
{
  char XArray[80];
  int x;

  /* set all 80 bytes of XArray to 0x83(ascii X)*/
  memset(XArray, 0x83, sizeof(XArray)); 
  /* print 40 lines of x's */
  for (x = 0; x < 40; x++)  
	  /* tricky printf: the * modifier specifys the min width
	   * of the string should be the firs param in the arg
	   * so will print 39 - x spaces. the ".*s" means to at most
	   * 'expr' from the string(so it prints 'expr' x's
	   * so as x changes value for each * iteration, then 
	   * the placement of spaces and x's changes
	   */
	   printf("%*s%.*s\n", 39 - x, "", ((x + 1) << 1) - 1, XArray);

  return 0;
}


