#include <stdio.h>
#include <string.h>

#define MAX 128

int main () {
	char numbers[] = "12345678";
	char LUN[32] = "hdiskpower5";
	/*strcpy(SIZE,"1024");*/
    strncat(LUN,"foobari",4); 
    printf("%s\n", LUN);
}

/* The strcat() and strncat() functions return a pointer to the resulting string dest. */

