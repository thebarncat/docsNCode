#include <stdio.h>

/* copy string a to string b */

/* Since these are globally defined, they are initialized to all '\0's */
char strA[16] = "My string";
char strB[16];

int main()
{
	char *pA;     /* a pointer to type character */
    char *pB;     /* another pointer to type character */
    pA = strA;    /* point pA at string A */
    pB = strB;    /* point pB at string B */
    while(*pA != '\0')   /* line A (see text) */
    {
        *pB++ = *pA++;   /* line B (see text) */
    }
    *pB = '\0';          /* line C (see text) */
    puts(strB);          /* show strB on screen */
    return 0;
}

/* condensed version */
char *my_strcpy(char *destination, char *source)
{
	char *p = destination;
    while (*source != '\0')
    {
    	*p++ = *source++;
	}
	*p = '\0';
	return destination;
}   

/* run it 
int main(void)
{
	my_strcpy(strB,strA);
	puts(strB);
}
*/


