
/* GOOD doc: http://c-faq.com/~scs/cclass/krnotes/sx8e.html */
/* LIST of C string funcs: * http://faculty.edcc.edu/paul.bladek/c_string_functions.htm */

#include <stdio.h>
#include <string.h>

char *myfunc(char *dst) {
	char *tmp = "foo";
	 strcpy(dst,tmp);
	 return dst;
}

int main () {
	// assigns  pointer to the charr array. can reassign to point elsewhere, but as long as it points to the 
	// string literal, we can't modify the characters it points to  meaning, we cant say: pmessage[0] = 'N'
	// pass to a function like this:  foo(&buf)
	char *str = "xxxxYYYYY";
	printf("%d\n", sizeof(str));
    printf("%d\n", strlen(str));
    // print to STDOUT
	write(1,str,strlen(str));
	/* point to a different char array */
	str  = "now is the time";
	printf("\n%s\n", str);

	/* initialize a string of chars to the chr array which may be overwriten with other characters, so we can say: msg[0]='A';  */
	char msg[32] = "blah";
	char buf[64];
	/* see utils.c for more strcpy */ 
	strcpy(buf,msg);
	/* notice the differernce in sizeof than when using a ptr2st. see sizer.c  */
	printf("%d\n", sizeof(buf));
	printf("%s\n", buf);

	/* strncpy scenarios */
	char *src = "baseball hockey football";
	char dest[16];
	int len; len = strlen(dest);
	/* when using sizeof as the size limit, do -1 IF weird stuff happens. see mang page */
	strncpy(dest, src, sizeof(dest)-1);
	printf("%s\n", dest);

	char buf2[32];
	memset(buf2, 'a', sizeof(buf2));
	/* shove as many strings as u want onto buf */
	snprintf(buf, sizeof(buf), "Kazaa: %s%s", buf2, "more");
	puts(buf);

	char st[8];
    char os[8];
	/* use a func to fill the str */
    sprintf(os,myfunc(st));
    printf("%s\n", os);

	/* string compare */
	char cpu[4] = "CPU";
	if (strncmp(cpu,"CPU",4) == 0)
        printf("match\n");

	/* str concat */
	char pidfile[64] = "/var/run/";
	char *name = "foo";
	strcat(pidfile, name);
	printf("%s\n", pidfile);

}

