#include <stdio.h>
#include <string.h>
 
main()
{
	char *p = "MEAS:VOLT?";
	/* Find a character in a string, in this case it will print string up until it finds the char ":" */
	while(( p = strchr( p, ':' )) != NULL )
	{
		printf("Found it here: %s\n", ++p);
	}
}

