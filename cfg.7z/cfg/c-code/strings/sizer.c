#include <stdio.h>
#include <string.h>

main () {
	char *buf = "xxxxxx\n"; 
	/* size in bytes of the array in memory as unsigned int or unsigned long. THIS IS NOT THE LENGTH OF A STRING */
	printf("%d\n", sizeof(buf)); 
	/* char buf[256]; 
	printf("%d\n", sizeof(buf)); // now prints 256 
	strncpy(buf,"hithere", 8);
	// zero out the last element of the buffer
	buffer[sizeof(buffer) - 1] = '\0';
	*/
	if (buf[strlen(buf)] != '\0')			
		puts("has term");
	printf("%d\n", strlen(buf));
	write(1,buf,strlen(buf));
}
 


 
