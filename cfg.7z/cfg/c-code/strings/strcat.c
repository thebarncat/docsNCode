/* -*- C -*-
 * FILE: "/home/jkipp/c-code/strings/strcat.c"
 * LAST MODIFICATION: "Fri, 25 Oct 2013 13:21:25 -0400 (jkipp)"
 * (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <unistd.h>
#include <syslog.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>

int main ( int argc, char *argv[] )
{
	char cmd[256];
	 /*strcat requires cmd to be a string -- i.e. to have a terminating
	 * null. It's purpose is to add one string *after* whatever is in cmd, and
	 * you  don't know what that is, not having put anything there. 
	 * so we need THIS: */
	cmd[0] = 0;

    strcat(cmd,"ls");

    /*cmd[strlen(cmd)-1]='\0'; */
    printf("command: %s",cmd);
    execlp(cmd, cmd, NULL);

}
~     
