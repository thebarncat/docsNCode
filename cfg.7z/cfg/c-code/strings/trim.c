#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/wait.h>

#define iswhite(c)  ((c)== ' ' || (c)=='\t')

/* NOTE: the isspace macro includes new lines and TABs */

/* strip trailing white space */
static char *rtrim2(char *x)
{
	char *y;
    if(!x)
    	return(x);
	/* the value of a ptr is the mem addr of which it points */
	/* a ptr to char stores the length of the array and nul byte + n bytes to store the pointer variable
	 * (where n dependes on the system) */
    y = x + strlen(x)-1;
    while (y >= x && isspace(*y))
    	*y-- = 0; /* skip white space */
	return x;
}

int rtrim(char *string)
{
	int len = strlen(string);
    while (isspace(string[len-1]))
    	len--;
    string[len] = '\0';
    return 0;
}

/* trims leading and trailing spaces and tabs from char array ptrs */
static void skipwhite(char **s)
{
	while(iswhite(**s))
    	(*s)++;
}

/* removes ALL spaces */
void squeeze(char *s)
{
	char *t = s;
	for(;*s;(*s != ' ') ? *t++ = *s++ : *s++)
		continue;
	*t = '\0';
}

/* removes ALL new lines */
int squeeze_nl(char *s)
{
	char *t = s;
	for(;*s;(*s != '\n') ? *t++ = *s++ : *s++)
		continue;
	*t = '\0';
}

/* removes ALL spaces and New lines 
int squeeze(char *s) {
	char *t = s;
    for(;*s;(!isspace(*s)) ? *t++ = *s++ : *s++)       
    	continue; 
	*t = '\0'; 
} 
*/

/* same as squeeze, using char array method */
int squeeze2(char *s) {
	int i, j;
	for(i = j = 0; s[i] != '\0'; i++)
		if(s[i] != ' ')
			s[j++] = s[i];
	s[j] = '\0';
}

int main ()
{
	/*
	rtrim(foo);
	printf("%s\n",foo);
	*/
	//char blah[32] = "squeezn hi there    \n \t \t \n";
	char blah[32] = "squee zn hi    there ";
	//char blar[16] = "fuki8\0";
	squeeze(blah);
	printf("%s\n",blah);
	/*
	char foo[16] = "arfuk  ";
	rtrim(foo);
	printf("%s\n",foo);
	char *line =  "\tbl ah";
	skipwhite(&line);
	printf("%s\n",line);
	*/
}

