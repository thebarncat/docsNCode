/* -*- C -*-
 * FILE: "/home/jkipp/c-code/strings/strlen.c"
 * LAST MODIFICATION: "Fri, 20 Dec 2013 15:53:00 -0500 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

int strlen(char s[])
{
	int i;
	while (s[i] != '\0')
	++i;
	return i;
}

