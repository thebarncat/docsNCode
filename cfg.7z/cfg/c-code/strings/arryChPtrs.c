#include <stdio.h>
#include <string.h>

#define MAX 128

/* https://groups.google.com/forum/#!topic/comp.lang.c/w1xdPAGneDk */

int main () {
	/*  array of ptrs to char(char *):  each element is of type char* and points to  first character of string*/
	/*  can incrment the array via it's value like:  *(name + i) or *(args+1) = ""xxx""; */
	char *a[10];
	/* another way: */
	char *name[] = { "one","two" };
	char *p;
	p = &name[0]; /* or simply p = name; */
	printf("%s\n", *++p);  

}


