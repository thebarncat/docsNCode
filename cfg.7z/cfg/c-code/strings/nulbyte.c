#include <stdio.h>      
#include <stdlib.h>
#include <string.h>

#define MESSAGE  "YOW"


/* null bytes added to the end dont matter */
int main () {
    char msg[20] = "foo";
	int n;
    /*msg[7] = '\0';
     msg[8] = '\0';
	*/
	/* strlen does not include the  terminating ‘\0’ */
    printf("len of MSG is %i\n", strlen(MESSAGE));
    /*if add null bytes before end it overwrites chars u  may want */
    printf("last char is %c\n",msg[strlen(msg)-1]); 
	/* char nul_byte = '\0'; 
	* puts adds a nl char 
	* puts(&nul_byte);
	*/

    /* msg[6] = '\0'; */
    /* printf("%i\n", strlen(msg)+1);  */
}

/*
char str[4];
str[0] = 'f';
str[1] = 'o';
str[2] = 'o';
str[3] = '\0';
*/
