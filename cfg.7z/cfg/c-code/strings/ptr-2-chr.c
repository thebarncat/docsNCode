#include <stdio.h>

/* array of pointers to char */

int main(int argc, char *argv[])
{
        char * args[3];
        int i,j;
        
        args[0] = "tiger";
        args[1] = "dog";
        args[2] = "horse";

        i = 0;
        
        while (i < 3)
        {
                j = 0;
                while (args[i][j++] != 0x00);
				/* do this to not count the null char: 
				 * j = -1;
				 * while (args[i][++j] != 0x00);
				 */
                printf("%s has length %d\n",args[i++],j);
        }

        return 0;
}
