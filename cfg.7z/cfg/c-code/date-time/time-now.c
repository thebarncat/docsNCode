/* -*- C -*-
 * FILE: "/home/jkipp/c-code/date-time/time-now.c"
 * LAST MODIFICATION: "Wed, 18 Apr 2012 12:18:03 -0400 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 256
 
int main(void)
{
	int hour, min;
	char buffer[SIZE];
	time_t now = time(0);
	/* print the time formatted */
	printf("%s", ctime(&now));
	struct tm *local;
	local = localtime(&now);
	hour = local->tm_hour;
	min = local->tm_min;
	printf("time: %i:%i\n",hour,min); 
	strftime(buffer, SIZE, "%I:%M %p\n", local);
	printf("%s", buffer);
}

