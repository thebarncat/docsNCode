#include <stdio.h>
#include <time.h>

int main(int argc, char *argv[]){
	int days;
    /* give command arg for the number of days you want to see ahead */
	days = atoi(argv[1]);
	/* initiate the time struct, which holds all of the date for these funcs */
    struct tm* t1;
   /* used to measure time in seconds */
    time_t t2;
    char* t3;
	/* returns the time in seconds since the epoch, stores the value in t2 */
    time(&t2); 
	/* converts the value returned from time() into broken down UTC time  stores in struct t1 */
    t1 = gmtime(&t2);
    /* converts the broken down time in the struct pointed to by t1 into readable string  stores the result in t3 */
    t3 = asctime(t1);
   /* printf("Now  = %s\n", t3?t3:"--"); */
    printf("Now  = %s", t3); 

    /* add some number to current day of month */
    t1->tm_mday += days;
    /* converts the value of t1 back to the value since the epoch */
    t2 = mktime(t1);
    t1 = gmtime(&t2);
        
    t3 = asctime(t1);
    printf("Now + %i days = %s\n", days, t3);

    return 0;
}



