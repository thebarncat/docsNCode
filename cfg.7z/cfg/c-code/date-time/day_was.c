/* -*- C -*-
 * FILE: "/home/jkipp/c-code/date-time/day_was.c"
 * LAST MODIFICATION: "Fri, 13 Apr 2012 09:09:59 -0400 (jkipp)"
 * $Id:$
 */

#include <stdio.h>
#include <time.h>

/* create an array of ptr to char */
static char  *dow[] = 
{
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday",
	"Unknown"
};

#define YEAR 2002
#define MONTH 10
#define DAY 9

int main(void)
{
	/* declare the time struct found in time.h */
	struct tm tm;

	/* fill the struct */
	tm.tm_year = YEAR - 1900;
	tm.tm_mon = MONTH -1;
	tm.tm_mday = DAY;
	tm.tm_hour = 0;
	tm.tm_min = 0;
	tm.tm_sec = 0;
	tm.tm_isdst = -1;

	/* mktime func converts the filled time struct 
	 * into time since the epoch. func returns specified time
	 * since the epoch or -1 on error */
	if (mktime(&tm) == -1)
	{
		/* unknown day */
		tm.tm_wday = 7;
	}

	/* print what day it was on that date */
	printf("%d-%02d-%02d is (or was) a %s!\n", tm.tm_year + 1900,
		tm.tm_mon + 1, tm.tm_mday, dow[tm.tm_wday]);

	return 0;
};
