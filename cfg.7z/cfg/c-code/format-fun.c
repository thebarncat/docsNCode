/* -*- C -*-
 * FILE: "/home/jkipp/c-code/format-fun.c"
 * LAST MODIFICATION: "Wed, 12 Dec 2012 14:49:55 -0500 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 */

#include <stdio.h>

int main(int argc, char *argv[])
{
	/*  the * modifier says the min with of the string should be the first param of the arg list. print "a" with a min of 4 char width */
	printf("%*s\n", 4, "a");

	char string[32];
	char *a = "stringer";
	char *b = "bellll";
	/* .n means print at most n chars */
	sprintf(string, "%s %.4s", a,b);
	printf("%s\n", string);

}
