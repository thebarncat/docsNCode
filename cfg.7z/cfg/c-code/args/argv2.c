/* -*- C -*-
 * FILE: "/home/jkipp/c-code/args/argv2.c"
 * LAST MODIFICATION: "Tue, 30 Sep 2014 15:56:59 -0400 (jkipp)"
 * (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdio.h>

int main(int argc, char **argv)
{
	int   i;
    char *cmd = *++argv;  

	/*
	for (i = 0; i < argc; i++)      
     	printf("argv[%d]: %s\n", i, argv[i]);
	*/

	printf("cmd is: %s\n", cmd); 
	printf("current argv is: %s\n", *argv);
	printf("argv[1] is %s\n", argv[1]);
}

