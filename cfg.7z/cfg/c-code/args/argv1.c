/* -*- C -*-
 * FILE: "/home/jkipp/c-code/args/argv1.c"
 * LAST MODIFICATION: "Wed, 01 Oct 2014 10:57:48 -0400 (jkipp)"
 * (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
 *
 *  reference the getopt() function for more
 */

#include <stdio.h>

/* argc is the count of args */
int main(int argc, char *argv[])
{
	printf ("program name:  %s\n",argv[0]);

	//increment the argv pointer. move argv past the prog name
	int   i;
	*++argv;
	for (i = 0; i < argc-1; ++i)
    	printf("argv[%d]: %s\n", i, argv[i]);
		
	printf("current arg %s\n", *argv);	

}
