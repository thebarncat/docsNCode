#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>

int main ( int argc, char *argv[] ) 
{
   if (argc < 2) {
        printf("USAGE : asroot <cmd> \n");
        exit(EXIT_FAILURE);
    }

   /* move pointer past the prog name, so first arg is the command (argv[1]) */
	*++argv;

	/* so at this poing argv[] contains what we want, the command itself and the args */
	if (execvp(*argv, argv) < 0) {     
		printf("*** ERROR: exec failed\n");
		exit(1);
	}

}
