chr=$HOME/testroot
mkdir -p $chr
mkdir -p $chr/{bin,lib,lib64}
# copy the needed binaries for our env
cp -v /bin/{bash,touch,ls,rm} $chr/bin
# make a list of the deps for our command
list="$(ldd /bin/bash | egrep -o '/lib.*\.[0-9]')"
# copy them the parents option make sure they go in the correct dir
for i in $list; do cp -v --parents "$i" "${chr}"; done
# repeat these commands from the needed binaries
# set the root chroot env, and specifies the shell.
sudo chroot $chr /bin/bash

