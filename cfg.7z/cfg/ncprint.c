/* -*- C -*-
 * FILE: "/home/jkipp/ncprint.c"
 * LAST MODIFICATION: "Wed, 25 Sep 2013 14:40:34 -0400 (jkipp)"
 * (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
 * $Id:$
 */

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#define NCPRINT_STDOUT           0x0001
#define NCPRINT_NONEWLINE        0x0002  /* don't print a newline at the end */
#define NCPRINT_NOFMT            0x0040  /* do not interpret format strings */


void ncprint(int type, const char *fmt, ...)
{
  int flags = type & 0xFF;
  char buf[512], newline = '\n';
  FILE *fstream = stderr;		/* output stream */
/* good link here: http://linuxprograms.wordpress.com/tag/va_list/ */
  va_list args;

  /* clear the flags section so we obtain the pure command */
  type &= ~0xFF;

  /* known flags */
  if (flags & NCPRINT_STDOUT)
    fstream = stdout;
  if (flags & NCPRINT_NONEWLINE)
    newline = 0;

  /* from now on, it's very probable that we will need the string formatted,
     so unless we have the NOFMT flag, resolve it */
  if (!(flags & NCPRINT_NOFMT)) {
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
  }
  else {
    strncpy(buf, fmt, sizeof(buf));
    buf[sizeof(buf) - 1] = 0;
  }

  switch (type) {
  case NCPRINT_NORMAL:
    fprintf(fstream, "%s%c", buf, newline);
    break;
#ifdef DEBUG
  case NCPRINT_DEBUG:
    if (opt_debug)
      fprintf(fstream, "%s%c", buf, newline);
    else
      return;		/* other flags has no effect with this flag */
    break;
  case NCPRINT_DEBUG_V:
    if (opt_debug)
      fprintf(fstream, "(debug) %s%c", buf, newline);
    else
      return;		/* other flags has no effect with this flag */
    break;
#endif
  case NCPRINT_ERROR:
    fprintf(fstream, "%s %s%c", _("Error:"), buf, newline);
    break;
  case NCPRINT_WARNING:
    fprintf(fstream, "%s %s%c", _("Warning:"), buf, newline);
    break;
  case NCPRINT_NOTICE:
    fprintf(fstream, "%s %s%c", _("Notice:"), buf, newline);
    break;
  }
  /* discard unknown types */

  /* post-output effects flags */
  if (flags & NCPRINT_DELAY)
    usleep(NCPRINT_WAITTIME);

  /* now resolve the EXIT flag. If this was a verbosity message but we don't
     have the required level, exit anyway. */
  if (flags & NCPRINT_EXIT)
    exit(EXIT_FAILURE);
}

