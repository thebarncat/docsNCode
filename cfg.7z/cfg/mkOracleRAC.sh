#!/bin/ksh
######################################################################################
#
# Description:          #       This script will take a standard AIX LPAR, & configure it for Oracle RAC.
#
#######################################################################################
 
#Allow Large page support for Oracle User
/usr/bin/chuser capabilities=CAP_NUMA_ATTACH,CAP_BYPASS_RAC_VMM,CAP_PROPAGATE oracle
/usr/bin/chuser capabilities=CAP_NUMA_ATTACH,CAP_BYPASS_RAC_VMM,CAP_PROPAGATE grid
 
#Sys0
/usr/sbin/chdev -l sys0 -a ncargs='1024' -P
 
#FC tunables.
lsdev |grep fcs |awk '{print $1}' |while read _FC
do
   chdev -l $_FC -a max_xfer_size=0x100000 -P
   chdev -l $_FC -a num_cmd_elems=400 -P
done
 
#Validate VIP entry in hosts file.
if [[ "grep -vip /etc/hosts |wc -l" -lt 2 ]];then
   echo "Warning vip private addresses are not defined in /etc/hosts"
fi
 
#Check, & Enable iocp
if [[ -n `lsdev |grep iocp0 |grep Defined` ]]
then
   chdev -l iocp0 -P -a autoconfig='available'
fi
 
#Network
no -p -o tcp_ephemeral_low=9000
no -p -o tcp_ephemeral_high=65500
no -p -o udp_ephemeral_low=9000
no -p -o udp_ephemeral_high=65500
no –p –o tcp_fastlo=1
ifconfig -a |grep UP |grep -v ^lo |awk -F: '{print $1}' |while read _NIC
do
   chdev -l $_NIC -a tcp_nodelay=1
done
 
#Disk
lspv |awk '{print $1}' |while read _DISK
do
   chdev -l $_DISK -a reserve_policy=no_reserve
done
 
#Change the default xntpd  startsrc arguments to "-x" for Oracle RAC; Verify xntpd is running;Verify startup in rc.tcpip
chsys -s xntpd -a "-x"
if ps -afe |grep "xntpd"|grep -v grep 
then
   stopsrc -s xntpd
   sleep 3
   startsrc -s xntpd
else
   startsrc -s xntpd; 
fi
 
if grep "#start /usr/sbin/xntpd" /etc/rc.tcpip
then
   cp /etc/rc.tcpip /etc/rc.tcpip.`date +%m_%d_%y`
   perl -i -p -e 's/#start \/usr\/sbin\/xntpd/start \/usr\/sbin\/xntpd/g;' /etc/rc.tcpip
   diff /etc/rc.tcpip /etc/rc.tcpip.`date +%m_%d_%y`
fi
 
