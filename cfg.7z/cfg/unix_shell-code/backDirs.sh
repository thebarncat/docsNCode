# script will tar and move specified dir to back themn up

if [ $# -eq 0 ]; then
	echo "Usage: backDirs.sh dir1 dir2 ...." 1>&2
	exit 1
fi

if [ ! -d  $* ]; then
	echo "Usage: backDirs.sh dir1 dir2 ...." 1>&2
	exit 1
fi

DATE=`date +%m%d%y`

for i in "$@"
do
	tar -zcvf /usr/backip/$i-"${DATE}.tgz" $i
done

