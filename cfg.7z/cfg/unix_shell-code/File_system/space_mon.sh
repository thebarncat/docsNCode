#!/bin/ksh 

#=================================================================================

function main
{
for host in "$@"                  
do
	
	if   [ $host == "ftbea01a" ]; then
	   fs="$a"
	elif [ $host == "ftbeb01a" ]; then
	   fs="$b"
	elif [ $host == "ftbec01a" ]; then
	   fs="$c"
	elif [ $host == "ftbed01a" ]; then
	   fs="$d"
	else
	   fs="$e"
	fi

        for x in $fs
		do

		cap=`rsh $host /bin/df -k $x | /bin/nawk '{print $5}' | sed -e 's#%##' -e 's/capacity//'`
		/bin/sleep 2
  
      		if [ "$cap" -gt "$alert" ]; then
            		 #rsh $1 /bin/ls -l `/bin/find $x -type f -size +20480k -print 2>/dev/null` | /bin/sort +2 > $tmpfile
            		 rsh $host /bin/find $x -type f -size +61440k -print 2>/dev/null | /bin/sort +2 > $tmpfile
			 /bin/sleep 2 
			 /bin/mailx -s " $x on $host is $cap % full: $event " $mailto < $tmpfile
        	fi

	done

done
/bin/rm -f $tmpfile
}

# set global vars

# change to the alert you want
alert=80
event=`/bin/date '+DATE: %m/%d/%y TIME: %H:%M:%S'`
tmpfile=~/spacechk.$$
/bin/touch $tmpfile
mailto="jkipp@exchus"

# file systems to check

a=" /usr
 /dbtmp/tmp
 /var
 /tmp"

b=" /usr
 /dbtmp/tmp
 /var
 /tmp"

c=" /usr
 /dbtmp/tmp
 /var
 /tmp"

d=" /usr
 /dbtmp/tmp
 /var
 /tmp"

e=" /usr
 /dbtmp/tmp
 /var
 /tmp"


# array of the domains

dom[0]="fpbea01a"
dom[1]="fpbeb01a"
dom[2]="fpbec01a"
dom[3]="fpbed01a"
dom[4]="ftbee01a"

# loop thru the domains 

#integer i
#for i in 0 1 2 3 4 
#	main "${dom[$i]}"
#done

main ${dom[*]}


