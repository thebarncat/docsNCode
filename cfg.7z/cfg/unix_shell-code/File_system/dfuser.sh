#!/bin/ksh 
#=================================================================================
#  Display dfuser in a more readable way
#
#=================================================================================

tmp=/dbtmp/tmp/temp.$$
trap "rm -f $tmp" 0 1 2 15

#case `uname -n` in
#  sundbsva|fpbea01a ) dir2grep=' /db|/appl';;
#  sundbsvb|fpbeb01a ) dir2grep=' /db|/appl';;
#  sundbsvc|fpbec01a ) dir2grep='/user|/dbtmp|/db|/appl';;
#  spbe497a|fpbed01a ) dir2grep='/aaa|/crm|/groupsale|/canada|develop|/dbtmp|/oradata|/misc|/acquisition|/user|/appl';;
#  ftbee01a ) dir2grep='/user|/appl';;
#esac

case `uname -n` in
  sundbsva) dir2grep=' /db|/appl';;
  sundbsvb) dir2grep=' /db|/appl';;
  sundbsvc) dir2grep='/user|/dbtmp|/db|/appl';;
  spbe497a) dir2grep='/aaa|/crm|/groupsale|/canada|develop|/dbtmp|/oradata|/misc|/acquisition|/user|/appl';;
  f[pt]be[abcde]01a ) dir2grep='/user|/appl|/db|/home';;
esac

df -k | egrep "$dir2grep" | \
  nawk '
    BEGIN {
      printf( "!!!\n" );
      printf("!!%-30s%10s%10s%10s%10s\n", "File System", "Total(G)", "Used(G)", "Avail(G)", "Avail(%)");
      printf( "!=========================================================\n" );
    }
    {
      printf("%-30s%10.1f%10.1f%10.1f%10.1f%%\n", $6, ($3+$4)/(1024*1024), $3/(1024*1024), $4/(1024*1024), $4/($3+$4)*100 )  ;
      total_used += $3/(1024*1024); 
      total_avail += $4/(1024*1024);
    }
    END {
						total_total = total_used + total_avail;
      printf( "z=========================================================\n" );
      printf("zz%-30s%10.1f%10.1f%10.1f%10.1f%%\n", "Total:", total_total, total_used, total_avail, total_avail/total_total*100 );
      print "zzz";
    }' > $tmp

/bin/sort $tmp | sed 's/^!!*//;s/^zz*//'

