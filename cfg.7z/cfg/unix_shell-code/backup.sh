#!/bin/sh
echo ====== Back-up system ===== /, /home, /var/cvs
# set volume label
# date=$(date --utc +"%Y%m%d%H%M")
date=`date --utc +"%Y%m%d%H%M"`
cdtemp=/home/ftp/cdimage
echo "Clean up $cdtemp"
rm -vrf $cdtemp/*
echo "Start back up >>>"
echo $date >$cdtemp/date
echo "dpkg --get-selection # use --set-selection later to recover"
dpkg --get-selections  | gzip >$cdtemp/dpkg-list.gz
#echo "ls-lR"
#ls -lR  / | gzip >$cdtemp/ls-lR.gz

echo -n 'Back up to image file (i), CD-R (r) or CD-RW (w).  Enter i/r/w: '
read YN
echo
if [ "$YN" = "r" -o "$YN" = "w" -o "$YN" = "i" ];  then
    echo "  Entered $YN"
else
    echo ... Oops! Stop here ; exit 1
fi
echo -n "Are you sure ? (y/n)"
read CNF
if [ ! "$CNF" = "y" ]; then
    exit 1
fi

echo 
echo Start making CD image ...
echo

# create tar file for directory limitted within each file system (-l)
tar -cvzl \
    --exclude='boot' \
    --exclude='bin' \
    --exclude='dev' \
    --exclude='proc' \
    --exclude='sbin' \
    --exclude='lib' \
    --exclude='tmp' \
    --exclude='usr' \
    -f ${cdtemp}/ROOT$date.tar.gz /
tar -cvzl \
    --exclude='ftp' \
    --exclude='Mail' \
    --exclude='.netscape' \
    -f ${cdtemp}/HOME$date.tar.gz /home/
tar -cvzl -f ${cdtemp}/CVS$date.tar.gz /var/cvs/
# create cd image no more -J
mkisofs -v -R -V "BU$date" \
    -o $cdtemp/../cd.img \
    $cdtemp

[ $YN = "i" ] && exit 1

echo
echo Start CD recording ...
echo

if [ $YN = 'w' ]; then
    OPTN="blank=fast"; echo Rewritable!
else
    OPTN=""; echo Recordable!   
fi
echo
exec nice --20 cdrecord -v -eject $OPTN speed=2 dev=0,0  /home/ftp/cd.img

