if df | grep 9[0-9]%; then df | mail -s " FS > 90%" $USER; fi
