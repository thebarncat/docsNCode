#!/bin/sh
# FILE: "C:\CODE\unix_shell\ENV\profile_example.sh"
# LAST MODIFICATION: "Sun, 20 Feb 2005 09:13:07 Eastern Standard Time"
# (C) 2005 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

# some sample /etc/profile ideas

# set prompt color based on user
USER=`whoami`
  if [ $LOGNAME = $USER ] ; then
    COLOUR=44  # blue
  else
    COLOUR=45  # magenta
  fi

  if [ $USER = 'root' ] ; then
    COLOUR=41  # red
    PATH="$PATH:/usr/local/bin" ## <- redhat dosen't have it as default.
  fi

  ESC="\033"
  #STYLE=';1m' # bold; choose which one to use
  STYLE='m' # plain
  PS1="\[$ESC[$COLOUR;37$STYLE\]$USER:\[$ESC[37;40$STYLE\]\w\\$ "
  PS2="> "

# some more ideas

case `$USER` in
    root )
        PS1="\[\033[1;31;40m\][\u]:\w>\[\033[0;37;40m\] " ;;
    Larry )
        PS1="\[\033[1;34;40m\][\u]:\w>\[\033[0;37;40m\] " ;;
    Curly )
        PS1="\[\033[1;32;40m\][\u]:\w>\[\033[0;37;40m\] " ;;
    Moe )
        PS1="\[\033[1;35;40m\][\u]:\w>\[\033[0;37;40m\] " ;;
    * )
        PS1="\[\033[1;32;40m\][\u]:\w>\[\033[0;37;40m\] " ;;




