tar -tvf /home/jkipp > tar_list.out
for FILE in `cat tar_list.out|cut -f6 -d" "`
do
	if [ -f $FILE ]; then
		echo "$FILE exists
		mv $FILE ${FILE}.orig
	fi
done

