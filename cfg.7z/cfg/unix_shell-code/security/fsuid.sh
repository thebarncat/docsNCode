#!/bin/bash

who=`whoami`
db_file=$HOME/fsuid.db
md5_file=$HOME/fsuid.md5

if [ $who  != "root" ]; then
    echo -e "You need to be root to run $0"
    exit 0
fi

case $1 in
    
    -f) 
	if [ -x /bin/find -o -x /usr/bin/find ]; then
	    find / -type f \( -perm -04000 -o -perm -02000 \) >$db_file
	else  
	    echo -e "You don't have find that dosen't look right"
	fi
	;;
   -fs) 	
	if [ -x /bin/find -o -x /usr/bin/find ]; then
	    find / -type f \( -perm -04000 -o -perm -02000 \)| xargs md5sum  >$db_file
	else  
	    echo -e "You don't have find that dosen't look right"
	fi
	;;
    -d) 
	if [ -x /bin/find -o -x /usr/bin/find ]; then
	    find / -type d \( -perm -04000 -o -perm -02000 \) >$db_file
	else  
	    echo -e "You don't have find that dosen't look right"
	fi
	;;
    -fds) 	
	if [ -x /bin/find -o -x /usr/bin/find ]; then
	    find / -type f \( -perm -04000 -o -perm -02000 \) >$db_file
	    find / -type f \( -perm -04000 -o -perm -02000 \)| xargs md5sum  >$db_file
	    find / -type d \( -perm -04000 -o -perm -02000 \) >$db_file
	else  
	    echo -e "You don't have find that dosen't look right"
	fi
	;;

     *) 
      echo -e "Usage:- $0 [flags]
	    -f	Scans Filesystem for suid sgid files.
	    -fs Scans Filesystem and generates md5 signatures for each file
	    -d	Scans Filesystem for suid sgid directorys."
        ;;
esac
