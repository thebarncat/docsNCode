#!/bin/sh

DATE=`date +%m%d%y`

if [ -f "/var/log/messages" ]; then
   cp /var/log/messages /var/log/messages-backup
	if [ -f "/var/log/messages-backup" ]; then
           mv /var/log/messages-backup /var/log/messages-"${DATE}"
     fi
fi
# clear the messages file after archiving         
cat /dev/null > /var/log/messages
    
