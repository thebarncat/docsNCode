#!/bin/bash

#TEXT=scripting_for_phun
TEXT=123456789ABCDEF
echo ${TEXT:10:3}
echo ${TEXT:10}
echo ${EXT:-foo}
E=ha
echo ${E=foo}
