#!/usr/bin/perl -w
# FILE: "/home/jkipp/limit.pl"
# LAST MODIFICATION: "Wed, 27 Apr 2016 13:30:35 -0400 (jkipp)"
# (C) 2015 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$


$count = 0;
@filedescriptors;

while ($count <= 1024) {
	$FILE = $count;
    open $FILE, ">", "junk/example$count" or die "\n\n FDs: $count $!";
    push(@filedescriptors, $FILE);
    $count ++;
}
