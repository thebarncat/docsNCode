#!/usr/bin/perl -w
# FILE: "/home/jkipp/trace.pl"
# LAST MODIFICATION: "Fri, 15 Dec 2000 13:43:03 -0500 (jj)"
# (C) 2000 by Jim Kipp, <jkipp@neptuna.com>
# $Id:$
use POSIX qw(strftime);
use strict;

my $target = shift || die "$0 targetip\n";
my @trace = `traceroute $target`;
my $date = strftime "%d%m%y", localtime;
my $i = 1;


open(FILE, ">>$ENV{HOME}/$target\.$date") or die "Can't open trace_results:$!";

print FILE "---------------------------\n";	
print FILE "$target\n";
print FILE "---------------------------\n";	

foreach (@trace) {
	chomp;
       	if (/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/g) {
		print FILE "$i => $1\n";
		++$i;
	}
	
}

close FILE or die "Failed to close trace_results:$!";
