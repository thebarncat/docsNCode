#!/db/app/perl/bin/perl -w

use Socket;
use POSIX qw(:sys_wait_h);
use Fcntl qw(F_GETFL F_SETFL O_NONBLOCK);

# $| = 1;
$port = 6668;
# $maxlen = 4096;

socket(S, AF_INET, SOCK_STREAM, getprotobyname('tcp')) ||
	die "\n $0: Cannot create socket: $!";
setsockopt(S, SOL_SOCKET, SO_REUSEADDR, 1);

($name,$addr) = (gethostbyname("spas099a"))[0,4];
# unpack the address from net byte order to ascii 
$ip = sprintf("%s", join('.', unpack('C4', $addr)) );
bind(S, sockaddr_in($port, inet_aton($ip)) ) || die "Cannot bind .. $!\n";

listen(S,5)  || die "$0: Cannot listen: $!\n";
print "Waiting for connections on  \"$name\" and at address: $ip:$port\n";

#  accept returns packed client addr
while ($remote = accept(C,S) )  {
		my ($rport,$raddr) = sockaddr_in($remote);
		# inet_ntoa converts 32 bit raw addr to dotted quad ascii
	   	print "Connection from ", inet_ntoa($raddr), " at port: $rport\n";

	    # $pid = fork();  die "Couldn't fork: $!" unless defined $pid;
	    if ($pid = fork) { # parent
			close(C); # close client handle. no use to parent
            # wait for ANY child proc to die and do a non blocking wait for pending zombies
			waitpid( -1, &WNOHANG );
			next; # ready for another client 
	    } else  {
			# child
			die "can't fork: $!" unless defined $pid;
			close(S); # close parent sock. no use to child
			print C "Connected to $ip:$port ";

			# turn of buffering for now
		    my $ofh = select C;
	  		$| = 1;
	  		select $ofh;

			# Header protocol, read the file name from the client packed as
			# NET byte order (always 4 bytes) 
			sysread(C, $l, 4) or die "couldn't read header: $!";
			# unpack the actual length of the file name 
			$hlength = unpack("N", $l);
		    sysread(C, $fname, $hlength )  or die "couldn't read: $!";  

			open (F, ">$fname") or die "couldn't open it: $!";
			print "recieving file: $fname\n";
			while ( sysread(C, $buf, 128) ) {
				print F $buf;
			}
			close F;
			print "Recieved file\n";
    		exit; 
		}
}


