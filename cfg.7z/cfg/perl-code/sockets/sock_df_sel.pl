#!/db/app/perl/bin/perl

use Socket;
use POSIX qw(:sys_wait_h);
# use Fcntl qw(F_GETFL F_SETFL O_NONBLOCK);

$port = 6668;

socket(S, AF_INET, SOCK_STREAM, getprotobyname('tcp')) ||
	die "\n $0: Cannot create socket: $!";

($name,$addr) = (gethostbyname("spas099a"))[0,4];
# unpack the address from net byte order to ascii, 
$ip = sprintf("%s", join('.', unpack('C4', $addr)) );
bind(S, sockaddr_in($port, inet_aton($ip)) ) || die "Cannot bind .. $!\n";
setsockopt(S, SOL_SOCKET, SO_REUSEADDR, 1 );

listen(S,5)  || die "Cannot listen: $!";

select(S); $|= 1; select(stdout);

*****TODO: PLAY WITH USING FNCTL TO DISABLE BLOCKING

while (1)  {
	my $interval = 5;
	my $rin = '';
	vec( $rin, fileno(S), 1 ) = 1;
	# **** WAIT for data to become avaiable on the socket return every 5 secs and wait again****
	my $nfound = select( $rin, undef, undef, $interval );
	print "Waiting for data from client\n";
	# *** IMPORTANT: we do the accept after select tells us there is data on the socket *** 
	# *** IF there is data avail on the socket (asynchronous event) return from select immediately 
	if ($nfound) {
	    $remote = accept(C,S) or die "error in accept: $!";
		my ($rport,$raddr) = sockaddr_in($remote);
		print "Connection from ", inet_ntoa($raddr), " at port: $rport\n";
        my $data = <C>;
        print $data;
    }

}






