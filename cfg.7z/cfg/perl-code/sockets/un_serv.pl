#!/appl1/perl/bin/perl

use IO::Socket;
use POSIX ":sys_wait_h";   # (for WNOHANG)

# example using unix domain socks
# unix domain socks are just files, once the file is created as a socket, any client can
# interact with it

my $sockname = "/tmp/unixsockd.sock";

start_daemon();

sub start_daemon {
    my $pid;
    if ($pid = fork()) {  
	# wait for child proc to die and do a non blocking wait for pending zombies
        waitpid($pid, 0);
    } else {
        if ($pid = fork()) { exit; }
        $0 = "unixsockd: accepting connections on $sockname";  
        service_clients( get_sock() );       # wait for incoming requests
    }
}

sub get_sock {
    unlink $sockname;
    my $sock = IO::Socket::UNIX->new(
                   Local  => $sockname,
                   Type   => SOCK_STREAM,
                   Listen => SOMAXCONN,
               ) or die "$0: error starting daemon on '$sockname': $@\n";
    # you might want to change permissions and ownership, e.g.:
    #chmod 0600, $sockname;
    #chown scalar getpwnam('nobody'), 0, $sockname;
    return $sock;
}

sub service_clients {
    my $sock = shift;
    $SIG{CHLD} = \&reaper;
    
    my $client;
    while ( $client = $sock->accept() ) {
        # fork yet another process to prevent buffer deadlock. one proc writes to
	# the sock, the other reads the deamons response
        my $pid = fork();  die "Cannot fork\n" unless defined $pid;
        if ($pid) {                   # parent
            close $client;            # no use to parent
            next;                     # be ready for another client
        }
        # child
        close $sock;                  # no use to child
        process_requests($client);
        exit;                         # terminate child
    }
}

sub process_requests {
    my $client = shift;
    $0 = "unixsockd: handling requests...";  
    # read from client until empty line which causes it to close connection
    while ( my $line = <$client> ) {  # read line from socket
        last if $line =~ /^\s$/;      # exit on empty line
        chomp $line;
        # put some more useful code here to read each line or whatever...
        printf $client "%s: %s, handled by PID %d\n",
                       scalar localtime(time), $line, $$;
                                      # return something to client
    }
}

sub reaper { 
    while (waitpid(-1,WNOHANG) > 0) {}
    $SIG{CHLD} = \&reaper; 
}


