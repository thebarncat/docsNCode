#!/db/app/perl/bin/perl -w
# FILE: "reverse.pl"
# LAST MODIFICATION: "Tue, 16 Mar 2004 13:59:57 Eastern Standard Time"
#  2004 by Jim Kipp, <james.kipp@mbna.com>
# $Id:$

# do a reverse lookup on the ip addr in the logs, in case
# we need to resolve host name

use Socket;
use constant TIMEOUT => 2;
$SIG{ALRM} = sub {die "timeout"};
 
 while (<>) {
     # the access logs start with an IP, capture it and run the lookup
     # on it
     s/^(\S+)/lookup($1)/e;
     print;
 }
 
sub lookup {
     my $ip = shift;
     return $ip unless $ip=~/\d+\.\d+\.\d+\.\d+/;
     eval {
     	alarm(TIMEOUT);
     	@i = gethostbyaddr(pack('C4',split('\.',$ip)),2);
     	alarm(0);
     };
     return $i[0] || $ip;
}

