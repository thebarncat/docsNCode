#!/usr/bin/perl 
# FILE: "U:\My Documents\scripts\perl\sysAdmin\Unix\Socket_Net\ftp\ftp_mget.pl"
# LAST MODIFICATION: "Mon, 24 Jun 2002 15:27:27 Eastern Daylight Time"
# (C) 2002 by Jim Kipp, <james.kipp@mbna.com>
# $Id:$
use strict;
use Net::FTP;

# change these vars to your stuff 
my $user = $ENV{'USER'};
my $pword = 'XXXXXXXXXX';
my $host = 'somehost';
my $remoteDir = "/home/$user/bin";
my $localDir = "/tmp/$user/somewhere";
my $pattern = qr/\.pl$/;
my @keepers;

#  main section

# make sure we have something in localDir that is really there
unless ( -d $localDir ) {
    mkdir $localDir or die "Unable to mkdir $localDir :$!\n";
}
chdir($localDir) or die "Unable to chdir to $localDir :$!\n";

my $ftp = Net::FTP->new($host, Debug => 0);
$ftp->login($user,$pword);
$ftp->cwd($remDir);

my @list = $ftp->ls ; # this command is like ls -l;

# find the files that matched the pattern we are looking for
for (@list) {
	#print "we see: <$_>\n"; # uncomment this to dir contents scroll by
    push(@keepers, $_) if (/$pattern/);
}

# get the files we want
foreach my $file (@keepers) {
    print "fetching: $file\n";
    $ftp->get($file);
}

$ftp->quit; 


