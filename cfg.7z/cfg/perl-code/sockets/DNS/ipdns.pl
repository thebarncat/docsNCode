#!/usr/bin/perl -w 
# FILE: "G:\CODE\Perl\sockets\DNS\ipdns.pl"
# LAST MODIFICATION: "Tue, 03 Mar 2009 09:13:59 Eastern Standard Time"

use strict; 
use Getopt::Std;
use Socket; 

my (%opts, $name, $ipaddr, %hosts);
getopts('hl:i:f:',\%opts);

if (defined($opts{i})) {
	my $ip = $opts{i};
	get_ip(\$ip);

	
} elsif (defined($opts{f} && $opts{l})) {
	my $file = $opts{f};
	my $log  = $opts{l};
	pfile_log(\$file, \$log);

	
} elsif (defined($opts{f})) {
	my $file = $opts{f};
	parse_file(\$file);
} elsif (defined($opts{h})) { usage(); } 
else { usage(); }
	
sub pfile_log {
     my ($file, $log) = @_;
     open(FILE, "$$file") or die "Can't open $$file:$!";
     my @file = <FILE>;
     close FILE or warn("File $$file empty.\n"),return unless @file;
     open(LOG, ">$$log") or die "Can't open $$log for writing:$!";
     foreach (@file) {
          chomp;
          if (/( \d{1,3} \. \d{1,3} \. \d{1,3} \. \d{1,3}  )/x) {
          $name = gethostbyaddr(inet_aton($1), AF_INET);
          $hosts{$name}->{$1}++;
          } 
        
    }
     foreach $name (keys %hosts) {
          foreach $ipaddr (keys %{$hosts{$name}} ) {
	  	if ($hosts{$name}->{$ipaddr} > 1) {
             		print LOG "$name => $ipaddr repeated $hosts{$name}->{$ipaddr} times\n";
          	} else {
			print LOG "$name => $ipaddr \n";
		}
	}
     }
     close LOG or die "Can't close $$log:$!";
}

sub parse_file {
	my ($file) = @_;
	chomp($$file);
	open(FILE, "$$file") or die "Can't open $$file:$!" if -e $$file;
	my @file = <FILE>;
	close FILE or die "Can't close $$file:$!";
	get_ip(\@file);
}


sub get_ip {
	my ($ips) = @_; 
	if (ref($ips) eq "SCALAR") {
		if ($$ips =~ /( \d{1,3} \. \d{1,3} \. \d{1,3} \. \d{1,3}  )/x) {
			$name = gethostbyaddr(inet_aton($$ips), AF_INET); 
			print  "$name => ",$$ips, "\n" if (defined($name && $$ips));
					
			
					
		} else {
 			die "$$ips is not a valid ip\n";
		}

	} elsif (ref($ips) eq "ARRAY") {
		foreach(@$ips) {
			chomp;
			if (/( \d{1,3} \. \d{1,3} \. \d{1,3} \. \d{1,3} ) /gx) { 
				$name = gethostbyaddr(inet_aton($1), AF_INET); 
				print STDERR  "$name => ",$1, "\n" if (defined($name && $_));
			} else { 
				next; 
			}
		}
	} else { die "not avalid reference was passed to get_ip\n"; }
}

sub usage {

print <<"EOF"

	Usage:- ipdns [ options ] [ argument or file ]

	-i <127.0.0.1>	Tries to resolve the ip given at the command.
	-f <file>	Tries to resolve all the ip's found in file.
	-l 		This option logs the result to a file, it needs 
			the -f flag for it to work.
	-h		This help message

	EXAMPLES:

	ipdns -i 200.10.11.12              will try to find the hostname for
					   this ip. Note only one ip can be
					   given if you pass more than one the
					   first one will be used the rest will
					   be ignore.
	
	ipdns -f ip_file		   Will grab all the ip found in
					   ip_file and will try to resolve
					   each and every one of them.

	ipdns -f ip_file -l ip_log_file    Will save the output in ip_log_file.
					   Note: -l flag only works if the 
					   -f flag was used.

	ipdns -h 			   This help message.
					
EOF

}
__END__
