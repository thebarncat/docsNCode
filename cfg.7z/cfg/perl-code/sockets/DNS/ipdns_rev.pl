 
sub pfile_log {
my @table;
my %counter;

my ($file, $log) = @_;
open(FILE, "$$file") or die "Can't open $$file:$!"; 
open(LOG, ">$$log") or die "Can't open $$log: $!";
while (<FILE>) {
			
	if (/( \d{1,3} \. \d{1,3} \. \d{1,3} \. \d {1,3}  )/x) {
  		my $name = gethostbyaddr(inet_aton($1), AF_INET);
   		print LOG "$name => ",$1, "\n"; 
			while(<LOG>) {
      			my ($name,$ip) = split /\s*=>\s*/;
        		push @table,[$name,$ip] if ! $counter{$name}++;
   					for (@table) {
        				print "$ip -> $host". ($counter{$name} > 1 ? " x $counter{$name}" : "")."\n";
 				
				
				}							
  			}
		}
			close LOG or die "Can't close $$log:$!";
	}
		close FILE or warn("File $$file empty.\n"),return unless @file; 
}
 

