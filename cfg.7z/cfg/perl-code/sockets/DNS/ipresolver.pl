# FILE: "/home/jj/code/ipresolver.pl"
# LAST MODIFICATION: "Fri, 20 Oct 2000 09:38:12 +0000 (jj)"
# (C) 2000 by Juan Fuentes, <juan.fuentes@codetel.net.do>
# $Id:$
# usage: ipresolver.pl /var/log/messages. 

use strict; 
use Socket; 

while (<>) {
	next if /^\s*$/; 
	#  (/ ([\d.]+)\.) # altenative to regex below
	if (/((\d){1,3}\.(\d){1,3}\.(\d){1,3}\.(\d){1,3})/g) { 
		my $ip = $1; 
		my $name = gethostbyaddr(inet_aton($ip), AF_INET); 
		print  "$name => ",$ip, "\n"; 
	} else { 
		next; 
	}
}

__END__
