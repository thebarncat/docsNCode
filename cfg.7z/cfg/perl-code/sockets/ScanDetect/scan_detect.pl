#!/usr/bin/perl

use Socket;
use IO::Socket;
use Time::localtime;

# some env vars
# all of these variables (except for date_time) should be defined in config file
$logdir = '$ENV{HOME}/detect_logs/'
$nmapbin = '/usr/local/sbin/nmap'
$quesobin = '/usr/local/sbin/queso'
$tcpportscan= '1';
$getos= '1';
$lowport= '10';
$highport= '100';
$date_time = ctime();


# default port will be a low numbered port, but user can enter other ports to listen on
#  run on port 54 , this is a random port, but better to use a low port
($port) = @ARGV;
$port = 54 unless $port;
$tcpport = $port;

print "Watching for portscans on port(s) $port...\n";

# turn on the flusher :-)
$| = 1;

foreach(@ports) {
	$pid$_ = fork();
#code to handle the forks and what to do, etc...




#ignore child processes to prevent zombies
# got this little gem from perlmonks, easier then calling a anon sub
# is there a better way to do this ?? Please jump in here Juan
#
# juan: No this work fine, i do prefer to use a anon sub, and the posix module, but
# this works.
# jim: how would I use theh posix module ?? give me example
# juan: here it goes:
# use POSIX 'WNOHANG' # WNOHANG is the one for avoiding zombies.
#### *** LOL !!! WNOHANG !! Sounds like Chinese food ..LOL !!!

## Yep!!! but that's what it's used in C.

# $SIG{CHLD} = \&ZOMBIE_KILLER

### ***** Isn't is supposed to be a anon sub ?
## No not really.

#sub ZOMBIE_KILLER
# {   
#     #WNOHANG means to return immediately if no child has exited.
#    while ((waitpid(-1, WNOHANG)) >0 ){} 
     
#     #reset the sig for the next child to die;
#     $SIG{CHLD} = \&ZOMBIE_KILLER;
# }
# Hope that's clear.

### *** Clear as mud ..:-)
## Huh??? Need more explaining :-).
### No , that is a joke !!!

# kill the ZOMBIES
$SIG{CHLD} = 'IGNORE'

# create the socket, bind to it, setup que of 5
$sock = new IO::Socket::INET (LocalHost => 'my_server',
                              LocalPort => $port,
                              Proto     => 'tcp',
                              Listen    => 5,
                              Reuse     => 1,
                             );
die "Could not connect: $!" unless $sock;

#wait for client_connection
while ( $client_connection = $sock->accept)
{   
    # fork the sonofbitch
    die "Can't fork: $!" unless defined ($child = fork());
	
	# now all the books and examples use $child == 0 , why 0, shouldn't it be 1 ??
	# juan: no 1 == the parent, 0 == child -1 == failed.
	# jim: Oh, I see. These are the args to fork(), duh, i should have looked in the nutshell book !!
    if ($child == 0) {
    
        #close the child's socket, don't need it now
        $sock->close;

	# Call the routine to get the info on who might be scanning us
	# Was not sure if this will fly, but seems cleaner
	# juan: it might work, but i guess this can be dependednt on how the module 
	# handle this.
	# jim: would it be better to put the child process code here ?
	# juan: no i don't think so.
	##Jim:  run it and see what happens, I can't run it here ..
	## Ok i will.
	### jim: any luck ??
	

        detect($client_connection);
               
        exit 0;
   } 
    else
   {  
    
        #close the client_connection
        $client_connection->close();
        
    }
     

}


sub detect
{
	my $connection = shift;
	
	# get the addr of who is scanning
	my $addr = $socket->peerhost;
	my $host = gethostbyaddr($addr, AF_INET); 
	
	# use STDOUT for now to print the scan detection
	select(STDOUT);
	print "\n*************************[ PORT SCAN DETECTED ]******************\n";
	print "Scan was attempted by IP Address $addr\n";
	print "By host $host\n";

	$filename = '$logdir/ $addr;

	if ($tcpportscan eq 'Y'){
		# Scan the f*** who scanned us
		# juan: i don't know if we should add this, it's feel like retaliation,
		# and can bring major problems, as some nim wits could abuse this.
		# jim: yes, I thought of that, we really don't need info on the ports of the attacker, 
		# I will take out
		# juan: ok.
		$tcpscanresults = `$nmapbin -sS -p $lowport-$highport $addr`;
		chomp($tcpscanresults);
	}

	#jim: what about this, I would like to know what kind of box is scanning us
	# juan: well the problem with this is that, if the ip is not spoofed, the attacker
	# will know we are on to him, and well hell can break loose, i'm thinking if the 
	# attacker is of the new breed of script kiddies, he might try a DDoS attack on the machine
	# so we might need to take a more inteligent approach, like using nmap really slow scan facility 
	# so that the kiddie doesn't noticed, but that's quite slow!!!, the other is to do a traceroute, and 
	# stop a few hops before hiting the kiddie, that way we could get quite a few interesting things, like
	# exactly how many hops he is, if he is in the local network, or outside etc....
	## Jim: this is where queso may be of use. From what i read, it is used as an alernative to nmap 
	## when you need good spoofing. Of course we can just leave all of this out and leave 
	## it up to the user to investigate further.
	### That's a possibility.

	
	if ($getos eq 'Y'){
		$getosresults = `$nmapbin -sS -O $addr`;
		chomp $getosresults;
	}
	open(SCAN, ">> $filename");
		print SCAN "$date_time : Scan Detected from $host\n";
		print SCAN "*********************************\n";
		if ($getos eq '1'){
			print SCAN "Operating System Name:$getosresults\n";
		}
		if ($tcpportscan eq 'Y') {
			print SCAN "TCP Port Scan Report:\n";
			print SCAN "$tcpscanresults\n";
		}
	close(SCAN);

	# back to STDOUT
	print "Info about scand detect logged to $filename\n";
				

        # Close the socket connection
	$connection->close();
	print "Connection to $addr Closed.\n";
	print "---------------------------------------------------\n";
	print "\nContinuing to listen on port $tcpport ...\n";
        exit(0);

}	
