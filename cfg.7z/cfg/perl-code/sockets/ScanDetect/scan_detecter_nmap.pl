#!/usr/bin/perl

use Socket;
use IO::Socket;
use Time::localtime;

# some env vars
# all of these variables (except for date_time) should be defined in config file
$logdir = '$ENV{HOME}/detect_logs/'
$nmapbin = '/usr/local/sbin/nmap'
$quesobin = '/usr/local/sbin/queso'
$tcpportscan= '1';
$getos= '1';
$lowport= '10';
$highport= '100';
$date_time = ctime();


# default port will be a low numbered port, but user can enter other ports to listen on
#  run on port 54 , this is a random port, but better to use a low port
#($port) = @ARGV;

# CAN THIS BE DEFINED IN THE CONFIG FILE ?
@ports = (54,1700,5000);
# $port = 54 unless $port;
# $tcpport = $port;

print "Watching for portscans on port(s) $port[0] , $port[1] , $port[2] ...\n";

# turn on the flusher :-)
$| = 1;

foreach $port (@ports) 
{
	listen($port);
}

sub listen
{
	my $port = shift;
	
	# kill the ZOMBIES
	$SIG{CHLD} = 'IGNORE';

	# create the socket, bind to it, setup que of 5
	$sock = new IO::Socket::INET (LocalHost => 'my_server',
                              	  LocalPort => $port,
                                  Proto     => 'tcp',
                                  Listen    => 5,
                                  Reuse     => 1,
                                  );
	die "Could not connect: $!" unless $sock;

	#wait for client_connection
	while ( $client_connection = $sock->accept)
	{   
    # fork the sonofbitch
    die "Can't fork: $!" unless defined ($child = fork());
		
    if ($child == 0) {
    
        #close the child's socket, don't need it now
        $sock->close;

	# Call the routine to get the info on who might be scanning us
	
        detect($client_connection);         
        exit 0;
   } 
    else
   {  
        #close the client_connection
        $client_connection->close();
        
    }
     
}


sub detect
{
	my $connection = shift;
	
	# get the addr of who is scanning
	my $addr = $socket->peerhost;
	my $host = gethostbyaddr($addr, AF_INET); 
	
	# use STDOUT for now to print the scan detection
	select(STDOUT);
	print "\n*************************[ PORT SCAN DETECTED ]******************\n";
	print "Scan was attempted by IP Address $addr\n";
	print "By host $host\n";

	$filename = '$logdir/ $addr;

	if ($tcpportscan eq 'Y'){
		# Scan the f*** who scanned us
		
		$tcpscanresults = `$nmapbin -sS -p $lowport-$highport $addr`;
		chomp($tcpscanresults);
	}

		
	if ($getos eq 'Y'){
		$getosresults = `$nmapbin -sS -O $addr`;
		chomp $getosresults;
	}
	open(SCAN, ">> $filename");
		print SCAN "$date_time : Scan Detected from $host\n";
		print SCAN "*********************************\n";
		if ($getos eq '1'){
			print SCAN "Operating System Name:$getosresults\n";
		}
		if ($tcpportscan eq 'Y') {
			print SCAN "TCP Port Scan Report:\n";
			print SCAN "$tcpscanresults\n";
		}
	close(SCAN);

	# back to STDOUT
	print "Info about scand detect logged to $filename\n";
				

        # Close the socket connection
	$connection->close();
	print "Connection to $addr Closed.\n";
	print "---------------------------------------------------\n";
	print "\nContinuing to listen on port $tcpport ...\n";
        exit(0);

}	

## TO DO:
# File locking protection - pg 420 Camel Book
# Better process managnement
# Taint Checking

