#!/usr/bin/perl

use Socket;
use IO::Socket;
use Time::localtime;

# some env vars
# logdir variable to be defined in the config file
$logdir = '$ENV{HOME}/detect_logs/'
$date_time = ctime();


# default port will be a low numbered port, but user can enter other ports to listen on
# run on port 54 , this is a random port, but better to use a low port

# CAN THIS BE DEFINED IN THE CONFIG FILE ?
@ports = (54,1700,5000);

print "Watching for portscans on ports $port[0] , $port[1] , $port[2] ...\n";

# turn on the flusher :-)
$| = 1;

foreach $port (@ports) 
{
	listen($port);
}

sub listen
{
	my $port = shift;
	
	# kill the ZOMBIES
	$SIG{CHLD} = 'IGNORE';

	# create the socket, bind to it, setup que of 5
	$sock = new IO::Socket::INET (LocalHost => 'my_server',
                              	  LocalPort => $port,
                                  Proto     => 'tcp',
                                  Listen    => 5,
                                  Reuse     => 1,
                                  );
	die "Could not connect: $!" unless $sock;

	#wait for client_connection
	while ( $client_connection = $sock->accept)
	{   
    # fork the sonofbitch
    die "Can't fork: $!" unless defined ($child = fork());
		
    if ($child == 0) {
    
        #close the child's socket, don't need it now
        $sock->close;
	
        detect($client_connection);         
        exit 0;
   } 
    else
   {  
        #close the client_connection
        $client_connection->close();
        
    }
     
}


sub detect
{
	my $connection = shift;
	
	# took out the scan back and OS detection stuff
	
	my $addr = $socket->peerhost;
	my $host = gethostbyaddr($addr, AF_INET); 
	
	# use STDOUT for now to print the scan detection
	select(STDOUT);
	print "\n*************************[ PORT SCAN DETECTED ]******************\n";
	print "Scan was attempted by IP Address $addr\n";
	print "By host $host\n";

	$filename = '$logdir/ $addr;
		
	}
	open(SCAN, ">> $filename");
		print SCAN "$date_time : Scan Detected from $host\n";
		print SCAN "The Ip address of this host is $addr \n";
		print SCAN "*********************************\n";
		
	close(SCAN);

	# back to STDOUT
	print "Info about scan detect logged to $filename\n";
	# close the connection from attacker	
	$connection->close();
	print "Connection to $addr Closed.\n";
	print "---------------------------------------------------\n";
	print "\nContinuing to listen for scans ...\n";
        exit(0);

}	

## TO DO in a later phase:
# File locking protection - pg 420 Camel Book
# Better process managnement
# Taint Checking

