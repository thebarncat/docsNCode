#!/usr/bin/perl
#
# J-Dog's Scan Detector 1.1
#
# Version 1.1 is almost identical to version 1.0B except that in 1.1 I 
# finally got around to building some 'reation' systems which gathers 
# data on the host who is scanning you. This script uses 'nmap' 'queso'
# and 'nmbnamex'. What this script does upon connection to a port (you
# specify which port to listen on) it grabs the IP and tries to resolve
# it to a hostname and then performs a tcp connect() scan on it (yap, 
# that's visible, so watchout =P ) and then tries to grab the NetBIOS 
# name of the scanner and then uses queso to resolve the Ip to an OS.
#
# This update as with the original script was written as a kind of 
# 'gee I am bored.. lets write something' project and while it can be
# used to detect portscans, it is not meant as a SERIOUS portscan 
# detection util. 
#
# I am not interested in making this script really any more user friendly 
# or cleaning up my code, or debugging this too any further since I do 
# not consider this tool to be a serious portscan detection util, but 
# rather a POC program that I wrote to satisfy some boredom.
#
# If you have any questions or comments, please direct them to
# J-Dog@Resentment.org
#
##########################################################################

# Declare some paths
# This is the only things you should need to change..
$logdir='/misc/personal/scandetector2/scans/';
$nmapbin='/Toolz/bin/nmap';
$nmbnamexbin='/usr/bin/nmbnamex';
$quesobin='/Toolz/bin/queso';
$tcpportscan='Y';
$getnbname='Y';
$getos='Y';
$lowport='10';
$highport='30';

# Define some shit for use later
$nmapgarbagecut='|grep -v ports|grep -v Warning|grep -v nmap';
$nmbgarbagecut='|grep -v netbios';
$quesogarbagecut='|tr -s \' \'';
$divider='-------------------------------------------------------------------';
$scantime=`date`;
chomp $scantime;

# Declare that we are going to be using the Sockets Library
use Socket;

# Read in the port number we are to use (if specified)
($port) = @ARGV;

# If no port specified, run on 54 (keep low to catch even small scans)
$port = 54 unless $port;
$tcpport = $port;

# Tell the administrator what port we are listening on
print "Watching for portscans on port $port...\n";

# setup the socket and bind it
socket(S,AF_INET,SOCK_STREAM,$protocol) || die "socket : $!";
$sockaddr = 'S n a4 x8';
$this = pack($sockaddr, AF_INET, $port, "\0\0\0\0");
bind(S, $this) || die "bind : $!";

# Queue up to 10 connections until they can be processed
listen(S,10) || die "listen: $!";


# Select S temporarily as the default output channel, turn on
# autoflushing, then select standard output again.
select(S);
$| = 1;
select(STDOUT);

# Create connections as clients "arrive".  $con maintains the connection
# number of the last client

for ($connection_number = 1; ; $connection_number++) {
        # grab that users info
        ($addr = accept(NS,S)) || die $!;

        # Temporarily set default output to the handle NS
        select(NS);
        $| = 1;
        select(STDOUT);

        # Fork this sukka
        if (($child = fork()) == 0) {   

                # unpack the information returned by 'accept' to get some
                # (readable) information about the client and print it 
                ($af,$port, $inetaddr) = unpack($sockaddr, $addr);
                @inetaddr = unpack('C4', $inetaddr);
                $hostname = gethostbyaddr ($inetaddr, 2);
                ($ip1,$ip2,$ip3,$ip4) = @inetaddr;
                $ipaddress = "$ip1.$ip2.$ip3.$ip4";
 
                # Tell the user we have a portscan attempt
                print "\n--------------=[ PORTSCAN DETECTED ]=--------------\n";
                print "Portscan attempt # $connection_number\n";
                print "IP Address is $ipaddress\n";
                print "Hostname is $hostname\n";

				if ($getnbname eq 'Y' || $getos eq 'Y' || $tcpportscan eq 'Y') {

					$filename=$logdir  . 'info-' . $ipaddress;
					if ($tcpportscan eq 'Y'){
						#print "TCP Scanning $ipaddress from $lowport to $highport\n";
						$tcpscanresults=`$nmapbin -t -p $lowport-$highport $ipaddress $nmapgarbagecut`;
					}
					if ($getnbname eq 'Y'){
		                #print "Getting NetBIOS name from $ipaddress\n";
						$nmbnamexresults=`$nmbnamexbin $ipaddress $nmbgarbagecut`;
					}
					if ($getos eq 'Y'){
		                #print "Getting OS ID from $ipaddress\n";
						$quesoresults=`$quesobin $ipaddress`;
						($junk,$goodshit) = split/\*/,$quesoresults;
						$quesoresults=$goodshit;
						chomp $quesoresults;
					}
					open(SCAN, ">> $filename");
						print SCAN "$scantime - Scan Detected $hostname\n";
						print SCAN "$divider\n";
							if ($getnbname eq 'Y'){
								print SCAN "NETBIOS Name (if any): $nmbnamexresults";
							}
							if ($getos eq 'Y'){
								print SCAN "Operating System Name:$quesoresults\n";
							}
							if ($tcpportscan eq 'Y' && $tcpscanresults ne ''){
								print SCAN "TCP Port Scan Details:";
								print SCAN "$tcpscanresults";
							}
					close(SCAN);
				print "Info about host logged to $filename\n";
				}

				close(SCAN);
                # If you want to let them now they were detected,
                # just uncomment the line below.
                # print NS "Portscan detected from you at $ipaddress - $hostname$

                # Close the socket connection
                close(NS);
				print "Connection to $ipaddress Closed.\n";
				print "---------------------------------------------------\n";
				print "\nContinuing to listen on port $tcpport ...\n";
                exit;
     }
}

