#!/usr/bin/perl 
# FILE: "G:\CODE\Perl\sockets\HTTP\link_grabber.pl"
# LAST MODIFICATION: "Thu, 23 Jun 2011 13:08:54 Eastern Daylight Time"

use Socket;

$EOL = "\015\012";
$host =  "www.hbo.com";
$url =  "http://www.hbo.com/billmaher/new_rules/";
$port = 80;
$dir = 'c:/media/newrules/';

($parts) = parse_URL($url);
$path = $$parts[3];

## Call our socket subroutine
$err = ConnectSocket('SOCK', $host, $port);
if ($err) { die($err); }

## Send the HTTP request
print SOCK "GET $path HTTP/1.0$EOL$EOL";

## read in large chunks of 1000 or fewer bytes, so quicker.
while(sysread(SOCK, $buff, 1024)) {
	$result = $result . $buff;
}

close SOCK;

## Clean up the line endings
$result =~ s/\r\n?/\n/g;

# gather the links to the files we want to grab
@links = grab_urls($result, ('a', 'href'));
foreach (@links) {
	next unless /200[1-9]/;
	push (@newrules, $_);
}

foreach $link (@newrules) {
    ($fname = $link) =~ s/\/.*\///;
	$full = $dir.$fname;
	# must reconnect at each link, since http is stateless
    $err = ConnectSocket('SOCK', $host, $port); if ($err) { die($err); }
	print SOCK "GET $link HTTP/1.0$EOL$EOL";
	unless ( -f $full ) { open (F, ">$full") or die "can't open: $!"; }
	while ($line = <SOCK>) { print F "$line" }
	close F; close SOCK;
	sleep 1;
}

sub ConnectSocket {
    my $proto = getprotobyname('tcp');
	my($sock, $hostname, $port) = @_;
	my ($ipaddr, $sockaddr);
	$ipaddr = inet_aton($hostname) || return "addr err";
	$sockaddr = sockaddr_in($port , $ipaddr) || return "sock err"; ## never errs
	socket($sock, PF_INET, SOCK_STREAM, $proto) || return "sock err";
	connect($sock, $sockaddr) || return "con err";
	select($sock); $| = 1; select(STDOUT);
	return 0;
}

sub parse_URL {
  # put URL into variable
  my ($URL) = @_;
  # attempt to parse into: into ($scheme, $hostname, $port, $path).  Return undef if it didn't parse.
  (my @parsed =$URL =~ m@(\w+)://([^/:]+)(:\d*)?([^#]*)@) || return undef;
  # remove colon from port number, even if it wasn't specified in the URL
  if (defined $parsed[2]) {
    $parsed[2]=~ s/^://;
  }
  # the path is "/" if one wasn't specified
  $parsed[3]='/' if ($parsed[0]=~/http/i && (length $parsed[3])==0);
  # if port number was specified, we're done
  return @parsed if (defined $parsed[2]);
  # otherwise, assume port 80, and then we're done.
  $parsed[2] = 80;
 
  \@parsed;
}


sub grab_urls {
  my($data, %tags) = @_;
  my @urls;
 
  # while there are HTML tags
  skip_others: while ($data =~ s/<([^>]*)>//)  {
 
    my $in_brackets=$1;
    my $key;
 
    foreach $key (keys %tags) {
 
      if ($in_brackets =~ /^\s*$key\s+/i) {     # if tag matches, try parms
        if ($in_brackets =~ /\s+$tags{$key}\s*=\s*"([^"]*)"/i) {
          my $link=$1;
          $link =~ s/[\n\r]//g;  # kill newlines,returns anywhere in url
          push (@urls, $link);
          next skip_others;
        } 
        # handle case when url isn't in quotes (ie: <a href=thing>)
        elsif ($in_brackets =~ /\s+$tags{$key}\s*=\s*([^\s]+)/i) {
          my $link=$1;
          $link =~ s/[\n\r]//g;  # kill newlines,returns anywhere in url
          push (@urls, $link);
          next skip_others;
        }    
      }       # if tag matches
    }         # foreach tag
  }           # while there are brackets

  @urls;
}

