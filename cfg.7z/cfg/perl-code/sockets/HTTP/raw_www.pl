#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\sockets\HTTP\raw_www.pl"
# LAST MODIFICATION: "Thu, 23 Jun 2011 13:06:30 Eastern Daylight Time"

use Socket;

print "Content-type: text/html\n\n";

$port = 80;
$host ='www.neptuna.org';
$proto = getprotobyname('tcp');
$addr = gethostbyname("$host"); 
$ip = join(".", unpack("C4", $addr));

my $dest = sockaddr_in($port, inet_aton($ip));
socket(S,AF_INET,SOCK_STREAM, $proto) or die "coudn't create sock: $!";  
connect(S,$dest) or die "can't connect: $!\n"; 

select(S); $| = 1; select(STDOUT);

print S "GET / HTTP/1.0\n\n";
print while (<S>);

