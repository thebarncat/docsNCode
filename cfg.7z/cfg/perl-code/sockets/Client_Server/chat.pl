#!/appl/perl5/bin/perl -w

use IO::Socket;
use IO::Select;

$max_msglen = 1024;
$max_clients = 10;
$port = 1234;

$new_client = IO::Socket::INET->new(Proto=>"tcp", LocalPort=>$port, Listen=>$max_clients, Reuse=>1);
$sel = IO::Select->new($new_client);

print "listening at port $port\n";

while (@ready = $sel->can_read) {

 foreach $client (@ready) {

  if ($client == $new_client) {

   $add = $client->accept;
   $sel->add($add);

   $message = "[Welcome user ".$add->peerhost.":".$add->peerport."! You can leave the chat by entering \"quit\" | ".($sel->count - 1)." user(s) online]\n\n";
   sendall($message);

  } else {

   $msg = "";

   $nread = sysread($client, $msg, $max_msglen);
   chop($msg); chop($msg);

   if ($msg eq "quit") {

    $message = "[User ".$client->peerhost.":".$client->peerport." left | ".($sel->count - 2)." user(s) online]\n\n";
    sendall($message);

    $sel->remove($client);
    close $client;

   } elsif ($nread) {

    $message = "[".$client->peerhost.":".$client->peerport."] ".$msg."\n";
    sendall($message);

   }

  }
 }
}

sub sendall {
 my ($msg) = @_;
 foreach ($sel->can_write) { syswrite($_, $msg, length($msg)) }
}

sub getmsg {
 my ($handle) = @_;
 my $msg = "";

 do {
  $nread = sysread($handle, $in, 1024);
  $msg .= $in;
 } while ($nread > 0);

 return($msg);
}
