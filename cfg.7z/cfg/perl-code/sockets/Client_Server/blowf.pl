#!/usr/bin/perl -w
# FILE: "C:\test\blowf.pl"
# LAST MODIFICATION: "Mon, 30 Dec 2002 15:30:26 Eastern Standard Time"
# (C) 2002 by Jim Kipp, <james.kipp@mbna.com>
# $Id:$
#
# File Transfer encrypted with Blowfish, crude vpn 
# Uses the Blowfish module from www.cpan.ork
# 
use IO::Socket;
use Crypt::Blowfish;
use Getopt::Std;
use strict;

# parse command line options
my %options;
getopts('hd:lp:o:kK:',\%options) or help();
help() if $options{h} || (! $options{d} and ! $options{l}) || ! $options{p}; 

# end of the prelim BS, let's start now
my $key = exists $options{k} && $options{k}==1 && setkey() || 
  exists $options{K} && length($options{K}) == 8 && $options{K} || '';
print $key ?  "Using your key\n" : "No valid key found, skipping encryption\n";

# start server side
server() if $options{l};
# start client side
client() if $options{d};


sub help
{
die <<HELP;
Connect to server:       $0 -d host -p port [-options]
Accept Connections:      $0 -l      -p port [-options]
Options:
        -o out file  Redirect the output 
        -k           Read the key from STDIN 
        -K key       use this key [8 chars]

HELP
}


# get key from STDIN 
sub setkey
{
    local $| = 1;
    local *TTY;
    my ($key1,$key2);
    open(TTY,"/dev/tty");
	# turn off echo on the console so peekers can not see the key as it
	# is typed
    system "stty -echo </dev/tty";
    print STDERR "the key must be 8 chars long\nType the key: ";
    chomp($key1 = <TTY>);
    print STDERR "\nRe-type key: ";
    chomp($key2 = <TTY>);
    print "\n\r";
    print "Keys dont match\n" and return unless $key1 eq $key2;
    print "The key must be 8 chars long\n" and return if length($key1) != 8;
    return $key1;
}

sub server
{
    my $socket = IO::Socket::INET->new(LocalPort => $options{p},
                       Listen    => 2,
                       Reuse     => 1,
                       Type      => SOCK_STREAM,
                       Proto     => 'tcp',
                       ) or die "Cant bind socket $options{p}: $!";

    my ($client,$response);

    while ($client = $socket->accept())
    {
        print "Conection from: ",$client->peerhost(),"\nAccept it? [y/n]";
        chop($response = <STDIN>);
        last if $response eq 'y';
        close($client);
    }
    print "\n";
    open(OUT,">$options{o}") || die "cant create $options{o}\n" if $options{o};
    my $stuff = *OUT;
    $stuff = *STDOUT unless $options{o};
    my $blow = new Crypt::Blowfish $key if $key;

    while(<$client>)
    {
        chomp($_);
		# pack the raw hex data into something humans like 
        $_ = pack("H*",$_);
        if ($key)
        {
			# unpack the key from the client
            my @blocks = unpack("a8" x (int(length($_) / 8)+1),$_);
            my $text;
			# decrypt the key
            foreach my $block (@blocks)
            {
                last unless $block;
                $text .= $blow->decrypt($block);
            }
            $text=~s/ *$//;
            print $stuff "$text\n";
            next;
        }
        print $stuff "$_\n";
    }
    exit;
}


sub client
{
	# connect to server
    my $socket = IO::Socket::INET->new(PeerPort => $options{p},
                       PeerAddr  => $options{d},
                       Type      => SOCK_STREAM,
                       Proto     => 'tcp',
                       ) or die "Cant connect to $options{d} $options{p}: $!";

	# encrypt key to send
    my $blow = new Crypt::Blowfish $key if $key;

	# send the key to the server, after key exchange, you can type shit
	# and watch it echoed on the client. or optionall to an output file
    while(1)
    {
        last unless $socket;
        chomp($_ = <STDIN>);
        last unless $_;
        if ($key)
        {
            my @blocks = unpack("a8" x (int(length($_) / 8)+1),$_);
            my $text;
            foreach my $block (@blocks)
            {
                $block .= " " x (8 - length($block)) if length($block) != 8;
                $text .= $blow->encrypt($block);
            }
            $text= unpack("H*",$text);
            print $socket "$text\n";
            next;
        }
        $_ = unpack("H*",$_);
        print $socket "$_\n";
    }
    close($socket);
    exit;                               
}

