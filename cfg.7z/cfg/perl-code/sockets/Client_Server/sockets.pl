use IO::Socket;

## server code

$sock = new IO::Socket::INET (LocalHost => 'jerry',
                              LocalPort => 8000,
                              Proto     => 'tcp',
                              Listen    => 5,
                              Reuse     => 1,
                             );
die "Could not connect: $!" unless $sock;
# use resuse to ensure proper closing of the socket

# ready for service
$new_sock = $sock->accept();

# it reads the new socket created until the other end closes its end of the connection. 
# At this point, the <> operator returns undef (sysread returns 0, the number of bytes read).
while ($new_sock = $sock->accept()) {
    while (defined ($buf = <$new_sock>)) {
       print $buf;
    }
}
close ($sock);

## client (caller) code

use IO::Socket;
$sock = new IO::Socket::INET (PeerAddr => 'jerry.neptuna',
                              PeerPort => 8000,
                              Proto    => 'tcp',
                             );
die "Socket could not be created. Reason: $!\n" unless $sock;
foreach (1 .. 10) {
    print $sock "Msg $_: Testing Socket?\n";
}
close ($sock);



# Forking server
$SIG{CHLD} = sub {wait ()};
$main_sock = new IO::Socket::INET (LocalHost => 'jerry',
                                   LocalPort => 8000,
                                   Listen    => 5,
                                   Proto     => 'tcp',
                                   Reuse     => 1,
                                  );
die "Socket could not be created. Reason: $!\n" unless ($sock);
while ($new_sock = $main_sock->accept()) {
    $pid = fork();
    die "Cannot fork: $!" unless defined($pid);
    if ($pid == 0) { 
        # Child process
        while (defined ($buf = <$new_sock>)) {
           # do something with $buf ....
           print $new_sock "You said: $buf\n";
		   $answer = <$new_sock> # read remote answer
        }
        exit(0);   # Child process exits when it is done.
    } # else 'tis the parent process, which goes back to accept()
}
close ($main_sock);

