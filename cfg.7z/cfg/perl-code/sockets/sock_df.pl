#!/db/app/perl/bin/perl

# THIS ONE SHOWS THE USE OF EXEC AFTER A FORK.  THE CLIENT CONNECTS AND 
# EXECS THE SPECIFIED PROGGRAM 	WHICH OUTPUTS HERE AT THE SERVER. 
# HAVE TO DO SOME MAGIC TRICKER TO GET THE EXEC OR SYSTEM CALL OUTPUT TO
# BE DUPPED TO THE CLIENT HANDLE. SEE  BELOW FOR EXPLAIN

use Socket; 
use POSIX qw(:sys_wait_h); 
# use Fcntl qw(F_GETFL F_SETFL O_NONBLOCK); 
use Fcntl qw(F_SETFD); 
$| = 1;
$port = 6668;
# $maxlen = 4096;

socket(S, AF_INET, SOCK_STREAM, getprotobyname('tcp')) ||
	die "\n $0: Cannot create socket: $!";
setsockopt(S, SOL_SOCKET, SO_REUSEADDR, 1);

$eol = "\015\012";

($name,$addr) = (gethostbyname("spas099a"))[0,4];
# unpack the address from net byte order to ascii
$ip = sprintf("%s", join('.', unpack('C4', $addr)) );
bind(S, sockaddr_in($port, inet_aton($ip)) ) || die "Cannot bind .. $!\n";

listen(S,5)  || die "$0: Cannot listen: $!\n";
print "Waiting for connections on  \"$name\" and at address: $ip:$port\n";

#  accept returns packed client addr
while ($remote = accept(C,S) )  {
		my ($rport,$raddr) = sockaddr_in($remote);
		# inet_ntoa converts 32 bit raw addr to dotted quad ascii
	   	print "Connection from ", inet_ntoa($raddr), " at port: $rport\n";

	    if ($pid = fork) { # parent
			print "our parent pid is: $$\n";
			print "we got our kid: $pid\n";
			close(C); # close client handle. no use to parent
            # wait for ANY child proc to die and do a non blocking wait for pending zombies
			waitpid( -1, &WNOHANG );
			next; # ready for another client 
	    } else  { # child
			die "can't fork: $!" unless defined $pid;
            # WHEN PERL OPENS A NEW FH, IT CHECKS THIS VAR (WHICH IS SYSTEM_FD_MAX)
			# IF THE FD USED BY THE CLIENT HANDLE IS GREATER THAN MAX, THE DESCRIPTOR IS MARKED TO 
            # CLOSE. WE SET IT VERY HIGH TO ELIMINATE THE CHANCE OF THIS HAPPENING TO OUR FD
			# PG 424 OF CAMEL BOOK EXPLAINS THIS AND MORE. 
			local $^F = 10_000;
			close(S); # close parent sock. no use to child
			# THIS IS THE ONLY WAY IT WILL WORK, WE NEED TO KNOW THE FD NUMBER OF THIS FH
            # THIS MARKS THE FH TO BE OPEN ACROSS EXECS. ALSO DUPS THE SOCKET DESCRIPTOR TO STDOUT
		    open STDOUT, ">&". fileno (C);
			print C "Connected to $ip:$port $eol$eol";
			# print "we should be on child now, so pid: $$ \n\n";
			# print C "Connected to $ip:$port ";
			exec("ls", "-l") or print STDERR "couldn't exec: $!";
			# sleep 1;
    		exit;  # don't let child fall back into main code
		}
}


