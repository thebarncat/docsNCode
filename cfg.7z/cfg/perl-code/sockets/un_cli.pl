#!/appl1/perl/bin/perl

use IO::Socket;

my $sockname = "/tmp/unixsockd.sock";

my $client = IO::Socket::UNIX->new(
                 Peer    => $sockname,
                 Type    => SOCK_STREAM,
                 Timeout => 5,
             ) or die "$0: error connecting to '$sockname': $@\n";

my $pid = fork();  die "Cannot fork\n" unless defined $pid;

if ($pid) {
    write_sock();
    waitpid($pid, 0);
} else {
    read_sock();
}

sub write_sock {
    for (1..10) {            # (feel free to change count)
        print $client "testline number $_\n";    # print to socket
    }
    print $client "\n";        # empty line causes server
                               # to terminate connection
    print "Done writing.\n";  # (goes to stdout, not socket)
}

sub read_sock {
    while (my $line = <$client>) {
        print $line;           # report to stdout
        # simulate someone reading slooowly (50ms/line):
        select(undef, undef, undef, 0.05);
    }
}


