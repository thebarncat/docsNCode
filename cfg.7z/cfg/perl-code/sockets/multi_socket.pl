#!/db/app/perl/bin/perl -w
# FILE: "C:\CODE\Perl\scripts\sockets\multi_socket.pl"
# LAST MODIFICATION: "Wed, 08 Sep 2004 10:19:17 Eastern Daylight Time"
# 2004 by Jim Kipp, <james.kipp@mbna.com>

use strict;
use IO::Socket;
use IO::Select;

my @pssock; # <-- array of listening sockets.
my $act;

# Listen on all given ports...
for ( 8080, 8081 ) {
   push @pssock, IO::Socket::INET->new( 
      Proto     => 'tcp',
      LocalPort => $_,
      Listen    => SOMAXCONN,
      Reuse     => 1);
}

my $selector = new IO::Select(@pssock);

for(;;){
   # Are any of the phones ringing?   
   my @newconn = $selector->can_read(0); #<-- don't block or wait.
   for( @newconn ) { #<-- handle new connections.
      my ( $client, $clientip ) = $_->accept();
      next if( !$client ); #<-- handle error upon accept.
      # Do something with the new client here.
      print $client "GO AWAY\n";
      undef $client;
      $act++; #<--signify activity.
	  print $act;
   }
   # sleep here if no work was performed to avoid cary spinning.
   sleep(1) unless $act;
}

