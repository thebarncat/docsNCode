#!/usr/bin/perl 
# FILE: "C:\CODE\Perl\scripts\sockets\SMTP\raw_mail.pl"
# LAST MODIFICATION: "Mon, 27 Sep 2004 19:48:25 Eastern Daylight Time"
# (C) 2004 by Jim Kipp, <james.kipp@mbna.com>

use Socket;
$port = 25;
$host ='smtp.comcast.net';# Change to your smtp server
$addr = gethostbyname("$host"); 
$ip = join(".", unpack("C4", $addr));
$eol = "\015\012";

my $dest = sockaddr_in($port, inet_aton($ip));

socket(S,AF_INET,SOCK_STREAM, $proto) or die "coudn't create sock: $!";  
connect(S,$dest) or die "can't connect: $!\n"; 
select(S); $| = 1; select(STDOUT);

$a=<S>;print "$a";
print S "HELO neptuna.org$eol";
$a=<S>;print "$a";
print S "MAIL FROM:bill\@comcast.net$eol";
$a=<S>;print "$a";
print S "RCPT TO:jkipp5\@comcast.net$eol";
$a=<S>;print "$a";# change to your mail id
print S "DATA$eol";
$a=<S>;print "$a";
print S "TO: jkipp5\@comcast.net$eol";
print S "FROM: foo\@bar.net$eol";
print S "SUBJECT: Hi$eol";
print S "MESSAGE BODY: This is a test$eol";
print S ".$eol"; 
$a=<S>;print "$a";
print S "QUIT";
exit 1 ;

