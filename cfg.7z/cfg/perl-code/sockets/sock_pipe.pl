#!/appl1/perl/bin/perl 

use Socket;
use IO::Handle;

# create two connected sockets. Each descriptor can be used for both input and output, which makes
# 2 way communication between parent and child
socketpair(CHILD, PARENT, AF_UNIX, SOCK_STREAM, PF_UNSPEC)
	or  die "socketpair: $!";

# using the autoflush method from the IO::Handle module
CHILD->autoflush(1);
PARENT->autoflush(1);

# after the fork, the parent closed it's handle then reads and writes via 
# the child handle. 
# the child proc is now $pid. but still in parent. the new child procid it returned to parent 
# and 0 to parent

if ($pid = fork) {
	close PARENT;
	# this is printed to child ($line)
	print CHILD "I am the Parent $$ sending this\n";
	chomp($line = <CHILD>);
	print "I am the Parent $$  and just read this: $line\n";
	close CHILD;
	# wait for child proc to terminate and returns PID when proc dead. 
	waitpid($pid,0);
} else {
	die "cannot fork: $!" unless defined $pid;
	close CHILD;
	chomp($line = <PARENT>);
	print "I am the Child Pid $$ and just read this: $line\n";
	print PARENT "I am the Child Pid $$ is sending this\n";
	close PARENT;
	exit;
}  
