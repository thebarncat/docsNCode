#!/usr/bin/perl -w
use strict;
# FILE: "/home/jj/scanip.pl"
# LAST MODIFICATION: "Wed, 25 Jul 2001 13:15:38 -0400 (jj)"
# (C) 2001 by Juan Fuentes, <juan.fuentes@codetel.net.do>
# $Id:$

# Scan and resolve ip to hostname and vice-versa. Yes i'm bored.

use Getopt::Std;
use Socket;

my %opts;
my $PROGNAME = "scanip";
my $ip = '\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}';
my $ping = 0;

usage() unless @ARGV;

getopts('hp:f:',\%opts);

# init (we need switch, bad);

if($opts{h}){ 
    usage(); 
}elsif($opts{f}){ # parse file for ip and/or hostname.
    parse_file($opts{f});
}elsif($opts{p}){
    die "You need to be root to use this flag\n" unless ($< == 0);
    $ping = 1;
    parse_file($opts{p});
}else{
    usage();
}


sub get_info
{
    my ($arg,$num) = @_;
    
    if($arg =~ /$ip\b/){
        my $ipaddr  = $arg;
        
        # get hostname of $ip
        my $host    = gethostaddr($ipaddr) if(defined($ipaddr));      
        # get $host ip to compare them.
        my $rhostip = getipaddr($host) if(defined($host)); 
        # get $rhost ip to double check.
        my $rhost   = gethostaddr($rhostip) if (defined($rhostip)); 

        
        if(defined($ipaddr) eq defined($rhostip)){
            print "$num " if (defined($num));
            print "$host\n";
        }elsif(defined($host) eq defined($rhost)){
            print "$num " if (defined($num));
            print "Hostname $host resolves to $rhost, possible alias\n";
            print "Ip for $host: $ipaddr \nIp for $rhost: $rhostip \n";
        }else{
            failed_lookup($host,$ipaddr,$rhost,$rhostip);
        }   
    }else{
        my $host    = $arg;
        # ip of $host.
        my $hostip  = getipaddr($host) if(defined($host));  
        # host name of $hostip.
        my $rhost   = gethostaddr($hostip) if(defined($hostip)); 
        # remote host ip.
        my $rhostip = getipaddr($rhost) if(defined($rhost)); 


        if (defined($host) eq defined($rhost)){
            print "$num " if defined($num);
            print $hostip,"\n";
        }elsif (defeined($hostip) eq defeined($rhostip)){
            print "$num " if defined($num);
            print "Hostname $host resolves to $rhost, possible alias\n";
            print "Ip for $host: $hostip \nIp for $rhost: $rhostip \n";
         }else{
            failed_lookup($host, $hostip, $rhost,$rhostip);
        }
    }
}

sub parse_file
{
    my $ipfile = shift;

    die "No such file $ipfile\n" unless -f $ipfile;
    
    open(FILE, "$ipfile") or die "$ipfile :$!";
    my $linenum;

    while(<FILE>){
        $linenum++;
        if(length($_) > 15){ # a single ip has a max 15 characters.
            my @line = split(/\s/);
            foreach my $ipaddr (@line){
                chomp($ipaddr);
                next unless $ipaddr = ~ /$ip/;
                
                if($ping == 1){
                    if(alive($ipaddr)){
                        get_info($ipaddr,$linenum);
                    }else{
                        print "$linenum $ipaddr seems to be down\n";
                        next;
                    }
                }else{
                    get_info($ipaddr,$linenum);
                }
            }
        }else{
            chomp;
            next unless /$ip/;

            if($ping == 1){
                if(alive($_)){
                    get_info($_,$linenum);
                }else{
                     print "$linenum $_ seems to be down\n";
                    next;
                }
            }else{
                get_info($_,$linenum);
            }
        }
    }
    close FILE;
}

        
sub alive
{
    my $host = shift;

    use Net::Ping;
    my $ping = Net::Ping->new("icmp");
    if($ping->ping($host,2)){
        return 1;
    }else{
        return 0;
    }
    $ping->close;
}


sub getipaddr
{
    my $gethost = shift;
    my $result = sprintf "%d.%d.%d.%d", unpack("C*",gethostbyname($gethost)) 
                            if(defined($gethost) && $gethost =~ /$ip/);
    if(defined($result)){ return($result);}
}

sub gethostaddr
{
    my $getip  = shift;
    if(defined($getip) && $getip =~ /^\w+/){
        my $result = gethostbyaddr(inet_aton($getip), AF_INET);
        if(defined($result)){ return($result); }
    }
}

sub failed_lookup
{
    my ($fhost, $fhostip, $frhost, $frhostip) = @_;

    die <<"FAILED";
REVERSE LOOKUP FAILED FOR: $fhost
$fhost resolves to ip: $fhostip 
but this ip does not match: $frhost ip: $frhostip 

FAILED

}


sub usage
{
    print STDOUT <<"HELP";

    $PROGNAME [-f] file
    $PROGNAME [-p] file
    $PROGNAME [-h] 

    
    -f [file]      Parses file for ipaddress (returns their hostname) and, 
                   hostnames (returns their ipaddress) hostname lookups not
                   implemented, undefinde behavior if you force it.
    -p [file]      Parses file, pings each ipaddress if it's reachable it 
                   procedes to resolve it. WARNING: See Notes below.

    -h             This help.

    NOTES: 
    
    This program can take a while to run, if the network connection is 
    slow, also if when using the -f flag in the output you see a number and a
    blank line, that means that the ip in that line in the file, was not:

    a.) resolved
    b.) down.

    You can use the -p flag to ping the hosts, before attempting to resolve.
    To use this flag you need to be root (not recommended).

    When using the -p flag a blank line denotes the ip was not resolved.
    Also using this flags, can be memory intensive, if the file is too large
    in those cases the -f flag is better to use.

    AUTHOR: 

    Juan Fuentes <juan.fuentes\@codetel.net.do> 

    COPYRIGHT:
     
     Copyright 2001-2002 Juan Fuentes.  All rights reserved.
     It may be used and modified freely, but I do request that this copyright
     notice remain attached to the file.  You may modify this program as you 
     wish, but if you redistribute a modified version, please attach a note
     listing the modifications you have made.

    
HELP
}
