#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/arrays/get_min.pl"
# LAST MODIFICATION: "Thu, 07 Aug 2014 11:05:58 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

@nums = (5,6,3,7,2);
$rv = min(\@nums);
print "$rv\n";

sub min {
	my($num) = @_;
	my ($min) = shift @$num;
	foreach $i (@$num) {
		$min = $i if $min > $i;	
	}
	return($min);
}

