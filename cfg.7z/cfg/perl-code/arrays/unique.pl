#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/arrays/unique.pl"
# LAST MODIFICATION: "Tue, 05 May 2015 16:41:23 -0400 (jkipp)"

# see  perlfaq4 

@data = qw( a a b c c d);
@temp = unique(\@data);
print "@temp\n";

# best way is probably to take an array ref of the list 
sub unique {
	($ref) = @_;
	foreach $item (@$ref) {
    	unless ($seen{$item}) {
        	$seen{$item} = 1;
        	push(@uniq, $item);
    	}
	}
	return @uniq;
}
