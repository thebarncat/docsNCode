#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/arrays/shuffle.pl"
# LAST MODIFICATION: "Wed, 08 Feb 2017 11:47:05 -0500 (jkipp)"
# $Id:$


@array = qw ( 5 8 98 45 8 4 56 );
shuffle(\@array); # randomize an array in place
print "@array\n";

sub shuffle {
    my $array = shift;
    my $i;
    for ($i = @$array; --$i; ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @$array[$i,$j] = @$array[$j,$i];
    }
}



