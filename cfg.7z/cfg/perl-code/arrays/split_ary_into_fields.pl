#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/arrays/split_ary_into_fields.pl"
# LAST MODIFICATION: "Wed, 27 Apr 2016 16:20:37 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$


my %data;
@fields = ("fname", "lname");
#open(DATA, "<list.dat");

while(<DATA>) {
	@data{@fields} = split(/;/, $_, scalar @fields);

	foreach (@fields) {
		printf("%10.10s = %s\n", $_, $data{$_});
	}
}

close(DATA);

# split creates an array which stores the values of fname and lname(jim, kipp). this is the
# same as doing this: @data{@list} = ("jim", "kipp");
# can be further simplefied to :
# @data{"fname", "lname"} =	("jim", "kipp");

__DATA__
dave;smith
joe;davis
