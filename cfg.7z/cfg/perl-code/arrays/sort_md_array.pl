#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/arrays/sort_md_array.pl"
# LAST MODIFICATION: "Thu, 02 May 2013 16:32:33 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

push(@array, [fud, foo, bar]);
push(@array, [bee, zee, tee]);
push(@array, [zee, glu, kunk]);

@array = sort { $a->[0] cmp $b->[0] } @array;

=cut
for $row (@array) {
	for $i (@$row) {
		print "$i\n";

	}
}
=cut

for $row (@array) {
	print "@$row\n";
}
