#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/arrays/count_uniq.pl"
# LAST MODIFICATION: "Fri, 11 Apr 2014 10:24:49 -0400 (jkipp)"
# $Id:$
#
my %hash;
my @a = qw(a a b c v x b e r t b);
foreach $i ( @a ) {
        $hash{$i}++;  
}

foreach $k ( keys %hash ) {
    print "$k = $hash{$k}\n";
}


