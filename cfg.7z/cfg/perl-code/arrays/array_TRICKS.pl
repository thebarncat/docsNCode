#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/arrays/array_TRICKS.pl"
# LAST MODIFICATION: "Thu, 28 Apr 2016 12:29:42 -0400 (jkipp)"

# see  perlfaq4 

@a = qw ( 1 2 3 4 5 );
# sort numbers
my @sorted = sort {$b <=> $a } @a;
# go backwards
print $a[-1];
# print the indexes
print "$_" for 0..$#a;
#splice: the index to start, the number of items to remove and the list to replace with. returns elemens removed
@sins = splice @deadlysins,3,2,@virtues
# the map block adds the '|' char in front of each array element and
# creates a new array, the second arg to splice removes the first
# element of the array. the next 2 lines do the same thing
@a = qw( 1 2 3); @a = splice @{[ map( ('|', $_), @a ) ]}, 1;
@a = ( $a[ 0 ], map( ('|', $_), @a[ 1 .. $#a ] ) );
@a = map +($_, '|'), @a;  pop @a;
# get min and max
my ( $min, $max ) = ( sort { $a <=> $b } @numbers )[ 0, -1 ];
# truncate the array length
$#animals = 1;

