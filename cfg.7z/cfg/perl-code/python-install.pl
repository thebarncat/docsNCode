#!/usr/bin/perl

use strict;
use File::Find;
use Cwd;

my $dir = '/home/jkipp/AIX_RPMS_python-aix61';
my @names;
# get file names of RPMs we are installing
#find sub { push @names, $_ if /\.rpm$/ && s/\-\d+.*// }, '/home/jkipp/AIX_RPMS_python-aix61';
find sub { push @names, $_ if /\.rpm$/ }, '/home/jkipp/AIX_RPMS_python-aix61';
#print "$_\n" for @names;

# list of rpms on this system
my @rpm_list = `rpm -qa`;
chomp @rpm_list;
# flatten list: use of quotes avoids scalar context
my $rpm_list = "@rpm_list";
if ($rpm_list =~ /openldap/i) {
    system("sudo rpm -e openldap openldap-devel") ==0  or warn "failed: $?";
}
# remove current cfengine
system("sudo rpm -e db cfengine") ==0  or die "failed: $?";

# upgrade libgcc first in case
#system("sudo rpm -Uvh $dir/libgcc-4.8.1-1.aix6.1.ppc.rpm") ==0  or die "failed: $?";
#print "\n";

# delete whats already installed from python rpm dir
# foreach my $rpm (@names) {
#     my $sname;
#     ($sname = $rpm) =~ s/\-\d+.*//;
#     unlink "$dir/$rpm" if grep(/^$sname-\d/, @rpm_list);
# }

# delete bash rpm file if aleady installed  and install python and deps:
chdir($dir) or die "Unable to chdir: $!";
my $have_bash = `rpm -q bash`;
if ($have_bash) {
	my $file = glob "bash*.rpm";
	my $path = "$dir/$file";
	unlink $path or warn "Could not unlink : $!";
}
#my $pwd = cwd();
system("sudo rpm -Uvh *.rpm") ==0  or die "failed: $?";

#clean up
chdir($ENV{HOME}) or die "Unable to chdir: $!";
system("rm -rf $dir") ==0  or die "failed: $?";

#upgrade sudo with noldap version and install new cfengine - DOESNT WORK
#system("sudo rpm -Uvh http://kickstart.ingdirect.com/aix/6.1/sudo-1.8.15-1noldap.aix6.1.ppc.rpm") ==0  or die "failed: $?";
system("sudo rpm -ivh http://kickstart.ingdirect.com/aix/6.1/cfengine-2.2.10-1.aix6.1.ppc.rpm") ==0  or die "failed: $?";




