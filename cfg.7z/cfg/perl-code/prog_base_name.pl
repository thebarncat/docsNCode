#!/usr/bin/perl 
use strict;
print $0, "\n";
#(my $prog = $0) =~ s#^(.*)?/([^/]+)$#\2#; 
(my $prog = $0) =~ s#^(.*)/([^/]+)$#\2#; 
print "$prog\n";
( $prog = $0)  =~ s!^.*/!!;
print "$prog\n";
