#!/usr/bin/perl  -w
use Net::SMTP;

chomp(my $host = `hostname -s`);

my $msg = get_rpt();
mailer();

# clear log:
#my $clear = "/usr/bin/omconfig system alertlog action=clear";
#system($clear) ==0  or die "cmd failed: $?";

sub get_rpt {
	my $omreport = '/usr/bin/omreport system alertlog';
	my $mesg;
	open (PIPE, "$omreport|") or die "could not pipe command: $!";
	while (<PIPE>) {
		my $event;
		($event) = split(/\n/, $_);
		$mesg .= "$event\n" unless $event =~ /Severity\s+: Ok/;
	}
	return $mesg;
	close (PIPE);
		
}
	
sub mailer {
	my $server = "smtp.ingdirect.com";
	my $smtp = Net::SMTP->new($server, Debug => 0);
	$smtp->mail('alert@ingdirect.com');
    $smtp->to('unix-alerts@ingdirect.com');
	$smtp->data();
   	$smtp->datasend("To: unix-alerts\n");
   	$smtp->datasend("Subject: OMSA Alert: $host\n");
   	$smtp->datasend("\n");
	# body
   	$smtp->datasend("Alerts Dump:\n $msg");
   	$smtp->dataend();
   	$smtp->quit;
}
