#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/dates_and_time/get_day_of_week.pl"
# LAST MODIFICATION: "Mon, 20 May 2013 13:33:21 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use Time::Local;

my @days = qw( Sunday Monday Tuesday Wednesday Thursday Friday Saturday );

my ($d, $m, $y) = (1, 2, 2004);                 # Feb. 1, 2004
my $when = timelocal(0,0,12, $d,$m-1,$y-1900);  # noon on Feb. 1, 2004
my $dow = (localtime $when)[6];                 # day of week (0-6)
my $day_name = $days[$dow];                     # name of day of week
print $day_name, "\n";

