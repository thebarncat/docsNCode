#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/dates_and_time/compare_dates.pl"
# LAST MODIFICATION: "Mon, 29 Aug 2016 13:09:20 -0400 (jkipp)"
# (C) 2014 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

use Time::Local;

$oneday = 86400;
# get current time in seconds
$now=time;
# current time formatted
$now_format = localtime;
$filez = 'here.pl';

# get timestamp of a file in seconds
$mtime = (stat($filez))[9];
# format it
$stamp = scalar localtime($mtime);

print $now_format, "\n";
print $stamp, "\n";

# get number of seconds between 2 dates
$delta = $now - $mtime;
print "$delta\n"; 
$delta_days = int($delta/$day);
print "$delta_days\n"; 

# now minus last mod time in days for this file. so pretty much same as delta!
$mod = -M $filez;
print int $mod, "\n";

# parse a date string and compare to now using Time::Local
my $stamp = "Mon Jul 26 10:59:12 2016";
my($month,$day,$year) = (split(/\s+/,$stamp))[1,2,4];
print "$month,$day,$year\n";
# convert month str to number
my $months = {
	'Jan' => 1,
	'Feb' => 2,
	'Mar' => 3,
	'Apr' => 4,
	'May' => 5,
	'Jun' => 6,
	'Jul' => 7,
	'Aug' => 8,
	'Sep' => 9,
	'Oct' => 10,
	'Nov' => 11,
	'Dec' => 12,
};
my $mon = $months->{$month};
print "$mon\n";
# get time in secs to compare against
my $when = timelocal(0,0,0,$day,$mon-1,$year-1900);
my $now = time;
my $delta = $now - $when;
my $delta_days = int($delta/$oneday);
print "$delta_days\n";


=cut
$when = 86400; # 1 day
$tomorrow = $now + $when;
print  localtime($tomorrow);
=cut
