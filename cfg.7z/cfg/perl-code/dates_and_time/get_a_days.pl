#!/usr/bin/perl -w

use strict;
use File::Find;

my $file = $0;
# easy way:
my $Adays =  -A $file;
my $Mdays =  -M $file;
print "$file accessed ", int $Adays, "\n";
print "$file modified ", int $Mdays, "\n";

# manual way:
my $atime = (stat($file))[8];
my $now=time;
my $oneday = 86400; 
my $a_days = ($now - $atime)/$oneday;
print int $a_days,"\n";

#my $tomorrow = $now + $when;
#print scalar localtime($tomorrow);


