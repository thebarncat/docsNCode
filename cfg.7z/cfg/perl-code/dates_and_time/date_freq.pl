#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/date_freq.pl"
# LAST MODIFICATION: "Tue, 05 May 2015 15:20:31 -0400 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

use Time::Local;

my $file = 'oma_test.csv';
my $out_file = 'oma_test.out';
my %dat;
my @fields;

my %d_index = (
	JAN => 0,
	FEB => 1,
	MAR => 2,
	APR => 3,
	MAY => 4,
	JUN => 5,
	JUL => 6,
	AUG => 7, 
	SEP => 8, 
	OCT => 9,
	NOV => 10,
	DEC => 11
);

open (OUT, ">$out_file") or die "can't open: $!";
open (F, "<$file") or die "can't open: $!";
while (<F>) {
    chomp;
	next if /^\s+$/;
	# skip header 
	# get info from todays date
	# note: month is actual month number-1, year is actual year-1900
	($d,$m,$y) = (localtime(time))[3,4,5];
	# build the date string for time at noon on above date
	my $day_at_noon = timelocal(0,0,12, $d, $m, $y);
	# find day of the week
	my $dow = (localtime $day_at_noon)[6];
	# if this is sunday then $dow is 1. 
	# we need to subtract 1 * 86400 (seconds in a day) from $day_at_noon.  
	# To get the Y/M/D for Saturday, we must add 5 * 86400 to $day_at_noon:
	my $sunday = $day_at_noon - $dow * 86400;
	my $saturday = $day_at_noon + (6 - $dow) * 86400;
	next if $. == 1;
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
    my(@fields) = split(/,\s?/,$_);
	# convert date string to epoch seconds using timelocal()
	# source file date looks like this: 31JAN2003:00:00:00
	$date = substr($fields[1],0,9);
	($d,$m,$y) = ($1,$2,$3) if $date =~ /(\d{2}) (\w*) (\d{4})/x;
	$good_date =  timelocal(0,0,0,$d,$d_index{$m},$y-1900); 
	push (@dates, "$good_date\n");
}

for $date ( sort { $b <=> $a } @dates ) {
	# convert date in epoch seconds back to readable date string
    my ($day, $month, $year) = (localtime($date))[3,4,5];
	# extract 2 digit year if needed
	# $year = sprintf("%02d", $year % 100);
	my $cdate = sprintf("%02s/%02s/%04s", $month+1,$day,$year+1900);	
	push(@cdates, $cdate);
}


# convert array to a hash with iterative count as the key to each date
$c = 1;
my %h_dates = map { $c++ => $_ } @cdates;

close F;
close OUT;

my %cnt_date;
for $key (keys %h_dates) {
	# group by dates 
	$dt = $h_dates{$key};
	$cnt_date{$dt}++;
}

for $k (keys %cnt_date) {
	print "Total for date  $k: $cnt_date{$k}\n";
}

