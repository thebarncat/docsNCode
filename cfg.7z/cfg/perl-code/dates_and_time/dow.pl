#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/dates_and_time/dow.pl"
# LAST MODIFICATION: "Wed, 24 Jul 2019 14:22:18 -0400 (jk24445)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;

use Time::Local; 

# date entered like 12-27-2005
unless ( $ARGV[0] =~ /\d{2}-\d{2}-\d{4}/ ) {
	printf("\n%-30s\n", "Must enter date in format: mm-dd-yyyy"); exit;
}

my $date = $ARGV[0];
my ($m,$d,$y) = split(/-/, $date);

# build the date string for time at noon on above date: $m is month-1, $y is year-1900
my $noon = timelocal(0,0,12, $d, $m-1, $y-1900);

# find day of the week
my $dow = (localtime $noon)[6];
# array slice
my $whatDay = (qw(Sunday Monday Tuesday Wednesday Thursday Friday Saturday))[$dow];

print "$date is a $whatDay\n";


