#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/dates_and_time/map_previous_days.pl"
# LAST MODIFICATION: "Mon, 20 May 2013 13:26:04 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

use POSIX;
$t = time();
# advance the date until the next saturday
$t += 86400 while strftime("%A", localtime($t)) ne 'Saturday';
# count back each day from next saturday, back 21 days and print DOW for each date
print map {strftime("%m/%d/%Y %A\n", localtime($t- 86400* $_))} (0..21);
