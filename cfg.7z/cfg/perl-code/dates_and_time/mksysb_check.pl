#!/usr/bin/perl -w
use strict;
use File::Copy;
use Net::SMTP;
use Time::Local;

umask(002);

my $mksysb_dir = '/export/images';
my $msg;
my $oneday = 86400;
my $now = time;
my $months = {
	'Jan' => 1,
	'Feb' => 2,
	'Mar' => 3,
	'Apr' => 4,
	'May' => 5,
	'Jun' => 6,
	'Jul' => 7,
	'Aug' => 8,
	'Sep' => 9,
	'Oct' => 10,
	'Nov' => 11,
	'Dec' => 12,
};

opendir(DIR, $mksysb_dir)  || die "Can't opendir $!";;
my @filez = grep { !/^\.+$/ && -f "$mksysb_dir/$_" } readdir(DIR);
closedir(DIR);

for my $f (@filez) {
	next unless $f =~ /mksysb/;
	my $mksysb_path = "$mksysb_dir/$f";
	my $lpar = $1 if $f =~ /mksysb_([a-z0-9]+).*/;
	$msg .= "warning mksysb for $lpar over 60 days old!\n" if -M $mksysb_path > 60;
	chomp( my $mksysb_defined = `asroot lsnim -t mksysb | grep -i $lpar` );
	if (not $mksysb_defined) {
		print "** $lpar mksysb resource NOT DEFINED ** Creating it..\n";
		system("asroot nim -o define -t mksysb -a server=master -a location=$mksysb_path mksysb_$lpar") ==0  or die "failed: $?";
		print "$lpar mksysb resource completed\n\n";
	}
	else {
		my ($mksysb_object,undef) = split(/\s+/,$mksysb_defined, 2); 
		print "Found mksysb resource for: $mksysb_object\n";
		my (undef,$mk_stamp) = split(/= /,`asroot lsnim -l $mksysb_object | grep creation_date`);
		my($month,$day,$year) = (split(/\s+/,$mk_stamp))[1,2,4];
		my $mon = $months->{$month};
		my $when = timelocal(0,0,0,$day,$mon-1,$year-1900);
		#print scalar localtime($when),"\n";
		my $delta = $now - $when;
		my $delta_days = int($delta/$oneday);
		if ($delta_days > 45) { 
			print "mksyb object time stamp too old. will re init:\n";
			system("asroot nim -o remove $mksysb_object ") ==0  or die "failed: $?";
			system("asroot nim -o define -t mksysb -a server=master -a location=$mksysb_path mksysb_$lpar") ==0  or die "failed: $?";
			print "$lpar mksysb re init completed\n\n";
		}
	}
}

if ($msg and $msg =~ /bprdeaxnim01/) {
	$msg .= "\n**mksysb for bprdeaxNIM01 is old and should be refreshed and copied to bprdelxcfg02:/nim. Please refresh and mount /mnt/nim and copy it over**\n";
}

mailer() if $msg;

sub mailer {
	my $server = "ponyex.capitalone.com";
	my $smtp = Net::SMTP->new($server, Debug => 0);
	$smtp->mail('360unixalert@capitalone.com');
	$smtp->to('UnixGroup@capitalone.com');
	$smtp->data();
	$smtp->datasend("To: #360 Unix\n");
	$smtp->datasend("Subject: MKSYSB CHECK ALERT\n");
	$smtp->datasend("\n");
	# body
	$smtp->datasend($msg);
	$smtp->dataend();
	$smtp->quit;
 }


