use strict;
use File::Find;

my $file = "ing-kill.sh";
my $Adays =  -A $file;
my $Mdays =  -M $file;

my $atime = (stat($file))[8];

print "$file accessed ", int $Adays, "\n";
print "$file modified ", int $Mdays, "\n";

my $now=time;
my $oneday = 86400; # 1 day

my $a_days = ($now - $atime)/$oneday;
print  int $a_days,"\n";

#my $tomorrow = $now + $when;
#print scalar localtime($tomorrow);
