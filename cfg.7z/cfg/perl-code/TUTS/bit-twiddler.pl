#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/bit-twiddler.pl"
# LAST MODIFICATION: "Sun, 05 Jul 2020 20:53:35 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
use strict;

# Detecting non printing chars, first way
my $out_ctr = 0;
while (<STDIN>) {
	next unless s/([[:cntrl:]])/'^' . ( $1 | "\x40" )/eg;
    $out_ctr++;
}
print "Total records = $.\n";
print "Total records written with non-printing chars = $out_ctr\n";

my $stuff = 'xxxyyyyy';
vec($stuff,length $stuff,8) = ord "E";
print "$stuff\n";
#vec  first argument as a stream of bits taken from the string.  third argument tells how many bits form a chunk.  
#8 bits gives chunks that can each have values from 0 to 255.  
#The second argument tells *which* chunk, numbering the chunks starting at 0.
#So the  statement above is looking at the scalar $output as a series of 8-bit chunks - essentially each character of the string.  
#And at the byte numbered length($stuff), which would be the byte just after
#the current end of the string, we're sticking a new 8-bit value.  
#This value is coming from computing the ascii value for the letter "E",
#In other words, that's just $stuff .= "E"
#vec() is really good for a "boolean" array.  
#If you take the string #1 bit at a time, you can represent 0/1 or false/true with 1 bit
#per bit in the string.  vec($data, $n, 1) = 1 sets bit $n to 1, and vec($data, $n, 0) = 0 clears that bit

# pack  to a signed 16 bit integer 
my $ps = pack( 's', 20302 );  
#  unpack same template returns the original integer value
my $s = unpack( 's', $ps ); 
print "$s\n";
#  pack can take a list of values and pack into a single str
print pack('A3 x2 A*', "one", "two"); # prints "one  two" 
print "\n";

# regex with map breaks the string of digits into chunks of 3 digit strings than chr converts each chunk into an ascii char
print map( {chr} ('106117115116032097110111116104101114032112101114108032104097099107101114') =~ /.../g), "\n";
