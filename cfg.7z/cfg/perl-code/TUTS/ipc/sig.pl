#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/sig.pl"
# LAST MODIFICATION: "Sun, 01 Mar 2020 11:44:31 -0500 (jk24445)"
# (C) 2015 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

# wrap these 2 examples in a function

# SIG alarm hander. 
$SIG{ALRM} = \&timed_out;
eval {
    alarm (5);
    $buf = <>;
    print $buf;
    alarm(0);           # Cancel the pending alarm if user responds.
};
if ($@ =~ /GOT TIRED OF WAITING/) {
    print "Timed out\n";
}
sub timed_out {
    die "GOT TIRED OF WAITING";
}

#----------

# catch INT sig, allow user to break out (types q) or continue
$SIG{INT} = sub {
    print "what ?";
    my $c = <STDIN>;
    exit if ($c =~ /^q/i);
    print "ignored sig\n";
};
while (1) {
    print "hi\n";
}
