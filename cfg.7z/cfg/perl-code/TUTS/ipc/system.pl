#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/ipc/system.pl"
# LAST MODIFICATION: "Tue, 05 May 2020 10:00:13 -0400 (jk24445)"
# (C) 2015 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$


my $RT = SyS('ls -l temp');
print "RT is $RT\n"; # 0 on success

sub SyS {
    my ($cmd) = @_;
    my $response = system($cmd);  # note no redirect of stdErr - it goes to the screen.
    my $retval = $? ;
    if ( $retval ) {
        # it failed - let us figure it out
        my $exit_value  = $response >> 8;
        my $signal_num  = $response & 127;
        my $dumped_core = $response & 128;
        print "SyS exit value:$exit_value:$signal_num:$dumped_core:\n";
    } 
    $response; 
} 

print "\n\n";

my $out = BackTk('ls -l temp');
print $out;

sub BackTk {
    my ($cmd  ) = @_;
    my $response = `$cmd 2>&1`;  # let me have the stderr not them
    my $retval = $? ;
    if ( $retval ) {
        # it failed - let us figure it out
        my $exit_value  = $retval >> 8;
        my $signal_num  = $retval & 127;
        my $dumped_core = $retval & 128;
        print "BackTick exit value:$exit_value:$signal_num:$dumped_core:\n";
    } 
    $response; 
} 
