#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/system2.pl"
# LAST MODIFICATION: "Sun, 01 Mar 2020 12:22:11 -0500 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
use strict;

# perl tries to fork and exec.
system "/no/file";
print "exit status:  $?\n";  # exit status
print "error is: $!\n";  

print "\n\n";

# when perl system sees shell meta char it does not to exec the string
# it does this: exec 'sh', '-c', '/no/such/file/ *'
my $cmd = "/no/file/ *";

# exececutes /bin/ls successfully, but ls fails, uncomment to see the  different numbers than above scenario
#my $cmd = "ls /no/file/";

system $cmd;
print  "\$? is $?\n";
print  "\$! is $!\n";
printf "[ status ] %016b [%d]\n", ($?) x 2;
printf "[ exit   ] %016b [%d]\n", ($? >> 8 ) x 2; 
printf "[ core   ] %016b [%d]\n", ($? & 128) x 2;
printf "[ signal ] %016b [%d]\n", ($? & 127) x 2;

