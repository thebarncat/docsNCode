#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/fork_me.pl"
# LAST MODIFICATION: "Sun, 01 Mar 2020 11:15:35 -0500 (jk24445)"
# (C) 2015 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

# THIS DOES NOT actually work but good overview

my @hosts = map "10.45.4.$_", 25..35;

#for (@hosts) { 
#	print "ping $_ is ", ping_a_host($_), "\n"
#}

sub ping_a_host {
	my $host = shift;
	`ping -i 1 -c 1 $host 2>/dev/null` =~ /0 packets rec/ ? 0 : 1;
}

# we'll have two processes running: the shell forked by the backquotes and the ping process itself
# Perl fork a shell needed child to have its  standard error output redirected.
# forking 20 kids to check 10 hosts WON'T scale 
my %pid_to_host; #keys child pid, and the value will be the host 
for (@hosts) {
	if (my $pid = fork) {
		## parent does...
		$pid_to_host{$pid} = $_;
		warn "$pid is processing $_\n";
	} else { # child does
	## child does...
	exit ping_a_host($_);
	}
}

# key will be the host, and the value will be 1 if the child said it was pingable,else 0
# wait for kids until they are all gone. wait returns the child pid and it's exit status is $?
my %host_result;
while (keys %pid_to_host) {
	my $pid = wait;
	last if $pid < 0;
	my $host = delete $pid_to_host{$pid} or warn("Why did I see $pid ($?)\n");
	warn "reaping $pid for $host\n";
	$host_result{$host} = $? ? 0 : 1;
}

# show results
for (sort keys %host_result) {
	print "$_ is ", ($host_result{$_} ? "good" : "bad"), "\n";
}

