#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/args.pl"
# LAST MODIFICATION: "Mon, 02 Mar 2020 11:58:01 -0500 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
use strict;

(my $prog = $0) =~ s/^.*[\\\/]//;

# simple and best
use Getopt::Std;
my %opts;
getopts('bs:u:', \%opts);
my $foo = $opts{s};
my $bar = $opts{u}; 
my $usage = "$0 -b -s <foo> -u <bar> \n";

my $usage2 = <<EOD;

Usage: $prog [-d] [-s=<str>] arg1 [<opt-arg> ... ]

	-d		turn on debug
	-s=<str>	text of s thingys
	arg1		some mandatory arg
	<opt-arg>	optional args
EOD

# if you want to roll your own. this is old so may not even work
our %task = (
        copy => \&test_cp,
        xcopy => \&test_cpx,
        stats => \&get_stats,
        rstats => \&rget_stats,	
);
sub parse_args
{
    my $action;
	# arg must start with a '-'
    unless ( (@ARGV) &&  $ARGV[0] =~ /^-/ ) { usage(); die "bye\n"; }
    my $v = $ARGV[0];
    if ($v =~ /^-h/) { usage() 
    } elsif ($v =~ /^-c/) {
         $action = 'copy';
        } elsif ($v =~ /^-d/) {
         $action = 'copy';
        } elsif ($v =~ /^-l/) {
         $action = 'stats';
        } elsif ($v =~ /^-f/) {
         $action = 'rstats';
    } else {
		die $usage;
	}
      return $action;
}
