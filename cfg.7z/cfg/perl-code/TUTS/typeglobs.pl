#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/typeglobs.pl"
# LAST MODIFICATION: "Wed, 22 Apr 2020 13:12:01 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$

$var = "foo";
@var = qw(a b);
# make bar eq to the var symbol table, makes $bar a symref to $var
$bar = *var;
print "$$bar\n"; # prints foo
# make a ref to a type glob (sym table var)
$globr = \*var;
print ${*$globr},"\n"; # sclar deref
print @{*$globr},"\n"; # array deref
print "\n"; 
# sym refs to FH globs to iterate thru an array of FH 
#for my $ix (@F_handles) {
#	no strict 'refs';
#	local *FH = *{"FH$ix"};
#	my @slurp = <FH>;
#}



