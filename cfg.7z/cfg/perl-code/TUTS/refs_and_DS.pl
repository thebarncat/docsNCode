#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/refs_and_DS.pl"
# LAST MODIFICATION: "Wed, 22 Apr 2020 12:57:23 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
use strict;

# https://perldoc.perl.org/index-tutorials.html
# https://perldoc.perl.org/perldsc.html

# scalars
my $i = 'i';
my @array = (\$i, \3);
print ${$array[1]}, "\n";
my @rlist = \localtime(time);
print ${$rlist[1]}, "\n";
print "\n";


# arrays
{
	no strict 'vars';
	$$aref[0] = "foo"; #autoviv
	print "$$aref[0]\n";
	@$aref[4..6] = qw( a b c);
	print $$aref[5],"\n"; 
}
my $ar = [1,2,['a','b','c']]; # anon array
print $$ar[2][1],$ar->[2][1],$ar->[2]->[2],"\n";
print "\n";
my @foo = ( 
	["dir1","/db"],
	["dir2","/dbm1"]
);
print "$foo[0]->[1]\n";
print "@{$foo[0]}\n";
for my $row (@foo) { print "@$row\n"; }
for my $row (@foo) { print "$row->[0]\n"; } #print first col of each row 
print "\n";
# pass aref to function
my @ar = qw( a b c); my @br = qw( d e f);
foo(\@ar, \@br);
sub foo {
	my ($ref,$ref2) = @_; 
	print $ref->[1],"\n";
	print "@$_\n" for $ref;
	print "@$_\n" for $ref2;
}
print "\n";
# function return array ref 
my $units = populate();
print $units->[1],"\n";
print "@$_\n" for $units;
sub populate { 
	my @a = (10,70); 
	return \@a 
}
print "\n";


# hashes
{
	no strict 'vars';
	$href = { APR => 4, AUG => 8 };
	print "$$href{$_}"," ","\n" for keys(%$href); 
	#print "$href->{$_}\n" for keys(%$href); 
	#print "${$href}{$_}\n" for keys(%$href); 
	@$href{"k1", "k2"} = ("val1", "val2"); # slice
	print $href->{'k1'},"\n"; 
}
# sub return hash ref 
my ($stuff) = get();
print "$$stuff{$_}\n" for keys(%$stuff);
sub get { my %hash = (km => 10, kg=>70); return \%hash;}


#NESTED DSC
my $john = [ {age => 1, eyes => 2, weight => 3}, 47, "brown", 186 ];
print "$john->[0]->{weight}, $john->[3]\n";
print "\n";
# AoA
my @AoA;
my @tmp = qw( a b c); my @tmp2 = qw( 1 2 3);
push @AoA, [ @tmp]; push @AoA, [ @tmp2 ];
print $AoA[0]->[1],"\n";
my $row;
for $row ($AoA[0]){print "@$row\n";} # print a row
print "\n";
for $row (@AoA){print "@$row\n";} # print all
print "\n";
# iterate 
for my $i (0 .. $#AoA) {
	for my $j ( 0 .. $#{ $AoA[$i] } ) {
		print "$i $j is $AoA[$i][$j]\n";
	}
}
print "\n";
# ref to anon array work the same
#my $mdr = [ [ "foo", "9"], ["bar", "8"], ]; 
# HoH
my @arh = ( { name => 'bill', age => '21', }, { name => 'fred', age => '40', } );
print $arh[1]{age},"\n";
print "\n";
my $href;
for $href ($arh[1]) { print "$href->{$_} " for keys %$href; }
print "\n";
for $href (@arh) { for my $key ( keys %$href ) { print "$href->{$key} ";} }
print "\n\n";
# HoA
my @x = qw( 1 2 3);
my @y = qw( 6 7 8 );
my %HOA = ( one => \@x, two => \@y );
print $HOA{one}->[2],"\n";
print "@{$HOA{'one'}}\n";
#print entire struct
print "@{$HOA{$_}} " for keys %HOA; 
print "\n\n";
# Hash of named anon arrays
my %HoA = (
	A => ["fred", "barney"],
	B => ["george", "jane", "elroy"],
);
print "@{ $HoA{A} }->[0]\n";
print "@{ $HoA{A} }\n";
# print entire struct
for my  $key (keys %HoA) {print "$key: @{$HoA{$key}} " };
print "\n";
# print the first col of each array ref 
for my $key (keys %HoA) { print "$HoA{$key}->[0] " }
print "\n\n";
# add another array and map to a flat array
$HoA{C} = ["bill", "tom"];
my @names = map @$_, @HoA{ keys %HoA };
# passing an HOH to a function
my %hoh = ( 
B1 => {
	a => 'fox', 
	b => 'fire',
},
B2 => {
	a => 'foo', 
	b => 'bar',
},
);
my $hr = \%hoh;
func($hr);
sub func { # iterate through the entire struct
	 my $h = shift;
	 for my $k (keys %$h)
	 {
	 	print "$k: ";
	 	for my $n ( keys %{ $h->{$k} } ) {
			print "$n => $h->{$k}{$n} ";
	 }
	 print "\n";
	 }
}
print "\n\n";

# DATA STRUCTS (HOA) example
# https://perldoc.perl.org/perldsc.html#HASHES-OF-ARRAYS
my %USERS;
while(my $line = <DATA>){
    chomp $line;
    my($user,@groups) = split(/\s+/,$line);
    $USERS{$user} = [@groups];
}
foreach my $user (keys %USERS) {
    print "$user: @{ $USERS{$user} }\n"
}
# print the whole thing with indices
foreach my $user ( keys %USERS ) {
    print "family: ";
	foreach $i ( 0 .. $#{ $USERS{$user} } ) {
		print " $i = $USERS{$user}[$i]";
	}
	print "\n";
}
print "\n\n";

# FUNCTIONS 
# dispatch table 
sub add { print 'add' }
sub delete { print 'delete' }
sub show { print 'show' }
my %commands = (
	v => \&add,
	w => \&delete,
	t => \&show,
);
print 'command>';
while ( my $op = <> ) {
	chomp $op;
	last if $op eq 'x';
	$commands{$op}->() if exists $commands{$op};
	print "\ncommand>";
}
print "\n\n";
my $sref = sub { print "Boink!\n" }; # anon function
print &$sref;


__DATA__
dave web db
joe web admin
