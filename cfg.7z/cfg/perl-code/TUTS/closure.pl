#!/usr/bin/perl

sub print_name
{
    my ($arg) = @_;  
    my $name = $arg;  #define lexical variable avaiable to this block only, 
    $closure = sub { print $name, "\n" }; # create anon sub that will be our closure
    # *closure = sub { print $name, "\n" } # some trickery using typeglob to alias the anon sub
    # pretty much does the same as above except the anon sub is not put into a sclalar var
    return $closure;  # return a ref to the anonymous sub
    
}

# can now use like this outside of the block since the closure makes our lexical
# var $name avaialbe outside the block when using the anon sub ONLY to access it:
$print_it = print_name 'jim';
$print_it->();
# normally the lexical var $name in the sub print_name will unavailable outside the sub, but since
# anon sub is being needs then outside the block the variable can be used accesible by the closure.
