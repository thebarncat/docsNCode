#!/usr/bin/perl
use File::Find;
#When Wanted() is called:
#$_ is set to the current file name (base name)
#$File::Find::dir is set to the current directory  (just current path)
#$File::Find::name is set to "$File::Find::dir/$_" (full path and file name) 
#you are chdir()'d to $File::Find::dir

#Preprocessing:  Code reference is used to preprocess the current directory. The preprocess routine is called with $File::Find::name set
#to the directory being processed, while @_ holds the names of all files and directories contained here excluded files will not be passed to the wanted routine 
#and excluded directories will be removed from the directory tree.
find {
  preprocess => sub { grep !/Foo/, @_ }, #skip dirs with 'Foo' 
  wanted     => sub { print if ($File::Find::name =~ /.*\.txt$/) }
 }, 'folder1';

# Prunes a dir from the search.. don't recurse tree that matches pattern:
find sub {
	if ($_ eq "FOO") { ++$File::Find::prune }
	print "$File::Find::name\n";
 }, 'folder1';
#or something like:
if (-d && /^[a-z]/) { $File::Find::prune = 1}

#skip unless the dir contains '_vti' at the beginning
unless($File::Find::dir =~ /^_vti/) { return }

# find perl mods
my @files;
find sub { push @files, $File::Find::name if -f _ && /\.pm$/ }, @INC; print join "\n", @files;

# file perms
# Because the mode contains both the file type and its permissions, you should mask off the file type portion and
# (s)printf using a "%o" if you want to see the real permissions.
find( \&FixMode, '.' );
sub FixMode {
	my $mode;
	$mode = (lstat)[ 2 ]
	and -f _
	and ( ( $mode & 02 ) == 02 or ( $mode & 020 ) == 020 )
	and chmod( ( $mode & 0755 ), $_ )
}

#  dirs that have more old files then new files.
my %ages;
find \&wanted, "/home/jkipp/rpmbuild";
sub wanted {
	return unless -f $_;
	my $old_flag = -M $_ > 90 ? 'old':'new';
	$ages{$File::Find::dir}{$old_flag}++;
}
for my $dir (sort keys %ages) {
	if ($ages{$dir}{old} > $ages{$dir}{new}) {
		print "$dir has more old than new\n";
	}
}

# find files that begin with the same 1000 bytes and consider them dups
# put them into an array by giving them the same checksum (flag), skip non dup  files
use Digest::MD5;
use constant BUF_SIZ => 1_000;
my $dir = shift || '.';
my %files;
find sub {
# If "stat" is passed the special filehandle consisting of an  underline, no stat is done, but the current contents of the stat
# structure from the last "stat", "lstat", or filetest are returned.
	stat;
	return unless -f _ or -s _ >= BUF_SIZ;
	# skip . and .. 
	open my $fh, '<:raw', $_ or do {
		warn "Cannot open '$File::Find::name' $!";
		return;
	};
	read $fh, my $data, BUF_SIZ or do {
		warn "Cannot read '$File::Find::name' $!";
		return;
	};
	# the hash key is the md5 hash that is created
	# the add method appends data to the msg to calculate a hash for
	# the hexdigest method returns the digest for the msg in hex format
	# duplicate files are pushed on the an array (they have the same
	# key(the hex digest). non dup files are pushed onto their own array
	push @{ $files{ Digest::MD5->new->add( $data )->hexdigest } }, $File::Find::name;
}, $dir;
