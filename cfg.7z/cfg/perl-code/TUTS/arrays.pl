#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/arrays.pl"
# LAST MODIFICATION: "Mon, 02 Mar 2020 14:11:36 -0500 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
use strict;

# find the index value for an array
@teams = qw(Miami Oregon Florida Tennessee Texas 
            Oklahoma Nebraska LSU Colorado Maryland); 
%rank = map { $teams[$_], $_  } 0 .. $#teams;
#print "$_ -> $rank{$_}\n" for keys %rank;
print "\n\n";
print "Colorado: $rank{Colorado}\n"; 
print "Texas: $rank{Texas}\n"; 
# get rid of dups
%temp = ();
@list = grep ++$temp{$_} < 2, @list;
# check for existence of an element
# one way:
if (grep {$_ eq $item} @myarray) { .. )
# another way, convert to hash
%myhash = map {$_ => 1} @myarray;
if exists $myhasg{$key};
# remove certain elements of a list
my %temp;
# put entire list as the keys in a hash slice (values are undef)
@temp{@list} = ();
@bad = qw ( foo bar );
foreach (@bad) {
    delete $temp{$_};
}
@list = sort keys %temp;
# compare arrays, a few ways:
%seen = ( );                    # lookup table to test membership of B
@aonly = ( );                   # answer
# build lookup table
foreach $item (@B) { $seen{$item} = 1 }
# find only elements in @A and not in @B
foreach $item (@A) {
    unless ($seen{$item}) {
        # it's not in %seen, so add to @aonly
        push(@aonly, $item);
    }
}

##--####
my %seen;     # lookup table
my @aonly;    # answer
# build lookup table
@seen{@B} = ( );

foreach $item (@A)
{
    push(@aonly, $item) unless exists $seen{$item};
}

##--####
my %seen;
@seen {@A} = ( );
delete @seen {@B};
my @aonly = keys %seen;


