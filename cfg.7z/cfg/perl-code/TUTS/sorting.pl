#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/sorting.pl"
# LAST MODIFICATION: "Fri, 24 Apr 2020 15:50:14 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$

# READ THIS:  http://www.stonehenge.com/merlyn/UnixReview/col06.html

@in = qw (100 45 234);
@ina = qw ( time space dimension );
@out = sort { $a <=> $b } @in; # numeric sort 
@out = sort { $b <=> $a } @in; # reverse numeric sort
@out = sort { $a cmp $b } @ina; # non numeric sort
print "@out\n";

my @IPS = qw(10.10.23.1 10.20.25.1 10.20.23.18);
my @sorted_IPs = map( {substr($_, 4)} sort map {pack('C4', /(\d+)\.(\d+)\.(\d+)\.(\d+)/) . $_} @IPS );
print "@sorted_IPs\n";
