#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/hash.pl"
# LAST MODIFICATION: "Wed, 22 Apr 2020 13:30:13 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
#use strict;

# build a hash from the elements of an array
@foo = qw ( a b c );
my %foo = map {$_ => 1} @foo;
print "$_ => $foo{$_}\n"  for keys %foo;

# build a hash in the slice method
@h{"Foo", "Bar", "Mamadoo", "Toto", "Lulu", "Momo"} = (1, 2, 3, 4, 5, 6);

# map an array to a hash 
@teams = qw(Miami Oregon Florida Tennessee Texas Oklahoma Nebraska LSU Colorado Maryland);
%rank = map { $_, $teams[$_] } 0 .. $#teams;
for my $key ( sort keys %rank) { #see what we have so far
	print "$key->$rank{$key}\n"
}
# play around a little more
print "$key -> $rank{$key}\n" for $key (keys %rank);
print "$_ -> $rank{$_}\n" for sort keys %rank;
print "\n\n";
print "Colorado: $rank{Colorado}\n"; 
print "Texas: $rank{Texas}\n"; 

# now the hard shit
%some_hash = ();          
*some_hash = fn( \%rank );
print "$_ => $some_hash{$_}\n" for sort { $some_hash{$a} <=> $some_hash{$b} } keys %some_hash;
sub fn {
        local *hashsym = shift;
        # now use %hashsym normally, and you  will affect the caller's %another_hash
        my %nhash = %hashsym; # do what you want
        return \%nhash;
}

# using hash to build freq tables. all you gotta do is iterate the key and print when done
while ($word = < DATA > ) {
      chomp $word;
      $freq{$word}++;
}
print $freq{'happy'} ;

__DATA__
happy
sad
elated
happy
pissed
peave
