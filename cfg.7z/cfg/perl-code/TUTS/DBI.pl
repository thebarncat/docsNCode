#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/DBI.pl"
# LAST MODIFICATION: "Mon, 02 Mar 2020 14:53:19 -0500 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
#use strict;


#Creating  Tables:

my $cs = "CREATE TABLE employee_Info (primary_key INT AUTO_INCREMENT NOT
NULL, name CHAR(20), surname CHAR(20), employee_no CHAR(10), shoe_colour
CHAR (10), PRIMARY KEY (primary_key))";
my $sth = $db->prepare($cs) or print"Prepare fails ".DBI::errstr."\n";
$sth->execute() or print"Execute fails ".DBI::errstr."\n";
$sth->finish;
$db->do ("INSERT INTO Employee_Info (primary_key, name, surname,
shoe_colour, employee_no) values (1,'Ambraal','Bruce','White', '9536826')")
or print"Insert 1 fails ".DBI::errstr."\n";
$db-> do("INSERT INTO Employee_Info (primary_key, name, surname,
shoe_colour, employee_no) values (2, 'September', 'John',
'Pink','9536456')")or print"Insert 2 fails ".DBI::errstr."\n";
$db->do("DELETE FROM Employee_Info WHERE shoe_colour = 'Pink'") or
print"Delete fails ".DBI::errstr."\n";
$db->do("UPDATE Employee_Info SET name = 'August' WHERE primary_key = 2")or
print"Update fails ".DBI::errstr."\n";

#Inserting with Placeholders

$sth = $dbh->prepare("INSERT INTO table(foo,bar,baz) VALUES (?,?,?)");
  while(<CSV>) {
    chomp;
    my ($foo,$bar,$baz) = split /,/;
        $sth->execute( $foo, $bar, $baz );
}

# to avoid having to write too many "?" , do this way
my @values = (
    $datetime, $conf_number, $name_logger, $phone_logger, $email_logger, 
    $logging_start, $acres );
my $placeholders = join(', ', ('?') x @values) ;
# the first arg is undef because the "fields" do not need to be specfied, see the 
# syntax for INSERT statement. do() returns the number of rows affected
my $rv = $dbh->do("INSERT INTO logger VALUES ($placeholders)", undef, @values );

#Inserting and retrieving Time and Date:

# this is how to insert the system date into a feild, don't do it in the execute statement, do it in the prepare
my $sth = $dbh->prepare( "INSERT INTO stats VALUES (SYSDATE,?,?,?,?)" )
        or die "Cannot prepare SQL statements from $DBI::errstr\n";
foreach (@stats){
        chomp;
        ($host, $user $cpu_pct, $mem_pct = split( /,/ );
        $sth->execute( $host, $user $cpu_pct, $mem_pct );
}

# using the TO_DATE func which converts the string format into an oracle date
my $sth = $dbh->prepare( INSERT INTO order_details (OrderID, ProductID, UnitPrice, Quantity,
				Discount, OrderDate, ProductName) 
				VALUES (5,1,1,1,1,TO_DATE ('4/01/1953', 'MM/DD/YYYY'),'name')  )
     		or die "Cannot prepare SQL statements from $DBI::errstr\n";

# USING THE TO_CHAR FUNC WHICH CONVERTS THE DATE TO THE STRING YOU WANT
$sql = "SELECT to_char(myDate,'YYYY/MM/DD HH24:MI:SS') from table .... ";

#Query Examples:

# using the oracle concat func
my $sth = $dbh->prepare(qq( SELECT  agentID, concat(lastname, ', ', firstname) as username FROM users ) );
$sth->execute(); 

# use the following SQL-statement to select a random record 
$sql = "SELECT * FROM atable ORDER BY RAND() LIMIT 1";
# good qry using to_char, sums, and grp by
my $_sql = qq{ SELECT username,  to_char(sample_Date, 'YYYY') ,  to_char(sample_date, 'IW') , sum(cpu) , sum(IO)
                          from stats
                          group by username, to_CHAR(sample_date, 'IW') , to_char(sample_Date, 'YYYY')
                          order by 1,2 
			 };

# Bind Columns:
#Instead of returning a list of row elements, the DBI 
#stores the values in bound scalars. This is very fast, as it 
#avoids copying returned values, and can simplify code greatly
my $table = 'users';
my @fields = qw( name email );
my %results;
my $fields = join(', ', @fields);
my $sth = $dbh->prepare("SELECT $fields FROM $table");
$sth->execute();
# slice %results with @fields to initialize the keys
# The map in the bind_columns() call creates a reference to the hash value 
# associated with each key in @fields. 
@results{@fields} = ();
$sth->bind_columns(map { \$results{$_} } @fields);
while ($sth->fetch()) {
	print "$results{name} <$results{email}>\n";
}
$sth->finish();

# USING CGI PARAMS

# have a checkbox that passes the selected 'hosts' to my CGI script. So i
# collected the params with: my @hosts = $q->param('host');
# so if the user selects (in the checkbox) hosts: a,b,c ,how can tell the
# query to look for all hosts matching the selections? 
# dynamically generate a list of placeholders and then call execute() with
# the list of values.
   $dbh -> {$RaiseErrors} = 1; # Always check for errors
   my $sWhere = "WHERE host in (" . join( ",", map { "?" } @hosts ) . ")";
   my $sth = $dbh -> prepare( "SELECT col, col FROM table $sWHERE" );
   $sth -> execute( @hosts );

#Meta Data:
   
# RETRIEVING THE COLUMN NAMES
# a reference to an array containing one hashref per result row and, 
# again, an array containing the names of all your columns.
my $sql = "SELECT * FROM FOO";
my $arrayref = $dbh->selectall_arrayref($sql, { Columns => {} });
my @names;
foreach my $key (keys %{$arrayref[0]}){
    push @names, $key;
}

#Once a statement is prepared and executed, DBI stores the following pieces of information as attributes of the statement handle:
$DBI::rows
#The number of rows affected or returned
$sth->{NUM_FIELDS}
#The number of fields returned by a select
$sth->{NUM_PARAMS}
The number of parameters returned by any query After a select query, the following attributes contain references to arrays of field-specific information:
$sth->{NAME}
#Column names returned by the query
$sth->{NULLABLE}
#Booleans indicating whether fields are nullable or not
$sth->{TYPE}

#Field types
$sth->{PRECISION}
#Floating-point precision of field
$sth->{SCALE}
#Field lengths

#Sequences, Triggers, and Advanced:

# PROCEDURE TO AUTO INCREMENT USING SEQUENCES
my $sth = $dbh->prepare("insert into "table" values (?, ?)");
my $insert = $dbh->prepare(<<"SQL");
Declare vID Integer;
select vID = seq.nextval from dual;
insert into "table" values ( vID, ?);
select vID from dual;
SQL
# if you don't know which value you just inserted, you can get at it with 
# "select seq.currval from dual" 
$insert->execute( $foo );
# even simpler
$sth->prepare("insert into foo (my_id, data) values (my_id_seq.nextval, ?)");
  $sth->execute('bar');

#Embedding PL/SQL:

# This is an oracle thing, calls the oracle function for you
$dbh->func(1000000, 'dbms_output_enable') || die $dbh->errstr;
################## Prepare SQL Statements ################################
my $SQL_getDate = q
{
 DECLARE
  today  varchar2(20);
 BEGIN
  SELECT sysdate into today from dual;
  DBMS_OUTPUT.PUT_LINE('Today is ' || today);
 END;
};
my $csr_getDate = $dbh->prepare ($SQL_getDate);
#########################################################
### If you KNOW there's only one statement:
$csr_getDate->execute();
my $text = $dbh->func('dbms_output_get');
print "\n$text\n\n"

#Cancel  a procedure ( time out)  :

# test $sth->cancel() implementation
$db = DBI->connect("dbi:Oracle:middev",'ops$jkipp','diamond', \%attr)
  or die "Cannot open $DBI::errstr\n";
my $q = $db->prepare ("begin loop null; end loop; end;");
$SIG{ALRM} = sub { print "Alarm\n"; $q->cancel; print "Cancelled\n"; };
alarm 5;
$q->execute();
$db->disconnect;
 
