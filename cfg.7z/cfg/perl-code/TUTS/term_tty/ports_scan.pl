#!/usr/bin/perl -w

#script for scannning of open socket on ports.
use IO::Socket;
use IPC::Open2;
use Term::ANSIColor;
use POSIX ":sys_wait_h";

my ($port, $sock, @servers);
my $pid = 0;
my($server, $begin, $end) = @ARGV;

usage() if (!$server);
$begin = 0 if (!$begin);
#$end = 65000 if (!$end);
$end = 1024 if (!$end);

print "Scanning from $begin to $end\n";
my $status;
$pid = fork;
# if we sucessfully spawned a kid, go ahead with it
if ($pid != 0) {
    for ($port=$begin; $port<=(($begin + $end)/2); $port++) {
		scan();
		if ($sock) {
		     print color 'bold blue';    
	         print "$$ Connected on port $port\n";
		} else {
		    print color 'bold blue';
	        print "$$ $port not connected\n";
		}
    }
    my $childpid;
    while ($status = waitpid(-1, WNOHANG)> 0) {
    	wait;
    }
}
else
{
	for ($port=($end/2)+1;$port<=$end;$port++){
		scan();
		if ($sock) {
	    	print color 'bold white';
    	    print "$$ Connected on port $port\n ";
		} else {
	    	print color 'bold white';
            print "$$ $port not connected\n";
		}
    }
}

sub usage{
    print "Usage: portscan hostname [start from port  to port number]\n";
	exit(0);
}

sub scan{
    $sock = IO::Socket::INET->new(PeerAddr => $server,
                                  PeerPort => $port,
                                  Proto => 'tcp');
}
													    

