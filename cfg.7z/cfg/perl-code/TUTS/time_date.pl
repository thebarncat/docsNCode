#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/time_date.pl"
# LAST MODIFICATION: "Mon, 02 Mar 2020 14:30:20 -0500 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
#use strict;

# simple date formatting using localtime
my ($day, $month, $year) = (localtime)[3,4,5];
my $date = sprintf("%04s-%02s-%02s", $year+1900, $month+1, $day);
# another way with localtime
my @date = localtime (time); 
my $datestr = sprintf "%02u/%02u/%04u", $date[4]+1, $date[3], $date[5]+1900;
 
# Adding and subtracting days 
=cut
1 hour 3600 
1 day 86400 
1 week 604800 
2 weeks 1209600 
3 weeks 1814400 
1 month 2419200 
6 months 14515200 
1 year 29030400 
1 decade 290304000 
=cut
$now=time;
$when = 86400; # 1 day
$tomorrow = $now + $when;
print scalar localtime($tomorrow);

# map future and previous DOW for today
use POSIX;
$t = time();
# advance the date until the next saturday
$t += 86400 while strftime("%A", localtime($t)) ne 'Saturday';
# count back each day from next saturday, back 21 days and print DOW for each date
print map {strftime("%m/%d/%Y %A\n", localtime($t-86400*$_))} (0..21);

# Some more one with POSIX strftime
# $date = strftime("%d %b %y", localtime());
# $today = strftime "%Y-%m-%d", localtime;
print "Timestamp: ", strftime('%m/%d/%Y %H:%M:%S', localtime), "\n";

my $dyear  = strftime "%j", localtime;
my $wyear = strftime "%W", localtime;

# another strftime example
my $time = time;
my @d = localtime $time;
my $date = strftime "%Y-%m-%d", @d;
my $time_now = strftime "%H:%M:%S", @d;
@d = localtime $time - 3600;
my $time_hour_ago = strftime "%H:%M:%S", @d;
print "date=$date, now=$time_now, hour ago = $time_hour_ago\n";

# map num of days into the year, with the actual date 
use Time::Local;
my $day_number = 32;
my @months = qw( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );
my $current_year = (localtime(time))[5];
my $year_start_time = timelocal (0, 0, 0, 1, 0, $current_year);
my $target_time = $year_start_time + ($day_number - 1) * 60 * 60 * 24;
my ($day, $month, $year) = (localtime($target_time))[3..5];
printf "%s %d, %d\n", $months[$month], $day, $year + 1900;

# DOW, adding + subtracing dates
# note: $m is month-1, $y is year-1900
# 2005-08-08, today's date
my ($d, $m, $y) = (8, 7, 105);
# build the date string for time at noon on above date
my $day_at_noon = timelocal(0,0,12, $d, $m, $y);
# find day of the week
my $dow = (localtime $day_at_noon)[6];
# In this case, $dow is 1.  This means that to get the Y/M/D for Sunday, 
# we need to subtract 1 * 86400 (seconds in a day) from $day_at_noon.  
# To get the Y/M/D for Saturday, we must add 5 * 86400 to $day_at_noon:
my $sunday = $day_at_noon - $dow * 86400;
my $saturday = $day_at_noon + (6 - $dow) * 86400;
# GET number day of year: 
$day_of_year = (localtime)[7];

# Given the month and year, derive what d.o.w the first lands on
#use Time::Local;
my ($mon, $year) = (11, 2001);
my $first = timelocal(0,0,0, 1, $mon-1, $year-1900);
my $dow = (localtime $first)[6];
my $day = (qw( Sun Mon Tues Wednes Thurs Fri Satur ))[$dow] . "day";

# get date of x days before today
use Time::localtime;
# 5 days before
$x = 86400 * 5;
$ago = ctime( time() - $x );
print $ago;

# getting d.o.w and dates around a given date
use Date::Calc qw/ Day_of_Week Add_Delta_Days /;
my @days = (undef, qw/ Mon Tue Wed Thur Fri Sat Sun /);
# get user supplied date to start with
if ($ARGV[0] !~ /^\d{4}-\d{2}-\d{2}$/) {
	die "Date given must be in YYYY-MM-DD form.\n";
}

my @ymd = split /-/, $ARGV[0]; # year,month,day
my $dow = Day_of_Week @ymd;

my $mon = sprintf "%s-%02s-%02s", Add_Delta_Days @ymd, 1 -($dow==1 ?  8:$dow);
my $sun = sprintf "%s-%02s-%02s", Add_Delta_Days @ymd, 7 -($dow==7 ?  0:$dow);

print "Given Date:      $ARGV[0] $days[$dow]\n";
print "Previous Monday: $mon\n";
print "Next Sunday:     $sun\n";

# getting what number day of the year
print "Today is day ",(localtime)[7]," of the year.\n";

