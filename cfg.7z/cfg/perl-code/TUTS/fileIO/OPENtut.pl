#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/fileIO/OPENtut.pl"
# LAST MODIFICATION: "Fri, 08 May 2020 12:49:51 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
#use strict;

# simple STDOUT redirect 
#open(STDOUT, ">logfile" or die "cant redirect STDOUT");
# open returns nonzero on success,  undefined value otherwise
# note that ``<&STDIN'' makes a copy, but ``<&=STDIN'' make an alias. if you close an aliased handle, all aliases become inaccessible.  not true with a copied one
#
# checkout IO::Handle   

# dup a file handle
# https://www.perlmonks.org/?node_id=750805
# https://www.perlmonks.org/?node_id=524435
open(my $fh, ">", "temp/dup.txt") or die "Can't open: $!";
open(my $fh2, ">&", $fh) or die "Can't dup filehandle: $!";
print $fh "hi there on\n";
print $fh2 "hi there on 2\n";

my $USER = $ENV{USER};
print  "$USER\n";

# can just switch file handles
# https://www.perl.com/article/45/2013/10/27/How-to-redirect-and-restore-STDOUT/
open LOG, ">temp/log.txt" or die "Cant open log file $!";
select LOG;
print "USER\n";
select STDOUT;
print "USER2\n";

# write to a file and STDOUT
open my $tee, "|-", "tee temp/file.out";
print $tee "choo choo\n";
close $tee;
# or like this:
{
	local *STDOUT;
	open(STDOUT, "| tee temp/tee.txt") or die "Couldn't pipe: $!";
	print  "w00p w00p\n";
	close(STDOUT);
}

# or like this
myprint(*LOG, "wtf\n");
sub myprint {
	my $handle = shift;
	for my $fh (*STDOUT, $handle) {
		print $fh @_;
	}
}

# use shell file-descriptor redirection to make STDERR a duplicate of STDOUT:
my $cmd = "df /home";
$out = `$cmd 2>&1`;
print $out;
print "--------\n";

open (P, "$cmd 2>&1 |") or die "can't pipe: $!";
print "$_" while (<P>); 
close P;

print "--------\n";

# a pipe open will fork
my $pid = open (my $read_fh, "-|", $cmd) or die "can't fork $!";
if ($pid) { 
	my $line = <$read_fh>;
	print "parent pid $$ read: $line";
	waitpid $pid, 0;
	close $read_fh;
} else {
	print "i am the pid $$ kid\n";
	exit;
}

my $dst = 'temp/dst';
pass_fh($dst);
#function that takes two filenames
sub pass_fh {
    my ($dst) = @_;
    local (*DST);
    open DST, "> $dst" or die "Can't write $dst: $!";
	print DST "howdy\n";
    close DST;
}

# stderr: https://perldoc.perl.org/perlfaq8.html#How-can-I-capture-STDERR-from-an-external-command%3f
{
	local *STDERR;
    open STDERR, '>temp/err' or die $!;
	warn "error!\n";
	close STDERR;
}




