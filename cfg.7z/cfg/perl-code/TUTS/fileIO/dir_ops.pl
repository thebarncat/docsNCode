#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/fileIO/dir_ops.pl"
# LAST MODIFICATION: "Thu, 23 Apr 2020 11:22:18 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
use strict;
use File::Path; 
use File::Find;

# get dir size in bytes
my $dirsize = 0;
find(sub {$dirsize += -s $_}, ".");
print "$dirsize\n";
print "\n";
# sort dir contents
opendir(DIR,".." ) || die $!;
# like the order of ls
foreach my $dir (sort {lc($b) cmp lc($a)} readdir(DIR)) {
	print "$dir\n";
}
closedir(DIR);
print "\n\n";

# recurse directory
use File::Spec;
#scan_dir($ARGV[0]);
scan_dir("..");
my @dirstack;
sub scan_dir {
   my $dir = shift;
   return unless -d $dir;
   my @subdirs;
   opendir DIR, $dir or die "Can't open directory ($dir): $!\n";
   while (my $file = readdir DIR) {
     next if $file eq File::Spec->curdir() or $file eq File::Spec->updir();
     my $path = File::Spec->catfile($dir, $file);
     if (-d $path) {
       push @subdirs, $file;
       next;
     } else {
       # => do something here <= #
       print "$path\n";
     }
   }
   closedir DIR;
   foreach my $subdir (@subdirs) {
     push @dirstack, $subdir;
     scan_dir(File::Spec->catdir($dir, $subdir));
     pop  @dirstack;
   }
}
print "\n\n";

# find file with txt extension
use File::Basename;
my $folder = ".";
opendir(DIR, $folder) || die "Didn't find folder";
foreach my $FileName (sort readdir(DIR)) {	# list context, sorted 
	# Split the file name into the name and extension
	my $ext = (fileparse($FileName,'\..*'))[2];
	$ext =~ s/^\.//; #Strip the first "." from the extension
	if ($ext eq "txt") {  #Then this is a file to attempt to process
		print "$FileName\n";
	}
}	
closedir(DIR);
