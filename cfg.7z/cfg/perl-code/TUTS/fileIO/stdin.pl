#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/fileIO/stdin.pl"
# LAST MODIFICATION: "Thu, 23 Apr 2020 10:46:41 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
# $Id:$
#use strict;

# reads STDIN and files as input eg ./prg.pl file1 file2; echo "hi"| ./stdin.pl 
=cut
while (<>) {
	 print;
}

# like above but do things at EOF  
while (<>) {
      print;
      print "--- End of $ARGV ----\n" if eof;
}

=cut

# slurp stdin
my @lines=(<>);
print @lines;


