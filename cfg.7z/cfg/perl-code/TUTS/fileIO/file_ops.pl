#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/fileIO/file_ops.pl"
# LAST MODIFICATION: "Wed, 22 Apr 2020 17:16:38 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>
use warnings;
use Fcntl;

my $out = 'out.txt';
open FILE, ">$out" or die "Cannot open $!";
print FILE <<TEXT;
1234567
wtf
TEXT

my $bin = "fg";
# open file for rw
sysopen(OUTFILE, "out.txt", O_WRONLY) or print "Couldn't open file: $!";
binmode OUTFILE;
# seek  3 bytes from beggining of file
sysseek OUTFILE, 3, 0;
# change out.txt from "1234567" to "123fg67"
syswrite OUTFILE, $bin, length($bin);
close OUTFILE;

open(ZZ,"+>zz") or die "Can't open zz: $!"; # rw,create
binmode ZZ;
# write some random binary data
for(0..19){
	$array[$_]= 2 * $_;
	# pack into little endian binary (unsigned long)
	$array1[$_]= pack ("L*",$array[$_]);
	print ZZ $array1[$_];
}
close ZZ;

$/= undef;
open (ZZ, "<zz") or die $!;
binmode ZZ;
my $file = <ZZ>; 
my @nums = (unpack "L*",$file);
print "@nums\n";
close ZZ;

my $cnt=0;
$cnt = wc('out.txt');
sub wc {
    my $file = shift;
    my $numlines;
    open(FILE,"$file") or die "$file :$!";
    $numlines += tr/\n/\n/ while sysread(FILE, $_, 2 ** 16);
    return($numlines);
}

# seek to beginning and insert 
use Fcntl ':seek';
my $filex = 'out.txt';
# open file rw with no create mode
open FILE, "+< $filex" or die "Cannot open $file: $!";
my @lines = <FILE>; # slurp current contents
seek(FILE, 0, SEEK_SET) or die "Cannot seek on $file: $!";
print FILE <<TEXT, @lines; # avoids truncation
This is the new line one.
This is the new line two.
TEXT

# seek to 50, read 8
$pos = 10;
$len = 8;
open F, "<out.txt" or die "can't read: $!";
seek F, $pos, 0;  
{
  # set record seperator to byte length 
  local $/ = \$len;  # number of bytes you want to read
  my @chars = split //, <F>;
  print @chars;
}
close F;

