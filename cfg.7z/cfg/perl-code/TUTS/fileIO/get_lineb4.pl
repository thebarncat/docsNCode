#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/TUTS/fileIO/get_lineb4.pl"
# LAST MODIFICATION: "Fri, 15 May 2020 10:17:41 -0400 (jk24445)"
# (C) 2020 by Jim Kipp, <kippjimmy@yahoo.com>

use strict;
use POSIX;

my $STAMP = strftime('%m-%d-%Y@%H:%M:%S', localtime);
my $OUTF = "/site.out.$STAMP";

#open(OUT, "<", "$OUTF") or die "cant open file: $!";
my $lineb4;
while ( my $line = <DATA>) {
    if ($line =~ /"msg":\s+"WARN|FAIL|ERROR|UNREACHABLE/) {
        $msg .= $lineb4.$line;
    }
    $lineb4 = $line;
}

__DATA__
ok: [cgvd1ldtscp001m] => {
    "msg": "WARN - cgvd1ldtscp001m - SELinux is not set to enforcing!!"
}
ok: [cgvd1ldtscp002m] => {
    "msg": "WARN - cgvd1ldtscp002m - SELinux is not set to enforcing!!"
}
ok: [cgvd1ldtsen001m] => {
    "msg": "WARN - cgvd1ldtsen001m - SELinux is not set to enforcing!!"
}
ok: [cgvd1ldtsen002m] => {
    "msg": "WARN - cgvd1ldtsen002m - SELinux is not set to enforcing!!"
}
ok: [cgvd1ldtsmt001m] => {
    "msg": "WARN - cgvd1ldtsmt001m - SELinux is not set to enforcing!!"
}
