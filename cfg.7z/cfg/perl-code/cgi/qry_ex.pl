#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/CGI/qry_ex.pl"
# LAST MODIFICATION: "Mon, 13 May 2013 09:43:05 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;
# interface to connect to the database and query
# does all the error checking on connection, auth, query strings before letting
# the actual execution script run
# NEED to write the form to call this 
use CGI qw(:standard);
use CGI::Carp qw(fatalsToBrowser); # used for testing
use DBI;

my $q = new CGI;

my($x, $usr, $pwd, $dsn, $sql);
$x = $q->param('x'); # hidden param: use as flag to execute
$usr = $q->param('usr');
$pwd = $q->param('pwd');
$dsn = $q->param('dsn');
$sql = $q->param('sql');

# default to:
$x = '' unless defined($x);
$usr = 'jkipp' unless defined($usr); # default schema for this project
$pwd = '' unless defined($pwd); 
$dsn = 'dbi:Oracle:middev' unless defined($dsn); 

# connect to database
my $dbh = DBI->connect($dsn, $usr, $pwd, {LongReadLen => 1024} ) #some of our fields are real long!
	or die "Cannot open $DBI::errstr\n";

# If statements are entered on new lines split them into an array execute them in sequence	
my @sql = split(/;(\n|\r\n)+/, $sql); 
my $sth; 
if (scalar(@sql) > 1) {
	foreach  my $tsql (@sql) {
		$tsql =~ s/^\s+|\s+$//;
		$sth = $dbh->prepare($tsql) || die "Cannot prepare SQL statements: $DBI::errstr\n";
		$sth->execute();
	}
	
} else {
	# prepare single statement
	$sth = $dbh->prepare($sql) or die "Cannot prepare SQL statements: $DBI::errstr\n";
	$sth->execute() 
}

print_results();

$dbh->disconnect;

sub print_results {
	print qq{<tr><td bgcolor="#006699"><font face="verdana" size="1" color="#ffffff">R E S U L T S
	<br></font></td></tr><tr><td bgcolor="#eeeecc"><table cellspacing="1"
	cellpadding="3" border="0"><tr bgcolor="#0099cc">};

	# this hanlde atrrib contains the columns to be returned by a select 
	for (my $i = 0; $i < $sth->{NUM_OF_FIELDS}; $i++) {
		# the NAME attrib contains the names of the columns
		print qq{<td><font face="verdana" size="1" color="#ffffff">$sth->{NAME}->[$i]</font></td>};
	}
	print qq{</tr>};

	while (my @row = $sth->fetchrow_array) {
		print qq{<tr bgcolor="#ffffff">};

		foreach (@row) {
			$_ = '<code>(null)</code>' unless defined($_);
			print qq{<td><font face="verdana"
            size="1">$_</font></td>};
		}

		print qq{</tr>};
	}

	# get rows and display count
	my $rows = $sth->rows;
	my $rows_affected = ($rows > 0 ? "<b>$rows</b> row(s) affected" : "(no rows affected)");

	print qq{</tr></table><font face="verdana"
    size="2"><br>$rows_affected<br></font></td></tr>};
	print qq{</table></form></body></html>}; 
}
