#!/usr/bin/perl
#
use strict;

my $hmc_server_name = "bprdelxhmc02";

#Verify the script was called with 1 argument (HMC name)
=cut
if ($#ARGV + 1 == 1 ) {
  $hmc_server_name = $ARGV[0]
}else{
  print "Specify HMC name as an argument\n";
  exit 1;
}
=cut

#%lshwres_slots is a hash that will store the output of the "lshwres" HMC command
my %lshwres_slots = ();

#lsmap_slots is a hash that will store the output of the "lsmap" VIO command
my %lsmap_slots;

#declare variables
my (@output, @output2, @output3, $line, $line2, $line3, @managed_systems);
my ($system_status, @lpar_list, $lpar_info, $out1, $out2, $previous_lpar);

#Colors to use in HTML output
my $color1 = "F0F8FF";
my $color2 = "F5FFFA";    
my $color3 = "F5F5F5";    
my $color4 = "FFF8DC";    

print "<html><body>\n";
#Get list of managed systems from HMC
@managed_systems = `ssh -q -o "BatchMode yes" $hmc_server_name lssyscfg -r sys -F "name,state" | sort`;
#Loop for each managed system
foreach $system_status (@managed_systems){
  chomp($system_status);
  if ($system_status =~ /(\S+),Operating/){  #Only look at running systems
    my $system = $1;
    %lshwres_slots = ();
    %lsmap_slots = ();
    $previous_lpar = "";
    get_lshwres($system);                  #Collect HMC inforamtion for this system
    if (keys %lshwres_slots == 0) {next;}  #skip managed system if lshwres didn't have any output
      #Start building the HTML table
      print "<table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bordercolor=\"#000000\">\n";
      print "<tr><th colspan=\"14\" bgcolor=\"$color3\"><h2>$system</h2></th></tr>\n";
      print "<tr><th width=\"125\" bgcolor=\"$color3\">LPAR Name</th>\n";
      print "<th width=\"45\" bgcolor=\"$color3\">LPAR ID</th>\n";
      print "<th bgcolor=\"$color3\" width=\"60\">LPAR hdisk</th>\n";
      print "<th bgcolor=\"$color3\" width=\"60\">LPAR VSCSI</th>\n";
      print "<th bgcolor=\"$color3\" width=\"60\">LPAR slot</th>\n";
      print "<th bgcolor=\"$color3\" width=\"125\">VIO Name</th>\n";
      print "<th bgcolor=\"$color3\" width=\"45\">VIO ID</th>\n";
      print "<th bgcolor=\"$color3\" width=\"60\">VIO vhost</th>\n";
      print "<th bgcolor=\"$color3\" width=\"60\">VIO slot</th>\n";
      print "<th bgcolor=\"$color3\" width=\"90\">VIO device name</th>\n";
      print "<th bgcolor=\"$color3\" width=\"125\">VIO backing device</th>\n";
      #print "<th bgcolor=\"$color3\" width=\"150\">hdisk LUN ID</th>\n";
      print "<th bgcolor=\"$color3\" width=\"150\">Backing Z1</th>\n";
      print "<th bgcolor=\"$color3\" width=\"150\">Backing Model/Type</th>\n";
      print "<th bgcolor=\"$color3\" width=\"275\">VIO backing hdisk serial</th></tr>\n";

      #Get a list of LPAR's that are on this managed system including their type and state.
      @lpar_list = `ssh -q -o "BatchMode yes" $hmc_server_name 'lssyscfg -m $system -r lpar -F "name,lpar_env,state" | sort'`;
      #Loop through each LPAR and find all running VIO servers
      foreach $lpar_info (@lpar_list){
        if ($lpar_info =~ /(\S+),(\S+),(.*)/){
          my $client_name = $1;
          my $client_type = $2;
          my $client_state = $3;
          if ($client_state eq "Running"){
            if ($client_type eq "vioserver"){
              #Collect lsmap information from this VIO server
              get_lsmap($system, $client_name);
            }
          }
        }
      }

      #Loop through each LPAR and find all running AIX servers
      foreach $lpar_info (@lpar_list){
        if ($lpar_info =~ /(\S+),(\S+),(.*)/){
          my $client_name = $1;
          my $client_type = $2;
          my $client_state = $3;
          if ($client_state eq "Running" && $client_type eq "aixlinux"){
            #Get the client information from this LPAR
            get_client_info($client_name);
          }
        }
      }
      #End the table
      print "</table><br/><br/><br/>";
   }
}

print "</body></html>\n";


sub get_lshwres {
  my $managed_system = $_[0];
  #Run the lshwres command on the HMC server
  @output = `ssh -q -o "BatchMode yes" $hmc_server_name 'lshwres -r virtualio --rsubtype scsi -m $managed_system -F lpar_name,lpar_id,slot_num,adapter_type,remote_lpar_id,remote_slot_num'`;
  #Loop through each line of output
  foreach $line (@output){
    my ($lpar_name,$lpar_id,$slot_num,$adapter_type);
    my ($remote_lpar_id,$remote_slot_num);
    #Regular expression to capture the data out of the output
    if ($line =~ /(\S+),(\d+),(\d+),(\S+),(\d+),(\d+)/){
      $lpar_name = $1;
      $lpar_id = $2;
      $slot_num = $3;
      $adapter_type = $4;
      $remote_lpar_id = $5;
      $remote_slot_num = $6;
      if ($adapter_type eq "server"){       #We are only interested in server adapters
        #The hash key is the LPAR_ID.SLOTNUMBER (exapmle:  3.20)
        my $key = "$lpar_id.$slot_num";
        #Add data to the hash
        push(@{$lshwres_slots{$key}}, $lpar_name);
        push(@{$lshwres_slots{$key}}, $lpar_id);
        push(@{$lshwres_slots{$key}}, $slot_num);
        push(@{$lshwres_slots{$key}}, $remote_lpar_id);
        push(@{$lshwres_slots{$key}}, $remote_slot_num);
      }
    }
  }
}

sub get_lsmap{
  my $managed_system = $_[0];
  my $vio_server = $_[1];
  #Run the lsmap command on the VIO server
  @output = `ssh -q -o "BatchMode yes" $hmc_server_name "viosvrcmd -m $managed_system -p $vio_server -c 'lsmap -all -field svsa physloc vtd lun backing bdphysloc status -fmt ,'"`;
  #Loop through each line of output
  foreach $line (@output){
    my ($svsa, $physloc, $vtd, $lun, $backing, $bdphysloc, $status);
    #Loop thourgh each line that matches the regular expression
    while ( $line =~ /(vhost\d+),([^,]*)/gc ) {
      $svsa = $1;
      $physloc = $2;
      while ($line =~ /,(.+?),0x(.+?),(.+?),(.+?),([^,]*)/gc){
        $vtd = $1;
        $lun = $2;
        $backing = $3;
        $bdphysloc = $4;
        $status = $5;
        my $key;
        #Hash key is the LPAR_ID-SLOT-LUNID
        if ($physloc =~ /.*V(\d+)-C(\d+)/){
             $key = "$1.$2.$lun";
        }
        #Add data to the hash
        push(@{$lsmap_slots{$key}}, $svsa);
        push(@{$lsmap_slots{$key}}, $physloc);
        push(@{$lsmap_slots{$key}}, $vtd);
        push(@{$lsmap_slots{$key}}, $lun);
        push(@{$lsmap_slots{$key}}, $backing);
        push(@{$lsmap_slots{$key}}, $bdphysloc);
        push(@{$lsmap_slots{$key}}, $status);
        #If thi backing device is a hdisk, get the serial number of the disk
        if ($backing =~ /hdisk\d+/){
          my ($serial, $z1, $typemodel);
          $serial = $z1 = $typemodel = "n/a";
          @output2 = `ssh -q -o "BatchMode yes" $hmc_server_name "viosvrcmd -m $managed_system -p $vio_server -c 'lsdev -dev $backing -vpd ' "`;
          foreach $line2 (@output2){
            if ($line2 =~ /Serial Number\.+(.*$)/){
              $serial = $1;
            }
            if ($line2 =~ /Device Specific\.\(Z1\)\.+(.*$)/){
              $z1 = $1;
            }
            if ($line2 =~ /Machine Type and Model\.+(.*$)/){
              $typemodel = $1;
            }
          }
          push(@{$lsmap_slots{$key}}, $serial);
          push(@{$lsmap_slots{$key}}, $z1);
          push(@{$lsmap_slots{$key}}, $typemodel);
        }else{
          push(@{$lsmap_slots{$key}}, "n/a");
        }
      }
    }
  }
}

sub get_client_info{
  my $aix_system = $_[0];
  #Get output of lspath
  @output = `ssh -q -o "BatchMode yes" $aix_system 'lspath -F "name,status,parent,connection" | sort'`;
  if (@output == 0){
    print "<tr><td colspan=\"13\" bgcolor=\"$color3\"> &nbsp </td></tr>";
    print "<tr><td colspan=\"13\" bgcolor=\"$color4\">Could not connect to $aix_system</td></tr>\n";
    $previous_lpar = $aix_system;
  }
  #For each line of output
  foreach $line (@output){
    chomp($line);
    #Check and see if the line matches the regular expression
    if ($line =~ /(\S+),(\S+),(\S+),(\S+)/){
      my ($status, $name, $parent,$hdisk_lun_id);
      $name = $1;
      $status = $2;
      $parent = $3;
      $hdisk_lun_id = $4;
      #Different versions of AIX pad this with different amounts of zeros
      #So the line below adds a set amount of zero padding
      $hdisk_lun_id .= 0 x ( 16 - length($hdisk_lun_id));
      #Find the lines that have vscsi adapters
      if ($parent =~ /vscsi\d+/){
        #Run lscfg to find the client id and the client slot of the vscsi adapter
        @output2 = `ssh -q -o "BatchMode yes" $aix_system lscfg -l $parent`;
        foreach $line2 (@output2){
          chomp ($line2);
          if ($line2 =~ /.*V(\d+)-C(\d+)/){
            my $vscsi_client_id = $1;
            my $vscsi_client_slot = $2;
            my $slot;
            #Search through the lshwres_slots hash to find the slot that matches this hdisk
            foreach $slot (keys %lshwres_slots){
              my $lookup = "@{$lshwres_slots{$slot}}[1].@{$lshwres_slots{$slot}}[2].$hdisk_lun_id";
              if ( (@{$lshwres_slots{$slot}}[3] == $vscsi_client_id) && 
                   (@{$lshwres_slots{$slot}}[4] == $vscsi_client_slot) && 
                   (@{$lsmap_slots{$lookup}}[3] =~ /$hdisk_lun_id/) ){
                if ($previous_lpar eq "") { 
                    $previous_lpar = $aix_system;
                }
                if ($aix_system ne $previous_lpar ){
                    print "<tr><td colspan=\"13\" bgcolor=\"$color3\"> &nbsp </td></tr>"
                }
                $previous_lpar = $aix_system;
                #Display the data
                print "<tr>\n";
                print "<td bgcolor=\"$color1\">$aix_system</td>\n";    
                print "<td bgcolor=\"$color1\">@{$lshwres_slots{$slot}}[3]</td>\n";    
                print "<td bgcolor=\"$color1\">$name</td>\n";    
                print "<td bgcolor=\"$color1\">$parent</td>\n";    
                print "<td bgcolor=\"$color1\">@{$lshwres_slots{$slot}}[4]</td>\n";    
                print "<td bgcolor=\"$color2\">@{$lshwres_slots{$slot}}[0]</td>\n";    
                print "<td bgcolor=\"$color2\">@{$lshwres_slots{$slot}}[1]</td>\n";    
                print "<td bgcolor=\"$color2\">@{$lsmap_slots{$lookup}}[0]</td>\n";    
                print "<td bgcolor=\"$color2\">@{$lshwres_slots{$slot}}[2]</td>\n";    
                print "<td bgcolor=\"$color2\">@{$lsmap_slots{$lookup}}[2]</td>\n";    
                print "<td bgcolor=\"$color2\">@{$lsmap_slots{$lookup}}[4]</td>\n";    
                #print "<td bgcolor=\"$color2\">$hdisk_lun_id</td>\n";    
                print "<td bgcolor=\"$color2\">@{$lsmap_slots{$lookup}}[8]</td>\n";
                print "<td bgcolor=\"$color2\">@{$lsmap_slots{$lookup}}[9]</td>\n";
                print "<td bgcolor=\"$color2\">@{$lsmap_slots{$lookup}}[7]</td>\n";
                print "</tr>\n";
              }
            }
          }
        }
      }
    }else {
      print "<tr><td colspan=\"13\" bgcolor=\"$color3\"> &nbsp </td></tr>";
      print "<tr><td colspan=\"13\" bgcolor=\"$color4\">Could not connect to $aix_system</td></tr>\n";
      $previous_lpar = $aix_system;
    }
  }
}
