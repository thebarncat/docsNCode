#!/usr/bin/perl
# Example for sending an Email to a SMTP server from a Perl script

use Mail::Sender;

print "Content-type:text/html\n\n";

$SIG{__DIE__} = \&Error_Msg;

sub Error_Msg {
  $msg = "@_";
  print "The following error occurred : $msg\n";
  exit;
}
ref ($sender = new Mail::Sender { from => 'from@mail.com',
     smtp => 'server.location.net', boundary => 'This-is-a-mail-boundary-435427'})
or die("Error($sender) : $Mail::Sender::Error\n");

$sender->Open({to => 'to@mail.com', subject => 'Test is a test'});
$sender->SendLine("This the first line !");
$sender->SendLine;
$sender->Send(<<'*END*');
I've found these jokes.

Doctor, I feel like a pack of cards.
Sit down and I'll deal with you later.

Doctor, I keep thinking I'm a dustbin.
Don't talk rubbish.

Hope you like'em. Jenda
*END*

print "<h1>Mail sent</h1>";

$sender->Close;

