#!/usr/bin/perl

use IO::Handle;
use strict;

my $Sendmail = "/usr/sbin/sendmail";
my $LogFile  = "/var/log/snort/alert";
my @Filter   = qw("Destination Unreachable", "Time Exceeded");
my $Email    = "admin\@net.org";

#leave the rest alone.

my $CurPos   = "";
my $LogLine  = "";
my $MailIt   =  1;

my $PID      = fork;

exit if $PID;
die("Error.") unless defined($PID);

pipe(CHILDREAD, CHILDWRITE);
CHILDWRITE->autoflush(1);

if(fork()) {
 open(FILE,"$LogFile");
 for (;;) {
    for ($CurPos = tell(FILE); $_ = <FILE>;
       $CurPos = tell(FILE)) {
       print CHILDWRITE $_;
    }
    seek(FILE, $CurPos, 0);
    sleep(1);
 }
 close(FILE);
 exit(0)
}else {
   while(1) {
      $LogLine = <CHILDREAD>;
      foreach(@Filter){
         if($LogLine=~m/$_/){
            $MailIt = 0;
         }
      }
      if($MailIt) {
         open(MAIL,"|$Sendmail -t");
         print MAIL "To: $Email\n";
         print MAIL "From: SnortAlert\n";
         print MAIL "Subject: Snort Alert\n";
         print MAIL "\n$LogLine\n";
         close(MAIL);
      }
      $MailIt = 1;
   }
}
