#!/usr/bin/perl   
#print "Content-type:text/html\n\n";

#Parse the form data
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/,$buffer);
foreach $pair (@pairs){
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
	$value =~ s/\n/ /g;
	$value =~ s/\r/ /g;
	$value =~ s/\cM/ /g;
	$name =~ tr/+/ /;
	$name =~ tr/_/ /;
	$FORM{$name} = $value;
	  }
	$name1 = ($FORM{$name});

use lib "home/sites/site3/web/lib";
use MIME::Lite;
use strict;

# for Win32 use SMTP (default is /usr/bin/sendmail)

my $server = #Server path
#my $server2 = 'ns.Zexas.com';
 if ($^O =~ /win32/i) {
MIME::Lite->send('smtp', $server, Timeout => 90);
} else {
MIME::Lite->send('sendmail', "/usr/sbin/sendmail -t -oi -oem");
}

form_select ($name1);

sub form_select {
	my ($name1) =@_;
	if ($name1 eq "visit")  {
	  $subject1 =  'Club Visit Report';
	  $info1 = 'Attached is the Club Visitation 
Report you requested';
	  $path1 = 'home/sites/site3/web/reports/visitation.txt';
	  $file1 = 'visitation.txt';
	mail_it ($subject1, $info1, $path1, $file1);
	} else {
	  $subject1 =  'Project Time Report';
	  $info1 = 'Attached is the Project Time Report you requested';
	  $path1 = 'home/sites/site3/web/reports/timereport.txt';
	  $file1 = 'timereport.txt';
	mail_it ($subject1, $info1, $path1, $file1);
	  }
	}

sub mail_it {
	my ($subject1, $info1, $path1, $file1) = @_;

# create a message and send file attachment

# Message body
my $me = #my email address
my $subject = "$subject1";
my $msg = MIME::Lite->new(To => $me, From => $me, 
Subject => $subject, Type => 'multipart/mixed',);

my $info ="$info1";
$msg->attach(Type => 'text/plain', Data => $info);

# Create attachment

$msg->attach(Type  => "TEXT",
       Disposition => 'attachment',
       Path     => "$path1",
       Filename => "$file1"
       );

$msg->send;
}

#Acknowledge receiving form

print <<EndHTML;
<html><head><title>Requested Reports</title></head>
<body>
<h2>Thank You!!</h2>
The report you requested is being sent as a e-mail 
attachment to you.<p>
Please select one of the options below.
<a href="../members/options.html">Return to options menu!
</a><p>
or
<a href="../members/reports.html">Return to select  
additional reports</a><p>
or
<a href="../index.html">Return to home page</a><p>
</body></html>

EndHTML
