#!/usr/bin/perl

#########################################################################################################
# handle for maillist																											  #
#########################################################################################################
use Net::POP3;
use Net::SMTP;

	open(SET, "<maillist.setup");
		@maillistset= <SET>;
	close(SET);
	foreach $m_set(@maillistset)
	{
		chomp($m_set);
		@xp_set = split (/\&/,$m_set);
		foreach (@xp_set)
		{
			($bereich, $variab)= split(/=/);
			$MAILLIST{$bereich} = $variab;
		}
	}
	
	

	$stauts = 'ACTTIV';
	open(HIS, ">>maillist/history.all");
			&ACTIVE;
	close(HIS);
exit;
####################
sub ACTIVE
{
	while ($status = 'ACTIVE')
	{
		sleep($MAILLIST{'refresh'});
		&lookformail;
		if($anz_message > 0)
		{
			
			foreach (@$new_head)
			{
				if($_ =~ m/From:/) { $from=$_; }
				if($_ =~ m/Subject:/) { $betref=$_; }
				if($_ =~ m/Date:/ ) { $datetime=$_; }			
			}
			foreach (@$new_body)
			{
				#types ermitteln
				$read = 'plain';
				$x_txt .= $_;
			}
			if ($read = 'plain')
			{
				($tmp, @txt)=split(/\n\n/s,$x_txt);
			}
			foreach(@txt) { $txt .= "$_\n"; }
			$txt =~ s/\n/#format:n#/g;
			$txt =~ s/\t/#format:t#/g;
			&check_scripe;
			&savemsg;
			&sendmail;
			$txt = '';
			$from = '';
			$betref = '';
			$server = '';
			$x_txt = '';
			$read = '';
			$anz_message = ''; 
		}
	}
}
####################

sub lookformail
{
	$server 	= $MAILLIST{'pop3_mailserver'};
	$user		= $MAILLIST{'user'};
	$pass		= $MAILLIST{'pass'};
	$pop3 = Net::POP3->new($server);
	$anz_message = $pop3->login($user,$pass);
	if($anz_message >= 1)
	{
		$newmail = 'YES';
		$new_head= $pop3->top($anz_message);
		$new_body= $pop3->get($anz_message);
		$pop3->delete($anz_message);
	}
	else
	{
		$newmail = 'NO';
	}
	$pop3->quit();
}

sub check_scripe
{
	if($txt eq "unsubscripe")
	{
	}
}

sub savemsg
{
	
	$datetime =~ s/Date://eg;
	$subject =~ s/Subject://eg;
	$from =~ s/From://eg;
	$maildate = substr($datetime,0,16);
	$mailtime = substr($datetime,17,8);
	chomp($from);
	$from =~ s/.*?(<)//gs;
	$from =~ s/(>).*?//gs;
	chomp($betref);
	chomp($txt);
	open(HIS, ">>maillist/history.all");
		print HIS "$maildate\t$mailtime\t$from\t$betref\t$txt\n";
	close(HIS);
}

sub sendmail
{
	chomp($txt);
	chomp($from);
	$from =~ s/.*?(<)//gs;
	$from =~ s/(>).*?//gs;
	chomp($betref);
	$txt =~ s/#format:n#/\n/g;
	$txt =~ s/#format:t#/\t/g;
	$tmp_file1= 'sendlist/';
	$tmp_file2= 'maillist.lst';
	$tmp_file = "$tmp_file1$tmp_file2";
	open(LIST, "<$tmp_file") || print "konnte datei nicht finden";
		@eint = <LIST>;
	close(LIST);
	foreach (@eint)
	{
		($mail, $name, $vorname, $tel, $adr, $firma)= split(/\t/);
		push(@sendto, $mail);
	}
	foreach $sendto(@sendto)
	{
		$smtp = Net::SMTP->new('mail.internet-shop.net');	
			$smtp->mail(ven_maillist);
			$smtp->to($sendto);
			$smtp->data();
			$smtp->datasend("Subject: $betref\n");
			$smtp->datasend("To: $sendto\n");
			$smtp->datasend("\n");
				$smtp->datasend("$txt\n");
			$smtp->datasend("\n");
			$smtp->dataend();
		$smtp->quit();
	}
}
