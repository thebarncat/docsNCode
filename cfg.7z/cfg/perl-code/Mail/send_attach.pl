#!/usr/bin/perl -w
#FILE: "C:\Dev\Perl\Code\scripts\Unix\Mail\send_attach.pl"
#LAST MODIFICATION: "Wed, 01 Sep 2004 12:00:14 Eastern Daylight Time"
#(C) 2003 by Jim Kipp, <james.kipp@mbna.com

use strict;
use MIME::Lite;
use LWP::MediaTypes qw(guess_media_type);

our %A;
for (my $ii = 0; $ii < @ARGV; ) {
	last if $ARGV[$ii] =~ /^--$/;
	if ($ARGV[$ii] !~ /^-{1,2}(.*)$/) { $ii++; next; }
	my $arg = $1; splice @ARGV, $ii, 1;
	if ($arg =~ /^([\w]+)=(.*)$/) { $A{$1} = $2; } else { $A{$1}++; } 
}

######################## Change me ###########################################
my $DEF_FN = 'Joe';		# from name
my $DEF_FE = 'jkipp5@comcast.net';		# from email addr
my $DEF_TN = 'Jim Doe';		# to name
my $DEF_TE = 'nep777@yahoo.com';		# to email addr
my $DEF_SERVER = 'smtp.comcast.net';	# default mail server
my $body = "Here are your file attachments";	# def body msg
my $subject = "Testing multiple file attachments";	# def subject
######################## Change me ###########################################

my $debug = $A{d} || 0;
my $fn = $A{fn} || $DEF_FN;
my $fe = $A{fe} || $DEF_FE;
my $inline = $A{i} ? 'attachment' : 'inline'; my $server = $A{ms} || $DEF_SERVER; 
my $tn = $A{tn} || $DEF_TN; my $te = $A{te} || $DEF_TE;

$0 =~ /^(.*[\\\/])?(.*)/; my $prog = $2; my $usage = <<EOD;

Usage: $prog [-d] [-b=<body>] [-fn=<from-name>] [-fe=<from-email>] [-i] \\
  [-ms=<mail-server>] [-tn=<to-name>] [-tn=<to-email>] [-s=<subject>] \\
  [path-to-attachment ... ]
	-d		debug
	-b=<body>	default main body text (def:
			"$body")
	-fn=<from-name>	from text name (def: $DEF_FN)
	-fe=<from-email>	from email address (def: $DEF_FE)
	-i		no inline disposition if set (use attachment instead)
	-ms=<mail-server>	your SMTP mail server (def: $DEF_SERVER)
	-s=<subject>	default subject line (def:
			"$subject")
	-tn=<to-name>	to text name (def: $DEF_TN)
	-te=<to-email>	to email addr (def: $DEF_TE)
	path-to-attachment	list of file attachments

EOD
die $usage if not @ARGV or $A{h} or $A{help};

$body = $A{b} if exists $A{b};
$subject = $A{s} if exists $A{s};

if ($debug) {
	print <<EOD;
>From name  : $fn
>From email : $fe
Inline     : $inline
To name    : $tn
To email   : $te
Body       : $body
Server     : $server
Subject    : $subject
EOD
}

MIME::Lite->send('smtp', $server, Timeout => 60, Debug => $debug);

my $msg = new MIME::Lite(
	From        => 'jkipp5@comcast.net',
	To          => 'jkipp5@comcast.net',
	Subject     => $subject,
	Data        => "$body\n",
);

# add the attachments

foreach (@ARGV) {
	/^.*[\\\/](.*?)$/;
	my $file = $1;
	# determine content type
	my $type = guess_media_type ($_);

	$msg->attach(
		Type        => $type,
		Disposition => $inline,
		Path        => $_,
		Filename    => $file,
		Length      => -s $_,
	);
}

$msg->send;

