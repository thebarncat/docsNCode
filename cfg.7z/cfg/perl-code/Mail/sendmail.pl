#!/usr/bin/perl -w
# FILE: "C:\Dev\Perl\Code\scripts\Unix\Mail\sendmail.pl"
# LAST MODIFICATION: "Mon, 23 Aug 2004 09:11:34 Eastern Daylight Time"
# (C) 2004 by Jim Kipp, <james.kipp@mbna.com>
# $Id:$



sub DoThatMailVoodoo {
    my ( $userName, $subject, $msg, $sig, $shar) = @_;

    my $bailFile = "/tmp/sendmail.bail.$$";
    my $sendmail = '/usr/lib/sendmail';

    # ok, so sharing the code back in may be over the top....
    if ( $shar ) {
        open (FH, "sharIt $0 |") or die "unable to self Shar:$!\n";
        $msg .= $_ while(<FH>) ;
        close FH;
    }

    $msg .= "\n$sig" ;
    $msg .= "\n\n";    # make sure it ends okish

    open (MAIL, "| $sendmail -t -oi 2>$bailFile")
        or die "unable to open sendmail:$!\n";

    print MAIL "To:  $userName \n";
    print MAIL "Subject: $subject\n\n";
    print MAIL "$msg";

    close MAIL;
    # Ok so this is MASSED Paranoia
    if ( -f $bailFile and -s  $bailFile) {
        print "we had an error case from sendmail\n";
        open(ER_FH, $bailFile) or die "unable to open Bail File:$!\n";
        my @err_msg=<ER_FH>;
        close(ER_FH);
        close(MAIL);
        unlink($bailFile);
        die "@err_msg\n\n";
    } else {
        unlink($bailFile);
    }

} # DoThatMailVoodoo

#-------------------
#  The Main Loop Section

my $toWhom = 'beginners@perl.org, joeBobBrigs@wetware.com';
my $about = ' RE: yahoo mail did\'t compile HTML mail ';
my $msg =<<EOL;


I'm not sure I understand the nature of the problem with
using the standard Email tricks through perl?

EOL

my $sig =<<SIG_FILE;
ciao
drieux

-----

SIG_FILE

DoThatMailVoodoo($toWhom, $about, $msg, $sig, 1);

