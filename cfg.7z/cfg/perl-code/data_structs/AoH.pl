#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/data_structs/AoH.pl"
# LAST MODIFICATION: "Tue, 17 Oct 2017 12:38:35 -0400 (jkipp)"
# (C) 2015 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

@ar = ( { name => 'bill', age => '21', }, { name => 'fred', age => '40', } );
# get a piece of one of the hashes  
print  $ar[1]{age},"\n";
print "\n";
# print a single hash
for $href ($ar[1]) { print "$href->{$_}\n" for keys %$href; }
print "\n";

# print all data
for $href (@ar) { 
	for $key (keys %$href) { 
		print "$href->{$key}\n"; 
	} 
}
print "\n";
# print all data a different way
for $hash (@ar) {
	# this is a slice
	printf "%s %s\n", @{$hash}{qw(name age)};
}

