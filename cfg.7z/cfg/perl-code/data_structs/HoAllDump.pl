#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/data_structs/HoAllDump.pl"
# LAST MODIFICATION: "Thu, 19 Oct 2017 10:55:01 -0400 (jkipp)"
# (C) 2017 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;
use Data::Dumper;

# hash of an array, another hash, regular hash element
my %data = (
    a => [1, 2, 'x'],
    b => { foo => 'bar', biz => 'buz' },
    j => '867-5309',
);

# print first element of each if applicable 
print $data{a}->[0],"\n";
print $data{b}->{foo},"\n";
print $data{b}{foo},"\n"; #same as above
print $data{j},"\n";

# print the entire anon array
print "@{$data{a}}\n";
# print one at time 
for my $i ( 0 .. $#{$data{a}} ) {
	print "$i = $data{a}->[$i]\n"
}

# print the entire anon hash
print "$data{b}{$_}\n" for keys %{$data{b}};
# print one at time 
for my $key (keys %{$data{b}}){
	print "$key -> $data{b}->{$key}\n";
}

print "\n\n";

print Dumper(\%data);
