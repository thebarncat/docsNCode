#!/usr/bin/perl -w
# FILE: "/export/home/jk24445/cfg/perl-code/HoA.pl"
# LAST MODIFICATION: "Mon, 05 Apr 2021 19:02:11 -0400 (jk24445)"
# (C) 2015 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;

my %slots;
my $name = "blah";
my $num = "aa";

push(@{$slots{'1'}}, $name,$num);
push(@{$slots{'2'}}, "foz","bb");

foreach my $key (keys %slots) {
    foreach ( @{$slots{$key}}[0] ) {
    #foreach ( @{$slots{$key}}[1] ) {
        print "$key->$_\n";
    }
}

