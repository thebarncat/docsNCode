#!/usr/bin/perl  
# FILE: "/home/jkipp/perl-code/FUN.pl"
# LAST MODIFICATION: "Tue, 24 Dec 2013 08:51:09 -0500 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

vec($name, 0, 32) = 0x416E6469;
$verb = pack("C*", 0x69, int(56<<1)+3) ;
$adj = sprintf("%s", "\x63\x6F\x6F\x6C" );
printf("\n%-s %s %s\n", $name,$verb,$adj); 


