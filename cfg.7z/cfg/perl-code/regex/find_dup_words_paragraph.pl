#!/usr/bin/perl

# FROM PERLFAQ 6

$/ = '';
while ( <DATA> ) {
    while ( /\b([\w'-]+)(\s+\1)+\b/gi ) {   # word starts alpha
        print "Duplicate $1 at paragraph $.\n";
    }
}


__DATA__
this is a paragraph for blah reading into
this program. blah blah. chooch you funny
ok for now.

another one one to peruse for you. yuck my
glass  bag.  stupid freak. life is funny 
sometimes. hi there there

