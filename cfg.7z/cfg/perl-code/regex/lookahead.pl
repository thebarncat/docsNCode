#!/usr/bin/perl

$_ = "Is it Jeff, Jeffy, Jeffrey, or JEFFREY?";
# The look-ahead made sure we could match the pattern /rey\b/i next, but after determining that, it backs up to .  
s{
   \b        # find a word boundary
   (jeff)    # match 'jeff'
   (?=rey   # look ahead for the 'rey'
    \b      # and a word boundary
   )
}{[$1]}gix; 
print "$_\n";

# capture a set of digits that does not have the string "LOTR" after it
$string = "100Silmarillion 102LOTR 101Hobbit";
@numbers = $string =~ /(\d+)(?!LOTR)/g; # look ahead NOT
print "@numbers\n";

# looks ahead for a match, but does not truly advance in the string, we have to use parentheses around the pattern to get it to be captured
$_ = "abcabcabcabca";
@all = /(?=(abca))/g; #all matches
print "@all\n";

# upper case first char in each word
$_ = "this is my string and it is nice";
s/\b(\w)(\w*)/\u$1\L$2/g;
print "$_\n";
# use negative look ahead to skip words like "the", "an", and "of", 
$_ = "this is the string and it is nice";
s/\b(?!(?:and|an?|o[rf]|the)\b)(\w)(\w*)/\u$1\L$2/g;
print "$_\n";


