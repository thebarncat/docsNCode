#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\PARSE\regex\get_adr_from_hdr.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:01:35 Eastern Daylight Time"
# $Id:$

# reads files containing mail messages and prints addresses it finds in headers
#

sub getadr 
{
	%seen = ();
	while (<>) {
    	next unless /^From:?\s/i .. /^$/;
    	while (/([^<>(),;\s]+\@[^<>(),;\s]+)/g) {
        	print "$1\n" unless $seen{$1}++;
    	}
}

