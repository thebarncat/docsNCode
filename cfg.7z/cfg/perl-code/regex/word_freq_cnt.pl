#!/usr/bin/perl

# FROM PERLFAQ 6

while (<DATA>) {
	while ( /(\b[^\W_\d][\w'-]+\b)/g ) {
		$seen{$1}++;
    }
}

while ( ($word, $count) = each %seen ) {
	print "$count $word\n";
}

__DATA__
some words to play with words to show 
what we are we doing some words
