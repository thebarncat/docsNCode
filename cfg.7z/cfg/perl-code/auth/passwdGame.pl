#!/usr/bin/perl -w
use strict;

# how to get passwd's in safely
# by turning off 'echo' at the command line.

my ($user,$pword);

if(-t) {  # are we attached to a tty???
    print "Enter username : ";
    $user = <STDIN>;
    chomp($user);
    return (undef, undef) unless length $user;
    print "Password: ";
    system("stty -echo");
    $pword = <STDIN>;
    system("stty echo");
    print "\n";  # because we disabled echo
    chomp($pword);
    
} else {
    die "we only play on the command line\n";
}

# get the user and passwd based upon the effective user id
my ($uname,$pwd) = (getpwuid($<))[0,1];

# bail out if they are now whom they say they are
die "you are not whom you are running as.\n" if ($uname ne $user );

if (crypt($pword, $pwd) ne $pwd) {
    die "Sorry...\n";
} else {
    print "ok - but \$pwd is :$pwd:\n";
}


