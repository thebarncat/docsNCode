#!/usr/bin/perl -w
# FILE: "C:\CODE\Perl\sys_security\logmon.pl"
# LAST MODIFICATION: "Tue, 07 Sep 2004 20:47:35 Eastern Daylight Time"
# (C) 2004 by Jim Kipp, <james.kipp@mbna.com>
# $Id:$
use strict;

# usage authMon < /var/run/syslog_auth
# have to setup a named pipe in /var/run and then edit syslog conf
# to put auth crap into this pipe
# real-time email alerts to login failures

use Mail::Sendmail;
use Time::localtime;

my $email = "jkipp\@mbna.com";
my $from = "jerry\@neptuna.com";
my $time = ctime();


my $monitor = <STDIN>;
	$monitor =~ s/^.*\:/DANGER PANIC WARNING/
	my $fail = ( $monitor =~ /fail|invalid/i );
	if ($fail) {
  		$Mail::Sendmail::mailcfg{mime} = 0;
  		my %mail = (
            	smtp  => 'localhost',
           		To    => $email,
           		From  => $from
          	);
  		$mail{"Subject: "}  = "Log Alert! ";
  		$mail{"Message: "} .= "Auth Failure alert : $time ,\n\n";
  		$mail{"Message: "} .= "$monitor\n\n";
	
  		sendmail(%mail) or die $Mail::Sendmail::error;
	}
)
