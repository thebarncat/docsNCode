#!/appl1/perl/bin/perl 

# Create a named pipe and send the current date to the pipe
# the date will be send when a caller reads the pipe. the open 
# call will block until the other end reads it 

$path = "./my_fifo";
unless (-p $path) { system("mkfifo -m 0666 $path"); }
# block until something is sent on other end, 'cat my_fifo' would do it
open(FIFO,"> $path") || die "Cannot open $! \n";
$date = `date`;
chop($date);
print FIFO "[$date]\n";
close FIFO;
# Remove when done.
unlink $path; 

sub pipeHandler {
    my $sig = shift @_;
    print " Caught SIGPIPE: $sig $1 \n";
    exit(1);
}

# catches broken pipes
$SIG{PIPE} = \&pipeHandler; 





