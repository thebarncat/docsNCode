
if (open(TO, "|-")) {
	print TO "hello from daddy\n";
}

else { $child = <STDIN>;
	print $child;
	exit;
}


