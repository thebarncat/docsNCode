#!/usr/bin/perl
# run the text of an email through this filter as STDIN or as a file
# the quote() will add the > to the front of everyline and the 
# number will add the line number to each line
# example:
=cut
echo "Are we still going?\nhuh? " | mail_re_filter.pl
> 1: Are we still going?
> 2: huh? 
=cut


quote();                    # push quote filter on STDOUT
number();                   # push number filter on STDOUT

while (<>) {                # act like /bin/cat
    print;
} 
close STDOUT;               # tell kids we're done--politely
exit;

sub number {
    my $pid;
    return if $pid = open(STDOUT, "|-");
    die "cannot fork: $!" unless defined $pid;
    while (<STDIN>) { printf "%d: %s", $., $_ } 
    exit;
} 

sub quote {
    my $pid;
    return if $pid = open(STDOUT, "|-");
    die "cannot fork: $!" unless defined $pid;
    while (<STDIN>) { print "> $_" } 
    exit;
} 
