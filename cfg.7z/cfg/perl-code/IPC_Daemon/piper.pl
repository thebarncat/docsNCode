#!/db/app/perl/bin/perl

use strict;
$| = 1;
my $nc = 3;             # number of children to create
pipe READER, WRITER;    # pipe for communication

for my $c (1 .. $nc) {
      # after the fork, both parent and child get a copy of the file handles 
	  # created by pipe
      defined(my $pid = fork) or die "Couldn't fork: $!";
      next if $pid;   # parent loops to create next child

      # child does it's thing and writes back to parent through pipe
      close READER;
      select WRITER;
      $| = 1;
	  # as long as the child writes less then PIPE_BUF chars (posix limit) the writes will
      # be automatic and should not be intermingled
      print "Hello, I am child $c, and my PID is $$\n";
      sleep rand(5) + 1;
      print "Goodbye from child $c\n";
      exit;           # child exits (IMPORTANT!)
}

# parent reads from children
# pipe will close when last child exits
close WRITER;
while(<READER>) {
     print $_;
}

1 while wait() > 0;   # reap all exit statuses



