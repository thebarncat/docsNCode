#!/appl1/perl/bin/perl
# example of using a named pipe. to run first make the pipe file with
# mkfifo -m 0666 rwfifo 
# then fir up this script and on another terminal write to the pipe:
# cat >rwfifo  hit ctrl-D when done
use warnings;

$|=1;
# select(STDERR); $|=1;
# select(STDOUT); $|=1;

my $inp;

die "pipe is missing\n" unless ( -p "rwfifo");

eval {
  local $SIG{ALRM} = sub {die "alarm clock restart" };
  alarm 20;
  open(FOUT,"rwfifo") || die "$!";
  $inp=<FOUT>;
  close(FOUT);
  alarm 0;
};

if ( $@=~/alarm clock restart/) {
  print "read from pipe failed\n";
} else {
  print "read from pipe worked: $inp\n";
}


