#!/usr/bin/perl -w
# FILE: "U:\My Documents\scripts\perl\func_libs\signals\catch_int.pl"
# LAST MODIFICATION: "Thu, 28 Feb 2002 13:37:28 Eastern Standard Time"
# (C) 2002 by Jim Kipp, <james.kipp@mbna.com>
# $Id:$

# catch interrupts like ctrl-c or ctrl-\

sub catch_zap
{
	my $sig = shift;
	our $count++;
	die "Sig: SIG$signame sent";
}

$count =0;
$SIG{INT} = \&catch_zap;


