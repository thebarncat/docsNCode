#!/usr/bin/perl -w
use strict;

use Proc::Daemon;           
use File::Basename;         
use Fcntl ':flock';         # import LOCK_* constants
use IO::Handle;             # autoFlush
use Time::localtime ;        

my $programmeName = basename $0;

my @daemonFoo = ("/tmp/${programmeName}.stdout" , 
                 "/tmp/${programmeName}.stderr" ,
                 "/tmp/${programmeName}.pid" );


if ( defined($ARGV[0]) and $ARGV[0] eq '-k' ) {
    justKillMe(@daemonFoo) if ( -f $daemonFoo[2] );
    print "and We $$ Are Outta Here\n";
    exit(0);
}
#
# in lieu of the classic lock picker strategy - especially since the
#   flock is not what I want in go daemon
#
die "$programmeName Someone Has my Pid File Out there already" if ( -f $daemonFoo[2] );

$SIG{TERM} = \&sigDown;         # warning this signal handler will call exit.

goDaemon( @daemonFoo);          #we Go Daemon her

dumbDoWork(100,6);

closeDownDaemon( @daemonFoo);   # A nice way to exit gracefully

#--------------------------------
# our growing list of basic subs


#------------------------
#
sub dumbDoWork {
    my ($count, $sleeptime ) = @_;
    
    my $pid=$$;
    while($count) {
        printf("Still Going %d at %s\n",$pid, ctime() );
        sleep $sleeptime ;
        $count--; 
    }
    
} # end of dumbDoWork

#------------------------
# 
sub goDaemon {
    my ($out,$err,$pidF) = @_;
    
    Proc::Daemon::Init ;    # make ourselves a deamon
    
    my $pid = $$ ;          # we want to have this PID, not what we were...
    
    # try to get the pid file...."
    open(PID, ">$pidF") or die "unable to open pid file:$!\n";
    my $flockMe = flock(PID, (LOCK_EX|LOCK_NB));
    
    # reset the STDOUT/STDERR since we want other things to
    # just print to where they expect to go, die, croak, the rest
    # no need to clog /dev/null
    
    close(STDERR);
    open(STDERR, ">>$err") or die "unable to reopen STDERR:$!\n";
    autoflush STDERR 1;
    close(STDOUT);
    open(STDOUT, ">>$out" ) or die "unable to reopen STDOUT:$!\n";
    autoflush STDOUT 1;
    
    
    unless($flockMe) {
        print STDERR "what if we had a pidfilePicker for $pidF\n";
        die "$programmeName with pid $pid unable to flock\n" ;
    }
    autoflush PID 1;
    
    print PID "$pid\n";
    close PID ;
    
    printf("We are %d - fired up at %s\n", $pid, ctime() ); 
} # end of goDaemon


#------------------------
#
sub sigDown {
    my ($signame) = @_;
    printf("recieved signal %s at %s\n",$signame, ctime() );    
    closeDownDaemon( @daemonFoo);
    
} # end of sigDown

#------------------------
#
sub closeDownDaemon {
    my ($out,$err,$pidF) = @_;
    
    printf("shutting down at %s\n",ctime() );   
    # depending upon what we want to do....
        
    unlink($pidF) if (-f $pidF);
    
    exit(0);        # this way we have an exit for the signal handler
    
} # end of closeDownDaemon


#------------------------
# for the -k shutdown side

sub justKillMe {
    my ($out,$err,$pidF) = @_;
    
    my $targetPid;
    
    open(PID, "$pidF") or die "unable to open pid file:$!\n";
    chomp($targetPid = <PID> );
    close(PID);
    
    die "You are on your own bud - grovel the proc table\n" unless $targetPid ;
    
    kill 'TERM', $targetPid ;
    
} # end of justKillMe



