#FIL "C\test\test.pl"
#LAST MODIFICATIO "Thu,  Apr 2003 1503:37 Eastern Daylight Time"
#(C)  by Jim Kipp, <james.kipp@mbna.com>
#

# use pipe to simulate an input and output FH
pipe (INPUT, OUTPUT);

$retval = fork();
if ($retval != 0 ) {
        # this is the parent process
		# the parent proc is sending data thru OUTPUT, it has no need
		# for INPUT, so it closes it
        close (INPUT);
        print ("Enter a line of input\n");
        $line = <STDIN>;
		# send the text to the child
        print OUTPUT ($line);

} else {

        # this is the child process
		# has no need for output handle, so it closes
        close (OUTPUT);
		# reads data from INPUT. Because data from OUTPUT is piped to INPUT, 
		# the program waits until the data is actually sent before continuing 
        $line = <INPUT>;
        print ($line);
        exit (0);
}

