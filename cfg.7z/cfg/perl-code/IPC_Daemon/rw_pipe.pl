#!/usr/bin/perl -w
# LAST MODIFICATION: "Fri, 02 Oct 2009 15:58:16 Eastern Daylight Time"
# $Id:$

use warnings;
use IPC::Open2;

# open a pipe from STDIN to STDOUT
# the 3rd arg to open2 is your input
local (*Reader, *Writer);
$pid = open2(\*Reader, \*Writer, "bc -l");
$sum = 2;
for (1 .. 5) {
    print Writer "$sum * $sum\n";
    chomp($sum = <Reader>);
}
close Writer;
close Reader;
# wait for and reap the dead children. open2 will not do this for you
#waitpid($pid, 0);
print "sum is $sum\n"

