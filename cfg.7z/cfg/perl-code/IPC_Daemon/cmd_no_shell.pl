#!/usr/bin/perl

use POSIX qw(:sys_wait_h);

$program = 'ls';
$arg =  '-a';
# open a pair of connected pipes. one for reading and writing. works like a named pipe
# this is just a one way pipe from WRITER to READER  
pipe(README, WRITEME);
if ($pid = fork) {
    # parent
    $SIG{CHLD} = sub { 1 while ( waitpid(-1, WNOHANG)) > 0 };
    close(WRITEME);
} else {
    die "cannot fork: $!" unless defined $pid;
    # child, dupe the FH, 
    open(STDOUT, ">&WRITEME")      or die "Couldn't redirect STDOUT: $!";
	# the child does not need this FH since the parent is the writer
    close(README);
	# exec the program and output is sent from WRITER to READER
	# system would work here as well, but exec doesn't return and we don't need it to
    exec($program, $arg)    or die "Couldn't run $program : $!\n";
}

# read the output send from WRITER, but reading the FH READEr
while (<README>) {
    $string .= $_;
    # or  push(@strings, $_);
}
close(README);

print $string;


