#!/appl1/perl/bin/perl
# name: snd2pip.pl 
use strict;
use warnings;

# this writes to the named pipe 'b2a'. 
# run the program read_pipe.pl which makes the pipe and reads it 
# the trick is to close the pipe after each write, so
# the scripts don't hang.

$|=1;

while(1){
	my $input = "blah, blah, blah";
	open(OUTB, ">b2a") or die $!;
	print OUTB "$input\n";
	close OUTB;
	sleep(1);
}

