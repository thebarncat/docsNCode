#!/appl1/perl/bin/perl

# makes a named pipe so unrelated procs can talk to each other
# this script creates the pipe and reads the input from the write_pipe.pl script

use warnings;
use POSIX 'mkfifo';
$|=1;

mkfifo( 'b2a', 0666 ) unless -p 'b2a';

while(1){
	open(INB, "<b2a")  or die $!;
	my $bytes = read(INB, $buffer, 4096) or die "Couldn't read from pipe: $!\n";
	print STDOUT "we got this from you: $buffer";
}

