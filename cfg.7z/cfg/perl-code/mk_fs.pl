#!/usr/bin/perl -w
# FILE: "/home/jkipp/mk_fs.pl"
# LAST MODIFICATION: "Fri, 03 Oct 2014 10:53:14 -0400 (jkipp)"
# (C) 2014 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;

my $file = "FS";
open(FILE, "<", $file) or die "cannot open $file: $!";
while (my $line = <FILE>) {
        chomp $line;
        my ($size,$FS) = ( split(/\s+/,$line) )[1,6];
        my $int_size = sprintf("%i", $size);
        $int_size.="G";
        print "$int_size  $FS\n";
        system("crfs -v jfs2 -a log=INLINE -a size=$int_size -m $FS -A yes -g prfvg -p rw") ==0  or warn "cmd failed: $?";
}

close FILE;
