#!/usr/bin/perl -w
use strict;

my $tecKey =<<EOF;
---- BEGIN SSH2 PUBLIC KEY ----
Comment: "1024-bit RSA, converted from OpenSSH by cmsys\@lxdepcfg.ingdirect.com"
AAAAB3NzaC1yc2EAAAABIwAAAIEAvjI5ClXIqdlQ0yqxnYgcmUOGmzHnL1v9UmMg770LgM
8HtnZDP+wLkmtuK7KILRw5Apu/MTPkf6tAZlwtEr9D7qyHYgQ5fV9T8LDi/i2flgDdTqJu
/mrp1zvnE+sx6HbQnADOQUyDLsYzIhwIIsr7D1Mm+qAgXpQUTVEYA7vgx4c=
---- END SSH2 PUBLIC KEY ----
EOF

print $tecKey;

undef $tecKey;
$tecKey = "blahj\n";

print $tecKey;

=cut
my $key = q[
---- BEGIN SSH2 PUBLIC KEY ----
Comment: "1024-bit RSA, converted from OpenSSH by cmsys@lxdepcfg.ingdirect.com"
AAAAB3NzaC1yc2EAAAABIwAAAIEAvjI5ClXIqdlQ0yqxnYgcmUOGmzHnL1v9UmMg770LgM
8HtnZDP+wLkmtuK7KILRw5Apu/MTPkf6tAZlwtEr9D7qyHYgQ5fV9T8LDi/i2flgDdTqJu
/mrp1zvnE+sx6HbQnADOQUyDLsYzIhwIIsr7D1Mm+qAgXpQUTVEYA7vgx4c=
---- END SSH2 PUBLIC KEY ----
];
=cut


