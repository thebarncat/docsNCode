#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/hash/split_ary_into_fields.pl"
# LAST MODIFICATION: "Thu, 19 Oct 2017 15:26:13 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

my %data;
@fields = ("fname","lname");
open(FILE, "<list.dat");

while(<FILE>) {
	@data{@fields} = split(/:/, $_, scalar @fields);

	foreach (@fields) {
		printf("%10.10s = %s\n", $_, $data{$_});
	}
}

close(FILE);

# the split func is done first. it creates an array of fields using the ; as a delimeter.
# the scalar @list is passed to split to get the # of fields. each 
# element in the new array is added to %data hash with a key of the feild name
for $key ( keys %data) {
		print "$key = $data{$key}";
}

# split creates an array which stores the values of fname and lname(jim, kipp). this is the
# same as doing this: @data{@list} = ("jim", "kipp");
# can be further simplefied to :
# @data{"fname", "lname"} = ("jim", "kipp");
