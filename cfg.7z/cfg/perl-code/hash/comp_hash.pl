#!/usr/bin/perl -w

# https://stackoverflow.com/questions/1273616/how-do-i-compare-two-hashes-in-perl-without-using-datacompare
# perldoc -q equal
#
use strict;
$ENV{https_proxy} = "http://proxy.kdc.capitalone.com:8099";
my $ec2_id = `curl -s http://169.254.169.254/latest/meta-data/instance-id`;
chomp(my $region = `curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep region | awk -F: "{print \\\$2}" | sed -e 's/[\\\", ]//g'`);

my $out = `aws ec2 describe-volumes --filters --region $region Name=attachment.instance-id,Values=$ec2_id --query 'Volumes[*].[VolumeId,Attachments[0].Device,Tags[?Key==\`mdir\`].Value]' --ou
tput text`;
chomp $out;
$out =~ s/.*sda.*\n?//;
$out =~ s/(vol-.*)\n/$1\t/g;

my @tmp = split(/\n/,$out);
print "\n",scalar @tmp," volumes attached, tag query output:\n";
print $out;
print "\n\n";

# build tag query hash table
my ($ID,$dev,$mnt);
my %tags;
for my $line (@tmp) {
    ($ID,$dev,$mnt) = split(/\s+/,$line);
    $tags{$dev} = $mnt;
}

my @tmp2 = `df | grep "^/dev"`;
# build volume FS mount hash table
my %fstab;
for my $line (@tmp2) {
    next if $line =~ /vda[0-9]/;
    ($dev,$mnt) = (split(/\s+/,$line))[0,5];
    $dev =~ s#mapper/vol_##;
    $fstab{$dev} = $mnt;
}

print "warning tables do not have same number of elements\n" unless %tags eq %fstab;
print scalar keys %fstab," volumes mounted, CMP of mdir tag and actual mount on the instance:\n";
my $mis = 0;
foreach my $dev_key (sort(keys %tags)) {
    unless ( exists $fstab{$dev_key} ) {
        print "$dev_key from tags table not found in mount table\n";
        next;
    }
    if ( $tags{$dev_key} eq $fstab{$dev_key} ) {
        print "MATCH for device $dev_key; tag: $tags{$dev_key}    mount: $fstab{$dev_key}\n"
    }
    else {
        print "*WARNING MISMATCH* for device $dev_key; tag: $tags{$dev_key}    mount: $fstab{$dev_key}\n";
        ++$mis;
    }
}
print "\n$mis MISMATCHES\n";
