#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/hash/string2hash.pl"
# LAST MODIFICATION: "Thu, 19 Oct 2017 15:27:10 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$


$string = "foo bar fud";
$i = 1;
for (split( /\s+/, $string)) {
	$h{$i++} = $_;
}

print $h{'3'}, "\n";

