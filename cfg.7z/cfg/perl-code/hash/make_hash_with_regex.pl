#!/usr/bin/perl -w

# let's dynamically build a hash from regexing strings
# the mininal matching in the first capture (?) is so it only gobbles
# up thru the first : , then the next is not min, it gobbles all after
# the first :

while(<>) {
	/^(.*?):(.*)$/;
	$hash{$1} = $2;

}

print "$hash{$_}\n" for keys %hash;

my %cmp = map { $_ => 1 } keys %hash;
print "$_\n" for keys %cmp;

# could also be:
#%fields = /^(.*?): (.*)$/gm;

