#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/bin-conv.pl"
# LAST MODIFICATION: "Thu, 22 Jan 2015 14:21:13 -0500 (jkipp)"
# (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;

sub binary { 
	my ($n) = @_;
	return $n if $n == 0 || $n == 1;
	my $k = int($n/2);
	my $b=$n%2;
	my $E = binary($k);
	return $E . $b;
}

my $s = binary(37);
print $s;
