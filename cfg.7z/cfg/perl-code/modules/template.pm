#!/appl/perl5/bin/perl -w

# add personal lib dir to the @INC array
# only  need this if you can not set the perlib env variable
BEGIN { push @INC, "~/perlmods" }

sub usage
{
	print <<'END';
	use Template;
	note: if this package is part of another package and in a nested subdir,
	 you must show that
	for expample if your perlib is ~/perlib and you have a a dir structure under that
	like bigmod/subdir/template.pm then you would do:
	use bigmod::subdir::Template
	my $obj = new Template (DATA => 'arg');
	$obj->some_method();
	
	END
}


use strict;
use Carp;
package Template;
$VERSION = "1.00";
use vars '$AUTOLOAD';


# keep count of objects created
# define a couple of closure subs to keep the stuff in this block private
# _add_count will be a private method

{
	my $_count = 0;
	sub get_count  { return $_count }
	sub _add_count { ++$_count     }
}


# example default data hashref. use to determine allowed constructor
# data and default constructor data

my %_default = (
	FILE => 'out.txt'
);

# this is the constructor for mew methods
sub new 
{
	my ($obj, %args)  = @_;   # get class as first arg and constructor args in @_
	my $class = ref($obj) || $obj;
	my $self    = { };	# data structure(anon hash) to be blessed
	bless $self, $class; # bless the new obj into the class

	#remember, when you populate the hash, create methods to access
	#the data in it. DO NOT access it directly.

	# check for valid input by sorting thru the keys in the args passed to the 
	# constructor and matching them with the default %data
	# the user must use a key defined in the %data hash or it won't take it
	# start adding the data and if there is not data in the args, then
	# use defualt if no data is passed

	foreach my $key ( keys %_default )
        {
                if ( (exists $args{$key}) && ($_default{$key} == uc($args{$key}) )
                        { $self->{$key} = $args{$key} }
                elseif ($_default{$key} != uc($args{$key}) )
                        { croak "Arg $key is not supported in $class\n"; }
                else
                        { $self->{$key} = $_default{$key} }
        }

	# accessor method:  use this method to define the output 
	sub define_file { return $self->{FILE} };

	$class->_add_count();	# add to count when new object is created
	return $self; # The object returned is $self

}


# destroy method to clean up after ourselves
sub DESTROY
{
	my $self = @_; # object is gone !
}

# the autoload sub will catch bad accessor funcs 
# and accessor methods (get and put) are generated on the fly.

sub AUTOLOAD 
{

	my $self = shift;
	my $class = ref($self) or die "hmmm $self must not be an oject\n";
  	my $attrib = $AUTOLOAD;
  	$attrib =~ s/.*:://;

  	unless(exists $self->{$attrib}) 
	{ croak "$attrib does not exist in $class \n"; }

  	if(@_) { return $self->{$attrib} = shift }
  	else { return $self->{$attrib} }
}


# another accessor method (method that changes internal data)
sub get_info  { $self->{_some_info} } #assumes we have defined attribs and want to access


# example public method
sub print_me 
{
	my $self = shift;
	#use accessor method to access internal vars instead of exporting them
	my $file = $self->define_file(); 
	
	open FILE, ">$file" or die: $!;
	print FILE "Calling this method\n";
	close FILE;
}
		
	
	
1;













