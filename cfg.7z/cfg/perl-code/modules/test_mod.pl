use strict;                 # ALWAYS use strict!
    use MyModule;               # Our module

    # A call to the constructor in our module
    my $obj = new MyModule ( FILE => 'foo.txt' );

    # A call to a method in our module
    $obj->print_me();
