#!/usr/bin/perl -w
# FILE: "/home/jj/LogChk.pm"
# LAST MODIFICATION: "jue, 04 oct 2001 09:37:02 -0400 (jj)"
# (C) 2001 by Juan Fuentes, <juan.fuentes@codetel.net.do>
# $Id:$

=head1 NAME

Log - Perl extension  Log

=head1 SYNOPSIS

use LogChk;

$foo = LogChk->new(LOGS    => ["/var/log/messages", "/var/log/sulog"],
                KEY_WORDS  => ["connect", "rsh", "warnning"],
                MAIL       => ["1" ], 
             );
print $foo->parse();

    or

use Log; 

@log  = qw( /var/log/messages /var/log/sulog);
@key  = qw(kernel ppp jj);
$mail = "1";
my $foo = LogChk->new(LOGS   => \@log,
                   KEY_WORDS => \@key, 
                   MAIL      => $mail,
               ); 
               
print $foo->parse();

_END_

=Head Functions

<B> new 

The argument to new are:

- LOGS: This is an array ref, it can be an anon array, here you give
  the full path to log files you want to parse.

- KEY_WORDS: Like LOGS it's an array ref, and it contains the key
  words to search for.

- MAIL: This is a true or false value to send mail, 1 it sends mail
  0 it doesn't, default is to $USER else to root.

=end 

=head1 DESCRIPTION

Parses Logs Duh!!!!!!!!

=head1 AUTHOR

Juan Fuentes <juan.fuentes@codetel.net.do>
Jim Kipp <jkipp5@home.com>

=cut

package LogChk; 
use strict;
use Carp;

use vars qw(@log $line $logs $VERSION); 

$VERSION = "0.1";

sub new 
{
	my ($caller, %args) = @_;  # is new :-).
	my $caller_obj      = ref($caller);
	my $class           = $caller_obj || $caller;
	bless {
        _log_files => $args{LOGS}        || croak("Missing log files"), 
        _key_words => $args{KEY_WORDS}   || croak("Missing key words"),
        _mail      => $args{MAIL}
    }, $class;
}


sub parse 
{
    my ($self)    =  shift;
    my ($logs)    =  $self->{_log_files}; 
    my ($key)     =  $self->{_key_words}; 
    my ($mail)    =  $self->{_mail};


    foreach $logs (@$logs) {
        chomp($logs);
        if ( -e $logs) {
            open(LOG, "$logs") or die "Failed to open $logs:$!";
            while ($line = <LOG>) {
                next if $line =~ /^\s*$/;
                foreach (@$key) {
                    if ($line =~ /$_/ig) {
                        push @log,$line;
                    } else {
                        next;
                    }
                }
            }
            close LOG or die "Failed to close $logs:$!";
        }
    }
    if ($mail eq "1") {
       send_mail(@log);
    } elsif ($mail eq "0") {
       return(@log);
    }
}

sub send_mail
{

    my $to      = "$ENV{USER}\@$ENV{HOSTNAME}" || "root\@$ENV{HOSTNAME}";
    my $subject = "Log report";

    open(MAIL, "|sendmail $to") or die "sendmail :$!";
    print MAIL "Subject: ",$subject,"\n";
    print MAIL @_;
    close MAIL;
}

1; 
