use strict;
package MyModule;
    

    ### private data to class
    ### this holds our default data
    ### AND our allowed data
    my %data = (
        FILE    => 'out.txt'
    );

    sub new {
        my $class   = shift;
        my %args    = @_;
        my $self    = { };

        ### check for wrong input ###
        for my $key ( keys %args ) {
            unless( exists $data{$key} ) {
                print "WARNING! Option $key is not supported in $class!\n";
            }
        }

        ### bless the object into the class ###
        bless $self, $class;

        ### now we start adding the data ###
        for my $key (keys %data) {
            if ( exists $args{$key} ) {
                $self->{$key} = $args{$key};
            } else {
                $self->{$key} = $data{$key};
            }
        }

        return $self;
    }

    sub print_me {
        my $self = shift;

        open O, ">$self->{FILE}" or die $!;

        print O "You succesfully called a method!\n";

        close O;
    }

    1;
