#!/usr/bin/perl -w
# BEGIN { push @INC, "~/perlmods" }

use strict; 
use Logs;

my $log = new Logs (  FILE => 'list' , FORM => 'htm' );

$log->write();        




