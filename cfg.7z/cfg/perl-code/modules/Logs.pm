#!/appl/perl5/bin/perl -w

BEGIN { push @INC, "~/perlmods" }

# module to pick the format of a logfile
# can be html, Unix text, Win32 text

# USAGE EXAMPLE
# use Logs;
# my $log = new Logs (  FILE => '$someFile',
#                       FORM => 'htm',
# );
# $log->write();

	
use strict;
package Logs;
use vars '$AUTOLOAD';

# routines to count objects
{
        my $_count = 0;
        sub get_count  { return $_count }
        sub _add_count { ++$_count     }
}



# acceptibe args for FORM are 'unix', 'htm', and 'win'
my %_default = (
        FILE => 'outfile',
        FORM => 'unix'
);



sub new 
{
	my ($obj, %args)  = @_;
        my $class = ref($obj) || $obj;
        my $self    = { };
        bless $self, $class;

	# test the arg Keys
	foreach my $key ( keys %_default )
        {
                if  (exists  $args{uc $key} )
                        { $self->{$key} = $args{$key} }
                elsif ($_default{$key} != $args{uc $key} )
                        { die "Arg $key is not supported in $class: $!\n"; }
                else
                        { $self->{$key} = $_default{$key} }
        }
	
	# test to make sure form is correct, if  not die
	unless ($self->{FORM} =~ /^(unix|htm|win)$/i ){
		 die "bad FORM value. Please use unix, htm, win\n";
	}


        $self->_add_count();    # add to count when new object is created
	return $self;

}


# accessor subs
sub get_file { my $self = shift; return $self->{FILE}; }
sub get_form { my $self = shift; return $self->{FORM}; } 

sub DESTROY
{
        my $self = @_; # object is gone !
}

sub AUTOLOAD
{

        my $self = shift;
        my $class = ref($self) or die "hmmm $self must not be an oject\n";
        my $attrib = $AUTOLOAD;
        $attrib =~ s/.*:://;

        unless(exists $self->{$attrib})
        { die "$attrib does not exist in $class \n";}

        if(@_) { return $self->{$attrib} = shift }
        else { return $self->{$attrib} }
}



sub write
{
        my $self = shift;
        my $file = $self->get_file();
        my $form = $self->get_form();

        my $line;
        my @buffer;
        my $out_file = ($form eq 'htm') ? "out.htm" : "out.txt";
        my $start = "
		    <HTML>
        	    <HEAD>
                    <TITLE>$file </TITLE>
                    </HEAD>
                    <BODY BGCOLOR=FFFFF>
                    <PRE>
                    <FONT FACE=Arial>\n";

        my $end = "
		  </PRE>
                  </BODY></HTML>";

        open (FILE, "<$file") or die "can't open $file $!";

        if ($form eq 'htm') {
                 my @array = <FILE>;
                 push (@buffer, $start);
                 foreach $line (@array) {
                         push (@buffer, $line);
                 }
                 push (@buffer, $end);
        }

        else
        {
                 while ( $line = <FILE>)
                 {
                         if ($form eq 'unix') {
                                 $line =~ s/<[^>]*>//g;
                                 $line =~ tr/\015//;
                                 push (@buffer, $line);
                         }
                         elsif ($form eq 'win')  {
                                 $line =~ s/<[^>]*>//g;
                                 $line =~ s#\012#\015\012#g;
                                 push (@buffer, $line);
                         }
                 }
         }

         close FILE;

         open (NEW, ">$out_file") or die " Can't open $out_file: $!\n";

         foreach my $newline (@buffer) {
                 print NEW "$newline";
         }
         close NEW;
}

1;


