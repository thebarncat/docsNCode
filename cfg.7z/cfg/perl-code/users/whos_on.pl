#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\FUNC_LIB\users\whos_on.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:05:15 Eastern Daylight Time"
# $Id:$

# routine to create a list of users logged on, skipping duplicates
#
#
sub whoson
{
	%ucnt = ();
	for (`who`) {
    	s/\s.*\n//;  # kill from first space till end-of-line, yielding username
    	$ucnt{$_}++;  # record the presence of this user
	}
	# extract and print unique keys
	@users = sort keys %ucnt;
}

# later we can print the users
# print "users logged in: @users\n";

