#!/usr/bin/perl

use User::pwent;
use File::stat;

while ($pwent = getpwent()) {
# goes thru the whole /etc/passwd to grab stuff

        $dirinfo = stat($pwent->dir."/.");
        #grabs the users home dir from /etc/passwd and stats the directory
        unless (defined $dirinfo ) {
                warn "uable to stat" .$pwent->dir." : $!\n";
                next;
}

warn $pwent->name."'s homedir is not owned by him/her id: (".$dirinfo->uid." instead "
        .$pwent->uid.")!\n" if ($dirinfo->uid != $pwent->uid);

# world writable is ok if we have the sticky bit set
warn $pwent->name."'s homedir is world writeable !!\n"
        if ($dirinfo->mode & 022 and (!$stat->mode & 01000)); 
} 
 
endpwent(); 
 
