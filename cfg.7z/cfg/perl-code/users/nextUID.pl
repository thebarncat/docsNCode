#!/usr/bin/perl

#$passwd = "/etc/passwd";
$passwd = 'getent passwd';

open (PW, "$passwd|") or die "can't open pipe $passwd:$!\n";
while (<PW>) {
	@fields = split(/:/);
	$highestuid = ($highestuid < $fields[2]) ? $fields[2] : $highestuid;
}
close (PW);
print "The next available UID is " . ++$highestuid . "\n";
