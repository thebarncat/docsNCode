#!/usr/bin/perl -w

use strict;

my $file = "users-allowed1";
open(FILE, "<", $file) or die "cannot open $file: $!";

while (my $line = <FILE>) {
	chomp $line;
	my ($user,$home) = ( split(/:/,$line) )[0,5];

	#SKIP users with no home dir, means they never logged in; 
	next unless -e $home;

	# IF users has no .profile then they have direct shell access 
	if ( -e "$home/.profile" ) {
		my $uid  = (stat("$home/.profile"))[4];
		my $owner = getpwuid($uid);
		my $gid = (stat("$home/.profile"))[5];
		my $gowner  = getgrgid($gid);
		my $mode = sprintf "%04o", (stat("$home/.profile"))[2] & 07777;
		#my $mode = (stat("$home/.profile"))[2] & 07777;
		print "$home/.profile is owned by $owner:$gowner\n";
		print "Permissions are $mode\n"; 
		# convert mode to decimal to compare
		print "NOT good mode\n" if (oct($mode) != 0664);
	}

}

close FILE;

