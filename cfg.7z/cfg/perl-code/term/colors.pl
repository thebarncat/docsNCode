#!/usr/bin/perl  
# FILE: "/home/jkipp/perl-code/term/colors.pl"
# LAST MODIFICATION: "Tue, 24 Dec 2013 09:34:18 -0500 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

use Term::ANSIColor;
print color("red"), "Stop!\n", color("reset");
print "hello\n";
