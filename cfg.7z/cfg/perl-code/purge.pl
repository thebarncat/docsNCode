#!/usr/bin/perl -w
use strict;

my @purge = qw( bdvdelxmondb01 );

sub dedup {
	# get rid of empty lines too 
	@_ = grep /\S/, @_;
	my %seen;
	grep !$seen{$_}++, @_;
}

my $purged = "shorty";
for my $old (@purge) {
	print "purging: $old\n";
	system("perl -pi -e 's/$old,\\s+//g' $purged") ==0  or die "failed: $?";
	system("perl -pi -e 's/,\\s+$old//g' $purged") ==0  or die "failed: $?";
	system("perl -pi -e 's/=\\s+$old//g' $purged") ==0  or die "failed: $?";
}



