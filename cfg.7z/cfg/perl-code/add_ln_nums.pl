#!/usr/bin/perl -w

# adds line numbers to script
# usage: cat add_ln_nums.pl | ./add_ln_nums.pl
use strict;

while (my $line = <>) {
   chomp($line);
   # pads 3 chrs before line no of current line
   $line =~ s/^/sprintf("%3s ", $.)/e;
   print "$line\n";
}


