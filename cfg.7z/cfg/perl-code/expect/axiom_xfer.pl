#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/expect/axiom_xfer.pl"
# LAST MODIFICATION: "Mon, 20 May 2013 16:59:22 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

use Expect;
$| = 1;

$cmd = '/appl/uas/ssh/bin/sftp xxxxx@omnia';
$pw = 'xxxxxxxxx';
$lcd = '/db/lsd10/loan/mrd/raw_downloads';

# switch to local dir where the xferd files should go
chdir $lcd;
 
# spawn the sftp program
my $sftp = Expect->spawn($cmd) or die "Can't spawn cmd: $!";
$sftp->log_stdout(0);

# wait 10 seconds for password prompt. -re arg means use regex
unless ( $sftp->expect(10, -re , '.*assword:') ) {
	print "timed out while waiting for Password Prompt. Server down ??\n";
	exit;
}

print $sftp "$pw\r";

# wait for sftp shell prompt:
unless ( $sftp->expect(10, -re , 'sftp>') ) {
    print "timed out or something else went wrong\n";
    exit;
}

# cd to the axiom dir to grab the files from
$sftp->send("cd /u10/seatab\r");

# $sftp->interact();

# wait for the next shell prompt:
unless ( $sftp->expect(10, -re , 'sftp>') ) {
    print "timed out or something else went wrong\n";
    exit;
}

# grab the files
$sftp->send("mget SUPP*.gz CARDHOLDER*.gz  AAA*.gz RACING*.gz MILITARYLAW*.gz AFFINITY*.gz TRANSPORTATION*.gz ALUMNI*.gz STUDENT*.gz\r");

# $sftp->expect(undef);

# wait FOREVER the next shell prompt, since we don't know how long the xfer will take:  expect will close the fh after a defualt of  15 seconds
unless ( $sftp->expect(undef, -re , 'sftp>') ) {
   print "timed out or something else went wrong\n";
   exit;
}

# quit the sftp session. MAY need to catch the HUP sig when running on cron
$sftp->send("quit\r");
$sftp->soft_close();

{
        local $fh = \*STDERR;
        open ($fh, ">/dev/null") or die "can't open error file\n";
        system("chown -R dbmsys:dbm $lcd");
}

