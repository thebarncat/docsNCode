#!/usr/bin/perl -w 
# FILE: "G:\bin\fix_width.pl"
# LAST MODIFICATION: "Tue, 29 Mar 2005 16:33:04 Eastern Standard Time"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

my $outfile = "bethany.txt";
my $file = 'ing_file.csv';

open (OF,">$outfile") or die "can't open for writing: $!";
open (F, "<$file") or die "can't open: $!";

$header = "PRIMNAME\tPRIMSSN\tADDR1\tCITY\tSTATE\tZIP";
print OF "$header\n";

while (<F>) {
	chomp;
	next if $. == 1;
	($n, $s,$a,$c,$st,$z) =  split(/,\s?/,$_) or die "$!"; 
	$name = sprintf("%-25s", $n);
	$ssn =  sprintf("%09d", $s); # left pad to add beginning 0s
	$addr = sprintf("%-35s", $a);
	$city = sprintf("%-16s", $c);
	$state = sprintf("%2s", $st);
	$zip = sprintf("%05d", $z);

	print OF "$name\t$ssn\t$addr\t$city\t$state\t$zip\n";
}

close F;
close OF;

