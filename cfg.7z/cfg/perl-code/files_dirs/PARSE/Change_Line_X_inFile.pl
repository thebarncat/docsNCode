#!/usr/bin/perl -w

# FROM PERLFAQ5

$file = "foo";
open my $in,  '<',  $file      or die "Can't read old file: $!";
open my $out, '>', "$file.new" or die "Can't write new file: $!";

while(<$in>) { # print the lines before the change
	print $out $_;
	last if $. == 4; # line number before change
}

my $line = <$in>;  # we are now at line we want to change
#  make the change
$line =~ s/\b(perl)\b/Perl/g;
print $out $line;

while( <$in> ) { # print the rest of the lines
	print $out $_;	
}
