#!/usr/bin/perl -w
# use strict;

open(IN, 'word.txt') or die "Can't open word.txt: $!\n";

while (<IN>) {
  print "dups found on line $.\n" if m/\b(\w+)\s+\1\b/;
}
close (IN);

# the back reference \1 is used to repeat the first char set (word).
# references the pattern memory while still inside the pattern. After this 
# statment anywhere else in the program, $1 will hold the repeated character.