#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/get_line_x.pl"
# LAST MODIFICATION: "Mon, 10 Jun 2013 16:20:04 -0400 (jkipp)"
# $Id:$

# usage:
$file = $ARGV[0];

# the line number you are seeking
$seeking = $ARGV[1];

open(FILE, "<$file")         or die "Can't open $file for reading: $!\n";
# open file rd,wr,create,trunc, no append
open(INDEX, "+>$file.idx")   or die "Can't open $file.idx for read/write: $!\n";
build_index(*FILE, *INDEX);
$line = line_with_index(*FILE, *INDEX, $seeking);
print $line;

# usage: build_index(*DATA_HANDLE, *INDEX_HANDLE)
# for every line in the data file write the byte pos to the index file
sub build_index {
    my $data_file  = shift;
    my $index_file = shift;
    my $offset     = 0;
 
    while (<$data_file>) {
		# print an unsig long in your machine's net byte order (this
		# insures the index size entries are correct
		# keep track of the offset and write to the index file to create
		# a byte marker for each line 
        print $index_file pack("N", $offset);
        $offset = tell($data_file);
    }
}

# usage: line_with_index(*DATA_HANDLE, *INDEX_HANDLE, $LINE_NUMBER)
# returns line or undef if LINE_NUMBER was out of range
sub line_with_index {
    my $data_file   = shift;
    my $index_file  = shift;
    my $line_number = shift;
 
    my $size;               # size of an index entry
    my $i_offset;           # offset into the index of the entry
    my $entry;              # index entry
    my $d_offset;           # offset into the data file
 
	# grabs the size of your an int according to your machine
    $size = length(pack("N", 0));
	# get the offset of the line number you are seeking 
    $i_offset = $size * ($line_number-1);
	# seek the index file to offset
    seek($index_file, $i_offset, 0) or return;
	# read the pos index byte marker into $entry 
    read($index_file, $entry, $size);
	# unpack the byte pos of where we are in the index file
    $d_offset = unpack("N", $entry);
	# seek to the specified byte offset in the data file
    seek($data_file, $d_offset, 0);
	# return the line of the position we are now at
    return scalar(<$data_file>);
}

 
