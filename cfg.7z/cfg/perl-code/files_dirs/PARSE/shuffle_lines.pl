#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\PARSE\data\shuffle_lines.pl"
# LAST MODIFICATION: "Tue, 17 Aug 2010 08:07:30 Eastern Daylight Time"
# $Id:$


# randomly shuffle the lines in a file
while (<INPUT>) {
    push(@lines, $_);
}
@reordered = shuffle(@lines);
foreach (@reordered) {
    print OUTPUT $_;
}

sub shuffle {
    my $array = shift;
    my $i;
    for ($i = @$array; --$i; ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @$array[$i,$j] = @$array[$j,$i];
    }
}

