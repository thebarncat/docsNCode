#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\PARSE\data\parse_csv.pl"
# LAST MODIFICATION: "Mon, 16 Aug 2010 15:14:15 Eastern Daylight Time"

# get the fields of a csv files but strip out all the wierd shit

# sample text:
# SAR001,"","Cimetrix, Inc","Bob Smith","CAM",N,8,1,0,7,"Error, Core Dumped"
sub parse_csv {
    my $text = shift;      # record containing comma-separated values
    my @new  = ();
    push(@new, $_) while $text =~ m{
        # the first part groups the phrase inside the quotes.
        "([^\"\\]*(?:\\.[^\"\\]*)*)",?
           |  ([^,]+),?
           | ,
       }gx;
       push(@new, undef) if substr($text, -1,1) eq ',';
       return @new;      # list of values that were comma-separated
}  

