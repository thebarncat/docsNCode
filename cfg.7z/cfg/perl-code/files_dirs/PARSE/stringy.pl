#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\PARSE\strings\stringy.pl"
# LAST MODIFICATION: "Tue, 17 Aug 2010 09:41:20 Eastern Daylight Time"
# $Id:$

$data = "fiver   eightttteighttttrestofthisshit";
$string ="five1five2five3five4";

# get a 5-byte string, skip 3, then grab 2 8-byte strings, then the rest
($leading, $s1, $s2, $trailing) = unpack("A5 x3 A8 A8 A*", $data);

#printf("%s\n%s\n%s\n%s\n", $leading, $s1, $s2, $trailing);

# split at five byte boundaries
@fivers = unpack("A5" x (length($string)/5), $string);

print "@fivers\n";
