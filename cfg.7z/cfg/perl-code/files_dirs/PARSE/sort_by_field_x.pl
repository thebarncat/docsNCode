#!/usr/bin/perl -w
# FILE: "G:\bin\munge\sort_by_field_x.pl"
# LAST MODIFICATION: "Wed, 01 Jun 2005 10:40:03 Eastern Daylight Time"
# (C) 2005 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

# Munge for a date field that looks like: 10/13/1995 0:00

use Time::Local;
my $file = 'fox.csv';
my %dat;
my @fields;
my $k = 0;

open (F, "<$file") or die "can't open: $!";
while (<F>) {
    chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	# get all the fields in the file
    my(@fields) = split(/,\s?/,$_);
	# convert date field to epoch seconds
	($month,$day,$year) = split(/\//, $fields[1]);
	$year =~ s/\s+0:00$//; # strip out time from year string
	$fields[1] = timelocal(0,0,0,$day,$month-1,$year-1900); 
	# make hash of arrays with iterative count as key names pointing
	# to each record array 
	$dat{$k} = [@fields];
	++$k;
}

# print the array ref indexes and values for each row
# for $key ( sort {$a <=> $b} keys %dat) {
# 	print "$key: ";
# 	for $i (0 .. $#{ $dat{$key} } ) {
# 		print "$i = $dat{$key}[$i]\t";
# 	}
# 	print "\n";
# }


# sort by *CHAR* field index x (desc) in the field array ref
#for $key ( sort { $dat{$a}[2] cmp $dat{$b}[2] } keys %dat ) {
#	print "$key:  @{ $dat{$key} }\n"
#}

# sort by *NUMERIC* field index x (desc) in the field array ref
for $key ( sort { $dat{$b}[4] <=> $dat{$a}[4] } keys %dat ) {
	print "$key:  @{ $dat{$key} }\n"
}


