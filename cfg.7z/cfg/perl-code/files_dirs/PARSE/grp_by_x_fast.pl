#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/grp_by_x_fast.pl"
# LAST MODIFICATION: "Mon, 10 Jun 2013 16:19:05 -0400 (jkipp)"
# $Id:$

my $file = 'sbo_no_hels.csv';
#my %dat;
my @fields;
my $k = 0;
# change this for the field you want to group by
my $grp_by = "DUE DATE";

open (F, "<$file") or die "can't open: $!";
while (<F>) {
    chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	## STUFF into hash of arrays
    # First item is the key field, rest of fields 
	my(@fields) = split(/,\s?/,$_);
	my($day,$month,$year) = split(/-/, $fields[2]);
	# iterate a hash key for each record
	$count{$day}++;
}

for $key (keys %count) {
	print "Total for $grp_by Day of Month: $key: $count{$key}\n";
}


