#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\string_manip\sort_ip_adr.pl"
# LAST MODIFICATION: "Thu, 16 Nov 2006 16:32:55 Eastern Standard Time"
# (C) 2005 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

# unpack the string created in the pack cmd below the x4 code
# overwrites the first 4 bytes (the packed binary
# ip) with null bytes and the A* simply prints the ip regular strings
print "$_\n" for map unpack( 'x4 A*', $_ ),
		# the C4 code part packs each byte of the ip
		# str into a unsigned struct, the regex does the job 
		# of filtering out the "." between
		# each byte in the ip because it looks for 1 or more digits in
		# row and repeats thru the entire ip adr str (/g qualifier)
		# the A* code part simply packs the entire IP as a string like it already is 
		# the packed strings are sorted 
		sort 
		map pack( 'C4 A*', /\d+/g, $_ ), 
qw[
192.168.0.1
192.168.0.100
192.168.0.101
192.168.0.114
192.168.0.115
192.168.0.116
192.168.0.117
192.168.0.118
192.168.0.119
192.168.0.12
192.168.0.120
192.168.0.121
192.168.0.122
192.168.0.123
192.168.0.124
192.168.0.125
192.168.0.126
192.168.0.127
192.168.0.128
192.168.0.129
192.168.0.13
192.168.0.130
];

