# FILE: "G:\CODE\perl-code\PARSE\get_last_line2.pl"
# LAST MODIFICATION: "Thu, 12 Jan 2012 13:33:32 Eastern Standard Time"

# get last line using tie
sub last_line_tie {
	use Tie::File;
	my @lines = shift;
    tie @lines, 'Tie::File', 'file' or die "Cannot read 'file' $!";
 	my $last_line = $lines[-1];
	return $last_line;
)


# get last line using seek

sub seek_last_line {
	use Fcntl ':seek';
	my $file = shift;
	my $size = 1024;
	my $buffer = '';
	my $last_line;

	sysopen FILE, $file, O_RDONLY or die "Cannot open 'file' $!";
	binmode FILE;
 	my $pos = sysseek FILE, 0, SEEK_END or die "Cannot seek on 'file' $!";
 	while ( $pos ) {
    	$pos = 0 if ($pos -= $size) < 0;
     	sysseek FILE, $pos, SEEK_SET or die "Cannot seek on 'file' $!";
     	sysread FILE, my $temp, $size or die "Cannot read 'file' $!";
     	chomp( $buffer = $temp . $buffer );
     	if ( ( $index = rindex $buffer, $/ ) >= 0 ) {
        	$last_line = substr $buffer, $index + length $/;
         	last;
         }
     }
	 return $last_line;
}
	
	

