#!/usr/bin/perl -w 
# FILE: "G:\bin\munge.pm"
# LAST MODIFICATION: "Tue, 29 Mar 2005 16:41:54 Eastern Standard Time"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$


{
use strict;
package Munge;

# set defualt class args
my %_default = (
	FILE => undef 
);


sub new {
				my ($obj, %args)  = @_;
				# if obj is a ref, then is an obj method, if not use
				# class string
                my $class = ref($obj) || $obj;
                my $self = {};
				#$self->{'FILE'} = $args{'FILE'};
                bless $self, $class;
        		for my $key (keys %args) {
                	if (exists  $args{uc $key} && ($key = 'FILE') ) {
				       $self->{$key} = $args{$key};
			    	} else {
						die "Arg $key not supported in class $class"; 
					}
				}

				return $self;

}

# accessor subs
sub get_file { my $self = shift; return $self->{FILE}; }

sub wc {
	my $self = shift;
	my $file = $self->get_file();
	my $numlines;
	open(F,"$file") or die "$file :$!";
	$numlines += tr/\n/\n/ while sysread(F, $_, 2 ** 16);
	close F;
	return($numlines);

}


sub head 
{	
	my $self = shift;
	my $file = $self->get_file();
	my @top;
	open(FILE, "$file") or die "$_ :$!";
	for (0..4) {
		push @top, scalar <FILE>,"\n";
	}
	close FILE; 
	return(@top); 
}






}


$a = Munge->new( FILE => 'fox.csv' );
$lines =  $a->wc();
print $lines, "\n";
@head = $a->head();
print @head;


