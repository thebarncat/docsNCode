#!/usr/bin/perl  -w
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/time_test.pl"
# LAST MODIFICATION: "Thu, 06 Jun 2013 11:18:16 -0400 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

use Time::Local;

my $file = 'oma_test.csv';
my $out_file = 'oma_test.out';
my %dat;
my @fields;

my %d_index = (
	JAN => 0,
	FEB => 1,
	MAR => 2,
	APR => 3,
	MAY => 4,
	JUN => 5,
	JUL => 6,
	AUG => 7, 
	SEP => 8, 
	OCT => 9,
	NOV => 10,
	DEC => 11
);

# note: $m is actual month number-1, $y is actual year-1900
# so this date would be 2005-08-08:
#my ($d, $m, $y) = (8, 7, 105);
# try this instead using todays date:

($d,$m,$y) = (localtime(time))[3,4,5];

# build the date string for time at noon on above date
my $day_at_noon = timelocal(0,0,12, $d, $m, $y);
# find day of the week
my $dow = (localtime $day_at_noon)[6];

print $dow;
