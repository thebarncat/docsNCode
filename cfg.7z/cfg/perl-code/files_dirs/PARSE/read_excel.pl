#!/usr/bin/perl -w
# FILE: "C:\test\read_excel.pl"
# LAST MODIFICATION: "Mon, 06 Jun 2005 15:08:49 Eastern Daylight Time"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

use strict;

use Win32::OLE qw(in with);
use Win32::OLE::Const 'Microsoft Excel';
use Win32::OLE::Variant;
use Win32::OLE::NLS qw(:LOCALE :DATE);

use constant TRUE  => 1;
use constant FALSE => 0;


$Win32::OLE::Warn = 3; # Die on Errors.
# ::Warn = 2; throws the errors, but  expects that the programmer deals  #

my $excelfile = 'c:/work/export2.xls';
my $Excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new('Excel.Application', 'Quit');
# turn off alert pop ups
$Excel->{DisplayAlerts}=0;   

my $Book = $Excel->Workbooks->Open($excelfile);     
$Book->SaveAs($excelfile); #Good habit when working with OLE, save often.

my $Sheet = $Book->Worksheets("Sheet1");
$Sheet->Activate();       
# $Sheet->{Name} = "sas_perl";

# read range of cells into data struct
my $data_array = $Sheet->Range( "A1:B6" )->{Value};
for (@$data_array) {
	for (@$_) {
          print defined($_) ? "$_|" : "<undef>|";
    }
    print "\n";
}

print "\n\n";

my $LastRow = $Sheet->UsedRange->Find({What=>"*",
    SearchDirection=>xlPrevious,
    SearchOrder=>xlByRows})->{Row};

my $LastCol = $Sheet->UsedRange->Find({What=>"*", 
    SearchDirection=>xlPrevious,
    SearchOrder=>xlByColumns})->{Column};


# search for dat
my $row = $Sheet->Range("A1:G500")->Find({What=>"10Y"})->{Row};
my $col = $Sheet->Range("A1:G500")->Find({What=>"10Y"})->{Column}; 



