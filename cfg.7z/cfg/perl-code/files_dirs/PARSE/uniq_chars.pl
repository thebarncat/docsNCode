#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\PARSE\strings\uniq_chars.pl"
# LAST MODIFICATION: "Tue, 17 Aug 2010 09:41:33 Eastern Daylight Time"
# $Id:$

sub uniq
{
	%seen = ();
	# get incoming string
	$string = shift;
	foreach $byte (split //, $string) {
    	$seen{$byte}++;
	}
	@uniq_chars = sort(keys %seen);
	return @uniq_chars;
}
