#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/grp_by_x.pl"
# LAST MODIFICATION: "Thu, 28 Apr 2016 09:44:47 -0400 (jkipp)"
# $Id:$

use Time::Local;
my $file = 'om_0305.csv';
my %dat;
my @fields;
my $k = 0;
# change this for the field you want to group by
my $grp_by = "ARM TYPE";

open (F, "<$file") or die "can't open: $!";
while (<F>) {
    chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# skip lines with just ",,".  
	# this is broken for large record files, need to fix at some point
	# next if (index($_, ",,") > -1); 
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	## STUFF into hash of arrays
    # First item is the key field, rest of fields 
	my(@fields) = split(/,\s?/,$_);
	# iterate a hash key for each record
	$dat{$k} = [@fields];
	++$k;
}

# simulate group by count for specified index for field array ref
my %count;
for $key (keys %dat) {
	# run get_fields.pl to get field number => name you want to group by
	$x = $dat{$key}->[12];
	$count{$x}++;
}

for $key (keys %count) {
	print "Total for $grp_by  $key: $count{$key}\n";
}


