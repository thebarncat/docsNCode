#!/usr/bin/perl -w
#
# simulate turning off buffering by making the File handle hot
# perl will flush the FH buffer immediatley

# the select makes FH, the hot filehandle. and then unbuffer it.
# when done we select whatever FH we were working with before

open (FH, ">some.file");

# returns the currently selected filehandle
{ my $ofh = select FH;
	  $| = 1;
	  select $ofh;
}

# could also use the IO::Handle module
 use IO::Handle;
 FH->autoflush(1);

# do the buffering yourself.  this comes in handy if you are writing to
# a datafile with set byte records. say each record has = chars and
# takes 57 bytes per record. you want to make sure the file is not
# corrupted and a record get chopped of is the proc is killed
# the defualt buffer is usually 8k, so 8151 is the highest number less
# then 8k that is divisble by 57
 use IO::Handle '_IOFBF'; # `FBF' means `Fully Buffered'
 	FH->setvbuf($buffer_var, _IOFBF, 8151); 

# MANUAL Buffering:
# this method is good for flushing buffers at intervals (10 secs)
if (time > $last_flush_time + 10) {
	  my $ofh = select LOG;
	  $| = 1;                    # Make LOG socket hot
	  print LOG "";              # print nothing
	  $| = 0;                    # LOG socket is no longer hot
	  select $ofh;
	  $last_flush_time = time;
}

	... Do something else ...
#
# can also use the IO modules method:
$filehandle->flush();         


# note: sysread and syswrite don't use buffering at all !!!!
