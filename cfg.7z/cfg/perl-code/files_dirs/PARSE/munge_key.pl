#!/usr/bin/perl -w
# FILE: "G:\bin\munge_key.pl"
# LAST MODIFICATION: "Mon, 17 Oct 2005 09:32:18 Eastern Daylight Time"
# (C) 2005 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

## IMPORTANT: this program relies on a UNIQUE key fields as the first
#  column in the file. If you don't need a key field use munge.pl
use Time::Local;

my $file = 'fox.csv';
my %dat;
my @fields;
my $sum = 0;
open (F, "<$file") or die "can't open: $!";
while (<F>) {
    chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# skip lines with just ",,"
	# next if (index($_, ",,") > -1); 
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	
	# assign first field as key, stuff the rest of the fields into a scalar
	#my ($key,$value) = split( /,\s?/, $_, 2); 
	#$dat{$key} = $value;

	## STUFF into 2 dim array (no key field)
	# my(@fields) = split(/,\s?/,$_); 	
	# push(@tmp, [@fields]);

	## STUFF into hash of arrays
    # ***** First item is the KEY field ***** rest of fields 
    my($kf,@fields) = split(/,\s?/,$_);
	# convert date string to epoch seconds
	($month,$day,$year) = split(/\//, $fields[0]);
	$year =~ s/\s+0:00$//; # strip out time from year string
	$fields[0] = timelocal(0,0,0,$day,$month-1,$year-1900); 
    # create a key with the first field and remaining fields the  value
	$dat{$kf} = [@fields];
}

# print the array ref indexes and values for each row
for $key ( sort {$a <=> $b} keys %dat) {
	print "$key: ";
	for $i (0 .. $#{ $dat{$key} } ) {
		print "$i = $dat{$key}[$i]\t";
	}
	print "\n";
}


