# FILE: "G:\CODE\Perl\PARSE\data\get_last_line.pl"
# LAST MODIFICATION: "Tue, 17 Aug 2010 08:07:44 Eastern Daylight Time"

# position pointer at the end of file, and then search for newlines

open F, "ncr_march.txt" or die $!;
# seek to the end of the file
seek F, 0, 2;
while ($pos = tell F) {
	# seek back 1024 bytes from end of file (current pos) unless $pos
	# is less thatn 1024, then use $pos
	seek F, -($pos > 1024 ? 1024 : $pos), 1 or die;
	# read the 1024 byte chunk at the end of the file into $block
    read (F, $block, 1024);
	# append block to $_
    $_ .= $block;
	# read the chunk data until the last new line char, then store
	# the rest into $1 and this is our last line , then break out;
	# the regex- match one or more of any chars up until a new
	# line (greedy, so it looks for the last new line). the /s specfier
	# says that . can match new lines as well. after it finds the 
	# last newline char, it stores everthing else in $1 which is $last
    do {$last = $1; print "$last"; last} if /.+\n(.+)/s;
}

