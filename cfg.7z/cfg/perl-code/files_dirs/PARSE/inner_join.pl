#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/inner_join.pl"
# LAST MODIFICATION: "Tue, 05 May 2015 15:35:08 -0400 (jkipp)"
# $Id:$

$file1 = 'trans.csv';
$file2 = 'cust.csv';
open(F1, "<$file1") or die "can't open: $!";
open(F2, "<$file2") or die "can't open: $!";
# get arrays for both file contents from the read_file subroutine
@F1 = read_file(\*F1);
@F2 = read_file(\*F2);
close F1; close F2;
# sort both arrays. ASSUMES the loan_num is the first field in each  file.
@F1 = sort { $a->[0] cmp $b->[0] } @F1;
@F2 = sort { $a->[0] cmp $b->[0] } @F2;

# simulate an sql **inner** join (only include records if key matches ) 
# this is the part that needs work. if you wanted to an outer join, it
# would not work since the inner loop does all it's iterations first.
# so if you wanted to print the records in the first file (left table)
# even if there is no match you would get a line for each inner loop
# iteration. uncomment the 4th line and run the code and you will see  that
for $row1 (@F1){  # trans records
    my $transrec = join ( ',', map { $_ }  @$row1);	
    for $row2 (@F2) { # cust records
		    #print "$transrec\n" if $row1->[0] != $row2->[0]; #don't work
			if ($row1->[0] == $row2->[0]) {
				# skip the loan_num field
				my $custrec = join ( ',', map { $_ }  @$row2[ 1 .. $#{$row2} ] );
				# concat the 2 lines into 1 
				my $newrec = $transrec . "," . $custrec;
                 # *** this just prints to the screen. I will leave to
				 # you to open an outpuf file and print to that **** 
				print $newrec, "\n";
			}
		}
}

# sub reads each small file into an array an returns that array
# assume csv file
sub read_file {
	my @tmp;
	local *FH = shift;
	while (<FH>) {
		chomp;
		next if /^\s+$/;
		# skip header 
		next if $. == 1;
		# remove leading commas:
	    $_ =~ s/^[\s*\,]+//;
	    # remove trailing commas:
	    $_ =~ s/[\s*\,]+$//;
		# remove quotes chars
		$_ =~ s/"//g;
		# split each line into fields
		my(@fields) = split(/,\s?/,$_);
		# push each line array onto another array
		push(@tmp, [@fields]);
	}
    return @tmp;
}


