# FILE: "U:\My Documents\scripts\perl\func_libs\file_parse\get_first_10_lines.pl"
# LAST MODIFICATION: "Thu, 31 Oct 2002 11:23:04 Eastern Standard Time"
# (C) 2002 by Jim Kipp, <james.kipp@mbna.com
#
my $file = "file.txt";

open (IN, "$file") or die "can't open $!\n";
open (OUT, ">test.dat");
while ($line = <IN>) {
	for (1 .. 10)  { print OUT $line }
	last;
}

close OUT;
close IN;


