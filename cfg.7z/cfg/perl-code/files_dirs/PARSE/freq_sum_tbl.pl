#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/freq_sum_tbl.pl"
# LAST MODIFICATION: "Wed, 28 May 2014 13:53:20 -0400 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$


my $file = 'fico.csv';
my $tot_bal = 0;
my $tot_loans = 0;
my $dunno;
my($loan,$bal,$fico);
my %bkts;

open (F, "<$file") or die "can't open: $!";

while (<F>) { $users{$name}{'ldap'} = 1
	chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	# remove quotes chars
	$_ =~ s/"//g;
	($loan,$bal,$fico) = split(/,\s?/,$_);
	#++$tot_loans if $loan;
	++$tot_loans;
	$tot_bal += $bal;

	if ( $fico == -99 || $fico == 0 ) {
		my $bkt = 'Missing';*
		bucket($bkt,$fico,$bal);
	}
	elsif ( $fico >= 650 && $fico < 700 ) {
		my $bkt = '650 - 750';
		bucket($bkt,$fico,$bal);
	}
	elsif ( $fico >= 700 && $fico < 725 ) {
		my $bkt = '700 - 725';
		bucket($bkt,$fico,$bal);
	}
	elsif ( $fico >= 725 && $fico < 750 ) {
		my $bkt = '725 - 750';
		bucket($bkt,$fico,$bal);
	}
	else { ++$dunno; print "don't know about $fico\n" }

}

close F;
print "\nThere were $dunno unknowns\n";
if
open (OUT, ">fico_roll.csv") or die "can't open: $!";
print OUT "Bucket,WAV,# of loans,% of loans,Sum Bal,% of bal\n";
# prit missing first
#print OUT "Miss,\0,$cnt_miss,\0,$tot_bal_miss\n";

sub bucket {
	my($bkt,$fico,$bal) = @_;
	# count freq in bucket
	++$bkts{$bkt}{'cnt'}; 
	# tot balance per bucket
	$bkts{$bkt}{'tot_bal_bkt'} += $bal;
	# weight each score
	$bkts{$bkt}{'wt_bkt'} = $fico * $bal;
	$tot_wt = $bkts{$bkt}{'wt_bkt'};
	# get total weight 
	$bkts{$bkt}{'tot_wt_bkt'} += $tot_wt; 
}


prt_csv(\*OUT,\%bkts);

sub prt_csv {
	local *FH = shift;
	my($bkts) = shift;
	my ($bkt,$wav,$p_loan,$p_bal);
	for $bkt (sort keys %$bkts) { 
		$wav = sprintf("%.0f",$bkts->{$bkt}{'tot_wt_bkt'} / $bkts->{$bkt}{'tot_bal_bkt'}); 
	    $p_loan = sprintf("%.2f",$bkts->{$bkt}{'cnt'} / $tot_loans * 100);
	    $p_bal = sprintf("%.2f",$bkts->{$bkt}{'tot_bal_bkt'} / $tot_bal * 100);
        $wav = 'N\A' if $wav <= 0;
        print FH "$bkt,$wav,$bkts->{$bkt}{'cnt'},$p_loan,$bkts->{$bkt}{'tot_bal_bkt'},$p_bal\n";
	}
}

# print totals last
print OUT "Total,\0,$tot_loans,\0,$tot_bal\n";
close OUT;


