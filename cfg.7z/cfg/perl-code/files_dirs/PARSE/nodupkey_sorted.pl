#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/nodupkey_sorted.pl"
# LAST MODIFICATION: "Wed, 28 May 2014 13:19:47 -0400 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

my $file = 'test.csv';

my $cur_id = ''; 
open (OUT, ">test_out.csv") or die "can't open: $!";
open (F, "<$file") or die "can't open: $!";
while (<F>) {
	chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	#($id,$bal,$fico) = split(/,\s?/,$_);
	($id,$note) = split(/,\s?/,$_);
	# use eq oper for strings
	next if $cur_id eq $id;
	#next if $cur_id == $id;
	print "$id\n";
	print OUT "$id,$note\n";
	$cur_id = $id;
}
close F; close OUT;

