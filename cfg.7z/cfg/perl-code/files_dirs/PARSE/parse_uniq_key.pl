#!/usr/bin/perl -w
# FILE: "U:\My Documents\Perl\Code\func_libs\file_parse\parse_uniq_key.pl"
# LAST MODIFICATION: "Fri, 03 Oct 2003 13:33:34 Eastern Daylight Time"
# (C) 2002 by Jim Kipp, <james.kipp@mbna.com>
# $Id:$

# looks for a uniq key on the first column of a datafile, only grabs
# first record with that uniq key,  example data below

#open(FILE, "data.dat") or die "can't open $!";
my(%LINES);
while(<DATA>){
	my($key) = split;
	$LINES{$key} = $_ unless exists $LINES{$key};
}
close FILE;

# %LINES now has key value pairs of '123' and '444' as the keys and the
# value is the first occurence in the file.

for $key (keys %LINES) {
	print $LINES{$key};
}

__DATA__
123    ABC    XX112    YYYY    Zzzzzzzzzz
123    DEF    XX113    WWWW    Zzzzzzzzz
123    EEF    XX112    YYYY    Zzzzzzzzzz
444    ccc    vvbfd    QQQQ    ccccccccc
444    CCd    vvbfd    QQQQ    ccccccccc
444    ddd    ssddd    QQQQ    xxxxxxxx
