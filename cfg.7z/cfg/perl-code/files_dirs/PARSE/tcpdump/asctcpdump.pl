#!/usr/bin/perl

#
# Program to take hexdumps and convert them to ASCII
# Specifically invokes TCPDUMP...
# Suggested invocation is:
#	 asctcpdump -s 1024 -x ...expr...
# or asctcpdump -x -s 2048
#

# turn off line buffering
$| = 1;
open(PIPE, "tcpdump -l " . join(' ', @ARGV)." |") || die "open: $!";

while (<PIPE>) {
    if (!m/^\s*([0-9a-f]+\s*)+[\n\r]+$/) {
	print;
	next;
    }
    # got a valid line...
    $processed = '';
    $ascii = '';
    $leftover = $_;
    chomp($leftover);
    while ($leftover =~ m/([0-9a-f][0-9a-f])(\s*)/) {
	$processed .= $&;	# add what what we skipped over
	$leftover = $'; 	# set to what's left of the line.
	$chr = chr(hex $1);
	$chr = '.' if ($chr !~ m/[\040-\176]/);
	$ascii .= $chr;
    }
    $processed .= ' ' x (39 - length($processed))  if (length($processed) < 39);
    print "\t$processed      $ascii\n";
}
close(PIPE);
