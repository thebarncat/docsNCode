#!/usr/bin/perl -w 
# FILE: "/home/jkipp/perl-code/Files_Dirs/PARSE/get_fields.pl"
# LAST MODIFICATION: "Wed, 28 May 2014 09:46:29 -0400 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

use Getopt::Std;
my %opts;
# usage(), exit 1 unless @ARGV;

getopts('xkh', \%opts);
usage(), exit 1 if $opts{h};
if ( !($opts{k} or $opts{x}) ) { 
	print "\n**Need to supply a valid option**, see usage:\n\n"; 
	usage();
	exit 1; 
} 

my $file = $ARGV[0]; usage(), exit 1 unless $file;
my ($fields,$kf) =  get_fields($file); 

#print join(', ', @fields);
print "\nKey field: $kf\n\n";

=cut
for ($i =0; $i <= $#$fields; $i++)  {
	$fields->[$i] =~ s/"//g;
	print "$fields->[$i]\n"; 
}
=cut

print_index_wkey($fields) if $opts{k};
print_index($fields) if $opts{x};

sub get_fields {
	my $file = shift;
	open(F, "<$file") or die "can't open file: $!";
	my $header = <F>;
	my @fields = split(/,/, $header);
	#$key_field = substr($header,0,5);
	($key_field = $header) =~ s/(?:(.*?)\,).*/$1/;
	# strip quote symbols
	$key_field =~ s/"//g;
	close F;
	return (\@fields,$key_field);
}

# sub to print field index after removing key(1st) field 
sub print_index_wkey {
	my ($f) = shift;
	my @idx = @$f;
	# shift off the first (key) field
	shift @idx;
	my $i = 0;
	for (@idx) {
		print "$i => $idx[$i]\n";
		++$i;
	}
}

#  print field index keeping key(1st) field 
sub print_index {
	my ($f) = shift;
	my $i = 0;
	for (@$f) {
		print "$i => $f->[$i]\n";
		++$i;
	}
}

sub usage {
	(my $prog = $0 ) =~ s/^.*\\//; 
print <<EOF;

usage: $prog <options> <path_to_file>

       $prog -h  # prints help
       $prog -x <file>  # prints regular index
       $prog -k <file>  # print index, skipping key(1st) field

EOF
}
