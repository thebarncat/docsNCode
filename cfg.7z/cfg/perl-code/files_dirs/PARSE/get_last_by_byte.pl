# FILE: "U:\My Documents\scripts\perl\func_libs\file_parse\get_last_by_byte.pl"
# LAST MODIFICATION: "Mon, 28 Oct 2002 14:31:46 Eastern Standard Time"
# (C) 2002 by Jim Kipp, <james.kipp@mbna.com

# get last 100 bytes of the file
use strict;

if (open (FH, "file"))
{
  seek FH, -100, 2;
  while (<FH>)
  {
    print $_;
  }
  close (FH);
}

