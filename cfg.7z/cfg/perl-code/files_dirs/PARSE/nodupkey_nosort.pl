#!/usr/bin/perl 
# FILE: "G:\bin\data_munge\nodupkey_nosort.pl"
# LAST MODIFICATION: "Fri, 27 Jan 2006 12:40:25 Eastern Standard Time"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

my $file = 'fico.csv';

my %hash; 
open (OUT, ">fico_out.csv") or die "can't open: $!";
open (F, "<$file") or die "can't open: $!";
while (<F>) {
	chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	($loan,$bal,$fico) = split(/,\s?/,$_);
	# checks if $hash{$loan} is true or it's value is set to 1 
	# see the iteration line below. if it is, it skips whole record
    next if exists($hash{$loan}); 	
	print OUT "$loan,$bal,$fico\n";
	#  does this: $hash{'123'} = 1, (marks it as seen) so if line above sees '123' it will
	#  now skip over it.  print out entire %hash after this loop to see what it is doing
	#  print "$_ -> $hash{$_}\n" for keys %hash;
    $hash{$loan}++; 
}
close F; close OUT;

