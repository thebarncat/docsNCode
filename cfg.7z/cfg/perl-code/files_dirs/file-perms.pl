#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/Files_Dirs/file-perms.pl"
# LAST MODIFICATION: "Tue, 05 May 2015 14:12:44 -0400 (jkipp)"
# (C) 2014 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;

use warnings;
use File::stat;

my $fpath   = "my.file";
my $info    = stat($fpath);
my $retMode = $info->mode;
$retMode = $retMode & 0777;

if ($retMode & 002) {
    # Code comes here if World has write permission on the file
}     
if ($retMode & 020) {
    # Code comes here if Group has write permission on the file
}
if ($retMode & 022) {
    # Code comes here if Group or World (or both) has write permission on the file
}
if ($retMode & 007) {
    # Code comes here if World has read, write *or* execute permission on the file
} 
if ($retMode & 006) {
    # Code comes here if World has read or write permission on the file
} 
if (($retMode & 007) == 007) {
    # Code comes here if World has read, write *and* execute permission on the file
} 
if (($retMode & 006) == 006) {
    # Code comes here if World has read *and* write permission on the file
}
if (($retMode & 022) == 022) {
    # Code comes here if Group *and* World both have write permission on the file
}
