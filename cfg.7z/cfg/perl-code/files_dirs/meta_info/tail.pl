#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/Files_Dirs/meta_info/tail.pl"
# LAST MODIFICATION: "Tue, 23 Jul 2013 13:59:18 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

$file = 'foo.txt';
$size = (stat($file))[7];
$num = wc($file);
$recl = round($size/$num);
@fivers = tail($file,$recl);
print "$_\n" for @fivers;

sub tail {
	($file,$recl) = @_;
	open F, "$file" or die $!;
	# seek to the end of the file
	seek F, 0, 2;
	#$pos = tell F;
	$len = $recl * 6;
	#seek F, -($pos > 1024 ? 1024 : $pos), 1 or die;
	#seek F, -($pos > $len ? $len : $pos), 1 or die;
	# seek back $len from  current pos which is end of file
	seek F, -$len, 1 or die;
	#read (F, $block, 1024);
	read (F, $block, $len);
	close F;
	@lines =  reverse(split("\n", $block));
	@last_five =  @lines[0..4];
	return  reverse @last_five;
}

sub wc
{
	my $file = shift;
	my $numlines;
	open(F,"$file") or die "$file :$!";
	$numlines += tr/\n/\n/ while sysread(F, $_, 2 ** 16);
	close F;
	return($numlines);
}

sub round {
    my($number) = shift;
    return int($number + .5);
}


