#!/usr/bin/perl -w
use strict;
use Sys::Hostname;
use POSIX;

my $file;
usage(),exit() if @ARGV == 0;
my $path = getcwd;
my $OS;
my $answer = 'n'; # default user answer is no.
my $def_printer;

BEGIN { push @INC, "/appl/perl5/lib/5.00503" , "/home1/p/pcis/general/scripts/utils" }
$OS = "unix";


sub unix
{
	my $dirname ='';
	print "Would you like to print file info [n]-NO [1]-dbm1_1 [2]-dbm2_1 [3]-mrktrsrch [4]-inetmktg [5]-DirectResponse? : ";
	$answer = <STDIN>; 
	chomp($answer);
	# case
	if ($answer =~ /n/i or $answer eq "")  { $answer = 10; }
	elsif ($answer == 1) { $def_printer = 'dbm1_1'; }
	elsif ($answer == 2) { $def_printer = 'dbm2_1'; }
	elsif ($answer == 3) { $def_printer = 'mrktrsrch'; }
	elsif ($answer == 4) { $def_printer = 'inetmktg'; }
	elsif ($answer == 5) { $def_printer = 'np19d0966_1'; }
	# end case

	unlink("allinfo.csv")     if -f "allinfocsv";
	unlink("all.info")        if -f "all.info";

	foreach $file (@ARGV) {
		die "$file :$!" unless -f $file;
		print "Processing file $file .......................\n";
		print "\n";
		(my $cwd = getcwd) =~ s/.+\/(\w+)$/$1/;
		#(my $numrec       = `wc -l $path/$file`) =~ s/\s+(\d+?)\s.+/$1/;
		#chomp($numrec);
		my $numrec                 = &wc($file);
		my $projcode       = $cwd;      # $projcode is the same as the cwd.
		my $size                   = (stat("$path/$file"))[7];
		my $vendor                 = substr($file,0,3); 
		my $lrecl          = sprintf "%.4f",("$size" / "$numrec");
		my $block                  = sprintf "%d", 32769*("$numrec"/"$size");
		my $factor         = sprintf "%.1f",("$block"*"$lrecl");
		my $user                   = getpwuid($<);
		# (my $username    = (getpwnam($user))[6]) =~ s/,,,//;  
		my $filedate       = strftime "%b %d", localtime((stat("$path/$file"))[8]); 
		
		open(ALL, ">>allinfo.csv") or die "allinfo.csv :$!";
		print ALL "Vendor, Projcode, File, Path, Size, RecSize, Records, Factor","\n";
		print ALL "$vendor\,$projcode\,$file\,$path\,$size\,$lrecl\,$numrec\,$factor","\n";
		close ALL;
		gen_file($file,$projcode,$path,$size,$lrecl,$numrec,$block,$factor,$filedate,$user,$dirname);
	}
}

sub gen_file
{
	my ($r_file,$r_projcode,$r_path,$r_size,$r_lrecl,$r_numrec,$r_block,$r_factor,$r_filedate,$r_user,$r_dirname) = @_;
	my ($print,@head, @tail,$system,$date);
	@head = chkpos(head($r_file)); 
	@tail = chkpos(tail($r_file,$r_lrecl, $r_numrec)); 
	$system = hostname;
	$date   = localtime();
 if ($^O eq "MSWin32") {
	open(FILE, ">$r_dirname/all.info") or die "all.info :$!";
	}
	else {
	open(FILE, ">all.info") or die "all.info :$!";
	}
	$print = <<INFO;
	
__________________________________________________________

	      FILE INFORMATION                      
 
	      System: $system
		File: $r_file                 
		Path: $r_path           
	File Creator: $r_user 
File Last Changed On: $r_filedate
					  
    File Size(bytes): $r_size              
	 Record Size: $r_lrecl
   Number of Records: $r_numrec
     Blocking Factor: $r_factor
	  Block Size: $r_block
__________________________________________________________
Today's date: $date

 Note: if you have a decimal in record size, check
       for an end of file control character
	  

INFO
print FILE $print;
print FILE "\n";
print FILE "This is the head of: $r_path/$r_file\n";
print FILE "\n";
print FILE @head;
print FILE "\n";
print FILE "This is the tail of: $r_path/$r_file\n";
print FILE "\n";
print FILE @tail;
print $print;
print "This is the head of: $r_path/$r_file\n";
print FILE "\n";
print @head;
print "\n";
print "This is the tail of: $r_path/$r_file\n";
print FILE "\n";
print @tail;
close FILE;

}

if ($OS eq "unix") {
	&print_file();
}


sub print_file
{
	my $ans = $answer;

	if ($ans == 1 || $ans == 2 || $ans == 3 || $ans == 4 || $ans == 5) {
		print "Printing all.info to $def_printer\n";
		#chdir $path;
		system( "sprt -pt 6 -d $def_printer all.info" ); 
	 } 
}

	
sub usage
{

print STDERR <<"HELP"

Usage: finfo.pl <filename1> <filename2> ... 

Two files are created:   

1.  all.info containing fileinfo for all processed files.
    
2.  allinfo.csv containing a list of all processed files (for Media Create)
    with vendorcode,ProjectCode,FileName,Path,Size,RecordLength,
	NumOfRecords,BlockSize.
	

HELP
}

sub head 
{       
	my $file = shift;
	my @top;
		
	open(FILE, "$file") or die "$_ :$!";
	for (0..5) {
		push @top, scalar <FILE>;
	}
	close FILE; 
	return(@top); 
}

sub tail
{
	
	my ($file, $recl, $numrec) = @_;
	my @end;
	my $rec_mult;
	my $reslength;
	my @hold;
	open(FILE, "$file") or die "$file :$!";
	$rec_mult = ($numrec-6)*$recl;          # Calculate the byte location of the beginning of the fifth to last line
	seek FILE,$rec_mult, 1;                 # Rewind file handle to the previously calculated position

	while (<FILE>){ 
		push @end, $_;
	}

	$reslength = 0;
	$reslength = scalar @end;
	if ($reslength > 5){
		@hold = reverse @end;   
		pop @hold;
	}

	@end =reverse @hold;
	close FILE;
	return(@end);   
		
}

sub wc
{
	my $file = shift;
	my $numlines;
	open(FILE,"$file") or die "$file :$!";
	$numlines += tr/\n/\n/ while sysread(FILE, $_, 2 ** 16);
	return($numlines);
}

sub chkpos
{
	my @chk  = @_; # The data from head and tail.
	my @result;    # The ruler.
	my $cntr  = 1;
	my $tens  = 1;
	my $lngth = length($chk[0]);
	my $lstr;
	my @tensmark;
	my @ruler;
	my @seperator;
	my $screensize =70;
	# get length of longest line
	foreach (@chk){
		$lstr = length($_);
		if ($lstr > $lngth){ 
			$lngth = $lstr; 
		} elsif ($lstr < $lngth){ 
			next; 
		} else { 
			next; 
		}
	
	}
	
	#count the characters by tens
	my  $place = 0;
	for (my $i = 0; $i < $lngth; $i++){
		
		push @tensmark, " ";
		$place++;
		if ($i == 0){ 
			push @tensmark, " ";
		}
		if ($tens*10 >100) {

			if ($place == 7) {
				if ( ($tens*10) < $lngth){ 
					push @tensmark, $tens * 10; 
					$tens++;
					$place = 0;
				}
			}
		}
		else {
			if ($place == 8) {
				if ( ($tens*10) < $lngth){ 
					push @tensmark, $tens * 10; 
					$tens++;
					$place = 0;
				}
			}
		}
	}
	
	#build the ruler
	push @result, "\n";
	for (my $i = 0; $i <$lstr; $i++){
		push @ruler, $cntr;
		$cntr++;        
		if ($cntr == 10){ 
			$cntr = 0;
		}
	}
	
	push @result, "\n";
	# add the seperator line
	for (my $i = 0; $i < $lngth; $i++){
	
		push @seperator, "-";
	}
	# add the lines of head or tail
	if ($lngth > $screensize) {
		my $wraps = int ($lngth / $screensize);
		my @wrapresult;
		my $wrapend;
		my $wrapbeg;
		my $exttemp;
		my $ext;
		my $line;
		my $g;
		for ($g=0; $g<$wraps; $g++) {
			my @tentemp;
			my @rulertemp;
			my @septemp;
			$wrapbeg = ($screensize)*$g;
			$wrapend = $wrapbeg + ($screensize-1);
			
			$exttemp = join "",@tensmark;
			$ext = substr($exttemp,$wrapbeg, $screensize);          
			push @wrapresult, $ext;
			push @wrapresult, "\n";
			
			$exttemp = join "",@ruler;
			$ext = substr($exttemp,$wrapbeg, $screensize);
			push @wrapresult, $ext;
			push @wrapresult, "\n";
			
			$exttemp = join "",@seperator;
			$ext = substr($exttemp,$wrapbeg, $screensize);                          
			push @wrapresult, $ext;
			push @wrapresult, "\n";
			
			foreach $line (@chk) {
			$ext = substr($line,$wrapbeg, $screensize);     
				push @wrapresult, $ext;
				push @wrapresult, "\n";
				
			}
		
		}
		return (@wrapresult);
	}
		else {
	push @result, @tensmark;
	push @result, "\n";
	push @result, @ruler;
	push @result, "\n";
	push @result, @seperator;
	push @result, "\n";
	push @result, @chk;
	return(@result);
	}

}

