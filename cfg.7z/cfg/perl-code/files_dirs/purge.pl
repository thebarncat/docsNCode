#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/Files_Dirs/purge.pl"
# LAST MODIFICATION: "Tue, 01 Mar 2016 09:02:21 -0500 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;

use Cwd;
 
# create array of unwanted file types
# @junk=("core","dead.letter","*.v","tmp","*.swp");
  
my $startDir = cwd;
 
opendir(DIR, $startDir) or die "Can't open $startDir: $!";
my @names = grep {($_ !~ /^\.\.?$/ ) && (! -d $_)} readdir(DIR); 

# you can do grep {!/^\.\.?$/) && -f} (-f means if file) readdir(DIR), does the same thing
# and it's faster because you are doing a stat and then you have to discard
# all dirs, it's faster if you just look for files. Also the regex can be
# optimized by just looking for the entry is only dots by doing /^\.$/
# starts with a dot and finishes with a dot, but this will catch files as
# .foo. as the one you have, but slightly faster. Also the !~ slows things
# down because you are doing a boolean search, which for some reason it's  slower than just plain !.

closedir(DIR);

chk_files();
 
sub chk_files {
	foreach my $name (@names) { 
 		chomp($name);
 		if ($name =~/core|dead\.letter|.*\.swp|tmp|.*\.v/) {
	    	#unlink($name) or die "can't delete $name: $!\n;";
 		    print "Removing $name\n";
 		}
	} 
}

