#!/usr/bin/perl -w
use strict;
use File::Find;
use Digest::MD5;

my @def = qw(/usr /bin /etc /sbin );

my @path = @ARGV || @def;

foreach (@path) {
	chomp;
	next if /^\.\.?/;
	next if /^\/proc/;
	find ( sub { 
			my $md5 = Digest::MD5->new;
			$md5->add($File::Find::name);
			print $md5->hexdigest," $File::Find::name","\n";
		}, "$_");
}

