#!/usr/bin/perl

# FILE: audit.pl
# Last Modification: Wed Jul  3 09:59:38 EDT 2002

use strict;
use Getopt::Std;
use File::stat;
use Cwd;

# add files to audit to this array
my @files = grep { -f } glob('/home/foo/*');
my %opts;
my $curdir = cwd;
my $time = localtime(time);

my $usage = <<EOF;
USAGE: 

Run with ** -b ** to build an intial database of the files we want to monitor.
This will establish a baseline of the last modification and access times 
that we want to check against. Only have to run this if we modify the list 
of files to check or if the files are indeed modified. 
ONLY run the ** -b ** option by itself, script will exit after it runs. It builds a db 
and ignores any other options !!
To monitor the files run with the ** -c ** option. This will compare the current 
mod times with the one's in the database, if they are different it will 
send an alert via email. 

EOF

unless (@ARGV) { print "$usage"; exit; }

getopts('bcda', \%opts);

if ($opts{b}) {
    stat_files(\@files);
    print "Database built\n";
    exit;
}

if ($opts{c}) {
    chk_files(\@files);
}


sub stat_files 
{
	my ($file) = @_;
	my ($db, $st, $atime, $mtime);
	open(DB, ">/home1/j/jkipp/tmp/audit_db") or die "can't open file for writing: $!\n";
	foreach $file (@$file) {
		$st = stat($file) or die "couldn't stat $file: $!\n";
		$atime = $st->atime;
		$mtime = $st->mtime;
		print DB "$file  $atime  $mtime\n"; # make space delimited file to check on
	}
	close(DB);
}
		
sub chk_files
{
	my ($file) = @_;
        my (@chk, @db, $st, $atime, $mtime);
        foreach $file (@$file) {
                $st = stat($file) or die "couldn't stat $file: $!\n";
                $atime = $st->atime;
                $mtime = $st->mtime;
                push (@chk, [ $file, $atime, $mtime ] );
        }
	
	open(DB, "</home1/j/jkipp/tmp/audit_db") or die "can't open file for writing: $!\n";
	while (<DB>) {
		chomp;
		push @db, [ split ];
	}
        close(DB);
	
	for my $i ( 0 .. $#chk ) { 
		if ( $chk[$i][2] ne $db[$i][2]) { mail_alert($chk[$i][0], undef) };
	}

}

sub mail_alert
{
my ($file, $flag) = @_;
my $sendmail = '/usr/lib/sendmail';
my $userName = 'jkipp@ingdirect.com, rgrams@ingdirect.com';
my $subject = "AUDIT ALERT";
my $a = "Somebody accessed $file. NO modification was made\n"; # access msg
my $b = "$time:\nSomebody MODIFIED $file\n"; # modify msg

my $msg = $flag ? $a : $b;


my $mailMessage=<<EOF;
To:  $userName
Subject: $subject

$msg

EOF

open(MAIL, "| $sendmail -t -oi 2>/dev/null") or die "unable to open sendmail:$!\n";
print MAIL $mailMessage ;
close MAIL;

}

