#!/usr/bin/perl -w

# cron frequent: DF critical alert 
# run every 15 minutes daily
# sends email if any volume is over threshold

open(F, "<fs_list") or die "can't open: $!\n";
while (<F>) {
        ($dir, $flag) = split();
        $dir =~ s/\/db\///;
        push(@tmp, $dir) if $flag != 1;
}
$skip = join("|", @tmp);
close F;

$head = sprintf("%-20s %9s %6s\n\n", "Mount","Avail(GB)", "Used");
open(P, "bdf|") or die "can't pipe: $!";
while (<P>) {
	next if ($_ =~ /^\/dev|^nfs|^File|prod|user|lsd/);
	($avail,$used,$mount) = (split)[2,3,4];
	next if ($mount =~ /$skip/);
	$used =~ tr/%//d;
	if ( $used >= 98 ) {
        $avail = sprintf("%.2f",$avail/(1024*1024)); 
		$info .= sprintf("%-20s %9s %6s\n", "$mount","$avail","$used%"); 
	}
}
close P;

if ($info) { mailer(); exit; }

sub mailer
{
my $sendmail = '/usr/lib/sendmail';
my $userName = '';
my $subject = "FS Alert on host";

my $mailMessage=<<EOF;
To:  $userName
Cc: $cc
Subject: $subject

$head$info

EOF

open(MAIL, "| $sendmail -t -oi 2>/dev/null") or die "unable to open sendmail:$!\n";
print MAIL $mailMessage ;
close MAIL;

}

