#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/Files_Dirs/FS_usage/df_alert.pl"
# LAST MODIFICATION: "Wed, 05 Jun 2013 15:57:42 -0400 (jkipp)"
# $Id:$

$host = `hostname`;
open(P, "df /home|") or die "can't pipe: $!";
$head = sprintf("%-20s %9s %6s\n\n", "Mount","Avail(GB)","Used");
while (<P>) {
	#next if ($_ =~ /^\/nfs|^File/);
	next if ($_ =~ /^\/dev|^File/);
	#next if ($_ =~ /^\/\//);
	#($avail,$used,$mount) = (split)[3,4,5];
	($avail,$used,$mount) = (split)[2,3,4];
	$used =~ tr/%//d;
	if ( $used >= 85 ) {
     	$avail = sprintf("%.2f",$avail/(1024*1024)); 
	 	$info .= sprintf("%-20s %9s %6s\n", "$mount","$avail","$used%"); 
	}
}

#if ( defined $info ) { mailer(); exit; }
if ( defined $info ) { print $info; exit; }

sub mailer
{
my $sendmail = '/usr/lib/sendmail';
my $userName = 'jkipp@ingdirect.com';
my $subject = "FS Alert on $host";
#my $cc = 'rgrams@ingdirect.com

my $mailMessage=<<EOF;
To:  $userName
Cc: $cc
Subject: $subject

$head$info

EOF

open(MAIL, "| $sendmail -t -oi 2>/dev/null") or die "unable to open sendmail:$!\n";
print MAIL $mailMessage ;
close MAIL;
}

