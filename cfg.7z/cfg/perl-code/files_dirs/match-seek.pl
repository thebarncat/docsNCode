#!/usr/bin/perl -w

# 1 way to grab the Power device and Device ID info from 
# powermt display 

open(F, "path-gonners") or die "cant open file: $!";

$dev_ID_len = 23;
$sym_ID_len = 26;
my $psize;
my $buf;
my $len;

LINE: while ( my $line = <F>) {
    if ( $line =~ /Pseudo name/ ) {
        $psize = length $line;
    }

    if ( $line =~ /Logical device/ ) {
		# get length of the 3 lines we are parsing
        $len = $psize + $dev_ID_len + $sym_ID_len;
        # seek all the way back to the start of the hdiskpower line
        # print "SEEKING BACK $len bytes\n";
        seek(F, -$len, 1) or die "seek failed: $!";
        # read in power device info
        read(F,$buf,$psize);
        print "DEVICE: $buf";
        # seek forward  past the "Sym ID" line  
        # print "SEEKING FORWARD\n";
        seek(F, $sym_ID_len, 1) or die "seek failed: $!";
        # read in Logical Dev ID info
        read(F,$buf,23);
        print "ID: $buf\n";
        # start next fh loop iteration at the current pos of the file
        next LINE;
    }

}

close F;

# data looks like this
__DATA__
Pseudo name=hdiskpower1
Symmetrix ID=000190103441
Logical device ID=0357
state=alive; policy=SymmOpt; priority=0; queued-IOs=0
==============================================================================
---------------- Host ---------------   - Stor -   -- I/O Path -  --
Stats ---
  HW Path                I/O Paths    Interf.   Mode    State  Q-IOs Errors
==============================================================================
   0 fscsi0                    hdisk213  FA  9cA   active  alive      0 0
   1 fscsi1                    hdisk85   FA  8cA   active  alive 0      0
~                                                                              

