#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/DBI/table_meta_qry.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 14:13:59 -0400 (jkipp)"
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';

# usual connection method  
$dbh = DBI->connect("DBI:Oracle:OFTDBPRD.INGDIRECT.COM","jkipp","diamond81")
 or die "Cannot open $DBI::errstr\n";


###########################
# USING Statment Handle attribs
my $tabsth = $dbh->table_info();
### Iterate through all the tables...
while ( my ( $qual, $owner, $name, $type ) = $tabsth->fetchrow_array() ) {
    ### The table to fetch data for
    my $table = $name;
    ### Build the full table name with quoting if required
	#$table = qq{"$owner"."$table"} if defined $owner;
	$table = qq{$owner.$table} if defined $owner;
	if ($owner =~ /^cai$/i) {
	    ### The SQL statement to fetch the table metadata
	    my $statement = "SELECT * FROM $table";
	    print "\n";
	    print "Table Information\n";
	    print "=================\n\n";
	    print "Statement:     $statement\n";
	    ### Prepare and execute the SQL statement
	    my $sth = $dbh->prepare( $statement );
	    $sth->execute();
		# The NUM of Field is the # of columns that will be returned by the statement
	    my $fields = $sth->{NUM_OF_FIELDS};
	    print "NUM_OF_FIELDS: $fields\n\n";
	    print "Column Name                     Type  Precision  Scale  Nullable?\n";
	    print "------------------------------  ----  ---------  -----  ---------\n\n";
	    # Iterate through all the fields and dump the field information
	    for ( my $i = 0 ; $i < $fields ; $i++ ) {
			# The NAME attr contains the names of the selected columns 
			# the attr is a ref to an array
	        my $name = $sth->{NAME}->[$i];
	        # Describe the NULLABLE value
	        my $nullable = ("No", "Yes", "Unknown")[ $sth->{NULLABLE}->[$i] ];
	        # Tidy the other values, which some drivers don't provide
	        my $scale = ($sth->{SCALE})     ? $sth->{SCALE}->[$i]     : "N/A";
	        my $prec  = ($sth->{PRECISION}) ? $sth->{PRECISION}->[$i] : "N/A";
	        my $type  = ($sth->{TYPE})      ? $sth->{TYPE}->[$i]      : "N/A";
	        # Display the field information
	        printf "%-30s %5d      %4d   %4d   %s\n",
	                $name, $type, $prec, $scale, $nullable;
	    }

    # Explicitly de-allocate the statement resources
    # because we didn't fetch all the data
    $sth->finish();
    }
}
