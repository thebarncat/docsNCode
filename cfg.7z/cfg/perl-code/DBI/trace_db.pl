#!/usr/bin/perl -w

use DBI;
$dbh = DBI->connect("dbi:Oracle:prj_test.ftbee01a","mkt_rsch","mkt_rsch")
  or die "Cannot open $DBI::errstr\n";
    
### Set the tracing level to 1 and prepare()
DBI->trace( 1 );
doPrepare();

### Set trace output to a file at level 2 and prepare()
DBI->trace( 2, 'dbitrace.log' );
doPrepare();

### Set the trace output back to STDERR at level 2 and prepare()
DBI->trace( 2, undef );
doPrepare();

# sub used for trace
sub doPrepare {
    print "Preparing and executing statement\n";
    my $sth = $dbh->prepare( "
        SELECT * FROM tbl_people
        " );
    $sth->execute();
    return;
}

exit;
