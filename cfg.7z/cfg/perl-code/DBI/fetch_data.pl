#!/usr/bin/perl -w
# connects to a database, executes a SQL statement, then fetches all the
# data rows out into a data structure. This structure is then traversed and printed.
use DBI;
# The statement handle
my $sth = $dbh->prepare("SELECT name, location, mapref FROM megaliths");
# or:
$sth = $dbh->prepare("SELECT * FROM tbl_people" ) or die "Cant prepare statements from $DBI::errstr\n";
# Execute the statement
$sth->execute();
# Retrieve the returned rows of data. each @row contains one record (data row)
while ( @row = $sth->fetchrow_array() ) {
    print "Row: @row\n";
}

#############################
# Fetch all the data into a Perl data structure, BATCH FETCHING
# this method gets the entire result set of a query in one call
# the fetchall_arrayref() with no args returns a ref to an array
# containing refs to each row in the results set  each of those 
# refs refers to an array containing the field values for that row The statement handle
$sth->execute();
my $array_ref = $sth->fetchall_arrayref();
# Traverse the data structure and dump each piece of data out
# For each row in the returned array reference.....
foreach my $row (@$array_ref) {
    ### Split the row up and print each field...
    my ( $name, $type, $location ) = @$row;
    print "\tMegalithic site $name, found in $location, is a $type\n";
}
# to fetch certain columns. So if the query returned name, site, location, and mapref
# the following would only fetch name and location(0,2 indices of the array)
$array_ref = $sth->fetchall_arrayref( [0,2] );
# get the last 2 colums:
$dat = $sth->fetchall_arrayref([-2,-1]);

# can also fetch being slick
my $array_ref = $sth->fetchall_arrayref();
@colNames = @{$sth-> {NAME}};
foreach my $row (@$array_ref) {
	my $rec = join ( ',', map { $_ }  @$row );
    print  "$rec\n";
	#print "$date, $time, $hour, $host, $load1, $load5, $load15\n";
}

# using selectall_arrayref to filter wanted columns:
# Using the @{} construct, the array struct turned into an flat array, and map will only filter 
# the wanted element from each row. 
$dbh = DBI->connect (blah.. );
# no need sth handle and execute needed. it does the prepare, execute, and fetch all at once
my $qry = qq[ SELECT hostName FROM hosts ORDER BY hostName asc ];
my @hosts = map {$_->[0]} @{ $dbh->selectall_arrayref($qry) };


#########################
# can also use different methods for selecting single rows 
# selectrow_array() and selectrow_arrayref()
# these methods DO NOT not need prepare and execute statements 
($name, $phone) = $dbh->selectrow_array(" SELECT lastname, phone FROM tbl_people");
print "$name has $phone\n";

################
# use hashref to fetch data and force all to *lower case* in  case 
# the fields are in UC at the database
while ($hash_ref = $sth->fetchrow_hashref('NAME_lc') ) {
	print "Name: $hash_ref->{lastname} \n";
}	
		
###################	
# quick fetch
$rows = $sth->dump_results();

# quick fetch with output formatted to a file\
# params are: Max Field length, Line Seperator, Field Sep, Output handle
open FILE, >results.txt;
$rows = $sth->dump_results(80, '\n', ':', \*FILE);

####################
# using ORA SAMPLE func:
# select 1% of the data
$sql = qq[ select D_ACCOUNT_KEY,state,zip_code  from CAI.CPRCDR_EXTRACT_200506_UPDATE_2 SAMPLE(0.1) ];
$sql = qq[ select * FROM oft.ing_loan_history SAMPLE(0.1) ];
# select 10%
$sql = qq[ select * FROM oft.ing_loan_history SAMPLE(10) ];
my $sth = $dbh->prepare($sql);

####################
# Fetch all the data into an array reference of hash references to all rows in 
# the result set!
my $array_ref = $sth->fetchall_arrayref( { name => 1, location => 1 } );
# Traverse the data structure and dump each piece of data out
# For each row in the returned array reference.....
foreach my $row (@$array_ref) {
    ### Get the appropriate fields out the hashref and print...
    print "\tMegalithic site $row->{name}, found in $row->{location}\n";
}

#########################
# using quoted string for query
$string = "Test string entry";
### Escape the string quotes...
my $quotedString = $dbh->quote( $string );
## Use quoted string as a string literal in a SQL statement
my $sth = $dbh->prepare( "
        SELECT *
        FROM tbl_people
        WHERE description = $quotedString
      " );
$sth->execute();

#############################
# Using Placeholders 
# the placeholder(?) is associated with the supplied value in the bind_param call
# the 1 is an index of where to start from
$sth = $dbh->prepare("
		SELECT fisrtname, lastname
		FROM tbl_people
		WHERE lastname = ?
		" );
$sth->bind_param(1, $name);
# specify multiple bind values
$sth = $dbh->prepare("
		SELECT fisrtname, lastname
		FROM tbl_people
		WHERE firstname = ?
		AND lastname LIKE ?
		" );
$sth->bind_param(1, "Joe");		
$sth->bind_param(2, "%Jones%");		

# Data typing with bind values
# the :sql_types imports standard SQL names that return the corresponing
# SQL integer type value
use DBI qw(:sql_types);
$sth = $dbh->prepare("
		SELECT pep.firstname, pep.phone, dep.department_name
		FROM tbl_people pep, tbl_department dep
		WHERE firstname = ?
		AND phone LIKE ?
		AND pep.departmentID_fk = dep.dept_id
		" );
$sth->bind_param(1, "Jim");
# need datatype for this, it is a string that looks like a number- Phone ext.
$sth->bind_param(2, 21457, {TYPE => SQL_VARCHAR} );
$sth->execute();

##############
# a BIND_COL example:
# does the prepare, execute, and fetch all at once. use map to filter the column we want
# bind col by number
my $q = q{select cbstat, 'desc' from CAI.PROFILE_ZUTBLCBSTAT};
my $sth = $dbh->prepare($q);
$sth->execute();
$sth->bind_col(1,\$stat);
# FAST !!
print "$stat\n" while $sth->fetchrow_arrayref;
##############

# bind_columns example, table has 3 cols, the # of vars must match the of cols:
$sth = $dbh->prepare("SELECT * FROM hosts ORDER BY hostName asc;" )
$sth->execute();
$sth->bind_columns( \( $host, $rel, $lev) );
print "$host\t$rel\t$lev\n" while $sth->fetchrow_arrayref;

		
# binding without bind_param(), the execute() does it all
$sth = $dbh->prepare("
		SELECT fisrtname, lastname
		FROM tbl_people
		WHERE firstname = ? OR lastname LIKE ?
		" );
$sth->execute( "Jim", "%jones%" );

######################################
# Getting META data
# get the column names of a qry. Do this after the execute()
@colNames = @{$sth-> {NAME}};

# returns number of rows affected by the qry
$DBI::rows 
$sth->rows # or this one

# get all of the tables in a DB
my @tables = $dbh->tables();


