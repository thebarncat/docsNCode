/* active OMA loans */
select * from
  oft.ing_loan where acct_status_key = 12 and prod_type_key = 5 
and LOAN_ORIGINATION_DATE < to_date('11/01/2005', 'MM/DD/YYYY');

/* DM */

select loan_number, acct_status_key, prod_type_key  from
  oft.ing_loan where  prod_type_key = 13 
and LOAN_ORIGINATION_DATE < to_date('11/01/2005', 'MM/DD/YYYY');

select a.loan_number, a.acct_status_key, a.prod_type_key, b.cid, b.d_account_key
 from oft.ing_loan a, cai.profile_cid_account_key_map b
where a.loan_number = b.d_account_key
and  a.prod_type_key = 13
and a.LOAN_ORIGINATION_DATE < to_date('11/01/2005', 'MM/DD/YYYY')
order by b.cid;

select loan_number, arm_type
 from  oft.ing_loan where acct_status_key = 12 and prod_type_key = 5 
and LOAN_ORIGINATION_DATE < to_date('11/01/2005', 'MM/DD/YYYY');


select loan_number, APPR_VAL_COLLATERAL_PROP, CURRENT_HOUSE_PRICE, ORIG_LOAN_TO_VAL_RATIO, ORIGINAL_AMT,
ORIGINAL_PRINCIPAL_AMT, ORIGINAL_SALES_PRICE 
 from  oft.ing_loan where acct_status_key = 12 and prod_type_key = 5 
and LOAN_ORIGINATION_DATE < to_date('11/01/2005', 'MM/DD/YYYY');

select loan_number, prod_type_key, original_amt,ORIGINAL_PRINCIPAL_AMT, acct_status_key from oft.ing_loan 
where original_amt is not null;


select count(*) from  oft.ing_loan where acct_status_key = 12 and prod_type_key = 5
and (CURRENT_LOAN_BAL = 0);

select loan_number,acct_status_key,prod_type_key,current_loan_bal
 from  oft.ing_loan where acct_status_key = 12 and CURRENT_LOAN_BAL = 0;

/* active OLA loans */
select count(*) from  oft.ing_loan where acct_status_key = 12 and prod_type_key = 6
and LOAN_ORIGINATION_DATE < to_date('09/01/2005', 'MM/DD/YYYY');

select * from  oft.ing_loan where prod_type_key = 6
and LOAN_ORIGINATION_DATE < to_date('09/01/2005', 'MM/DD/YYYY');

/* active OHE loans */
select count(*) from  oft.ing_loan where acct_status_key = 12 and prod_type_key = 4
and LOAN_ORIGINATION_DATE < to_date('09/01/2005', 'MM/DD/YYYY');

select * from  oft.ing_loan where prod_type_key = 4
and LOAN_ORIGINATION_DATE < to_date('09/01/2005', 'MM/DD/YYYY');
	   
select a.prod_type_key,b.prod_type_desc, sum(a.CURRENT_LOAN_BAL) as tot_bal    
     from oft.ing_loan a, oft.REF_PRODUCT_TYPE_CODE b
	 where a.prod_type_key = b.prod_type_key
	 group by a.prod_type_key,b.prod_type_desc; 
	 
select count(*)from oft.ing_loan where acct_status_key = 12 and ORIG_LOAN_TO_VAL_RATIO is null;

/* loan purp uknown - OMA */
select count(*) from oft.ing_loan where prod_type_key = 5 and loan_purpose_key in(33,59,167,112,92,93);

/* prop type unknown and null - OMA */
select  count(*)  from oft.ing_loan where prod_type_key = 5 and property_type_key  in(36,37,21,42);

select  count(loan_purpose_key)  from oft.ing_loan where prod_type_key = 5;

/* prop types unknown and null - OHE */
select  *  from oft.ing_loan where prod_type_key = 4 and property_type_key  in(36,37);

/* loan purp unknown - OHE */
select count(*) from oft.ing_loan where prod_type_key = 4 and loan_purpose_key = 59;

select loan_number,ORIGINAL_PRINCIPAL_AMT, APPR_VAL_COLLATERAL_PROP, 
(ORIGINAL_PRINCIPAL_AMT/APPR_VAL_COLLATERAL_PROP)  as oltv from oft.ing_loan
where loan_number = 2743;

select PROD_SUBTYPE_KEY, count(*) as subtot from oft.ing_loan where prod_type_key = 5
group by PROD_SUBTYPE_KEY;

select loan_number, prod_type_key, prod_subtype_key from oft.ing_loan where prod_subtype_key = 33 
  and prod_type_key = 5;

select loan_number,ORIGINAL_INTEREST_RATE,rate_life_cap from oft.ing_loan where prod_type_key = 5;

/*  cross reference real and scrambled acct numbers. Get all loans from the ING tabletable */ 
select a.loan_number, a.APPR_VAL_COLLATERAL_PROP, a.CURRENT_HOUSE_PRICE,
       a.ORIGINAL_PRINCIPAL_AMT, a.ORIGINAL_SALES_PRICE, b.cid 
   from oft.ing_loan a, cai.profile_cid_account_key_map b
   where a.loan_number = b.d_account_key
   and a.PROD_TYPE_KEY = 5;
        
   
select a.loan_number,a.DAYS_DELINQUENT, a.prod_type_key, b.cid 
   from oft.ing_loan a, cai.profile_cid_account_key_map b
   where a.loan_number = b.d_account_key;
 	
select a.REPORTED_LOAN_DUE_DATE, b.cid 
   from oft.ing_loan a, cai.profile_cid_account_key_map b
   where a.loan_number = b.d_account_key 
   and (b.cid = 33003625);	
   
select * from  cai.profile_cid_account_key_map  
 order by cid;
   

/* days_delq compare to delinq status check */   
select a.loan_number, a.prod_type_key, a.acct_status_key, a.current_loan_bal, a.next_payment_due_date,
to_date('20050930','yyyymmdd') - a.next_payment_due_date days_delin_calulation, 
a.days_delinquent days_delin_OCB, a.delinquency_stat_key, b.cid 
from oft.ing_loan a, cai.profile_cid_account_key_map b
where a.loan_number = b.d_account_key 
and (a.acct_status_key != 13 and to_date('20050930','yyyymmdd') - a.next_payment_due_date > 0);


select * FROM oft.ing_loan_history SAMPLE(0.5) where acct_status_key = 12
order by loan_number desc;
 	 
select commitment_number_inv, current_loan_bal from oft.sbo_loan order by commitment_number_inv desc;

select count(*) FROM oft.sbo_loan where acct_status_key in(4,5,6,7,8,9,16);

select count(*) FROM oft.sbo_loan where acct_status_key = 2 and prod_subtype_key = 32;

select CONTROL_LAST_CUTOFF_DATE, count(*) total FROM oft.sbo_loan_history group by CONTROL_LAST_CUTOFF_DATE;


select * FROM oft.sbo_loan where acct_status_key = 2
 and CONTROL_LAST_CUTOFF_DATE = to_date('31-AUG-2005','dd-mon-yyyy');
 

/* map purp to levels */ 
select loan_number, LOAN_PURPOSE_KEY,
case when LOAN_PURPOSE_KEY in(3,10,11,12,31) then 'C'
     when LOAN_PURPOSE_KEY in(6,16) then 'R'
	 else 'P'
end as level_case
FROM oft.sbo_loan where acct_status_key = 2 
 and CONTROL_LAST_CUTOFF_DATE = to_date('31-AUG-2005','dd-mon-yyyy')

/* map doc type to levels */
select loan_number, DOCUMENT_TYPE_KEY,
case when DOCUMENT_TYPE_KEY in(1,4,7) then 'Z'
     when DOCUMENT_TYPE_KEY in(2,3,8,10,12) then 'X'
	 when DOCUMENT_TYPE_KEY in(9) then 'Z'
	 else 'S'
end as level_doc
FROM oft.sbo_loan where acct_status_key = 2 
 and CONTROL_LAST_CUTOFF_DATE = to_date('31-AUG-2005','dd-mon-yyyy');

/****************************************/
select loan_number, LOAN_PURPOSE_KEY,
case when LOAN_PURPOSE_KEY in(42,44,48,101,118,134,155) then 'P'
     when LOAN_PURPOSE_KEY in(139,163,173) then 'R'
	 else 'C'
end as level_purp
from  oft.ing_loan where acct_status_key = 12 and prod_type_key = 5
and LOAN_ORIGINATION_DATE < to_date('10/01/2005', 'MM/DD/YYYY');
 
