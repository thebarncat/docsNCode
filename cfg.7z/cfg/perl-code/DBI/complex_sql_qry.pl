#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/DBI/complex_sql_qry.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 14:17:09 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';

# usual connection method  
$dbh = DBI->connect("DBI:Oracle:OFTDBPRD.INGDIRECT.COM","jkipp","xxxxxx")
 or die "Cannot open $DBI::errstr\n";

#$from = '08/01/2005';
$to = '08/31/2005';

my $sth = $dbh->prepare("
SELECT count(*) as total, sum(ORIGINAL_LOAN_AMOUNT) as sumbal 
	FROM CAI.OMA_OHEL_OLA_09012005
	WHERE ACCOUNT_OPEN_DATE <= to_date(?, 'MM/DD/YYYY') 
	AND PRODUCT_TYPE_CODE = '7200' AND (ACCOUNT_STATUS = 0)
") or die "cant prepare sql statement: $DBI::errstr\n";

# *******************
# bind_col establishes a relationship between one column and your variable *** 
# bind_columns binds a whole row of the dataset to a list of variables
# 
$sth->execute($to) or die "can't execute $DBI::errstr\n";   
# even better use length statements
#$header = sprintf("%-10s %-5s\n", "Total", "Foo");
$header = sprintf("%-s %-s\n", "Total", "Foo");
print $header;
print '-' x 20,"\n";
my ($total,$sumbal);
$sth->bind_columns(\$total,\$sumbal);
while ($sth->fetch()) {
      print "$total $sumbal\n";
}
$sth->finish();


=cut
while ( @row = $sth->fetchrow_array() ) {
    print "Row: @row\n";
}
print "\n",$sth->rows," rows selected\n";
=cut
