#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/DBI/chk_dup.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 14:17:31 -0400 (jkipp)"
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';

# usual connection method  
$dbh = DBI->connect("DBI:Oracle:OFTDBPRD.INGDIRECT.COM","jkipp","diamond81")
 or die "Cannot open $DBI::errstr\n";

$sql = qq[ select loan_number,time_key FROM oft.ing_loan ];

my $sth = $dbh->prepare($sql);
$sth->execute() or die "can't execute $DBI::errstr\n";   

my $array_ref = $sth->fetchall_arrayref();

my %dup;
foreach my $row (@$array_ref) {
	#my $rec = join ( ',', map { $_ }  @$row );
	my $loan = $row->[0];
	push (@dups,$loan) if exists($dup{$loan});
	$dup{$loan}++;
}

if (@dups) {
	print "@dups\n"
} else {
	print "Checked $DBI::rows records. No dups found\n";
}
