#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/DBI/stats_d.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 14:09:56 -0400 (jkipp)"
# (C) 2013 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$

# RUN AS DBMSYS
use strict;

BEGIN{
$ENV{PATH} = "/appl1/oracle/product/9.0.1/bin:$ENV{PATH}";
$ENV{LD_LIBRARY_PATH} = "/lib:/usr/openwin/lib:/usr/dt/lib:/appl1/oracle/product/9.0.1/lib:/appl1/oracle/product/8.1.6/lib";
$ENV{ORACLE_HOME} = "/appl1/oracle/product/9.0.1";
}

use POSIX qw(setsid);
use POSIX ":sys_wait_h";
use DBI;

chop (my $host = `uname -n`);
my $user = qw(ops$jkipp);


# start daemon
start_d();


while(1) {
	(my $time = localtime) =~ s/.*?(\d{2}:\d{2}).*/$1/;
        (my $hour = localtime) =~ s/.*?(\d{2}):\d{2}.*/$1/;
	my ($stats, $loads) = get_stats();

	my $dbh = DBI->connect("dbi:Oracle:dbmstest.fpbee01a", "$user", "diamond")
           or die "Cannot open $DBI::errstr\n";

	my $sth = $dbh->prepare( "INSERT INTO uptime VALUES (SYSDATE,?,?,?,?,?,?)" )
         or die "can not prepare statement: $DBI::errstr\n";

	my $sth2 = $dbh->prepare( "INSERT INTO stats VALUES (SYSDATE,?,?,?,?,?,?,?,?)" )
         or die "can not prepare statement: $DBI::errstr\n";

	$sth->execute($time, $hour, $host, $loads->[0], $loads->[1], $loads->[2]);   

	for my $row (@$stats) {
		$sth2->execute($time, $hour, $host, $row->[0], $row->[1], $row->[2], $row->[3], $row->[4] );
        }
	
	# write stats to db every 10 minutes
	sleep 600;
}


sub start_d {
        umask 0;
        open (STDIN, "/dev/null")   or die "Can't read /dev/null: $!";
        open (STDOUT, ">/dev/null") or die "Can't write to /dev/null: $!";
        open (STDERR, ">&STDOUT") or die "Can't write to /dev/null: $!";

        # fork a child
        defined(my $pid = fork)   or die "Can't fork: $!";

        # exit parent and let child take over. hopfully child lives even after this
        # terminal dies
        exit if $pid;

        # start a new proc group with our kid
        setsid() or die "Can't start a new session: $!";

        # handle kill or term  signal and and kill zombies
        $SIG{TERM} = 'IGNORE';
	# non blocking wait for all pending zombies
        sub REAP { 1 until waitpid(-1, WNOHANG) == -1 }
        $SIG{CHLD} = \&REAP;
}


sub get_stats {

        my (@stats,@totals,@loads);
        my $ps = '/usr/bin/ps -eo user,pcpu,pmem,vsz,args';
open (PIPE, "$ps|") or die "could not pipe command: $!";
        while (<PIPE>) {
                next if  /USER|root|patrol|maestro|nobody|daemon/; # skip header, root and admin procs
                next if  /0.0\s+0.0/; # skip idle procs
                s/^\s+//;
                my @tmp = split(/\s+/);
                push (@stats, [ @tmp ]);
        }
        close PIPE;

        my $loads = `/usr/bin/uptime`;
        chomp $loads;
        if ($loads  =~ /(\d{1,2}\.\d{2}), \s+(\d{1,2}\.\d{2}), \s+(\d{1,2}\.\d{2})/gx ) {
                @loads = ($1, $2, $3);
        }

        return (\@stats, \@loads);

}

