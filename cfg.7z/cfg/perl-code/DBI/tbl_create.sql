	CREATE TABLE mkt_rsch.requester
 (
  req_id                     NUMBER(5) NOT NULL,
  req_name                   VARCHAR2(50) NOT NULL,
  req_phone                  VARCHAR2(10) NOT NULL,
  req_soc_member             VARCHAR2(50) NOT NULL,
  req_fax                    VARCHAR2(10) NOT NULL,
  req_mailstop               VARCHAR2(4) NOT NULL,
  req_type                   VARCHAR2(50) NOT NULL,
  req_desc                   VARCHAR2(100) NOT NULL,
  req_due_date               DATE NOT NULL
 )
 PCTFREE    10
 PCTUSED    40
 INITRANS   1
 MAXTRANS   255
 TABLESPACE users
 STORAGE   (
      INITIAL     1048576
      NEXT        1048576
      PCTINCREASE 50
      MINEXTENTS  1
      MAXEXTENTS  2147483645
   )
/

-- Constraints for REQUESTER

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_ID" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_NAME" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_PHONE" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_SOC_MEMBER" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_FAX" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_MAILSTOP" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_TYPE" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_DESC" IS NOT NULL)
/

ALTER TABLE mkt_rsch.requester
 ADD CHECK ("REQ_DUE_DATE" IS NOT NULL)
/



