#!/usr/bin/perl -w

use DBI;

$dbh = DBI->connect("dbi:Oracle:middev",'ops$jkipp','xx') or die "Cannot open $DBI::errstr\n";

# Instead of returning a list of row elements, the DBI 
# stores the values in bound scalars. This is very fast, as it avoids 
# copying returned values, and can simplify code greatly

my $table = 'tbl_people';
my @fields = qw( lname fname );
my %results;
my $fields = join(', ', @fields);
my $sth = $dbh->prepare("SELECT $fields FROM $table");
$sth->execute();

# slice %results with @fields to initialize the keys
# The map in bind_column call creates a reference to the hash  value associated with each key in @fields. 
@results{@fields} = ();
$sth->bind_columns(map { \$results{$_} } @fields);

# With each call to fetch, each field will be updated with the appropriate values for the current row
while ($sth->fetch()) {
	print "$results{lname} <$results{fname}>\n";
}
$sth->finish();

##----###

my ( $name, $phone, $dept);
$sth = $dbh->prepare("
        SELECT pep.firstname, pep.phone, dep.department_name
        FROM tbl_people pep, tbl_department dep
        WHERE pep.departmentID_fk = dep.dept_id
        " );
$sth->execute();
# associate vars with each output colum
$sth->bind_col(1, \$name);
$sth->bind_col(2, \$phone);
$sth->bind_col(3, \$dept);
# fetch data from results set
while ( $sth->fetch) {
    print "$name and $phone in $dept\n";
}

# same thing using  bind_columns()
# the number of columns must match the number of vars exactly
$sth->bind_columns( undef, \$name, \$phone, \$dept);
while ( $sth->fetch) {
    print "$name and $phone in $dept\n";
