#!/usr/bin/perl 
use DBI;

$dbh = DBI->connect("dbi:Oracle:middev",'ops$jkipp','diamond')
  or die "Cannot open $DBI::errstr\n";

# can do something like this as well:
# $dbh->do("insert into foo(id, ...) values(foo_id_seq.nextval, ....)");

my $cs = "
INSERT INTO tbl_task ( task_id, task_name) VALUES(seq_task_id.NEXTVAL, 'New One') ";

my $sth = $dbh->prepare($cs) or die "Prepare failed  $DBI::errstr";

$sth->execute or die "can't execute SQl: $DBI::errstr";

print "data inserted\n";




  




	
