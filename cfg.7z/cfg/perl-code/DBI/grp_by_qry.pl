#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/DBI/grp_by_qry.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 13:40:44 -0400 (jkipp)"
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';

open (OUT, ">freq.csv") or die "can't open: $!\n"; 
# usual connection method  
$dbh = DBI->connect("DBI:Oracle:OFTDBPRD.INGDIRECT.COM","jkipp","xxxxx")
 or die "Cannot open $DBI::errstr\n";

@fields = qw (
LOAN_ORIGINATION_DATE
LOAN_MATURITY_DATE
LAST_INT_RATE_CHANGE_DATE
NEXT_INT_RATE_CHANGE_DATE
FIRST_DISBURSEMENT_DATE
LAST_PAYMENT_DATE
INTEREST_PAID_THRU_DATE
ACCOUNT_CLOSE_DATE
FIRST_PAYMENT_DATE
NEXT_PAYMENT_DUE_DATE
);
	
foreach $field (@fields) {
	print OUT "\n**$field**\n";

	my $sth = $dbh->prepare("select to_char($field,'MM/DD/YYYY'), count(*) as subtot FROM oft.ing_loan group by $field ") or die "$DBI::errstr\n";
	$sth->execute() or die "can't execute $DBI::errstr\n";   

	while ( $row = $sth->fetchrow_arrayref ) {
		my $rec = join ( ',', map { $_ }  @$row );
        print OUT "$rec\n";
	}
}

close OUT;


