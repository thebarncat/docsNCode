#!/usr/bin/perl  
# FILE: "/home/jkipp/perl-code/DBI/filter_col.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 13:41:34 -0400 (jkipp)"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';

# usual connection method  
$dbh = DBI->connect("DBI:Oracle:OFTDBPRD.INGDIRECT.COM","jkipp","diamond81")
 or die "Cannot open $DBI::errstr\n";

# does the prepare, execute, and fetch all at once. use map to
# filter the column we want
# selectall_arrayref is a reference to a bi-dimensional array. 
# Using the @{} construct it is turned into an array
my $q = q{select cbstat, 'desc' from CAI.PROFILE_ZUTBLCBSTAT};
my @cbstats = map {$_->[0]} @{$dbh->selectall_arrayref($q)};

print "@cbstats";



