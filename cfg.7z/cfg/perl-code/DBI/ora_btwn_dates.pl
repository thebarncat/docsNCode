#!/usr/bin/perl 
use strict;
use DBI;

my $dbh = DBI->connect("dbi:Oracle:dbms.fpbec01a", "sys_monitor", "sysmon")
        or die "can't connect: $DBI::errstr\n";

my $sth = $dbh->prepare("
SELECT * FROM uptime 
WHERE sdate BETWEEN TO_DATE ('08/1/2002', 'MM/DD/YYYY')
	AND TO_DATE ('08/31/2002', 'MM/DD/YYYY')
") or die "cant prepare sql statement: $DBI::errstr\n";


$sth->execute() or die "can't execute $DBI::errstr\n";   

my $array_ref = $sth->fetchall_arrayref();

foreach my $row (@$array_ref) {
    my ( $date, $time, $hour, $host, $load1, $load5, $load15 ) = @$row;
    print "$date, $time, $hour, $host, $load1, $load5, $load15\n";
}

# --- another script --- #

$from = '04/12/2003';
$to = '04/14/2003';

my $sth = $dbh->prepare(" 
SELECT *
      FROM uptime
      WHERE sdate >= TO_DATE( ?, 'MM/DD/YYYY' )
        AND sdate <  TO_DATE( ?, 'MM/DD/YYYY' ) + 1
") or die "Cannot prepare SQL statements from $DBI::errstr\n";

# Execute the statement
$sth->execute($from,$to);

# Retrieve the returned rows of data
while ( @row = $sth->fetchrow_array() ) {
    print "Row: @row\n";
}
