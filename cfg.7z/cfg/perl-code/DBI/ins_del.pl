#!/usr/bin/perl -w
use DBI;

# INSERTING ROWS
# syntax: INSERT INTO <table> (<column(s)>) VALUES ( 'value'(s))
# or if inserting a row across all  columns:
# syntax: INSERT INTO <table> VALUES ('val', '"val", ...)
# the ? is called a placeholder , sort of like a wildcard
$sth = $dbh->prepare( "INSERT INTO tbl_people ( lastname ) VALUES (?)" );
foreach $name (qw( Smith Jones Roberts Johsnon Fredericks) ) 
{
	$sth->execute($name);
}

# or using do()
foreach $name (qw( Smith Jones Roberts Johsnon Fredericks) ) {
	$dbh->do("INSERT INTO tbl_people ( lastname ) VALUES (?)", undef, $name );
}
	
# or do() like this:
# the bad thing about using interpoated variables as opposed to bind values
# is that this statment	produces 100 sql statements		
for $x ( 100 .. 200 ) {
     $querystring = "insert into $wuzult (search) values (\"$x\")";
     print "$querystring\n";
     $dbh->do($querystring);
}

#-------------------------------------#

my @fields = qw( lname fname );
my $fields = join(', ', @fields);
# simply writes a string of place holders for each field in the DB
my $places = join(', ', ('?') x @fields);
$sth = $dbh->prepare( "INSERT INTO tbl_people ($fields) VALUES ($places)" );
%names = ( qw (joe sneed jack jone ) );
for $key ( keys %names) {
	$sth->execute($key, $names{$key}) or die "cant do it: $DBI::errstr";
}
$sth->finish;

$sth = $dbh->prepare( "INSERT INTO aug_stats VALUES (SYSDATE,?,?,?,?)" );
$sth->execute('22','03','spas','joe') or die "cant do it: $DBI::errstr";

 
###############################
# DELETING ROWS
# the do method does not setup a cursor to the data, it simply affects the rows
# and does not return anything
# don't need an execution or fetching statment for these
$rows = $dbh->do(" DELETE FROM tbl_people WHERE LASTNAME = 'Smith' ");

##############################	
#  execute the statements(s)
$sth->execute()
	or die "Can't execute: $DBI::errstr\n";	


