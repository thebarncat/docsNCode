#!/usr/bin/perl 
use DBI;

$dbh = DBI->connect("dbi:Oracle:middev",'wk_matrix','feelg00d')
  or die "Cannot open $DBI::errstr\n";

my $cs = "
CREATE SEQUENCE seq_task_id
MINVALUE 1
START WITH  1
INCREMENT BY  1
CACHE 20
"; 

my $sth = $dbh->prepare($cs) or die "Prepare failed  $DBI::errstr";

$sth->execute or die "can't execute SQl: $DBI::errstr";

print "sequence created\n";




  




	
