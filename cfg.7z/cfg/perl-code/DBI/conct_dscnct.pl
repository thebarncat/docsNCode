#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/DBI/conct_dscnct.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 14:15:10 -0400 (jkipp)"
use DBI;
 
# usual connection method  
$dbh = DBI->connect("dbi:Oracle:prj_test.ftbee01a","mkt_rsch","mkt_rsch") or die "Cannot open $DBI::errstr\n";

######################
# connect with error checking
#  initialize hash for error checking
%attr = (
	PrintError => 0, # print warning on error
	RaiseError => 0  # dies on error
);

$dbh = DBI->connect("dbi:Oracle:prj_test.ftbee01a","mkt_rsch","mkt_rsch", \%attr)
  or die "Cannot open $DBI::errstr\n";
# enable warning-level auto error reporting  
$dbh->{printError} = 1; 
  
#########################  
# make a second connection to a different DB dbase, creates a 2cd DB handle:
$dbh2 = DBI->connect("dbi:Oracle:prj_trk.ftbee01a","mkt_rsch","mkt_rsch")
  or die "Cannot open $DBI::errstr\n";  
  
#######################
# using attributes on connect
# the LongReadLen attr determines how much buffer space to allocate when
# fetching fields with very long strings (LONG Datatypes)
my $dbh = DBI->connect($dsn, $usr, $pwd, {LongReadLen => 32 * 1024} )

$dbh->disconnect
	or warn "failed: $DBI::errstr\n";

	
