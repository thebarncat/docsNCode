#!/usr/bin/perl 
use DBI;

$dbh = DBI->connect("dbi:Oracle:middev",'wk_matrix','feelg00d')
  or die "Cannot open $DBI::errstr\n";

# example 
my $cs = "
ALTER TABLE tbl_task
ADD CONSTRAINT chk_status CHECK (task_status IN ('New', 'In Progress', 'Closed') ) 
"; 

# example 2
my $cs = "
ALTER TABLE tbl_task
ADD CONSTRAINT chk_prior CHECK (task_priority > 0 AND task_priority < 5 ) 
"; 

my $sth = $dbh->prepare($cs) or die "Prepare failed  $DBI::errstr";

$sth->execute or die "can't execute SQl: $DBI::errstr";

print "constraint created\n";
	
