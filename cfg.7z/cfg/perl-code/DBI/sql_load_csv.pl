#!/usr/bin/perl -w 
# FILE: "/home/jkipp/perl-code/DBI/sql_load_csv.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 14:14:39 -0400 (jkipp)"
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';

# usual connection method  
$dbh = DBI->connect("DBI:Oracle:caidev.ingdirect.com","jkipp","diamond81")
  or die "Cannot open $DBI::errstr\n";

my $sh = $dbh->prepare( q( alter session set NLS_DATE_FORMAT='MM/DD/YYYY' ) ) 
	or die "Prepare fails:  $DBI::errstr\n";;
$sh->execute or die "can't execute: $DBI::errstr";


my $file = 'fox.csv';
# my @fields = get_fields($file);
# my $fields = join(', ', @fields);
# printf("num fields are: %d \n", scalar @fields);

open (F, "<$file") or die "can't open: $!";
while (<F>) {
    chomp;
	next if /^\s+$/;
	# skip header 
	next if $. == 1;
	# remove leading commas:
    $_ =~ s/^[\s*\,]+//;
    # remove trailing commas:
    $_ =~ s/[\s*\,]+$//;
	# split line into fields
    @line = split(/,\s?/,$_);
	$holders = join(', ', ('?') x @line);
	$line[1] =~ s/\s+0:00$//; # strip out time from date string
	$sth = $dbh->prepare( "INSERT INTO loan_test VALUES ($holders)" );
	$sth->execute(@line);
	$sth->finish();
	print "row inserted\n";
}

sub get_fields {
	my $file = shift;
	open(F, "<$file") or die "can't open file: $!";
	my $header = <F>;
	my @fields = split(/,/, $header);
	close F;
	return (@fields);
}

$dbh->disconnect or warn "failed: $DBI::errstr\n";




