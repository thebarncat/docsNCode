# FILE: "/home/jkipp/perl-code/DBI/hide_pw_in_bin.pl"
# LAST MODIFICATION: "Thu, 23 May 2013 16:39:23 -0400 (jkipp)"
# $Id:$


use DBI;

# use strict;
use DB_File;
use Fcntl;

my %hash;

tie %hash,"DB_File","auth",O_RDWR|O_CREAT|O_EXCL,0777 || die $!;
my $user = $hash{'user'};
my $pw = $hash{'pw'};


my $dbh = DBI->connect("dbi:Oracle:dbms.fpbec01a", "$user", "$pw")
           or die "Cannot open $DBI::errstr\n";

my $date = '2-Jun';

my $sth = $dbh->prepare(<<"SQL");
  SELECT *
  FROM   uptime
  WHERE  TO_CHAR(sdate, 'DD-Mon') LIKE ?
SQL

$sth->execute("%$date%");


# Retrieve the returned rows of data
while ( @row = $sth->fetchrow_array() ) {
    print "Row: @row\n";
}



