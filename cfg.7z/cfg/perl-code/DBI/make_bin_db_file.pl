# FILE: "/home/jkipp/perl-code/DBI/make_bin_db_file.pl"
# LAST MODIFICATION: "Thu, 23 May 2013 16:31:10 -0400 (jkipp)"
# $Id:$


#!/usr/bin/perl -w
use strict;
use DB_File;
use Fcntl;

my %hash;

# make the binary file with user + pw
tie %hash,"DB_File","auth",O_RDWR|O_CREAT|O_EXCL,0777 || die $!;
$hash{'user'} = 'me';
$hash{'pw'} = 'my_password';

