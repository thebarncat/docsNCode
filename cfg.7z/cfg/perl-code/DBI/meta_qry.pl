#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/DBI/meta_qry.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 14:03:46 -0400 (jkipp)"
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';
unless (@ARGV) { print "Supply schema name as argument\n"; exit 1 }

# usual connection method  
$dbh = DBI->connect("DBI:Oracle:OFTDBPRD.INGDIRECT.COM","jkipp","diamond81")
 or die "Cannot open $DBI::errstr\n";

# change schema name to query
$schema = uc($ARGV[0]);
# use q to quote literal string w/out interpolation. qq for interpolation
$sql = q ( select owner,table_name,column_name,data_type from all_tab_columns where owner = ? );

my $sth = $dbh->prepare($sql);
$sth->execute($schema) or die "can't execute: $DBI::errstr";

#@colNames = @{$sth-> {NAME}};
#print "$_\n" foreach @colNames;


open FILE, ">results.txt";
print FILE "OWNER:TABLE:NAME:COLUMN:DATA_TYPE\n";
close FILE;
=cut
while ( @row = $sth->fetchrow_array() ) {
    ($owner,$table,$col,$dtype) = @row;
	print "$owner,$table,$col,$dtype","\n";
}
=cut

