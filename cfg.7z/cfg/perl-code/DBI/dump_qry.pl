#!/usr/bin/perl 
# FILE: "/home/jkipp/perl-code/DBI/dump_qry.pl"
# LAST MODIFICATION: "Mon, 03 Jun 2013 13:50:14 -0400 (jkipp)"
# $Id:$

use DBI;
# need to set ora vars first
$ENV{'ORACLE_HOME'} = 'C:\oracle\ora9201';

# usual connection method  
$dbh = DBI->connect("DBI:Oracle:OFTDBPRD.INGDIRECT.COM","jkipp","diamond81")
 or die "Cannot open $DBI::errstr\n";

#$from = '08/01/2005';
$to = '08/31/2005';

my $sth = $dbh->prepare("
SELECT D_ACCOUNT_KEY, CURRENT_LOAN_PRINCIPAL, ACCOUNT_OPEN_DATE  
	FROM CAI.OMA_OHEL_OLA_09012005
	WHERE ACCOUNT_OPEN_DATE <= to_date(?, 'MM/DD/YYYY') 
	AND PRODUCT_TYPE_CODE = '7200' AND (ACCOUNT_STATUS = 0)
") or die "cant prepare sql statement: $DBI::errstr\n";

$sth->execute($to) or die "can't execute $DBI::errstr\n";  

open FILE, ">out.csv" or die "can't open: $!"; 
$rows = $sth->dump_results(80, "\n", ',', \*FILE);

$sth->finish();


