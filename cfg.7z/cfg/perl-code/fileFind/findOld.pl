#!/usr/bin/perl -w

use strict;
use File::Find;
use Getopt::Std;

@ARGV = qw(.) unless @ARGV;
my $dir = $ARGV[0];
my $argCount = @ARGV;
print "\nChecking \"$dir\" ..\n\n";

my $usage = "Arg must be a directory\n";
print $usage and die unless -d $dir;

my $lpath;
if (-d $dir and -l $dir) {
    #print "$dir is a dir and link\n";
    $lpath = readlink($dir);
    print "The directory is a link to:  $lpath\n";
    $dir = $lpath;
}

print "\n";

my $maxtime = 120; 

my @tmp;
sub wanted {
    my $owner = getpwuid( (stat)[4] );
    return if $maxtime  > -A _;
	return unless -f;
 
    push @tmp, {
        file  => $File::Find::name,
        owner => $owner ? $owner : "no owner",
	    dayz  => -A _,
	};
}

find( { wanted => \&wanted }, $dir );

printf "%-80s %-12.12s  %s\n", "File","Owner","Days";
print '-' x 98,"\n";
# Print out hash table
for my $hash ( sort { $a->{ dayz } <=> $b->{ dayz } } @tmp ) {
    printf "%-80.80s %-12.12s  %d\n", @{ $hash }{ qw( file owner dayz ) };
}

