#!/usr/bin/perl -w

# this program does not descend past the current directory

use strict;
use File::Find;
use File::Copy;

use vars qw/*name/;
*name = *File::Find::name;

my $junk_dir = '/usr/local/admin/junk';

@ARGV = qw(.) unless @ARGV;
my $dir = $ARGV[0];

my $usage = "Arg must be a directory\n";
print $usage and die unless -d $dir;

sub wanted {   
    #return if /(?:\.\d+|\.old)$/;
    #return unless /(?:\.\d+|\.old)$/;
    #print "removing junk: $name\n" if -f and /(?:\.\d+|\.old)$/;
    if ( -f and /(?:\.\d+.*|\.old)$/ ) {
        print "removing junk: $name\n";
       move($name, $junk_dir);
     }
    #print "DIR: $name\n" if -d; 
    $File::Find::prune = 1 if $File::Find::name ne $dir;
    #print "$name\n" if $dir = ".";
}

find( { wanted => \&wanted },  $dir );
#find( { wanted => \&wanted, no_chdir => 1},  $dir );
