#!/usr/bin/perl -w

# Get empty folders and files with no owner or non standard owner

use strict;
use File::Find;
use Getopt::Std;

@ARGV = qw(.) unless @ARGV;
my $dir = $ARGV[0];
my $argCount = @ARGV;
print "\nChecking \"$dir\" ..\n\n";

my $usage = "Arg must be a directory\n";

print $usage and die unless -d $dir;

my $lpath;
if (-d $dir and -l $dir) {
	#print "$dir is a dir and link\n";
	$lpath = readlink($dir);
    print "The directory is a link to:  $lpath\n";
	$dir = $lpath;
}

# get any empty dirs
print "\nEMPTY folders in $dir:\n";
my @subdirs;
find sub { push @subdirs, $File::Find::name if -d }, $dir;
for (@subdirs)  { 
	next if $_ eq $dir;
	my $out = `ls -l $_ | wc -l`;
	print "$_\n" if $out <= 1;
}
print "\n";

# ths syscall wont work cuz defaults to local group: my $members = (getgrnam('prfdba'))[3]; so list it manually:
my $prfdba = "jkipp bschill ccenter bramdoss mcu674 leh198 rshapiro fab122 dcinalli itk863";

my @tmp;
sub wanted {
	return unless -f;
	my $owner;
    $owner = getpwuid( (stat)[4] ) or $owner = "-NoOwner-";
 
	if ( $prfdba !~ /$owner/ ) { 
    	push @tmp, {
        file  => $File::Find::name,
        owner => $owner,
	    dayz  => -A _,
        };
	}
}

find( { wanted => \&wanted }, $dir );

printf "%-80s %-12.12s  %s\n", "File","Owner","Days"; 
print '-' x 98,"\n";
# Print out hash table
for my $hash ( sort { $a->{ dayz } <=> $b->{ dayz } } @tmp ) {
    printf "%-80.80s %-12.12s  %d\n", @{ $hash }{ qw( file owner dayz ) }; 
}
 

