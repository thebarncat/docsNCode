#!/usr/bin/perl -w
# FILE: "/home/jkipp/bin/test-find.pl"
# LAST MODIFICATION: "Fri, 02 Jun 2017 14:24:46 -0400 (jkipp)"
# (C) 2006 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$
use strict;
use File::Find;

use vars qw/*name *dir *prune/;
*name   = *File::Find::name;
*dir    = *File::Find::dir;

find sub {
	#if ($_ =~ /(?:\.pl|\.sql|\.sh|\.ksh|\.cgi|\.php)$/ ) {
	 if ($_ =~ /hmc|play|asm/ ) {
		my $user;
		$user = getpwuid( (stat)[4]) or  $user = "NOPE"; 
		my $grp = getgrgid( (stat)[5] );
		# this gets the users GID:
		#my $gid = getgrgid((getpwnam($user))[3]);
		#print "$name,$user,$grp,$gid\n"; 
		print "$name,$user,$grp\n"; 
		my $members = (getgrnam('unixadm'))[3]; 
		#print "$members\n";
		print "user is not in group!\n" if $members !~ /$user/;
     }
      
 }, '.';


my $fiz = "lsasm";
my $uid = (stat($fiz))[4];
my $uzer;
$uzer = getpwuid($uid) or $uzer = "nope";
#print "$uzer\n";




