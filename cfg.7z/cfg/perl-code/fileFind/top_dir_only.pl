#!/usr/bin/perl -w
#
# https://stackoverflow.com/questions/12334037/perl-how-to-stop-filefind-entering-directory-recursively

use File::Find qw( find );

my $root = '.';
find({
   wanted   => sub { listfiles($root); },
   no_chdir => 1,
}, $root);

sub listfiles {
   my ($root) = @_;
   print "$File::Find::name\n";
   $File::Find::prune = 1  # Don't recurse.
      if $File::Find::name ne $root;
}
