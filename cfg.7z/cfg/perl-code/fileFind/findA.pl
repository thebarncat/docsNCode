#!/usr/bin/perl -w
# FILE: "/home/jkipp/bin/findA.pl"
# LAST MODIFICATION: "Fri, 02 Jun 2017 11:13:46 -0400 (jkipp)"
# (C) 2006 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$
use strict;
use File::Find;

use vars qw/*name *dir *prune/;
*name   = *File::Find::name;
*dir    = *File::Find::dir;

my $maxtime = 10;  # Expressed in days

find sub {
		my $user = getpwuid( (stat)[4]); 
		my $atime = int -A _;
		if ( $atime >= $maxtime) {
			print "$name,$user,$atime\n"; 
		}
      
 }, '.';

=cut
sub wanted {
    my ($dev,$ino,$mode,$nlink,$uid,$gid);
    (($dev,$ino,$mode,$nlink,$uid,$gid) = lstat($_)) &&
    (int(-A _) > 10) && print("$name\n");
}
find({wanted => \&wanted}, '.');
=cut
