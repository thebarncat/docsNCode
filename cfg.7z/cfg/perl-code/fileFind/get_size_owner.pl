#!/usr/bin/perl -w

# note: doesn't Seem to matter if you use the "_" symbol for current item or not
# eg "> -A _"  same as "> -A"
use File::Find;
 
#my $minsize = 50; # Expressed in Megabytes
my $minsize = 5; # Expressed in Megabytes
my $maxtime = 90; # Expressed in days
 
# Get defined inputs and convert them to something we can use
my $nosmaller = $minsize * 1024;
 
#print "$nosmaller\n\n";

my @tmp;

sub wanted {
	my $owner = getpwuid( ( stat )[ 4 ] );
	# age of file in days since last access
	#return if $maxtime > -A _;
	return if $nosmaller > -s _; # -s returns size in bytes
 
	push @tmp, {
		owner => $owner ? $owner : "no owner",
		size => ( -s _ ) / 1024 / 1024,
		file => $File::Find::name,
 };
}
 
#find( { wanted => \&wanted }, @ARGV );
find( { wanted => \&wanted }, "." );
 
# Print out hash table
for my $hash ( sort { $a->{ size } <=> $b->{ size } } @tmp ) {
printf "%10s %12.2f MB %s\n", @{ $hash }{ qw( owner size file ) }; }
