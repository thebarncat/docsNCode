#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/bin-math.pl"
# LAST MODIFICATION: "Thu, 22 Jan 2015 14:11:21 -0500 (jkipp)"
# (C) 2012 by Jim Kipp, <jkipp@ingdirect.com>
# $Id:$
use strict;

# umask octal AND
printf("%o\n",0666 & ~0022);

my $num = 2;
my $comp = ~$num;

printf "%b\n", $comp;

print 1 << 4, "\n";

print 123 & 234, "\n";

