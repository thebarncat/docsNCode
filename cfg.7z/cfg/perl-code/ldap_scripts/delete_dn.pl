#!/usr/bin/perl -w

use strict;
use Net::LDAP;

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
my $base_dn = "dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';

# the object we are oging to modify
#my $dn = "CN=emcadm,OU=Unix Groups,OU=Ing Direct,DC=ingdirect,DC=com";
my $dn = "cn=sysadmins,ou=Group,dc=lnx,dc=kmhp,dc=com";

my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
$mesg->code && print "bind failed\n";

# loop thru deleting stuff
while(<>) {
        chomp $_;
        $dn="uid=$_,ou=Users,dc=lnx,dc=kmhp,dc=com";
        $ldap->delete($dn);
}
