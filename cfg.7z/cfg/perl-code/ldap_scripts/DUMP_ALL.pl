#!/usr/bin/perl -w

use strict;
use Net::LDAP;
use Net::LDAP::Util qw(ldap_error_text);

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
my $base_dn = "dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';

my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
$mesg->code && print "bind failed\n";

$mesg = $ldap->search(filter=>"(objectClass=*)", base=>$base_dn);
my @entries = $mesg->entries;
foreach my $entry (@entries) {
        $entry->dump;
}



