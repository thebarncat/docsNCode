#!/usr/bin/env perl

use Net::LDAP; 

$ldap = Net::LDAP->new("localhost", timeout=>30) or die "failed";
$msg = $ldap->bind("uid=easypush,ou=People, dc=$ARGV[3],dc=$ARGV[4]", password=>$ARGV[5]);
print $msg->code;


$cngrp=$ARGV[0];
$grpid=$ARGV[1];
$memberuid=$ARGV[2];
$domain="\@$ARGV[3].$ARGV[4]";
$altr="-catch-all\@$ARGV[3].$ARGV[4]";
$gmail= $cngrp.$domain;
$altmail=$cngrp.$altr;
$store="/home/groups/$cngrp/Maildir";
$home="/home/groups/$cngrp";
$sidn=($grpid*2)+1001; 
$sid1="$sidn"; 
$samsys=`net getlocalsid|cut -d":" -f2|cut -d" " -f2`;
chomp($samsys);
#print $sid1;
$samloc="$samsys-$sidn";
print $samloc;

$search = $ldap->search( filter=>"(cn=$cngrp)", base=>"ou=Groupdc=$ARGV[3], dc=$ARGV[4]");

@entries = $search->entries;

if ( $search->count != 1 )  # Nope.. Create the group and search again
	{

 		$groupresult = $ldap->add( dn => "cn=$cngrp,ou=Group,dc=$ARGV[3],dc=$ARGV[4]",
                        				attr => [ 'objectClass' => 'top',
                                 			 'objectClass' => 'posixGroup',
                                 			 'objectClass' => 'qmailGroup',
                                 			 'objectClass' => 'qmailUser',
                                 			 'objectClass' => 'sambaGroupMapping',                                  
                                  			 'cn'          =>  $cngrp,
                                  			 'gidNumber'   =>  $grpid,
                                   			 'uid'         => $cngrp,
                                  			 'qmailUID'    => '1000',
                                  			 'qmailGID'    => $grpid,
                                  			 'description' => $cngrp,
                                  			 'mail'        => $gmail,
                                  			 'mailAlternateAddress'  => $altmail,
                                  			 'mailMessageStore' => $store,
                                  			 'homeDirectory' => $home,
                                  			 'sambaSID'      => $samloc,
                                  			 'sambaGroupType'=> '2',
				  			 ]);

		$groupresult->code && warn "failed to add entry: ", $groupresult->error;
		$search = $ldap->search( filter=>"(cn=$cngrp)", base=>"ou=Group,dc=$ARGV[3],dc=$ARGV[4]");

		@entries = $search->entries;

	}

my $dn = @entries[0]->dn;         # yes.. get the DN

print($dn);
print "\n";

$search1 = $ldap->search( filter=>"(uid=$memberuid)", base=>"ou=People,dc=$ARGV[3], dc=$ARGV[4]");

@entries1 = $search1->entries;

if ( $search1->count != 1 ) {  $search1->code;print "failed to search entry: "; exit; }  # Nope.. exit

my $rfc = @entries1[0]->get_value("mail");         # yes.. get the mail id
 
print($rfc);

my @AddArray;
push @AddArray, 'memberUid', $memberuid;
push @AddArray, 'rfc822member', $rfc;

if ( $#AddArray > 0 ) 
	{
   		push @whatToChange, 'add';
   		push @whatToChange, \@AddArray;
 	}
	else
 		{
 			print "null"
 		}
		

my $result = $ldap->modify ( $dn,
                             changes => [
                                        	 @whatToChange
                                        ]
                           );
