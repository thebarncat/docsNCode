#!/usr/bin/perl

use Net::LDAP;

my $dc = "ingdedc01";
my $domain = "ingdirect.com";
my $base_dn = "dc=ingdirect,dc=com";

print "Username: ";
chomp(my $user = <STDIN>);
print "Password: ";
system ("stty -echo");
chomp(my $pass = <STDIN>);
system ("stty echo");
print "\n";
print "List File Name: ";
chomp(my $file = <STDIN>);
print "\n";

my $ldap = Net::LDAP->new("$dc.$domain") or die "$@@";

my $mesg = $ldap->bind($user.'@'.$domain, password => $pass);
$mesg->code && die $mesg->error;

open(FH, "<$file") or die "Can't open '$file': $!";
my $rec;
while ( chomp($rec = <FH>) ) {
  my ($name,$dept) = split /\s*\|\s*/, $rec;

  $mesg = $ldap->search( base => "$base_dn",
                         filter => "(&(objectCategory=CN=Person,CN=Schema,CN=Configuration,DC=ingdirect,DC=com)(sAMAccountName=$name))",
                         attrs => ['1.1','department']);

  $mesg->code && die $mesg->error;

  my $count = $mesg->count;
  if ($count < 1) {
    printf "NOT FOUND: %-15s\n", $name;
    next;
  } elsif ($count > 1) {
    printf "MULTIPLE:  %-15s (%3s)\n", $name, $count;
    next;
  }

  # entry(n)  Returns the n'th entry (initial entry is 0)
  my $entry = $mesg->entry(0);
  my $old_dept = $entry->get_value('department');
  if ($old_dept =~ m/^$dept$/) {
    printf "SKIPPING:  %-15s : %-15s\n", $name, $dept;
  } else {
    printf "UPDATING:  %-15s : %-15s ==> %-15s", $name, $old_dept, $dept;
    $entry->replace( department => $dept );
	# pushes changes made to the entry to the LDAP server (not sure need this)
    $mesg = $entry->update($ldap);
    if ( $mesg->code ) {
      print "ERROR: ".$mesg->error;
    } else {
      print "\n";
    }
  }

}

