#!/usr/bin/perl -w

use strict;
use Net::LDAP;
use Net::LDAP::Util qw(ldap_error_text);

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
my $base_dn = "dc=lnx,dc=kmhp,dc=com";
#my $base_dn = "ou=Users,dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';
#my $pw = readpassword();

my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
# if you need stronger auth: http://ldap.perl.org/perl-ldap-oscon2001.pdf (sasl auth) 
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
#$mesg->code && die $mesg->error;
$mesg->code && print "bind failed\n";

# schema. need to see the schema map
#$schema = $ldap->schema;

# SEARCH
# filter is mandatory!
# 'scope' can be one of:
# base: Search the base object only 
# one: Search only the entries one level below the base
# sub: Search the entire subtree below the base (DEFAULT)
# the 'attrs' param specifies which attribs you want returned

$mesg = $ldap->search( 
                        base   => $base_dn,
						scope  => 'sub',
                        #filter => "(uid=jk24*)",
                        #filter => "(&(uid=st185*) (sn=st185*))",
                        filter => "(uid=ma21634)",
                        #filter => "(uid=jk24445)",
                        #filter => "(cn=ldapuser)", # group
                        #filter => "(&(gidNumber=*) (objectClass=posixGroup))",  
                        #filter => "(objectClass=*)",  
                        #filter => "(uidNumber=*)",  
                        #filter => "(&(uid=st*) (sn=st*))",
                        # defaults to all if leave out:
						#attrs  => [ 'cn','gidNumber', 'loginShell' ] 
						##attrs  => [ qw(cn) ],
						#attrs  => [ qw(cn gidNumber shadowMax) ],
);

#$mesg = $ldap->search(filter=>"(objectClass=*)", base=>$base_dn);

if ($mesg->code) {
	print "Return code: ", $mesg->code;
	print "\tMessage: ", $mesg->error_name;
	print " :",          $mesg->error_text;
	print "MessageID: ", $mesg->mesg_id;
	print "\tDN: ", $mesg->dn;
}

# perldoc Net::LDAP::Entry:

# see here for deref of these structs
# http://www.perlmonks.org/?node_id=32196
my @entries = $mesg->entries;
foreach my $entry (@entries) {
	# dn: Returns the DN of the current entry. If given with a  param, it sets the DN
	print "DN:" . $entry->dn() . "\n";
	# returns the n'th entry (initial entry is 0):  $entry = $mesg->entry(0);
	# just get the value of one of the attribs
	#printf "\tCN:%s\n", $entry->get_value('cn');
	# @phone = $entry->get_value("homePhone");  # return the first value in scalar context and all in list context
	# print "Attributes of DN " . $entry->dn() . ":\n";
    #my @attrs =  sort $entry->attributes();
	#foreach my $attr (@attrs) {
	 foreach my $attr ( sort $entry->attributes ) {
		# get  the value(s) for the attribute, given as a parameter.  If used to assign to a scalar variable, it
		# returns only the first value for the attribute; if used with a list, it returns all of the attributes 
		# THIS print format will truncate the any attr that is a LIST to the first element 
		#printf("\t%s: %s\n", $attr, $entry->get_value($attr));
		print "  $attr : ", $entry->get_value($attr) ,"\n";
    }
	#print "---\n";
}

#could also use the DUMP method to just dump the contents of the ojject
#foreach my $entry (@entries) {
#	$entry->dump;
#}

