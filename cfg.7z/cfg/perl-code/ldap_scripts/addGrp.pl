#!/usr/bin/perl -w

use strict;
use Net::LDAP;
use Net::LDAP::Util qw(ldap_error_text);
use Getopt::Std;
use Term::ReadKey;

my %opts;
#getopts('u:U:radqG', \%opts);
# use -U in case a gidNumber is needed
getopts('g:U:', \%opts);

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
#my $base_dn = "dc=lnx,dc=kmhp,dc=com";
my $base_dn = "ou=Group,dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';
my $DN;
my $LS = "------------------------------------------------------------------------\n";

die "need GID" unless($opts{g});

my $GID = lc($opts{g});

# in the rare case of group not already in AD use supplied gidNum. if not use gidNum from AD
my $GidNum;
if ($opts{U}) {
	$GidNum = $opts{U};
} else {
	$GidNum = `getent group $GID | awk -F: "{print \\\$3}"`;
}
chomp $GidNum;

my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
$mesg->code && die "bind failed\n";

#  check if user exists
$DN = getDN($GID);

if ($DN) {
	print "GROUP EXISTS:\n" if $DN;
	print "$DN\n\n";
	exit;
} else {
	print "GROUP DOES NOT EXISTS\n";
	print "\nAdding Group: $GID\n";
	my $rv = addGroup($GID,$GidNum);
	print "Group $GID Added\n" if $rv;
	$DN = getDN($GID);
	print "New Object DN: $DN\n";
}

print $LS;

# close connection when all done
$mesg = $ldap->unbind;

sub addGroup {
	my($cn,$GidNum) = @_;
	my $dn = "cn=$cn,ou=Group,dc=lnx,dc=kmhp,dc=com";
	print "DN:$dn  CN:$cn NUM:$GidNum\n";
	my $result = $ldap->add($dn, 
    	attr => [ 'cn' => $cn,
                   'gidNumber' => $GidNum,
                   'objectclass' => [ 'posixGroup', 'top' ],
               ]
           );
    # result->code returns 0 on success
	$result->code && warn "failed to add entry: ", $result->error;
	return 1 if $result->code == 0;
}

# get DN of an object in the tree
sub getDN {
	my $cn = shift;
	my $dn;
	my $mesg = $ldap->search( filter=>"(cn=$cn)", base=>$base_dn);
	# i don't know how to flatten this, will need to RTFM more
	foreach my $entry ( $mesg->entries) {
		$dn = $entry->dn;
	}
	return $dn;
}
	
