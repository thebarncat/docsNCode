#!/usr/bin/perl -w

use strict;
use Net::LDAP;
use Net::LDAP::Util qw(ldap_error_text);

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
my $base_dn = "ou=Group,dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';


my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
$mesg->code && print "bind failed\n";

$mesg = $ldap->search( 
                        base   => $base_dn,
						scope  => 'sub',
                        #filter => "(&(gidNumber=10000) (objectClass=posixGroup))",  
                        filter => "(&(gidNumber=54331) (objectClass=posixGroup))",  
						#attrs  => [ qw(cn uidNumber) ] 
);

my @entries = $mesg->entries;
foreach my $entry (@entries) {
	print "DN:" . $entry->dn() . "\n";
	printf "CN:%s\n", $entry->get_value('cn');
	my @members = $entry->get_value('memberUid'); 
	print "$_\n" for @members;
}

