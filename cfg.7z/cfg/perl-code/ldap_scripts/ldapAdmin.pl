#!/usr/bin/perl -w

use strict;
use Net::LDAP;
use Net::LDAP::Util qw(ldap_error_text);
use Getopt::Std;
use Term::ReadKey;

my %opts;
getopts('u:U:radqG', \%opts);

system "stty erase ^H";

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
my $base_dn = "dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';
my $DN;
my $LS = "------------------------------------------------------------------------\n";

usage(), exit 1 unless($opts{u});

my $UID = lc($opts{u});
my $UidNum = `getent passwd $UID | awk -F: "{print \\\$3}"`;
chomp $UidNum;

my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
$mesg->code && die "bind failed\n";

# let check if user exists
$DN = getDN($UID);

if ($DN) {
	print "USER EXISTS:\n" if $DN;
	print "$DN\n\n";
	#getCNattrs($UID) if $opts{q};
	if ( $opts{q} ) { print "All info for user:\n"; getCNattrs($UID) }
	print $LS;
	my $groups = getUsrGrps($UID);
	print "User \"$UID\" is a member of these groups:\n";
	print "$_\n" for @{$groups};
} else {
	print "USER DOES NOT EXISTS\n";
	exit unless $opts{a};
    $UidNum = $opts{U} if $opts{U};
	print "\nAdding User: $UID\n";
    die "Can't query UIDNumber. RUN AGAIN  with \"-U <uidNumber>\"" unless $UidNum;
	my $rv = addUser($UID,$UidNum);
	print "User $UID Added\n" if $rv;
	$DN = getDN($UID);
	print "New Object DN: $DN\n";
}

print $LS;

# delete user 
if ($opts{d}) {
	die "couldn't get DN" unless $DN;
    # remove from groups before delete user
	my $groups = getUsrGrps($UID);
    my $grp_dn = "ou=Group,dc=lnx,dc=kmhp,dc=com";
    for my $grp (@{$groups}) {
		my $dn = "cn="."$grp,$grp_dn";
		$mesg = $ldap->modify($dn, delete => { 'memberUid' => $UID } );
		print "removed $UID from $grp\n";
    }
    deleteDN($DN); 
	print "\n$DN DELETED\n";
    print $LS;
	exit;
}

# add user to group(s)
if ($opts{G}) {
	print "GROUPS YOU CAN ADD:\n";
	my $groups = getGroups();
	for my $key ( sort { $a <=> $b }  keys %{$groups} ) {
		print "$key: $groups->{$key}\n"
	}
	print "\nChoose THE NUMBER for group to add:\n";
	my $selection;
	while ( $selection = <STDIN>) {
		chomp $selection;
		last if $selection =~ /no/i;
		if ($selection =~ /[0-9]+/) {
			my $group_dn = getDN($groups->{$selection});
			my $result = $ldap->modify($group_dn, add => { memberUid => $UID });
			$result->code && die "failed to modify group", $result->error;
			print "Added Group: $groups->{$selection}\n";
		}
		print "BAD CHOICE: \"$selection\". Try again\n" unless $selection =~ /[0-9]+/;
		print "choose another? Type \"no\" if no more groups to add\n";
	}
}

# close connection when all done
$mesg = $ldap->unbind;

# if $entry->exists('xx');
sub getNextUidNum {
	my $users_dn = "ou=Users,dc=lnx,dc=kmhp,dc=com";
	my $mesg = $ldap->search(base => $users_dn, filter => "(uidNumber=*)", attrs => [ 'uidNumber' ],);
	my @entries = $mesg->sorted('uidNumber');
	my $entry = pop @entries;
	my $nextNum = $entry->get_value('uidNumber');
	return ++$nextNum;
}

sub getUsrGrps {
	my $ID = shift;
	my @grplist;
	my $grp_dn = "ou=Group,dc=lnx,dc=kmhp,dc=com";
	my $mesg = $ldap->search(filter=>"(objectClass=posixGroup)", base=>$grp_dn, attrs=>[ qw(cn memberUid) ],);
	my @entries = $mesg->entries;
	foreach my $entry (@entries) {
        my $cn = $entry->get_value('cn');
        my @members = $entry->get_value('memberUid');
        push(@grplist,$cn) if grep /$ID/i,@members;
	}
	return \@grplist;
}

# DUMP attrs after done
sub addUser {
    # UidNum will match what is in AD, DO NOT  generate
	#my $UidNum = getNextUidNum();
	my($cn,$UidNum) = @_;
	my $dn = "uid=$cn,ou=Users,dc=lnx,dc=kmhp,dc=com";
	my $result = $ldap->add($dn, 
    	attr => [ 'cn' => $cn,
                  'sn' => $cn,
                  'uid' => $cn,
                  'uidNumber' => $UidNum,
                  'homeDirectory' => "/export/home/$cn",
                  'loginShell' => "/bin/bash",
                  'gecos' => $cn,
                  'gidNumber' => 10000,
				  'shadowMin' => 0,
                  'shadowMax' => 99999,
                  'shadowExpire' => 99999,
                  'shadowWarning' => 7,
                  'shadowLastChange' => 16086,
                  'mail' => "$cn\@amerihealthcaritas.com",
                  'objectclass' => [ 'posixAccount', 'top', 'inetOrgPerson', 'shadowAccount', 'person', 'organizationalPerson' ],
                  'userPassword' => "{SASL}$cn\@kmhp.com",
               ]
           );
    # result->code returns 0 on success
	$result->code && warn "failed to add entry: ", $result->error;
	return 1 if $result->code == 0;
}

# get DN of an object in the tree
sub getDN {
	my $cn = shift;
	my $dn;
	my $mesg = $ldap->search( filter=>"(cn=$cn)", base=>$base_dn);
	# i don't know how to flatten this, will need to RTFM more
	foreach my $entry ( $mesg->entries) {
		$dn = $entry->dn;
	}
	return $dn;
}

sub deleteDN {
	my $dn = shift;
	my $mesg = $ldap->delete($dn);
	$mesg->code && warn "delete object failed\n";
}
	
sub getCNattrs {
	my $cn = shift;
	my $mesg = $ldap->search( filter=>"(uid=$cn)", base=>$base_dn);
	my @entries = $mesg->entries;
	foreach my $entry (@entries) {
        $entry->dump;
        #print $entry->dn,"\n";
	}
}

# gets group CN name
sub getGroups {
	my $mesg = $ldap->search(base  => $base_dn, filter => "(objectClass=posixGroup)", attrs  => [ 'cn' ]);
	my @entries = $mesg->entries;
	my @names;
    foreach my $entry (@entries) {
		my $cn = $entry->get_value('cn');
		push(@names,$cn);
	}
	@names = sort @names;
	my %gnames = map { $_, $names[$_] } 0 .. $#names;
	return \%gnames;
}


sub usage {
	(my $prog = $0)  =~ s!^.*/!!;
print <<EOF;

usage: $prog  -u <UID> <options> 

       $prog -u  # prints ID and exits. must have -u or program exits
       $prog -u -q  # prints full query for user(UID) 
       $prog -u -a  [ -U ] #  add this user, if program cant find uidnum, must supply with -U 
       $prog -u -d  #  delete this user 
       $prog -u -G  #  add user to group(s)
       $prog -u -r  #  remove  user from group(s)

EOF
}


