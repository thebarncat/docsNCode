#!/usr/bin/perl -w

use strict;
use Net::LDAP;

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
my $base_dn = "dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';

# the object we are oging to modify
#my $dn = "CN=emcadm,OU=Unix Groups,OU=Ing Direct,DC=ingdirect,DC=com";
#my $dn = "cn=sysadmins,ou=Group,dc=lnx,dc=kmhp,dc=com";
my $dn = "cn=ldapuser,ou=Group,dc=lnx,dc=kmhp,dc=com";

my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
$mesg->code && print "bind failed\n";

# modify can be used with params add, delete, replace(change val of attrib)
#my $mesg = $ldap->modify($dn, add => { "unixGid" => "emcadm", "unixGidNumber" => "1013" });

# If you want to do a number of changes at once, modify also provides
# the changes parameter, which takes a list of add, delete and replace operations
#$mesg = $ldap->modify($dn, changes => [ add => [ employeeNumber => "4321" ], delete => [ mail => [] ] ] );
# single change on an attr that has multiple values
#$mesg = $ldap->modify($dn,  delete => { 'memberUid' => 'jk24445' } );
$mesg = $ldap->modify($dn,  delete => { 'memberUid' => 'br22714' } );
# code method returns the status code that the server returned. success
# returns 0,  a value of true usuaully means error
$mesg->code && die $mesg->error;
print "mod on $dn successful\n";

#my $result = $ldap->modify($group_dn, add => { memberUid => $UID });

