#!/usr/bin/perl -w

use strict;
use Net::LDAP;
use Net::LDAP::Util qw(ldap_error_text);

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
my $base_dn = "dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';


my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);
$mesg->code && print "bind failed\n";


# should probably change var to result for less confusion
$mesg = $ldap->search( 
                        base   => $base_dn,
						scope  => 'sub',
                        #filter => "(objectClass=person)",
                        #filter => "(uid=*)",
                        filter => "(objectClass=posixGroup)",
						attrs  => [ 'cn' ] 
);

my @entries = $mesg->entries;
foreach my $entry (@entries) {
	# in case you just want to get values of an attribute, as in dont specify attrs in the search or attrs=*
	# printf "UID %s\n", $entry->get_value('uid');
    my @attrs = $entry->attributes();
	foreach my $attr (@attrs) {
		#printf("%s: %s", $attr, $entry->get_value($attr));
		printf("%s", $entry->get_value($attr));
    }
	print "\n";
}

# get count of objects
printf "\ncount %s\n", $mesg->count;
