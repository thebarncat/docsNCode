#!/usr/bin/perl -w

use Net::LDAP;

my $server = "phlprlxldap011";
my $domain = "kmhp.com";
#my $base_dn = "dc=lnx,dc=kmhp,dc=com";
my $base_dn = "ou=Group,dc=lnx,dc=kmhp,dc=com";
my $user = 'Manager';
my $pw = 'Slapd#Manager1';

my $ldap = Net::LDAP->new($server, timeout=>30) or die "$@";
my $mesg = $ldap->bind("CN=Manager,dc=lnx,dc=kmhp,dc=com", password => $pw, version => 3);

$mesg = $ldap->search(filter=>"(objectClass=posixGroup)", base=>"$base_dn", attrs=>[ qw(cn memberUid) ],);

# for attributes with multiple entries (memberUid) will only grab first one because  context
#my $ID = 'pmann';
my $ID = $ARGV[0];
my @grplist;
@entries = $mesg->entries;
foreach $entry (@entries) {
		my $cn = $entry->get_value('cn');
		my @members = $entry->get_value('memberUid');
		push(@grplist,$cn) if grep /$ID/,@members;
}
print "User \"$ID\" is a member of these groups:\n";
print "$_\n" for @grplist;

