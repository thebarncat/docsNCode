#!/usr/bin/perl  
# FILE: "G:\CODE\Perl\FUN2.pl"
# LAST MODIFICATION: "Mon, 23 Oct 2006 07:57:41 Eastern Daylight Time"
# (C) 2004 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$


# the regex with map breaks the string of digits into chunks
# of 3 digit strings than chr converts each chunk into an ascii char
print map( { chr } 
           ('106117115116032097110111116104101'.
			   '114032112101114108032104097099107101114') 
           =~ /.../g
         ), "\n";


