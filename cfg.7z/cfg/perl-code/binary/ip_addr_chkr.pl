#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/binary/ip_addr_chkr.pl"
# LAST MODIFICATION: "Thu, 09 May 2013 12:39:18 -0400 (jkipp)"
# $Id:$

use strict;
use Socket;

my $file = <<FILE;
58.253.0.0/16;
58.254.0.0/16;
58.255.0.0/16;
60.0.0.0/16;
60.1.0.0/16;
60.10.0.0/16;
60.16.0.0/16;
60.17.0.0/16;
60.18.0.0/16;
60.19.0.0/16;
60.2.0.0/16;
60.20.0.0/16;
60.21.0.0/16;
60.22.0.0/16;
60.23.0.0/16;
60.3.0.0/16;
FILE

open my $fh, "<", \$file or die "Cannot open $file: $!";

my @ips;
while  ( <$fh> ) {
	next unless /^(\d+\.\d+\.\d+\.\d+)\/(\d+)/;
	# sets mask to 32 bit (4 octets) string of nuls
    my $mask = "\0\0\0\0";
	# THE FOR LOOP FLIPS THE FIRST 15 bits
	# SETTING THE MASK TO 255.255.0.0 (16 MASK BITS)
    vec($mask, $_, 1) = 1 for 0 .. ( 31 - $2 );
	# the line above is the same as doing this:
	# vec( $mask,0, 8 ) = 255; # sets first octet(byte) to 255 
	# vec( $mask,1, 8 ) = 255; # sets second octet(byte) to 255 
	# push the binary ip addr and mask onto arry of hashes
    push @ips, { ip => inet_aton($1), mask => $mask };
}

for my $ip ( qw/ 59.32.232.33 60.19.232.33 / ) {
    for my $cmp (@ips) {
		# AND off the host portion of the ip and compare the result to the IP from the file 
        if ( ( inet_aton($ip) & $cmp->{mask} ) eq $cmp->{ip} ) {
            print "$ip exists in file\n"
            }
        }
}


