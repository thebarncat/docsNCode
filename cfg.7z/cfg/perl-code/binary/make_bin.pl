#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/binary/make_bin.pl"
# LAST MODIFICATION: "Thu, 09 May 2013 12:48:18 -0400 (jkipp)"
# $Id:$

# this program works with read_bin

# open rw and no clobber
open(ZZ,"+>zz") or die "Can't open zz: $!";
binmode ZZ;

for(0..19){
	$array[$_]= 2 * $_;
	print "$array[$_] ";
	# pack the data into unsinged long binary 
	$array1[$_]= pack ("L*",$array[$_]);
	# could also use:
	# $array1[$_] = sprintf("%b",$array[$_]);
	print ZZ $array1[$_];
}

close ZZ;
exit 0;

