#!/usr/bin/perl -w
# FILE: "/home/jkipp/perl-code/binary/read_bin.pl"
# LAST MODIFICATION: "Thu, 09 May 2013 12:47:49 -0400 (jkipp)"
# $Id:$
use strict;
use warnings;

# this program works with make_bin

# $/ is the rec sep variable, this is set to slurp the whole file
$/='undef';
open (ZZ, "<zz") or die $!;
binmode ZZ;
my $file=(<ZZ>); 
# unpack the binary file to regular
my @nums = (unpack "L*",$file);
print "@nums\n";

close ZZ;

