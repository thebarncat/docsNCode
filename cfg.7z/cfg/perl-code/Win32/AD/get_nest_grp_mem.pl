#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_nest_grp_mem.pl"
# LAST MODIFICATION: "Wed, 18 Apr 2007 09:59:36 Eastern Daylight Time"
# (C) 2007 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

#  prints the nested membership of a group.

# ------ SCRIPT CONFIGURATION ------
my $strGroupDN = "CN=unixgrp1,OU=UNIX-Grps,OU=UNIX-Access,DC=ingqa,DC=com";  
# ------ END CONFIGURATION ---------
use Win32::OLE 'in';
$Win32::OLE::Warn = 3;
$strSpaces  = " ";
my %dicSeenGroupMember;
print "Members of " . $strGroupDN . ":\n";
DisplayMembers("LDAP://" . $strGroupDN, $strSpaces, %dicSeenGroupMember);

sub DisplayMembers {
my ($strGroupADsPath, $strSpaces, %dicSeenGroupMember) = @_;

   my $objGroup = Win32::OLE->GetObject($strGroupADsPath);
   foreach my $objMember (in $objGroup->Members) {
      print $strSpaces,$objMember->Name,"\n";
      if ($objMember->Class eq "group") {
         if ($dicSeenGroupMember{$objMember->ADsPath}) {
            print $strSpaces, "   ^ already seen group member (stopping to avoid loop)\n";
         }
         else {
            $dicSeenGroupMember{$objMember->ADsPath} = 1;
            DisplayMembers($objMember->ADsPath, $strSpaces . " ", %dicSeenGroupMember);
         }
      }
   }

}


