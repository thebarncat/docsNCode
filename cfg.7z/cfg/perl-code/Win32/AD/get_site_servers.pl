#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_site_servers.pl"
# LAST MODIFICATION: "Wed, 18 Apr 2007 10:56:58 Eastern Daylight Time"
# (C) 2007 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

# lists the server objects in the site topology.   

use Win32::OLE;
$Win32::OLE::Warn = 3;
my $objRootDSE = Win32::OLE->GetObject("LDAP://RootDSE");
my $strBase    =  "<LDAP://cn=sites," .
              $objRootDSE->Get("ConfigurationNamingContext") . ">;";
my $strFilter  = "(objectcategory=server);" ;
my $strAttrs   = "distinguishedName;";
my $strScope   = "subtree";

my $objConn = Win32::OLE->CreateObject("ADODB.Connection");
$objConn->{Provider} = "ADsDSOObject";
$objConn->Open;
my $objRS = $objConn->Execute($strBase . $strFilter . $strAttrs . $strScope);
$objRS->MoveFirst;
while (not $objRS->EOF) {
    print $objRS->Fields(0)->Value,"\n";
    $objRS->MoveNext;
}

