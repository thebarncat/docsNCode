#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\query_ad.pl"
# LAST MODIFICATION: "Mon, 16 Apr 2007 16:57:58 Eastern Daylight Time"
# (C) 2003 by Jim Kipp, <james.kipp@mbna.com

use strict;
use Data::Dumper;
use Win32::OLE;

sub enumerateServers {
	my $ad_conn = Win32::OLE->new("ADODB.Connection");
	my $ad_recs = Win32::OLE->new('ADODB.Recordset');
        my $rootDSE = Win32::OLE->GetObject("LDAP://rootDSE");
        my $strADsPath = shift @_ || $rootDSE->Get("DefaultNamingContext");
	my $query = "LDAP://$strADsPath";
	my @computer_list;
	# ----
	my $userid = "domain\\account"; #Change account name to match a user account on your domain
	my $passwd = "password";        #Change account password to match a user account on your domain
	# ----
	$ad_conn->{Provider} = ("ADsDSOObject");
	$ad_conn->{ConnectionString} = "Active Directory Provider";
	$ad_conn->Properties('User ID')->{Value} = $userid;
	$ad_conn->Properties('Password')->{Value} = $passwd;
	$ad_conn->Open;
	$ad_recs = $ad_conn->Execute("
		SELECT Name, userAccountControl
		FROM '$query'
		WHERE objectClass='computer'
        ");
        while (! $ad_recs->EOF) {
	    if ( ($ad_recs->Fields("userAccountControl")->Value & 2) != 2 ) {
		#if bit 2 is on in userAccountControl, then the account is disabled.
		#We only want enabled accounts.
		push @computer_list, uc($ad_recs->Fields("Name")->Value);
	    }
            $ad_recs->MoveNext;
        }
    	@computer_list;
}




print Dumper &enumerateServers();


