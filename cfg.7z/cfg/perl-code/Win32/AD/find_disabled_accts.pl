#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\find_disabled_accts.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:13:08 Eastern Daylight Time"
# (C) 2005 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

#finds all disabled user accounts  

my $strBase   =  "<LDAP://cn=users,dc=rallencorp,dc=com>;";
my $strFilter = "(&(objectclass=user)(objectcategory=person)" . 
                "(useraccountcontrol:1.2.840.113556.1.4.803:=514));";
my $strAttrs  = "name;";
my $strScope  = "subtree";

use Win32::OLE;
$Win32::OLE::Warn = 3;
my $objConn = Win32::OLE->CreateObject("ADODB.Connection");
$objConn->{Provider} = "ADsDSOObject";
$objConn->Open;
my $objRS = $objConn->Execute($strBase . $strFilter . $strAttrs . $strScope);
$objRS->MoveFirst;
while (not $objRS->EOF) {
    print $objRS->Fields(0)->Value,"\n";
    $objRS->MoveNext;
}

