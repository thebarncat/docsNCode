#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_subnets.pl"
# LAST MODIFICATION: "Thu, 19 Apr 2007 08:35:11 Eastern Daylight Time"
# (C) 2007 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

# This Perl code lists all the subnets stored in Active Directory.

use Win32::OLE 'in';
$Win32::OLE::Warn = 3;
my $objRootDSE = Win32::OLE->GetObject("LDAP://RootDSE");
my $objSubnetsCont = Win32::OLE->GetObject("LDAP://cn=subnets,cn=sites," .
                         $objRootDSE->Get("configurationNamingContext") );
$objSubnetsCont->{Filter} = ["subnet"];
foreach my $objSubnet (in $objSubnetsCont) {
   print "  ", $objSubnet->Get("cn"),"\n";
}


