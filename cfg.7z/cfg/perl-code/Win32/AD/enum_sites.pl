#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\enum_sites.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:12:50 Eastern Daylight Time"
# $Id:$

use OLE;
use Win32;

my $strServer		= 'apps.test.ditec.sk';
my $strDomain		= 'dc=test,dc=ditec,dc=sk';
my $strAdminName	= 'administrator';
my $strAdminPwd	= 'xxxxxxxxxx';

sub EnumSites{
	my ($strServer, $strDomain,
		$strAdminName, $strAdminPwd) = @_;
	my $adsiNameSpaces = CreateObject OLE 'ADsNameSpaces' or warn "Couldn't create new instance of the
ADSI Name Spaces Check your registry for ADsNameSpaces key under classes!!";
	PrintError( 'ADsNameSpaces');
	my $ldapNameSpace = $adsiNameSpaces->getobject( "", "LDAP:");
	PrintError( 'LDAP Provider');

	my $sitesObject = $ldapNameSpace->OpenDSObject( "LDAP://" .
$strServer . "/CN=Sites,CN=Configuration," . $strDomain, "cn=" .
$strAdminName . ",cn=users," . $strDomain, $strAdminPwd, 1);
	&PrintError( 'binding to Sites object');

	foreach (keys %$sitesObject){
		next if ($_->Name eq 'CN=Inter-Site Transports');
		next if ($_->Name eq 'CN=Subnets');
		print $_->Name . "\n";	
	}
}

sub PrintError{
	my $errNum = Win32::OLELastError;
	if ($errNum != 0){
		print "OLE Error for $_[0]: ", Win32::FormatMessage( $errNum);
	}else{
#		print "OLE Success for $_[0]\n";
	}
	return $errNum;
}

&EnumSites( $strServer, $strDomain, $strAdminName, $strAdminPwd);


