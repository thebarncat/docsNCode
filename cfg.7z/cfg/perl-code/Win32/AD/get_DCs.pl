#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_DCs.pl"
# LAST MODIFICATION: "Mon, 16 Apr 2007 16:46:16 Eastern Daylight Time"
# (C) 2005 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

# get domain controllers for the specified domain

my $strDomain = "ingdirect.com";  
#my $strDomain = "INGDE";  

use Win32::OLE 'in';
$Win32::OLE::Warn = 3;
my $objRootDSE = Win32::OLE->GetObject("LDAP://$strDomain/RootDSE");
my $objDomain = Win32::OLE->GetObject("LDAP://" . $objRootDSE->Get("defaultNamingContext"));
my $strMasteredBy = $objDomain->GetEx("masteredBy");
foreach my $strNTDSDN (in $strMasteredBy) {
   my $objNTDS = Win32::OLE->GetObject("LDAP://" . $strNTDSDN);
   my $objServer = Win32::OLE->GetObject($objNTDS->Parent);
   print $objServer->Get("dNSHostName"),"\n";
}

