#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_grp_members.pl"
# LAST MODIFICATION: "Wed, 18 Apr 2007 09:17:27 Eastern Daylight Time"
# (C) 2007 by Jim Kipp, <jkipp5@comcast.net>
# $Id:$

# This Perl code prints the direct members of the specified group.

# ------ SCRIPT CONFIGURATION ------
my $strGroupDN = "CN=unixgrp1,OU=UNIX-Grps,OU=UNIX-Access,DC=ingqa,DC=com"; 
# ------ END CONFIGURATION ---------
use Win32::OLE 'in';
$Win32::OLE::Warn = 3;
my $objGroup = Win32::OLE->GetObject("LDAP://" . $strGroupDN);
print "Members of ", $objGroup->Name . ":\n";
foreach my $objMember (in $objGroup->Members) {
   print $objMember->Name,"\n";
}


