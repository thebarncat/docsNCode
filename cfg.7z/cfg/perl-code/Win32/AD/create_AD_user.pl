#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\create_AD_user"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:10:18 Eastern Daylight Time"
# $Id:$

use Win32::OLE;
my $OU = Win32::OLE->GetObject('LDAP://OU=someOU,DC=someDC,DC=someDC'); 
my $user = $OU->Create("User", "cn=testuser ");
if ($user) {
		$user->{sAMAccountName} = "testuser";
		#$objUser->Put("sAMAccountName", "jsmith"); # mandatory attribute
		$user->SetInfo();
  		if (!Win32::OLE->LastError()) {
 			print "testuser Create: " . Win32::OLE->LastError();
			$user->{Sn} = $NUserln;
			$user->{GivenName} = $NUserfn;
			$user->{displayName} = "$NUserln, $NUserfn";
			$user->{mail} = $userPrincipal;
			$user->{userPrincipalName} = $userPrincipal;
			$user->{description} = $description;
			$user->{homeDirectory} = $homepath;
			$user->{homeDrive} = $homedrv;
			$user->{scriptPath} = $script;
			$user->{title} = $title;
			$user->{company} = $company;
			$user->{department} = $department;
			$user->{manager} = $manager;
			$user->{userWorkstations} = ($logonWS);
			$user->{msNPAllowDialin} = $dialin;
   			$user->SetInfo();
 			print "$NUserName Properties Set: " .  Win32::OLE->LastError();
	  }
}


