#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_DC_site.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:14:30 Eastern Daylight Time"
# $Id:$

# code prints the site (ie city, country) the specified DC is in

# ------ SCRIPT CONFIGURATION ------
my $strDC = "ingdedc01";  # e.g. dc1.rallencorp.com
# ------ END CONFIGURATION ---------
use Win32::OLE;
$Win32::OLE::Warn = 3;
my $objRootDSE = Win32::OLE->GetObject("LDAP://" . $strDC . "/RootDSE");
my $objNTDS = Win32::OLE->GetObject("LDAP://" . $objRootDSE->Get("dsServiceName"));
my $objSite = Win32::OLE->GetObject(
                          Win32::OLE->GetObject(
                             Win32::OLE->GetObject(
                                 $objNTDS->Parent)->Parent)->Parent);
print $objSite->Get("cn"),"\n";


