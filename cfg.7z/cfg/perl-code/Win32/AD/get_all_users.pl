#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_all_users.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:13:36 Eastern Daylight Time"
# $Id:$

# This Perl code finds all user accounts in a domain.

# ------ SCRIPT CONFIGURATION ------
my $strDomainDN = "dc=ingdirect,dc=com";    # e.g. dc=rallencorp,dc=com
# ------ END CONFIGURATION ---------
use Win32::OLE;
$Win32::OLE::Warn = 3;
my $strBase   =  "<LDAP://" . $strDomainDN . ">;";
# To search the whole forest using the global catalog, uncomment the following line:
# $strBase   =  "<GC://" . $strDomainDN . ">;";

my $strFilter = "(&(objectclass=user)(objectcategory=person));";
my $strAttrs  = "name;";
my $strScope  = "subtree";

my $objConn = Win32::OLE->CreateObject("ADODB.Connection");
$objConn->{Provider} = "ADsDSOObject";
$objConn->Open;
my $objRS = $objConn->Execute($strBase . $strFilter . $strAttrs . $strScope);
$objRS->MoveFirst;
while (not $objRS->EOF) {
    print $objRS->Fields(0)->Value,"\n";
    $objRS->MoveNext;
}


