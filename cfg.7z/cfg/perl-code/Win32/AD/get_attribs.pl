#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\get_attribs.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:14:15 Eastern Daylight Time"
# $Id:$

# This Perl code prints all attributes for the specified $object.

# ------ SCRIPT CONFIGURATION ------
my $strObjectDN = "CN=kipp,OU=IT Associates,OU=IT,OU=Wilmington,OU=Ing Direct,DC=ingdirect,DC=com"; 
# ------ END CONFIGURATION ---------
use Win32::OLE 'in';
$Win32::OLE::Warn = 3;
DisplayAttributes("LDAP://$strObjectDN");

sub DisplayAttributes {
my $strObjectADsPath = $_[0];

   my $objObject = Win32::OLE->GetObject($strObjectADsPath);
   $objObject->GetInfo;

   #Declare the hash (dictionary), constants and variables
   #Values taken from $ADSTYPEENUM
   my %dicADsType;
   $dicADsType{0} = "INVALID";
   $dicADsType{1} = "DN_STRING";
   $dicADsType{2} = "CASE_EXACT_STRING";
   $dicADsType{3} = "CASE_IGNORE_STRING";
   $dicADsType{4} = "PRINTABLE_STRING";
   $dicADsType{5} = "NUMERIC_STRING";
   $dicADsType{6} = "BOOLEAN";
   $dicADsType{7} = "INTEGER";
   $dicADsType{8} = "OCTET_STRING";
   $dicADsType{9} = "UTC_TIME";
   $dicADsType{10} = "LARGE_INTEGER";
   $dicADsType{11} = "PROV_SPECIFIC";
   $dicADsType{12} = "OBJECT_CLASS";
   $dicADsType{13} = "CASEIGNORE_LIST";
   $dicADsType{14} = "OCTET_LIST";
   $dicADsType{15} = "PATH";
   $dicADsType{16} = "POSTALADDRESS";
   $dicADsType{17} = "TIMESTAMP";
   $dicADsType{18} = "BACKLINK";
   $dicADsType{19} = "TYPEDNAME";
   $dicADsType{20} = "HOLD";
   $dicADsType{21} = "NETADDRESS";
   $dicADsType{22} = "REPLICAPOINTER";
   $dicADsType{23} = "FAXNUMBER";
   $dicADsType{24} = "EMAIL";
   $dicADsType{25} = "NT_SECURITY_DESCRIPTOR";
   $dicADsType{26} = "UNKNOWN";
   $dicADsType{27} = "DN_WITH_BINARY";
   $dicADsType{28} = "DN_WITH_STRING";

   foreach my $intIndex (0 .. $objObject->PropertyCount - 1 ) {
      my $objPropEntry = $objObject->Item($intIndex);
      foreach my $objPropValue (in $objPropEntry->Values) {
         my $value = "";  

         if ($dicADsType{$objPropValue->ADsType} eq "DN_STRING") {
            $value = $objPropValue->DNString;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "CASE_EXACT_STRING") {
            $value = $objPropValue->CaseExactString;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "CASE_IGNORE_STRING") {
            $value = $objPropValue->CaseIgnoreString;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "PRINTABLE_STRING") {
            $value = $objPropValue->PrintableString;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "NUMERIC_STRING") {
            $value = $objPropValue->NumericString;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "BOOLEAN") {
            $value = $objPropValue->Boolean;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "INTEGER") {
            $value = $objPropValue->Integer;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "LARGE_INTEGER") {
            my $objLargeInt = $objPropValue->LargeInteger;
            $value = $objLargeInt->HighPart * 2^32 + $objLargeInt->LowPart;
         }
         elsif ($dicADsType{$objPropValue->ADsType} eq "UTC_TIME") {
            $value = $objPropValue->UTCTime;
         }
         else {
            $value = "<" . $dicADsType{$objPropEntry->ADsType} . ">";
         }
         print $objPropEntry->Name," : $value\n";
      }
   }
}



