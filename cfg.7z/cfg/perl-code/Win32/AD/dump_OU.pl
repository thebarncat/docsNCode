#!/usr/bin/perl -w
# FILE: "G:\CODE\Perl\Win32\AD\dump_OU.pl"
# LAST MODIFICATION: "Fri, 02 Oct 2009 16:12:35 Eastern Daylight Time"

use Win32::OLE;

my $SERVER = 'ingmnqadc1';

my	$adscon = Win32::OLE->new('ADODB.Connection');
	$adscon->{Provider} = 'ADsDSOObject';
	$adscon->{Properties}->Item('ADSI Flag')->{Value} = 517;
	$adscon->Open('Active Directory Provider','domain\user','password');

my	$Searcher = Win32::OLE->new('ADODB.Command');
	$Searcher->{ActiveConnection} = $adscon;
	$Searcher->{Properties}->Item('Page Size')->{Value} = 500;
	$Searcher->{Properties}->Item('Cache Results')->{Value} = 0;
	$Searcher->{Properties}->Item('Asynchronous')->{Value} = 1;
	$Searcher->{CommandText} =	
	#"SELECT cn FROM 'LDAP://$SERVER/dc=company,dc=domain,dc=com' ".
		"SELECT cn FROM 'LDAP://$SERVER/dc=ingqa,dc=com' ".
		"WHERE objectClass = 'OrganizationalUnit' ";

my	$recordset = $Searcher->Execute();

while (! $recordset->{EOF}) {
	## Deal with recordset here
	$recordset->MoveNext();
}

