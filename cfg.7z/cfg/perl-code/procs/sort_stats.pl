#!/appl1/perl/bin/perl

use Proc::ProcessTable;
 
$t = new Proc::ProcessTable;
 
@sizes = map { [$_->cmndline, $_->size] } 
              @{$t->table};
 
$count = 20;    
 
foreach $rec (sort { $b->[1] <=> $a->[1] } @sizes) {
     printf "%11s %s\n", commify($rec->[1]), 
     $rec->[0];
     last unless --$count;
 }
 
sub commify {    
     my $number = shift;
     while($number =~ s/(\d)(\d{3})\b/\1,\2/) { }
     return $number;
 }

