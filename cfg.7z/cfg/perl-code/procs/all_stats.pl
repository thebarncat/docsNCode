#!/appl1/perl/bin/perl
# collect stats on running processes

use Proc::ProcessTable;

$t = new Proc::ProcessTable;

foreach $proc ( @{$t->table} ){
     #printf "%5d %8d %4.2f %4.2f %s\n",

     $n = $proc->fname;
     $c = $proc->pctcpu;
     $m = $proc->pctmem;
     
     print "$n\t$c\t$m\n";
 }

