#!/appl1/perl/bin/perl

# list programs spawning the most processes in descending order

use Proc::ProcessTable;
$tobj = new Proc::ProcessTable; # create new process object

collectstats();
dumpstats(); 

# collect the process statistics
sub collectstats 
{
    my($p);
    foreach $p (@{$tobj->table}) {
        # ignore this process
        next if ($p->pid() == $$);
        # ignore this process if was in last iteration
        next if ($last{$p->pid()} eq $p->fname());
        # else remember  and add to count
        $collection{$p->fname()}++;
    }
}

# dump out the results 
sub dumpstats 
{
    print scalar localtime(time).("-"x50)."\n";
    for (sort reverse_value_sort keys %collection){
        write;
    }

}

# reverse sort by values in %collection and by key name
sub reverse_value_sort
{
    return $collection{$b} <=> $collection{$a} || $a cmp $b;
}

format STDOUT =
@<<<<<<<<<<<<<  @>>>>
$_,             $collection{$_}
.

format STDOUT_TOP =
Name            Count
--------------  -----
.
