#!/appl1/perl/bin/perl 

# FILE: stats.pl
# Modification: Tue Feb 11 16:37:14 EST 2003
# Jim Kipp <james.kipp@mbna.com>

# Modification: Mon Oct 13 09:41:46 EDT 2003
# Jim Kipp <james.kipp@mbna.com>
# HP Conversion: check HP 'uname' and 'ps' commands

# RUN AS DBMSYS
use strict;

BEGIN{
$ENV{ORACLE_HOME} = "/db/app/oracle/product/9.2.0";
$ENV{UNIX95} = "yes";
}

use DBI;

chop (my $host = `uname -n`);
# my $user = qw(ops$jkipp);

(my $time = localtime) =~ s/.*?(\d{2}:\d{2}).*/$1/;
(my $hour = localtime) =~ s/.*?(\d{2}):\d{2}.*/$1/;

my ($stats, $loads) = get_stats();
my $dbh = DBI->connect("dbi:Oracle:middev", 'ops$jkipp', "diamond") 
	or (warn "can't connect: $DBI::errstr\n"  &&  exit(0) );

my $sth = $dbh->prepare( "INSERT INTO uptime VALUES (SYSDATE,?,?,?,?,?,?)" )
         or (warn "can not prepare statement: $DBI::errstr\n" && exit(0) );

my $sth2 = $dbh->prepare( "INSERT INTO stats VALUES (SYSDATE,?,?,?,?,?,?,?)" )
         or (warn "can not prepare statement: $DBI::errstr\n" && exit(0) );

if ( sprintf("%3.2f",$loads->[2]) > 0.60 ) {
	$sth->execute($time, $hour, $host, $loads->[0], $loads->[1], $loads->[2]);   
}

for my $row (@$stats) {               
	if ( sprintf("%2.1f",$row->[1]) > 90.0 || ($row->[2] > 102400) ) { # user, cpu%, vmem, args
		$sth2->execute($time, $hour, $host, $row->[0], $row->[1], $row->[2], $row->[3] );
	}
}


sub get_stats {

        my (@stats,@totals,@loads);
        my $ps = '/usr/bin/ps -eo user,pcpu,vsz,args';

        open (PIPE, "$ps|") or die "could not pipe command: $!";
        while (<PIPE>) {
			chomp;
        	next if /USER/; # skip header
        	# next if  /0.0\s+0.0/; # skip idle procs
        	next if  /0\.0/; # skip idle procs
			next if (/^\s*$/);  # skip blank lines
			s/^\s+//; #strip white space from front
            my @tmp = split(/\s+/, $_, 4);
            push (@stats, [ @tmp ]);
        }
        close PIPE;

        my $loads = `/usr/bin/uptime`;
        chomp $loads;
        if ($loads  =~ /(\d{1,2}\.\d{2}), \s+(\d{1,2}\.\d{2}), \s+(\d{1,2}\.\d{2})/gx ) {
                @loads = ($1, $2, $3);
        }

        return (\@stats, \@loads);

}

