#!/usr/bin/perl -w
use strict;

# psTree.txt-  testing the odd idea - what IF we built at least one
#               if not two trees to hand back.....
#
sub getPidsOfPPid {
    my ($pid, @ps_data) = @_;
    return() unless($pid);
    
    ( @ps_data ) = getChildrenOfPid($pid, @ps_data);
    
    my @returnArray;
    for (@ps_data) {
        /^\s*\w+\s*(\d+)\s*$pid/;
        push(@returnArray, $1);
    }
    
   (@returnArray);
    
} # end of getPidsOfPPid

#------------------------
# generate a tree of the process data as it comes through....
        #
        # we expect that the $ppid will always occur after the $pid but...
        #
=cut

wetware: 52:] pag 15930
    root 15931 15930  0 13:50:54 ?        0:00 /usr/lib/sendmail -bd -q10m
    root 15930 27125  0 13:50:54 ?        0:00 /usr/lib/sendmail -bd -q10m
  drieux 15953 15938  0 13:52:30 pts/4    0:00 egrep 15930
wetware: 53:]

Ah FreMonge - who ownes pid 0 ???
pid: 0 is owned by UNK and has children:
	 1 2  

=cut

sub getProcessTree {
	# my ($psArg) = @_;
    my $psArg = '-eo user,pcpu,pmem,vsz,comm'; 
    
    my %psTree;
    
    my %userData;

    open(PS, "ps $psArg |" ) or die "no grovel ps data:$!\n";
    my $headerLine = <PS> ; # the first line is header junk
                            # this is a dangerous spot....
    
    while(<PS> ) {
        chomp;
        /^\s*(\w+)\s*(\d+)\s*(\d+)\s*(\S+)/;
        my $username = $1 ;
        my $pid = $2 ;
        my $ppid = $3;
        my $cmd = $4;
        
        die "bad ps data\n" unless($pid);
        #
        # accumulate the user specific pids
        #
        $userData{$username} .= "$pid ";
        

 
        if ( exists( $psTree{ $ppid } )) {
            # our parent already exists
            $psTree{ $ppid }->{'children'} .= "$pid ";
        } else {
            
            $psTree{ $ppid } = {
                'user' => 'UNK' ,
                'cmd' => 'UNK' ,
                'children' => "$pid ",
            };
        }
        
        #
        # if we set the pid because the ppid occured first
        #
        if ( exists( $psTree{ $pid }->{children} ) ){
            $psTree{ $pid }->{'user'} = $username;
            $psTree{ $pid }->{'cmd'} = $cmd ;
        } else {
            $psTree{ $pid } = {
                'user' => $username ,
                'cmd' => $cmd ,
                'children' => "",
            };
        }

    }
    chomp( my @psArray =<PS> ) ;
    close(PS);
    
    return(\%userData , \%psTree);
    
} # end of getProcessTree


#-----------------------
# The main loop here 


my ($userHashRef , $psTreeRef ) = getProcessTree;


=cut

while ( my ( $key, $val) = each %{$userHashRef}) {
    print "User :$key: is running pids\n\t $val\n";
}


=cut

while ( my ( $key, $val) = each %{$psTreeRef}) {
    my $children = $val->{'children'};
    my $user = $val->{'user'};
    my $cmd = $val->{'cmd'};
    print "pid: $key is owned by $user running $cmd ";

    if ($children)  {
        print "spawned children:\n\t $children \n";
    }else{
        print  "\n";
    }
}

# end of the world as I knew it drieux@wetware.com all rights reserved
# ginned On 9-May-02
#


